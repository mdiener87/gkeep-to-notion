# Sesion 19 - Freedom of Flight

    **Created:** 2022-12-15 19:56:14  
    **Last Edited:** 2024-11-14 16:58:30  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

Players are going to finish the Chipahua arc today. There is the Gith Monk they have faced earlier waiting in the temple. At the bottom lies a religious draconic artifact that the cult, and the people of Chipahua, find holy in nature.

Gameplay Notes 12/15/2022

The cult is interested in the church of the dragon not just for propoganda or morale reasons, but for a practical reason as well: Kaladan, before his death, entrusted a magical artificat to the Church of the Dragon: The Heart of the Dragon. It served as a conduit of sorts between Kaladan's energy and his loyal cult followers. Its exact location, and powers, are unknown. 

Quintus failed a dispell magic check on the teleporation circle. This led to Quintus and Zephyr trying to smudge out the circle and short circuit it physically. Unfortunatley, they accidentally activated the teleportation circle while trying to smudge it out instead. Quintus easily jumped back and prevented himself from falling into this magic. Zephyr, however, did not. In a blinding flash of light, Zephyr was gone.

Dorc, never one to leave a friend behind, performed an amazing performance check and litterally danced his way into activating the teleporation circle. Cardar tried to intervene, but Dorc succesffully intimidated the Dragon Cultist into backing down. With another flash of light, Dorc too was gone.

This left Quintus and Kipla to finish the mission. They succesffully snuck past another Gith Monster using invisibility, and found themsleves in the basement. They would go on to use Ila the Handsome to defeat the monster, and also discover the hiding place of the Heart of the Dragon.




Additional items found in the cellar:
spell scroll - sleep
2x healing potions


Additional Charachter Details:
ila knows polymorph

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
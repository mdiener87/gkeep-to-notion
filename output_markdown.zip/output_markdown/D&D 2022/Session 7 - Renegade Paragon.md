# Session 7 - Renegade Paragon

    **Created:** 2022-07-07 18:50:13  
    **Last Edited:** 2024-11-14 17:08:41  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The party has passed the initiation of the Dragon Cult. Equipped with their ceremonial robes and daggers, they now follow their cult initiation to meet Ares Shadowblade. This Kobold cultist will marshal the players for an assault on Black Scar Garrison. If BSG falls, the cult will be able to Isolate Borrend and exert greater pressure on the Kingdom.

How will the players react?

====

Gith LodeStone - Somewhere in Selevarum. If destroyed, the Gith Arcane Portal will collapse.

Warrior 1 - Warren Callahan (3mo cultist) (naive, young man voice)
Warrior 2 -= Don Anthony (over 12mos) (slow, quiet, deep voice)
Cult Initiate Leader - August Harris (unk mos) (normal voice)

Shadow Marble - 5 times per day, can be used as per the Sending spell to communicate with another who holds a Shadow Marble that you are familiar. These charges refresh at midnight.


Ares Shadowblade- kinda high pitched, nasally, talk quickly, excitable
As Drow Shadowblade 

=====
Missing notes from N++:
Commander Tristan

In the prior timeline, was in charge of the Garrison. He was pushing for open conflic with Borrend after several of his men were injurred or killed by Borrend Aggression.

In this timeline, Commander Tristan once again leads an outpost under siege. Borrend is now a close alley, but the Garrison is now amongst the most exposed Norther points. The Dragon Cult, Orcs, and the occasional Gith Cutter all make occasional attacks. 

===


The dragon cult would like to seize this Garrison. The party has proven to be powerful allies. Ares Shadowblade will propose a coordinated attack on the Garrison. Ares will lead a stealth mission in through the back of the Garrison, while the party mounts a frontal assault on the doors. 



=====

Gameplay Notes 7/7/22

The party started the session following the Cult Leader August, and his warriors, Warren and Don, deeper into the mountains. There was some RP discussion with these cultists about the cult. The party then arrived at a clearing, with two other groups of cultists, and the entire assembly led by Ares Shadowblade.

Ares excitedly had the players introduce themselves, and welcomed them to the Cult. He gave them their first mission - to attack and claim Black Scar Garrison, led by a Commander Tristan. The Party's mission was to lead a frontal assault against the base, while Ares led an assassination attack through the back gates.

Zephyr proposed a different plan. The party would sneak into the keep, posing as normal citizens, and get better intel about the keep. They did not yet have the shadow magic of the cult obviously infused into their bodies, and so could pass as normal. This persuasion worked, and August gave the party a Shadow Marble with which they could communicate any intel gained.

Ares separately talked with Kipla. He offered her a higher percentage on light of her being a fellow kobold. Kipla gave him the rotting remains of one of the fish she carried, which Ares gleefully slurped down. Ares quickly grew fond of Kipla, and offered her a second, hidden Shadow Marble. He did not trust the look of the rest of the party and wished her to alert him to any treachery.

The party departed the cultist gathering, and once cleared of their presence, discussed options. Taking out BSG was obviously not going to happen. After some discussion, they elected to launch a surprise sneak attack and betrayal on the cultists. Quintus cloaked the party in invisibility, and off they went back to the clearing.

They found the cult busy reading themselves for battle. Quintus summoned 6 dire wolves to start things off. They tore into the cult on a surprise round, knocking several down.

Ares had a high Initiative roll, and quickly took action on the regular round. He teleported near Quintus and engaged him in a melee battle. Ares hit hard, and forced Quintus to use Shield to absorb some damage.

The rest of the party tore through the Cult. While Cultists are much stronger than individual orcs, they aren't nearly as strong as the party. Dorc turned into a veritable blender while Zephyr flew from outlying cultist to outlying cultist.

Kipla was initially hesitant to get involved. She hid her first turn, then accidently rolled a nat 1 attack and blew up the rock she was hiding behind on the second. She would go on to reveal herself to Ares, confirming her part in the betrayal.

Quintus had to rely on Sunbeam blinding Ares to survive his duel. Ares struggled to hit through blindness, but still was able to get Quintus to single digit HP before being routed. The Order would surround him, stun him up, and finally Zephyr delivered the final blow.

Next time - looting the battlefield. How will the party use the cultist gear for their own ends?

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
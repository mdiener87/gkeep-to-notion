# Session 20 - Prisoners of the Gith

    **Created:** 2023-01-05 19:15:56  
    **Last Edited:** 2023-01-12 19:46:35  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The last session took a serious turn. The party is split, with two wayword birds now captured by the Gith. I don't have a Mind Razer battlemap that satisfices me, so we will skip that scene. Instead, the two birds will find themselves in a Gith dream. Powerful psychics, the Gith are trying to gleam secrets from these members - and how to defeat them.

Note, there will be a dream within a dream. The players will get the carrot, and then the stick. If they can break through to the inner layer, they will meet a false Kaetus who will try to have them work against their own interest. If they can break through out of this final dream level, they will reach the real world aboard the Mind Razor. The Real (??) Kaetus is in a cell next to them.

Meanwhile, Cardar will insist that the Cult deliver the Heart of the Dragon to Sethrikar at once. If Seth gets his claws on it, it will dramatically increase his power, scaling with the number of his followers.

Gameplay notes

Gameplay Notes 1/5/23

uh didn't take any notes last time lol.
This session was all about the waywird birbs, captured on the Mind Razor 
They were in a dream within a dream, and had to work their way through the psychic interrogation world to survive
They met up with Timeworn Kaetus, whom the Gith have had captured for years now. 
After escaping the holding cells, they decided to stay on the ship and look for their gear.

They found their gear in the evidence lockers, but some of it was missing. The Gith captain took certain items for themselves! The players were given the option to reserve one attuned item that could not be taken. But the Captain would claim at least one other item for himself.

---

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
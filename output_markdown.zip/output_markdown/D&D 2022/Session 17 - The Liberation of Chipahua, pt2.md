# Session 17 - The Liberation of Chipahua, pt2

    **Created:** 2022-12-01 18:47:26  
    **Last Edited:** 2022-12-01 23:13:17  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

Chipahua has a special place in the party's history, as this was once the setting for an unexpected battle. The people of Chipahua were loyal to Kaladan, and they turned on the party. Kaladan attacked while a riot tried to surround the party. Our heroes were barely able to get away from Kaladan's lightning strikes.

Now, the party finds itself in the peculiar position of supporting Dragon Cult warriors to re-take Chipahua from its Orc/Gith occupiers. 

In this Age of Chaos, the people of Chipahua still nurse strong attachment to the Dragon Cult. Deeply supersitious in nature, Chipahua has always entertained outlandish cults and prophets. The Dragon Cult has actual power, and an actual deity that cares, and protects, his followers. The Gith invasion has endangered the Alluin government, which is seen as incapable of protecting its citizens.

--

The city of Chipahua is under occupation by an Orc horde. Citizens the party encounters will be all too eager to help the Dragon Cult if they can.

Gith airships patrol the skies above. There is one additional ship besides the vessel Sethrikar is now fighting in the skies above.

An orc warchief commands the forces in the main part of the city, which needs to be secured. A large contingent of orcs are in the center of the town, with some orcs occupying residences around the edges. Villages encountered will aid the party.

The Church of the Dragon is also of importance to the people, and Dragon Cult, to secure. It is guarded by a small force of elite Orcs. 

The Gith strike force can make an entrance to either fight, depending on time/need. Get name of [martial artist leader from Slyavarum University] as he is the leader of the strike. They will teleport into a seal of teleportation on either map.

[build Gith strike force units]


=====

Cardar Orlabroth, dragon cult warrior,
Cult of whispers

qui 23
gandus 16
ki 12
do 7


===

Gameplay notes 12/1/2022

The party entered the town of chipahua. Using the dragon cult squads on a stealth flank, the party strolled down the main street of the market. What began as a stealth mission quickly went loud, as Gandus repeatedly rolled nat1 perception checks and would bumble into carts or go on long winded historical speeches regarding the construction of the town wall. 

Quintus found some Orcs hiding in the stalls up ahead. He was able to kill one on a surprise round, and call out the position of the second. Kipla saw his target, and fired off Valzumin's crossbow from stealth. It vaporized the orc, along with the house it was hiding in, and two nearby civilians. This would be a theme, with Kipla taking out multiple homes and orcs in single fire RPG shots. No chance of stealth to this mission remained.

The orcs tried to resist a little, but most were quickly, if not instantly dispatched. Gandus one shot one elite orog straight up with the blade of molten magic. 

The dragon cult dispatched a few other orcs along the side quietly while the party walked down the street. 

The townspeople came out of hiding, sensing a shift in power. They celebrated the party, aka, the dragon cult, and praised Sethrikar's blessing of freedom!

==

The party pushed forward to the towns square. 


An orc warchief led a group of elite and regular orcs. No stealth was at play, the orcs had regrouped and were ready for action. The warchief and her orcs charged the party. Quintus, Kipla, and Dorc all pushed forward and killed the first three orcs. Kipla's crossbow explosion kicked up a cloud of dust, which the orcs ran into to gain conceleament.

The Orcs tried to focus Quintus, including one that succeeded in grappling him for a bit. However, the fight quickly turned against the orcs. The party was just too strong. Quintus hit some orcs with Tidalwave, that also absorbed and dispersed the lingering cloud of dust.

Sensing the battle going poorly, the Orc warchief shouted at her minion to unleash the monstrosity the Gith had given them. That orc ran off, into a building out of LOS. Horrible crunching noises could soon be heard - the orc was eaten. Out came an Aeorian Absorber - a terrible monstrosity made from Githyanki magic. It turned and attacked the party, pouncing on Kipla and injuring her. 

Quintus handled the warchief, while the rest of the party turned on the new threat. Dorc and Gandus got into melee range, with Gandus hitting a compelled duel that forced the monster to turn its attention soley to him. Gandus would then proceede to hit it with a 100dmg hit from two attacks, finishing the creature off.

With the town square freed, now the party only has to liberate the Church of the Dragon, on the edge of town, to complete Sethrikar's final objective. Next time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
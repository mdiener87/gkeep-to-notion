# Session 5 - Do You Like the Dragon?

    **Created:** 2022-06-09 18:46:24  
    **Last Edited:** 2022-06-30 19:25:00  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The party has escaped the Gith and now find themselves in the empty ruins of Galtorah's Keep. The highlands around the Crystal Desert are operating on an alternate-timeline Dragon Cult's control. The Dragon offers peace and safety from the constant attacks at the hands of Orc and Gith... so long as they swear fealty to the Dragons and not the failing, weak Kingdom of Dawn. 

// dynamic content
dragons control the north
Galtorah and Chipahua in particular.
Borrend is a hold out and is fiercely united to the Kingdom following the events in the past
Sethrikar might potentially be encountered, but unlikely. He is a baby dragon and not as strong as his now deceased older brother, Kaladan.

========

Gameplay Notes 6/9/22

A large amount of table talk occured as the party tried to determine what course of action they should pursue. A lack of real time information confounded their choices, as did their lack for long range communication. After much discussion, it was determined they would head towards the town of Galtorah, and then on to Tinethra's Mannor.

Exiting the inner chamber of Galtorah's Keep, the party encountered a horde of Kruthik that were occupying the lower chambers of the keep. Quintus cast wind walk, transforming the party into clouds... as quietly as he could. The Kruthik's tremor sense picked up on the movement of the spell, and a curios one investigated and even briefly stabbed Zephyr as the spell completed.

Windwalk enabled party members flew through the keep, taking the form of a majestic anatomically correct cloud horse. They exited into the hills of Galtorah, and then proceeded to check out the town. They were expecting the Orcs to have seized or attacked the the town. Instead, they found a town under an uneasy occupation by the Dragon Cult. Lead by Sethrikar, these cult members acted for their dragons benefactor and were keeping order while looking for new recruits. The party acted like they were trying to join the cult, and convinced the members not to seize their weapons. The cult led them into the woods, tasking the party to hunt a Grizzly bear in the woods to prove their worthiness to join.

Next time - To join a cult

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
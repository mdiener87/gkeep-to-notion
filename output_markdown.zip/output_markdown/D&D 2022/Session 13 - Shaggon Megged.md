# Session 13 - Shaggon Megged

    **Created:** 2022-10-06 20:08:23  
    **Last Edited:** 2024-11-14 17:03:03  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The boss battle to finish the Battle for Bronzefell. Shaggon Megged is back, and he is angry! The players will have to defeat their old original first boss if they wish to clear the last remains of the Orc horde that threatens this town.

====
gameplay notes 10/6

It was a 3 man party for today's session. Gandus, Dorc, and Quintus against the undead, reanamiated, and fully enraged Shaggon Megged. The party is dangerously low on on resources coming into this battle, and a boss fight just shambled into range! Shaggon Megged was defeated in this timeline, but his body kept his signature-named blade. His madness and hatred slowly fused with the power of his blade, and it brought him shambling back to life.

The party was granted the small blessing of a short rest from the town's party before coming into battle. Everyone regained as much HP as they could, and then Quintus proceeded to just pick a fight with old Sheggy boy. Unconcerned about the giant, undead orc before him, he closed to melee range and attacked.

Shaggon Megged struck back. Way harder. And then he summoned two undead shadow orcs to his side! Dorc and Gandus finally realized a fight was afoot, but Quintus was dangerously injured and in point blank range to the boss. He would spend the rest of the fight here, going blow for blow with Shaggon Megged. He would use Shadow Clone, and Gandus' Protection From Good and Evil. He would use Cosmic Omen and Shield all to stay oh so barely alive. Time and Time again, Quintus would be one hit away from certain death, only to roll the exact save he needed to avoid the blow.

Shaggon Megged switched between Dorc and Gandus with his Maddening Presence. Whomever drew agro would draw his insane eye, paralyzing them on a failed save. Shaggon Megged kept summoning more shadows as a legendary action, and soon the battle was filled with these insane, undead, shadow orcs. While they had trouble landing hits, their attacks were dangerous - inflicting necrotic damage and draining STR attribute stat. Dorc would lose 7 str through this effect, but his belt of giant strength prevented any stat loss. Quintus was not so lucky, and soon found himself geriatric - but still alive.

Shaggon Megged was pressed, and in turn he hit back at the party with his Sould Rend. Quintus was lucky to have just healed back to full, as Shaggon's Soul Rend inflicted 50 damage to him, 25 to dorc, and 12 to Gandus. Shaggon healed from half the damage dealt, repairing and restitching his rotting body. 

Dorc and Gandus weren't having it. They tag team hit Shaggon for incredible damage each, Gandus with an all time high of 98 damage from a single turn. This proved too much for Shaggon Megged even with his healing, and he was put back down. His summoned shadows went insane and berzerked, switching focus to Dorc, whom stood over their master's body. Another round of combat dispatched the shadows, and silence was again returned to the town.

The party took a long rest, and spent some time on RP actions. Gandus finished his tome of leadership. Dorc finally! switched to his new sword, got laid, and identified the Ioun Stone of Sustenance he had looted earlier from the Orc battle. Quintus tried to move to the Megged Blade and failed, his 4 total strength way too small to move it. He instead dreampt of vengeance against the Gith.

To finish the evening, everyone earned a level up!



Loot tables:

+2 Silver GreatAxe - quintus
Strikes for an additional +2d6 psychich damage
When you critically strike an Ethereal creature with this attack, it is forced to return to the material realm.


Ioun Stone of Sustenance - dorc

Great healing potion - gandus

Manticore's Streamlined Leather Armor + 1 - kipla
If you have ground movement speed, you gain +5 ground movement speed while wearing this armor. 
If you have flight movement speed, you gain +15 flight movement speed while wearing this armor.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 10 - Hotdrop Bronzefell

    **Created:** 2022-08-25 20:03:54  
    **Last Edited:** 2024-11-14 17:06:21  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The Party has secured an airship in the prior session, but the Orc army is still a threat. It is on the move, and will soon arrive at the town. The Orcs capture slaves for the Gith, and the claim the land and possessions for themselves. Their eyes now lie on Bronzefell, a small, undefended mountain community. Only the Order of Sun and Moon might be able to save the day.

Théo Deramaut - Governor of town of Bronzefell
	talks slow, old man
Amina Deramaut  - wife
	talk slow, more aware of things
Isabelle Deramaut - daughter
	young, hot

---

The Orc has several waves of attacks. While not a big threat to the order, their weapons are all enchanted silver from the Gith. This upgrades their stats as follows:

+4 to hit
+2d6 psychic damage on hit
+10 hp
+1 resist all

The orc army also has several trolls in its troope, see their stats and add as needed.


====

Gameplay notes 8/25/22

With the Gith airship captured, the party investigated their winnings. The ship name on the side was 'the Rising Scream'. A search revealed no important documents or means of communication. Within the hold, however, were 3 human captives: Theo Deramaut and his family. His wife Amina, and daughter Isabelle were all in chains and beaten. Kipla's lockpicking skill and Quintus' healing magic came into play, as they freed the family and brought them up to speed.

Quintus brough the ship below the cloud cover, near the town of Bronzefell. He tried to get Lopez to pilot the ship, but he proved to be a bit shaky at the helm. Isabelle volunteered, rolled a Nat20, and immideatley leveled out the ship. Quintus gathered the party, and performed a hot drop onto the city. They jumped off the ship, descended 1000ft, and then cast featherfall, descending the final 200ft in a more safe and controlled manner. 

The party landed right outside the town, and practically on top of an orc scouting party. Everyone but Kipla rolled above a 20 on initiative rolls, and were granted a bonus surprise round on the surprised orcs. Their HP and AC were no match for the party, which quickly ended combat with the Orcs defeat.

The party entered the town, which found a people scared of the immanent invasion and panicking on how to deal with it. Quintus picked up on their being some old mining charges in the nearby mine, and dispatched a villager to check. He came back with two large, soggy satchels. Explosives, but somewhat decayed and of questionable use. The village was instructed to prep the town's bridge with explosives. The party would head out and meet the Orcs in combat, perhaps laying a trap for the invaders with their own satchel of explosives...

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 16 - The Liberation of Chipahua, pt1

    **Created:** 2022-11-03 22:54:58  
    **Last Edited:** 2022-12-01 19:34:29  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

Coming into this session, Sethrikar is making a surprise attack on the Eclipse cutter! How will the party respond:

=============
Gameplay Notes 11/3/2022 Results:

The party convinced Sethrikar that they had seized the Gith Cutter in the name of the dragon, thereby ending combat. Seth then led the party, and their ship, to the 'usual meeting spot' where the dragon cult had amassed. Seth instructed the cult to board the vessel, and they would use it to launch a surprise attack on Chipahua.

Aboard the ship, the Cardar Orlabroth, dragon cult warrior, leader of the Cult of Whispers, challenged Zephyr, aka FalconPunch the Third, to a duel, for leadership of the ship and its amassed cultists. Zephyr took the dragon warrior apart, and only Quintus' intervention saved the leader's life.

Isabella set the ship down quietly near the outskirts of Chipahua. The combined party disembarked. With the direction of Zephyr, the cult members used their shadow teleport abilities to ambush the Orc warriors arranged in watch along the forests and walls of Chipahua.

After huddling and planning their next moves for the dragon, they pressed into the city... next time, on D&D!

eclipse combat:

HP 155 / 200

====

Isabella was equipped by the party with the following equipment:
Shadow Shortsword +1
Staff of Birdcalls
Cultist Robes
Dragon Cultist Dagger

======



Cardar Orlabroth, dragon cult warrior, leader of the Cult of Whispers
Gemtec Fenbith, second in command to the cult of whispers


=====

Cultist Names
Zephyr: FalconPunch the Third
Gandus: The Great Wall of St Paul
Quintus: Overkill
Kipla: Quiet Riot
Dorc: Battle of the Buldge

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 11 - The Battle for Bronzefell

    **Created:** 2022-09-15 19:08:09  
    **Last Edited:** 2024-11-14 17:05:21  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The Orcs are invading Bronzefell, and the Order of Sun and Moon must stop their advance! They'll have a bit of time to prepare the field of battle, but the Orcs have their own tricks up their sleeves...

9/15/2022 Gameplay result:

The party prepared to meet the orcs on the fields near the town. Out in the fields, they found several Orcs scouting the situation from nearby rocks. The party quickly crushed them, and sent the final orc fleeing towards the army. Wearing the Cultist Robes, the party claimed to be Dragon Cultists that worship Sethrikar. Gandus gave an inspiring speech in prepartion, granting his party additonal temporary HP.

The party then took a few moments to prepare for the incoming orcs. They piled the bodies, dried the explosives, and improvised fuses to connect the charges. Quintus enlarged the plants in the field, making them grow tall, wild, and impose a heavy 4:1 movement penalty ratio to walk through them. The DM added a 1d4 penalty for moving 4 or more squares through the grass, just because.

The orc army arrived.

Waves of Orcs attempted to blitz the party. The tall grass heavily impeded their movement. What would be a blitzkreig became a slow moving wave of orc molases. Two Orogs that threw the fleeing Orog into the pile of bodies charged the nearby party members. Kipla decided to fire her crossbow at point blank range.. and criticlaly hit. The resulting force explosion hit her party for heavy damage, and vaporized the Orogs. Feeling that explosions were in vogue, Zephyr launched a fireball at a collection of orcs wading through the tall grass, vaporizing them as well. 

More waves of orcs charged down the path. They met Dorc, whom had let the explosives they planted in the field of boddies. The explosions wiped out this wave of orcs, and inflicted some minor damage on nearby party members.

The orcs called for flyer support. Three manticores joined the fray, launching a wave of spikes at Kipla. 


Orc Combatants have silver weapons:
+4 to hit
+2d6 psychic damage on hit

The orc army also has several trolls in its troope, see their stats and add as needed.
manticores + 30flight range vs party ranged attacks

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 15 - Return to Black Scar Garison

    **Created:** 2022-10-27 19:32:56  
    **Last Edited:** 2024-11-14 17:00:20  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The party has returned to BSG. Having saved Bronzefell, they must now consider their next course of action. Do they attempt to confront Sethrikar? Or turn towards the Gith? They have not yet returned to Alluin, to meet the Queen Protector Floriana. Probably a light RP game while we figure out next steps.

Also, Gandus purified the Megged Blade. Its stats have changed, and are pretty wicked(ly good)!


============

gameplay notes 10/27/2022

Party arrived at BSG and debriefed with Commander Tristan. They reviewed tactical maps from Alluin Intelligence that revealed the influence/occupation of both the dragons and orcs. 

Isabella joined the party as a recurring NPC, volunteering to pilot the captured Airship.

Airship has been renamed to "The Eclipse"

Party has 9 wounded soldiers from BSG on board, to be taken to Alluin for medical care.

Quintus got a message from Sethrikar. The dragon cult plans to attack and 'free' Chipaua from the orcs. Seth orders the dragon cultists to meet at the 'usual spot' near Chipaua. 

Rather than head directly to Alluin, Quintus ordered the ship north, to meet up with the dragon cult. No one questioned this.

Sethrikar spotted the ship and made a stealth approach upon it. The party failed their perception checks to spot Sethrikar on approach. After a short call about Seth's plan to attack a "Gith Airship", the party's only warning of danger was the lightning breath attack that struct their brand new ship!

Next time - The Surprise Duel with Sethrikar

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Sessino 18 - The Liberation of Chipahua, pt3

    **Created:** 2022-12-08 22:57:52  
    **Last Edited:** 2024-11-14 16:58:35  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

Gameplay Notes 12/8/2022

The party, having seized the townsuare of Chipahua, pushed onward towards the Church of the Dragon. The church overlooks the town, and had raised battlements. FalconPunch the Third (Zephyr) told the Cult members to push forward and join them in battle, despite their injuries.

The party observed several elite orcs nervously guarding the parpets along the walls. The shadow cult members were ordered in to clear the way and lower the drawbridge. Using their shadowstep, they completed the acts of assassination and opend the gate into the interior.

Quintus summoned dire wolves, which he and Dorc rode into battle. Gandus likewise summoned his celestial elk. Together they rode forth into battle, cutting down the remaining Orcs without any resistance. 

As Zephyr approached the church doars, he encountered a large monstrosity from within the church. The Orcs weren't charging the party's position - they were fleeing.

Two more monstrosities burst through the walls on the left and right side of the church as well. The fight was on.

These monstrosities had unique abilities, including the ability to reflect magical damage and counter spells on demand. The large one with multiple mouths nearly grabbed quintus and kipla, and was able to fear quintus into a retreat. However, these monstrosities proved insufficent to stop the party. With the creatures dead, the inner sanctum of the churhc is now accessible.

Next time - on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
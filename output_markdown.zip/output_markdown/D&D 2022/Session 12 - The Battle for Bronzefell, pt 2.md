# Session 12 - The Battle for Bronzefell, pt 2

    **Created:** 2022-09-29 23:01:40  
    **Last Edited:** 2024-11-14 17:04:58  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

9/29/2022

The siege of Bronzefell, pt 2

Coming into this session is the middle of the battle. The Party has cleverly constructed a defensive position to fend off the attack. They are currently mid battle, but the worst of this storm is still yet to come!


orc waves:

currently: manticores + orcs

next: trolls + orc warchief


---

party basically wiped the floor with the orcs. 


other worthy notes:

note: vizir Orianna is still alive
need to figure out how this played out with Rupert in this timeline

Quintus used the Shadow Marble to commune with Sethrikar during the town party. He deceived the dragon into thinking at least some of the cult near black scar garrison is still alive, and protecting bronzefelle from dragons.

Coming back to the party, Quintus spotted a shambling orc approaching the party. Its the undead version of Sheggon Megged, come to take revenge!

Next time - Shambling Sheggon Megged!




---

Missing notes from N++:

The siege of Bronzefell, pt 2

Coming into this session is the middle of the battle. The Party has cleverly constructed a defensive position to fend off the attack. They are currently mid battle, but the worst of this storm is still yet to come!


orc waves:

currently: manticores + orcs

next: trolls + orc warchief


---

party basically wiped the floor with the orcs. 




note: vizir Orianna is still alive
need to figure out how this played out with Rupert in this timeline

Quintus used the Shadow Marble to commune with Sethrikar during the town party. He decieved the dragon into thinking at least some of the cult near black scar garison is still alive, and protecting bronzefelle from dragons.



--

boss fight:

Undead Sheggon Megged:
The Order of Sun and Moon defeated him in this timeline, but never recovered his signature blade. His evil bond with this weapon survived his death, and has reanimiated his form. No longer in control of the Orc army, he shadows its movements, still lusting for battle and hungering for revenge.

Stats:

HP: 150-250
AC: 15
STR 22 (+6)
DEX 15 (+2)
CON 21 (+5)
INT 11 (+0)
WIS 11 (+0)
CHA 9 (-1)

Saving Throws: STR + 8, CON + 7
Legendary Save 0/1

Resistance to Necrotic Damage

Legendary Actions: 3/3

Soul Hearld: 2 Actions
Sheggon Megged shepherd pulls twisted souls from the Underworld; 1d6 orc shadows arise in unoccupied spaces within 20 feet of the summoner. The shadows act right after Sheggon Megged on the same initiative count and fight until they’re destroyed. They disappear when Sheggon Megged Dies.

Sould Rend: 2 Actions
Sheggon Megged creates a vortex of life-draining energy in a 20-foot radius centered on itself. Each creature in that area must make a DC 18 Constitution saving throw, taking 44 (8d10) necrotic damage on a failed save, or half as much damage on a successful one. Sheggon Megged heals for half of the total damage dealt through this ability.

Maddening Presence: 1 Action
Sheggon Megged targets one creature it can see within 30 feet of it. If the target can see or hear Sheggon Megged, the target must make a DC 17 Wisdom saving throw. On a failed saving throw, the target becomes paralyzed until the end of its next turn. If a creature’s saving throw is successful, the creature is immune to Maddening Presence for the next 24 hours.

Berzerker Swing: 1 Action
Sheggon Megged attacks with berzerker furyat one enemy he can see. His AC is reduced by 1 until the start of his next turn, stacking each time this ability is used.

Movement:
Speed: 20ft, fly: 10ft

Actions:

Aggressive. As a bonus action, the orc can move up to its speed toward a hostile creature that it can see.

Multiattack. The orc makes three attacks with its sword.

The Megged Blade: Melee Weapon Attack: 
+11 to hit, reach 5 ft., one target.
Hit: (2d8 + 3) + (2d6) necrotic damage
Sheggon Megged heals for all necrotic damage dealt by this weapon.



=========== Shadow Orcs ===========
Some mix of Shadow and base Orc, maybe just give them aggresive and or flight speed

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
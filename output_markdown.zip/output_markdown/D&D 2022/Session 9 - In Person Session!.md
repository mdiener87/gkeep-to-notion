# Session 9 - In Person Session!

    **Created:** 2022-08-21 10:46:14  
    **Last Edited:** 2022-08-25 20:30:20  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

8/21/22

Today is a special gameplay day, as its the first in-person D&D session this group has played in years. 

To that end, I hope we can have some fun gameplay moments and really capture the magic of D&D.

At this point in the story, the party is at Black Scar Garrison. They've destroyed a Dragon Cult cell, and stolen all of their gear. What comes next is the obvious question, and perhaps needs some DM intervention.

While I'll give a little room to the players to advance the plot, if I'm not satisfied quickly, an NPC will rush in with news of Orc movement. I think its time to see that side of the conflict as well.

In the mountains north of Alluin lies the small town of Bronzefell. A sleepy mountain community, Bronzefell has minimal defenses. The Alluin army has received word that a contingent of Orcs is marching on Bronzefell, supported by a Gith airship. 

The Gith are interested in slaves and gold, the orcs in land. In addition to powerful enchanted silver weapons, the orcs are being given magicks they don't understand. They have used this to create powerful troll variants, which now wreak havock on the battlefield. Their spellcasting shaman also has access to even more powerful magics, such as the ability to grow Corpse Flowers from fields of the dead.


=====


-- result --
The party learned of an impending attack on Bronzefell from Commander Tristain. The commander outfit them with 9 spell scrolls of flying, and attached two squires to their unit: a Morris Lopez, and Carla Ortaund. The party took off on Quintuss airways and headed toward the imperiled town. They encountered two Gith airships just above the cloud layer. The party split into two attack squadrons, and began combat.

The starbord ship was handled by Gandus and Lopez. While Gandus failed to resist the GIth COmmander's Telekinis, he used Misty Step to teleport back on board. There, he and Lopez went back to back and fought the waves of gith monks, and the commander. Ureausa stayed flying above, reigning spells down onto the defenders.

Kipla and Quintus took the other ship. This ship was larger, with fewer, but more powerful units defending it. The Gith Star Seer critically failed her spells and accidentally destroyed her spellbook. Quintus boarded the ship while Kipla stayed at range with her crossbow. The Star Seer was defeated, but the Gish started blasting Quintus with fireball after fireball. These attacks took their toll, but also severely damaged the ship, which started listing badly to port. Quintus was dropped in combat with the commander, ending his giant eagles summons. Everyone still on them started to fall - Kipla, Ureausa, and Ortaund. Kipla used Ila to return to the ship, and then ordered Ila to save Quintus and take him to the healer on that ship.

Gandus used flight and started flying to the other ship. This was perfectly timed, as the commander of that ship used Telekinis to fling Kipla off the vessel and into the void. Gandus caught Kipla midair and Lopez fired another shot - critically striking the damaged ship, blowing its ammunition stores, and vaporizing what was left of it.

The order, plus Lopez, now are in command of a captured Gith Vessel. Bronzefell, and the orc invasion army, are somewhere still below. Can the party save the town? Next time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
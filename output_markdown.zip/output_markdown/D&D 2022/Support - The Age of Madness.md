# The Age of Madness 

    **Created:** 2022-04-14 01:25:18  
    **Last Edited:** 2024-11-14 17:12:13  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

4/14/2022

The effects of time travel on the kingdom

Overall result: not good

While Kaetus did choose personal happiness for himself, the Order's actions in the past have resulted in a significantly different timeline than the one they departed.


Kaetus:
Kaetus and Gwen lived in happiness for over 200 years. Queen Gwenestry assumed her rightful place as Lord of the Kingdom of Alluin. She ruled over an era of peace, harmony, and growth for the Kingdom. Kaetus was successful in expanding the Compact of Dawn, and proudly admitted Borrend to its ranks as a full member. 

Kaetus and Gwen had a child, Quintus. A half elf, Quintus was born to two worlds, with a gilded life of opportunity and achievement. He quickly excelled in magical talent, taught by his father, Kaetus, Warden of the Realm. Kaetus would lead his son on a number of expeditions through both the Kingdom and its cities, as well as into the Astral Plane aboard the Endimyon. Quintus skill grew, and was soon inducted into the Order of the Phoenix - the youngest knight in the Order's history.

However, these good times were not to last. The Order's adventures would go on to attract unwanted attention. The Pirate Gith were not pleased that the Order would promise the Soul Stone's return, and then fail to follow through. Existing outside of normal time, they had decades of impatient waiting for the Order to fulfill its bargain. Their patience exhausted, they issued a Vendetta against the order - and all those that supported them. The Gith traced the order - and Kaetus in particular - back to the Kingdom. They attacked.

The Gith would succeed in ransacking Alluin. They killed the royal guard, and the aging Galtorah. They captured Queen Gwenestry, and her final fate is still unknown. Kaetus secreted away Quintus to the Endimyon. They set sail together, but soon Kaetus would depart. Claiming to know of allies he could draw upon, Kaetus would take the form of an air elemental and fly off solo through the endless astral sea. He gave Quintus a set of instructions to follow, and his families heirloom, Galtorah's Bracer.

Those instructions had quintus pilot the Endimyon to a pre-arranged meeting point, where he would reunite with his father. However, Quintus was intercepted by Gith patrols and attacked. Quintus was forced to alter course. Diving into Psychic Storm, he was able to evade the Gith pursuit, but was wildly off course. He no longer had any way of making his father's rendezvous.

The instructions from his father had one final directive. Were Quintus unable to meet up with his father, he was to instead head to a backup location. This Plan B led Quintus to a distant and unfamiliar constellation of the Astral Sea. Having arrived, it instructed him to return to the Material World from this location. His father's closest allies would be waiting for him. 


----
Order would not form normally in time. They were confronted by the Orc invasion without the aid of the Doom Cannon to vaporize its army. This led to a bloody conflict without total victory. Sheggohn Megged was killed, but his Daughter, Sharog Megged, would go on to claim leadership of the horde. Armed and supplied by the Githyanki, they have fortified their hold of the Eastern Settlements. 

[note - add a mountain pass to the mapp near Bashaw Lake. This is where the Orcs came into the kingdom from]

The Gith have neither the numbers nor the interest in conquering a kingdom the size of Alluin. Instead, they found willing, ruthless, and easily manipulated allies in the Orc hordes. The Gith would serve as the Orc's patrons. The Gith would supply the Orcs with their wonderous magick, and in return the Orcs would give them anything the Gith desired. Slaves. Gold. Wonderous Artifacts. The pleasure of battles won, lives shattered, and lands conquered. 

The Gith would launch raiding parties from their Airships upon the cities and townships of Alluin. This raiding action greatly drained the Kingdom of its forces, people, and wealth. Meanwhile, the Orc Invasion from the East could barely be contested.

Knight Commander Floriana would assume leadership of the Kingdom. One of the last remaining members of the Order of the Phoenix, she assumed Military control of the Kingdom once Selevarum feel to the Gith onslaught. Floriana leads from Alluin, but has little military resources remaining to protect the city - let alone the Kingdom.

The Gith, while not interested in conquering the Kingdom, were interested in Conquering a city. Alluin was too well protected with its magical dome of force to seize. Their initial raiding attack required their interceptors to planar jump direct within the city's walls. This risky maneuver required their finest pilots, and still over a third were lost in the jump. Ships materialized buried in dirt, or melted in two by the Dome of Force. Even if the Gith desired to roll the dice again, the barrier was later augmented with anti-teleportation magic that made the endeavor even riskier to consider.

Selevarum, however, was not nearly so protected. Full of haunty and contemptible elves, the Gith would raid the city, and eventually claim Selevarum Castle as their own. The Gith would open a permeant Planar Portal above Selevarum to their base of operations in the Astral Sea. Now, all matter of Gith vessel travels between the two. 


Without the Doom Cannon to genocide him, Sethrikar grew into a full young adult dragon. Without an Order to confront him, Kaladan would grow in power and influence unchcked. The Dragon Invasion is well underway, but has taken an entirely new and unexpected angle to it. For those that have met them, the Dragons are heroes. They have established a no-fly zone around the Onyx Mountain and the surrounding Crystal Desert. Borrend is protected, as is Chipahua. 

Most of the kingdom secretly hopes these rumors of Dragon Saviors are true. The Orcs dismiss them as the mindless whispering of humans. The Gith know better, and have no real interest in confronting the dragons. They are content with raiding and pillaging what they can. If the Dragons ever become too large a threat, they will retreat through the Portal in Selevarum and close it behind them. 


The Orcs have seized the eastern settlements, as well as El Enna. Their ventures into the Vodurn Morass have always ended in disaster, and they now steer clear of that area. El Enna has become their seat of power, and rule with a cruelty over their captured cities. 




missing notes from N++:
Kaetus between sessions notes

- Resurrects the Order of the Phoenix
- "Warden of the Realm"
- Goes full hermit mode in his later years and disapears from history

Gwenestry:
- Murdered and/or captured by the Gith who are mad at Kaetus for not fullfilling their deal with the Soulstone
- Provides motivation for Quintus 
- 


Quintus -

- Kaetus and Princess Gwens Son
- Potential heir to the throne, Aragorn style?
-

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
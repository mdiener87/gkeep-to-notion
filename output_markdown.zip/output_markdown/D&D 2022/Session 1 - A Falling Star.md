# Session 1 - A Falling Star

    **Created:** 2022-04-14 23:21:15  
    **Last Edited:** 2022-04-28 19:01:51  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

See age of Madness for overall notes coming into here. This session will introduce Quintus, Kaetus' son. He will be joining the party from the astral plane, having travelled through time and space to reach safety amongst his father's closest friends.

-- Gameplay notes 4/14/22

- quintus found the soul stone in the arcanum. It is being carried by Dorc.
- This soul still has the soul of the Spirit Naga
- After exiting the keep, Quintus Collapsed the Reality Marble of Valzumins Keep and took it with him
- The party took to Quintus airways and flew up to survey the area. They spotted a GIth Cutter, and tried to hide from it. However, Quintus froze up upon seeing it and Gandus' armor was too large and shiney to stay hidden
- The gith ship came at them on an intercept course
- Quintus and Kaetus tried to evade the ship by diving along its hull. Rolling a nat1 on the acrobatics check, they instead crashed into the Airship.
- Still on the ground,  Dorc convinces a squirrel to keep an eye on the Soul Stone on the ground. He then joined the battle.

- The Gith had a surprise round against the crashed Order members on the ship. They inflicted some heavy damage on Quintus from the start.
- During the resulting battle on the ship, Zephyr accidentally struck Quintus and downed him. This caused all of his conjured Giant Eagles to poof out of existence, sending Gandus, Kipla, and Dorc falling to the ground.

- Gandus used Dimension Door and directly teleported aboard the ship
- Dorc Iron Man landed on the ground. Then, in an improbable roll, used athletics and a nat20 Str Ability check to fling himself back aboard the airship, using a young tree near him as an impromptu catapult
- Kipla summoned Ila the Handsome and had him scoop herself and skittles up in his arms. They flew up to the airship and landed on it.

- The gith were not much of a fight for the Order. While they fought well and hit hard, there were only 3 Gith warriors, and the battle quickly turned against them.
- The captain and one Gith pirate were killed in battle. The final Gith successfully used Plane Shift to teleport away from the battle. Gandus tried to use Agar's blade to counterspell it, but failed the roll to do so.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
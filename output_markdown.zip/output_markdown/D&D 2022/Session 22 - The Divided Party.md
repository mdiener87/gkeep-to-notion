# Session 22 - The Divided Party

    **Created:** 2023-01-19 18:53:44  
    **Last Edited:** 2023-01-19 19:10:38  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The last session focused on the Chipahua side of our divided party. Kipla was out, so it was just Gandus and Quintus. Of course, Quintus would go on to shockingly (or not so - we knew) join Sethrikar for realsies. 

So today .. where on earth do we go?

We really need to get the party back together. The teleportation circle in the church to the Mind Razor is still up and running. The Chip. side could use it to rejoin the party on the MR. 

As for the MR, the party there is in trouble. The ship is alerted to their escape. This is a massive capital ship. There are lots of Gith onboard, including boss units. While it's fine if they kill some mooks, they're going to have to really work to actually claim the ship for any real length of time. 

Ultimatley I think I need to let the current plot play out. Let it breathe a little. Let the party dictate how they want to take things. And respond to their decision. They got themselves into this mess, and it's only fair to let them get themselves out of it.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
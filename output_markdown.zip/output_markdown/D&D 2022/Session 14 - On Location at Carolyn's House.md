# Session 14 - On Location at Carolyn's House 

    **Created:** 2022-10-15 15:12:32  
    **Last Edited:** 2022-10-27 20:27:27  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The prior session, which was supposed to set up the plot for this in-person game, did not actually take place. Sooo. Have to wing this. Need to figure things out. Typing to myself quickly, but ahhh we have a game to run!

--

Inspiration from this morning: Lair of Forgotten Sins, but age of chaos edition.

In the Prime Timeline, the party found the Lair of Forgotten Sins, and fought the yuan-ti anathamancer at the heart of this dungeon. Plus, bonus enemy.. Ureasua's anathamancer form! She never joined the Order in this timeline, and has instead usurped the anathemancer of the lair of forgotten sins. Now an ascended anathemancer herself, she seeks to lead the yuntai in a glorious revolution against the moral surface world. The kingdom's broken defenses make this a prime time to invade.


--- gameplay notes 10/15/22

in person D&D notes, 10/15 - Carolyn's house

Gandus used Remove Curse on the megged blade. This purified the blade, and removed most of the benefits of this cursed, haunted blade. Through its purification, the trapped Pit Fiend was released back into the material plane. Gandus succeeded on an intimidation check against it, identifying himself as the avatar of Tyr. The Pit Fiend decided to avoid combat, and tried to fly away. Gandus was having none of this, and proceeded to attack the demon. Combat ensued.

Gandus was trapped in a wall of fire summoned by the pit fiend. Uraeusa used Conjure Water to quench the wall, extinguishing the flames. The Fiend tried to use Hold Monster on Gandus so he could escape, but with Quintus' inspiration was able to overcome the demon's spell. It died soon thereafter.

Examining the demon found a magical ring, which Quintus identified as a Ring of Spell Storing, holding a single spell - hold monster.

----===----

Panic struck the town following this battle. Gandus tried to calm the people with a long-winded speech, but nis nat1 proved unpersuasive. Kipla decided to throw some words of doom with a 19 on a deception, and many in the town decided to evacuate towards Alluin. Kipla looted 50g from loot left behind in various houses, and Quintus cast Wind Walk to aid the party's flight towards black scar garrison. 

----====----

Next time, on D&D! Black Scar Garrison round 2, with Lopez and Issabel? in the captured airship.

Also - the purified meg blade needs stats

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
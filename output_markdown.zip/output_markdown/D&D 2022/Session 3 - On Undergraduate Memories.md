# Session 3 - On Undergraduate Memories

    **Created:** 2022-05-19 18:30:10  
    **Last Edited:** 2022-05-24 19:10:04  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

Party likely to hit Alluin today and meet Floriana. The Order of Sun and Moon is defeated in this timeline, in which they defeated Kaladan at the cost of their own lives. The Kingdom is facing an ongoing Gith threat, roaming packs of Orcs in the East, and Sethrekar's attempts to form a new and permanent Cult of the Dragon in the North. Borrend, led by Councilor Disa, is a stalwart ally of the Kingdom. However, much is in disarray.

 Can the party prove themselves in this new timeline?

======

selevarum university
college of swords


Homecoming - Gith enjoying elves fighting against orcs in brutal unarmed combat

Chi Phi Chi


--

Scroll of Detect Thoughts
Small Lockbox


--

Gameplay Notes 5/19

Party took Quintus Warhorses towards the edge of Alluin. Quintus scryed the Alluin thrownroom, and didn't recognize the woman sitting on the thrown. Distrusting the state of the Capitol, the party decided to use Transport Via Plants to Seleverum the next morning.

At the SU grounds, they encountered a school under the occupation of the Gith. A Gith Cutter flew overhead as they studied the area, but luckily did not spot the group. They cast Invisibility on themselves, and snuck past an initial patrol on the school grounds. The party used this invisibility to survey the area, and saw an immense planar portal above the Seleverum Bay. Gith Cutters could be seen coming and going through it.

The party elected to break into the college and try to find diamond dust for Zephyr. Entering a wing Quintus knew contained alchemical supplies, they looked around and tried to find some diamond dust. 

Several Gith occupied the college. Kipla snuck into a room with some magical students, but found nothing of interest in there. Just some casual kobold denialism.

Quintus snuck into another room, and here struck gold. His Frat Bro code snuck him into the room, and convinced the group to hand over their found diamond dust - 90gp worth. The amount wasn't sufficent, however, and so he used Mage Hand to search a top shelf of the room the students hadn't been able to reach. Here he found a scroll of Detect Thots, and a small lockbox with another 80gp of diamond dust. 

With sufficient Diamond Dust in hand, he was able to restore Zephyr from the Feeble Minded state he suffered from.

Quintus also pressed the students on the state of the world. They described repeated attacks by the Gith. How they were able to kill the Galtorah family and launch pirate raids across the land. How the GIth armed the Orcs and empowered their invasion. How the Gith were able to seize Seleverum, and erect a permeant planar portal using the ley lines that run through the island. And finally, most dramatically, how the northern section of the kingdom is now ruled by a Dragon. Pissed at his brother's loss, this Dragon, named Sethra-something, is starting a new Dragon Cult. Followers have been drawn to him, as he can protect his lands from Gith pirate attacks.


Next time on DND- oh shit we are in a hostile occupied city lollll

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
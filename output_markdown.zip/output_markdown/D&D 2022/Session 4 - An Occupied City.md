# Session 4 - An Occupied City

    **Created:** 2022-05-24 19:10:07  
    **Last Edited:** 2022-06-09 18:53:05  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The party chose to use transport via plants to hit up Selevarum early. Well okay then! They find themselves in Selevarum University, having snuck into this occupied building in search of diamond dust with which they could cure Zephyr. This effort has succeeded, but has left Quintus no longer invisible from his Invisibility spell. The University is occupied with Gith, much like the rest of the city. How will the players react?


============


Gameplay notes 5/24/22

Party took the Githyanki fight to start the session. Quintus made too much noise investigating the area, and a Gith was dispatched to 'silence the students lurking about'. Instead the Gith met Quintus, whom, after a bit of back and forth, ended the duel by succesfully Polymorphing his opponent. The Enlighted Monk became alert to the fight at this point

Master Ipon - Enlightened Monk that escaped the Party in the Selevarum College. He teleported out to safety after making a WIS check to not fight a helpless fight seeking revenge. Revenge, however, is certainlly on his mind.


The party escaped the way they came. Out into the campus plaza they fled. Gith Airships could be seen approaching in the distance. The Gith on the campus grounds could be seen grouping up and attempting to incircle the Order. The party didn't want to stick around and fight, and so Quintus broke out Transport Via Plants once again to escape. He tried to remember a plant near Galtorah, but his History roll was unimpressive, and Derick couldn't recall one either. It was handled as a poor Teleport attempt, and the party ended up taking 6d10 Force damage as they Plantported into... the start of Galtorah's maze.

The party originally toured this maze in the prior Modern Timeline. These vents still remained, and so much of the maze was empty. Except an old decripit Drow Stalker, which mistook Kipla for its Princess target and attacked her out of the blue. Dorc once again encountered the Ice Devil of the Frozen Lake, and after impressing her again with a Nat20 athletics check, learend that his prior... encounter... with this devil resulted in a little Ice Devil spawn. He gave junior a hug, and junior kiss/bit 'DADDY'. Dorc accepted junior's magic (whom he dubbed Spork), and gained permanant resistance to Frost damage.

At the end of the maze, they found the same corrupted celestial horse as they originally encountered. With its Sibrix demon corrupter / tormentor / sponsor gone, the creature was drained of energy and slowly dying. The party snuck around and Kipla hacked open the door to the exit. Meanwhile, Gandus slowly purged the creature's affliction with his radiant Aura. Gandus did not find the creature worthy of saving, however, and left before granting it the reprieve of death to the light.

The party has emerged into the comforting silence of Galtorah's Keep. Emptied of its treasures following its compromise by the Drow in the past, the Keep now sits abandoned and empty. Where will they go next?

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 6 - Cult Recruiting 

    **Created:** 2022-06-30 19:23:29  
    **Last Edited:** 2022-07-07 20:14:07  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The party is attempting to infiltrate this timeline's Dragon Cult, in some sort of bid to create a widening conflict between the Cult and the Githyanki. The Cult members are going to start by evaluating the party's power in a series of challenges. First, to hunt a Grizzly Bear. Then, a test on dragon politics. Finally, they will be taken to meet Aries Shadowend to be inducted into the cult proper.

====

Gameplay Notes 6/30/2022

The party set off to hunt Bear and complete the Cultist initiation challenge. They tracked bear sign to the pond at the center of the map. From there, they discovered signs of Orc. Gandus split off to pursue bear, while the rest of the party tried to track down the Orcs.

The Party found a series of concealed trip-wires. Quintus transformed into a bear, and made loud, obnoxious bear sounds. Concealed Orcs jumped out from blinds and attacked him on a surprise round.

The party returned fire. Simple Orcs were no match for the current party members. Zephyr one shot two orcs, and injured a third. Kipla overkilled an orc with a sneak attack, and bear Quintus finished off the fourth. Gandus came upon the scene and, spotting a bear with a 1 on Perception check, attacked and finished off bear quintus.

The Orcs bore the insignia of a leader related to Sheggohn Megged. It also bore twing Silver Longswords - an unmistakable signature of the Githyanki. The party grabbed armor and weapons that bore this signia to prove they killed this Orc party. 

The party pushed on into the late hours of the night. They found their original quarry - a large, powerful, Girzzly Bear. Gandus attacked it with a surprise round, then charged and slayed the creature with his morning star. He cut off its head and paws with a longsword, and brought them back to prove feat of their deed. 

Returning to the Cult, they provided ample proof of their worthiness. Not only did they kill the original objective in the Bear, they also eliminated an Orc scouting party as a bonus. The Cult Leader quizzed the party about the dragon and the objective of the cult, and indeed the party knew about the dragons. Satisfied they had proven their might and will, the cult leader inducted the party into the Dragon Cult. He issued them each a Cultist Robes and Cultist Ceremonial Dagger. The Party had officially gone Renegade.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
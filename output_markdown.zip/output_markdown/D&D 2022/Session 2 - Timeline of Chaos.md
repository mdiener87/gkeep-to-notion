# Session 2 - Timeline of Chaos

    **Created:** 2022-04-28 19:00:28  
    **Last Edited:** 2022-05-19 19:18:33  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

Gameplay notes:

The party sent Ila the Handsome off in the Gith Airship to cause a distraction for any other nearby Gith pirates. Meanwhile, the party returned to the forest to try to find the SoulStone that Dorc had hidden previously.

Unfortunately, a Nagpa had found the SoulStone first and bought it from the squirel entrusted with protecting it. The Nagpa used its illusion magic to seperate the party. Then, charming Kipla, it offered to sell the Soul Stone for the small price of her entire inventory. She failed the contested roll, and sold her inventory to the Nagpa.

Once reunited, the party took after the Nagpa. The Nagpa had used Etheralness to try to walk away. Zephyr's Robe of Eyes allowed him to track and pursue the Nagpa, eventually forcing a confrontation in the forest. The Nagpa struck back, hitting Zephyr with the Feeble Mind spell and reducing his intelligence to 1. The resulting fight was dangerous - the party underestimated the depths of evil magic the Nagpa had in its arsenal. On its final action, the Nagpa tried to Disintegrate Gandus and Kipla. Gandus armor provided ample protection, but the squishy Kipla failed her save. Her HP was insufficent, and she was moments away from being vaporized. Skittles intervened in the last frame, adding his HP vs. the damage pool and soaking enough of the beam so as to save Kipla's life.

However, in the process, Skittles was permanently vaporized. 

The Nagpa defeated, Kipla found half of her original inventory, plus some items the Nagpa carried. However, the loss of her companion weighed heavily on the party's mind. Just what kind of future have they returned to?

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 14 - Low Energy RP Session (did not happen)

    **Created:** 2022-10-13 19:32:06  
    **Last Edited:** 2022-10-15 15:13:04  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The party has vanquished the Orc horde threatening Bronzefell. The town is grateful for their assistance, and the party has earned a long night of revelrey. Complete with a level up!

Coming into this session, they'll likely move to the next stage of their plan to get the Dragon Cult and Gith Pirates to end their truce and attack one another. The party wore cultist robes for the entire orc battle, and the surviving orc members will report it as dragon cultists who felled them. Meanwhile, they have infiltrated the Dragon Cult and have a line of contact to Sethrikar. The murder of that cell is now confusing, as the cult knows many cultists in it were wiped out. But not this small group? Intriguing.

-- result

-- game did not really happen. Not enough players or energy to run this

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 8 - A Betrayed Cult

    **Created:** 2022-07-28 18:30:36  
    **Last Edited:** 2022-07-28 22:14:12  
    **Labels:** D&D 2022  

    ---

    ## Note Content (HTML)

The Dragon Cult has been betrayed. While the exact details are unclear, Ares Shadowblade was able to use his Shadow Marble to convey to his master, Sethrikar, that the recent cult hires were actually powerful assassins sent to destroy them. Sethrikar will not accept this lying down. This massacre of his followers occured on his turf, on his mission. He will dispatch cultists, shadow elementals, and even his secret weapon - a Narzugon on contract - to deal with these betrayers.

Meanwhile, the party has successfully destroyed this grouping of the cult. They haven't looted the bodies or investigated further. What will they be able to do with their items?

Loot - 
2 Shadow Staves +1, +1D6 necrotic damage on hit
Requires Attunement by a Druid, Sorcerer, Warlock, or Wizard
Once per long rest, you may use an action to cast the spell Darkness from this staff.

5 Shadow Longswords
Requires Attunement
+1 weapon, +1D6 Necrotic Damage

8 Cultist Cloaks
9 Cultist Dragon Masks
37 Gold

Twisted Shadows - Ares' Left Weapon
Dagger, Requires Attunement
+2 Weapon, +2D6 Necrotic Damage
This weapon has 2 Charges, which recharge at midnight. On hit with this weapon, you may consume a charge to increase the damage your Sneak Attack strikes for for an additional 2d6 damage.

"A ceremonial dagger with a wicked edge, this blade was blessed by Dragon Lord Sethrikar and infused with his dark power."

Twilight's Reach - Ares' Right Weapon
Short Sword, Requires Attunement
+2 Weapon, +2D6 Necrotic Damage
This weapon has 2 Charges, which recharge at midnight. As a bonus action, and while in dim light or darkness, you may consume a charge to Shadow Step. You and any carried equipment teleport up to 20 feet to an unoccupied space that you can see that is also in dim light or darkness. 

"Ares custom designed this blade as the perfect assassin's weapon. He would end any threat to the cult - and keep a lucrative percentage in the process."

=======

Gameplay Notes 7/28/22

The party first looted the remains of the cult. They found a number of their weapons, cloaks, and masks. Ares Shadowblade had two powerful weapons, and a bag full of gold to loot as well. With their looting complete, Quintus used cast without a trace, and the party covertly escaped the battlefield without leaving, well, a trace. They decided to head towards Black Scar Garison and introduce themselves to Command Tristan.

The party snuck up on the Garrison in the dead of night. Kipla attempted to sneak into the garrision alone, but the sentries were on high alert and partially spotted her approach. A wizard cast a spell of light over the field, revealing the party and their approach. It was difficult to convince the garrision of their good intentions in such a setting, and Quintus used invisibility to make a stealthy retreat. The wizard used a scroll of fireball, attempting to blast the party, but all had moved from their original position. The spell missed.

The party head north and bunkered down in the woods. They got a long rest in, and came back to the garrision during  the day. Once again they approached with stealth, but this time with quintus' signature invisibility spell in use. They were able to infiltrate the base, locate commander tristan, and make a grand, surprising entrance as they dumped the cultist gear on table which the commander and his staff were dining. In the ensuing conversation, they somehow convinced the commander that they were from the past - or is it the future? and were indeed the order of sun and moon. They learned the original order died in battle against Kaladan, but also succeeded in killing the dragon in their assault. The commander rolled a nat 20 and realized that Quintus is a prince, and heir to the kingdom. He implored Quintus to help and take leadership of the kingdom, as the realm needs hope.

The party gathered around the table to discuss their next steps...

NExt time, on DnD!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
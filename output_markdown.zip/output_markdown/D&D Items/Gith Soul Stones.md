# Gith Soul Stones

    **Created:** 2021-10-29 11:36:17  
    **Last Edited:** 2021-10-29 11:36:19  
    **Labels:** D&D 2020, D&D Items & Monster Stats  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Gith Soul Stone
Wonderous Item, Very Rare

‘The Gith Soul Stone is used to imprison the soul, and even the corporeal body, of creatures or monsters. To employ, the
desired soul must be recently removed from the body, or its mortal vessel heavily injured. The wielder must make a
DC14 arcane check, be within 30ft of the desired target, and the target must be visible (or have a means of tracking
equivelant to vision).

Upon a successful Arcane check, the target must make a DC20 Will saving throw, plus whatever excess margin made
from the activating Arcane check. If the target is alive, they gain an additional +5 bonus to this saving throw.

If the target succeeds, their soul is not trapped and this Gith Soul Stone cannot be used on that target again for 24
hours.

If the target fails the roll, it will be imprisoned within the Gith Soul Stone until released with a DC14 arcane check, or the
Soul Stone is otherwise destroyed. While holding a Soul, the Soul Stone cannot be placed in a bag of holding.

#### ChatGPT Output:
### Gith Soul Stone
**Wonderous Item, Very Rare**

The Gith Soul Stone is used to imprison the soul, and even the corporeal body, of creatures or monsters. To employ, the
desired soul must be recently removed from the body, or its mortal vessel heavily injured. The wielder must make a
DC14 arcane check, be within 30ft of the desired target, and the target must be visible (or have a means of tracking
equivalent to vision).

Upon a successful Arcane check, the target must make a DC20 Will saving throw, plus whatever excess margin made
from the activating Arcane check. If the target is alive, they gain an additional +5 bonus to this saving throw.

If the target succeeds, their soul is not trapped and this Gith Soul Stone cannot be used on that target again for 24
hours.

If the target fails the roll, it will be imprisoned within the Gith Soul Stone until released with a DC14 arcane check, or the
Soul Stone is otherwise destroyed. While holding a Soul, the Soul Stone cannot be placed in a bag of holding.

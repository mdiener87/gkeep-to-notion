# The Aether Flame

    **Created:** 2021-10-29 11:25:12  
    **Last Edited:** 2021-10-29 11:25:17  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
This legendary substance was thought to be purely theoretical in nature until successfully synthesized by the Elf Lord
Teinithra, It is said to be composed of competing and contradictory Prime Elemental Motes: Fire and Water; Earth and
Air; and finally Shadow and Light. Such a substance should be highly unstable and explode in some grand manner upon
its creation, but such was Teinithra's alchemical skill

‘The Aether Flame is therefore a pure substance composed from all material layers of reality. The potential uses for such
a substance are practically limitless; it could serve as an energy source for extreme spelicasting, or as a breakthrough
regent in alchemy. With the Aether Flame comes the ability to warp and recreate the inner planes at will.

Using the Aether Flame comes with inherit risk to both the sample, and the user. And everyone and everything else in
the vicinity, for that matter.

Spellcast
Wielding the Aether Flame allows one to cast from among the following list of spells without requiring knowledge of the
spell or the requisite spell slot. Instead, make an Arcane Check DC 10 + Spell Level . On success, the spelll resolves as it
‘would normally. On failure, the wielder takes 1D10 Force damage for every point missed by the Arcane spell check. The
desired spell will still otherwise resolve as normal if the Arcane Check was within 5 of the specified DC level. This damage
bypasses all resistances or immunities.

Ona Natural 1, the user is killed instantly and the Aether Flame explodes out of its container. All creatures within 40ft
must make a DC20 Reflex save or take 20D10 force damage, or half on a successful save. This damage otherwise
bypasses all resistances and immunities.

Spells:

* Conjure elemental {any}
* Control Water

+ Control Weather

* Create or Destroy Water

* Creation
* Darkness
* Daylight

* Detect evil and good
+ Detect magic
= Enlarge/reduce

"Fly
= Fogcloud

= Gaseous form

= Invisibility

* Major image

= Move Earth

*  Phantasmal Killer
+ Plane Shift

= Purify Food and Drink
= Stone Shape

* Thunder Wave

= Tongues

+ Wall of fire

+ Wall of stone

"= Water breathing

= Water walk

= Wind walk

Alchemy
‘The Aether Flame may be used to create magical items of Very Rare, Legendary, or Sentient levels. Work with the DM to
decide the nature of the item you are creating. When used as an alchemy regent, itis subject to the same failure rules as
for spelicasting, above.

#### ChatGPT Output:
This legendary substance was thought to be purely theoretical in nature until successfully synthesized by the Elf Lord
Teinithra. It is said to be composed of competing and contradictory Prime Elemental Motes: Fire and Water; Earth and
Air; and finally Shadow and Light. Such a substance should be highly unstable and explode in some grand manner upon
its creation, but such was Teinithra's alchemical skill.

The Aether Flame is therefore a pure substance composed from all material layers of reality. The potential uses for such
a substance are practically limitless; it could serve as an energy source for extreme spellcasting, or as a breakthrough
reagent in alchemy. With the Aether Flame comes the ability to warp and recreate the inner planes at will.

Using the Aether Flame comes with inherent risk to both the sample, and the user. And everyone and everything else in
the vicinity, for that matter.

### Spellcast
Wielding the Aether Flame allows one to cast from among the following list of spells without requiring knowledge of the
spell or the requisite spell slot. Instead, make an Arcane Check DC 10 + Spell Level. On success, the spell resolves as it
would normally. On failure, the wielder takes 1D10 Force damage for every point missed by the Arcane spell check. The
desired spell will still otherwise resolve as normal if the Arcane Check was within 5 of the specified DC level. This damage
bypasses all resistances or immunities.

On a Natural 1, the user is killed instantly and the Aether Flame explodes out of its container. All creatures within 40ft
must make a DC20 Reflex save or take 20D10 force damage, or half on a successful save. This damage otherwise
bypasses all resistances and immunities.

#### Spells:

- Conjure elemental (any)
- Control Water
- Control Weather
- Create or Destroy Water
- Creation
- Darkness
- Daylight
- Detect evil and good
- Detect magic
- Enlarge/reduce
- Fly
- Fogcloud
- Gaseous form
- Invisibility
- Major image
- Move Earth
- Phantasmal Killer
- Plane Shift
- Purify Food and Drink
- Stone Shape
- Thunder Wave
- Tongues
- Wall of fire
- Wall of stone
- Water breathing
- Water walk
- Wind walk

### Alchemy
The Aether Flame may be used to create magical items of Very Rare, Legendary, or Sentient levels. Work with the DM to
decide the nature of the item you are creating. When used as an alchemy reagent, it is subject to the same failure rules as
for spellcasting, above.

# Golden Ring Upgrades

    **Created:** 2021-10-29 11:23:42  
    **Last Edited:** 2021-10-29 11:23:47  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Cloak of Many Travels

Requires attunement.
While wearing this cloak, you have advantage on athletic checks involving jumping, falling, or moving through sand or loose dirt.
‘While wearing this cloak, you may activate any of the following abilities as an action. The cloak has only once charge for these abilities
that recharges daily at dawn:

Blazing Entrance
Cast this as action as per the dimension door spell, except that you disappear and reappear in a brightly-lit burst of flames.

Roc Flight
‘You gain Fly speed of 60ft for up to 10 minutes. If you are in the air when this effect ends with this cloak still equipped, you may
cast Feather Fall on yourself as a reaction.

Wurm Tunneling
You gain Burrow speed of 30ft and tremor-sense (30ft) for up to 10 minutes.

This amazing cloak has intricately woven Wurm Scales on its exterior face. The scales opalescence's glimmers and shifts color as it
moves about. The interior face is insulated with warm Roc feathers that seem to naturally catch the faintest of breezes, leaving the
cloak to dance around the user in a dramatic, billowing fashion.

Asingle small, bright golden ring may be found along the lining. This master's mark always gleams with a soft, otherworldly glow.

Shield of Smoldering Obsidian
#2 Shield (Total AC. 4)

Heavy: 16
Minimum strength to wield this shield in combat is 16. The shield offers no benefit to those who
cannot wield it.

Fire Resistance
While equipped, you have resistance to fire damage

‘Smoldering
‘Once per day, you may cast the Fire Shield spell as an action without requiring material
components. You may only chose the ‘heated’ option when cast this way.

This massive tower shield was forged by the legendary Azer forge masters, the Golden Ring. Soot and ash
seem to continuously fail off the shield, leaving black smudges everywhere it goes. Striking the shield in
combat awakens it, unleashing bouts of flame that come pouring out of its sharp, irregular angles.

Asingle small, bright golden ring may be found near the grip. This master's mark always gleams with a
soft, otherworldly glow.

‘ShadowsScale Dragon Armor of Elemental Rage

6AC + DEX Mod {max 2)
Requires attunement.

Dragon Armor
‘Advantage on saving throws against the Frightful Presence and breath weapons of dragons.
Necrotic Resistance
Damage resistance: necrotic
Shadow Scales
Advantage on stealth roles while concealed in shadows
DRAGAR
‘Once per day, You may focus your senses to find the nearest shadow dragon within 120, or nearest
dragon of any other kind within 30mi
Aspect of the Dragon
‘When you beast shape, you may consume a Rage charge to alter your natural wildshape form into
that of a chimeric dragon. Rage counters recharge one/day at first light. Max two Rage counters
may be stored within this armor at any time.

Flight Aspect
Your beast form also grows leathery dragon wings appropriate to your new creature's size,
‘You gain flight speed equal to twice your normal movement speed. If your beast form already
had flight speed, that flight speed is instead tripled.

Terror Aspect
Your beast form grows dark and terrible, as leathery blue scales cover your body. Upon
transforming, humanoid creatures within 20ft of you must make a DC14 will save or be
terrified of you until the end of you next turn. The thick scales also grant +1 AC to your beast
form.

‘Marder Aspect
Your beast form grows exaggerated, terrifying claws. When you perform a melee attack with
‘them, your reach increases by 5ft, you gain a bonus +1 on the attack rolls, and you deal an
additional 148 slashing damage.

Breath Weapon Aspect
Your beast form grows engorged, volatile sacks of chemicals along its neck. You may cast the
Breath Weapon as per the DragonBorn racial ability, as if you were a Blue dragon.

This unique armor set was crafted by the legendary dwarven armorer, Morkral. Dark-blue dragon scales
are accented by white dragon bone and gold inlays. impossible shadows seem to dance about the scales,
darting this way and that when just out of sight.

Following travels on the Elemental Plane of Fire, this armor was further improved by the legendary Azer
forge masters, the Golden Ring. With their work applied, the true spirit of the dragon from within this
armor has emerged. The shadow's dance with barely contained animosity; the eye sockets glow with a dull
red glare. Just to don this armor takes a feat of courage.

single small, bright golden ring may be found on the lapel. This master's mark always gleams with a soft,
otherworldly glow.

#### ChatGPT Output:
# Cloak of Many Travels

**Requires attunement.**  
While wearing this cloak, you have advantage on athletic checks involving jumping, falling, or moving through sand or loose dirt.

While wearing this cloak, you may activate any of the following abilities as an action. The cloak has only one charge for these abilities that recharges daily at dawn:

- **Blazing Entrance**  
  Cast this as action as per the dimension door spell, except that you disappear and reappear in a brightly-lit burst of flames.

- **Roc Flight**  
  You gain Fly speed of 60ft for up to 10 minutes. If you are in the air when this effect ends with this cloak still equipped, you may cast Feather Fall on yourself as a reaction.

- **Wurm Tunneling**  
  You gain Burrow speed of 30ft and tremor-sense (30ft) for up to 10 minutes.

This amazing cloak has intricately woven Wurm Scales on its exterior face. The scales' opalescence glimmers and shifts color as it moves about. The interior face is insulated with warm Roc feathers that seem to naturally catch the faintest of breezes, leaving the cloak to dance around the user in a dramatic, billowing fashion.

A single small, bright golden ring may be found along the lining. This master's mark always gleams with a soft, otherworldly glow.

# Shield of Smoldering Obsidian

**+2 Shield (Total AC: 4)**

- **Heavy:** 16  
  Minimum strength to wield this shield in combat is 16. The shield offers no benefit to those who cannot wield it.

- **Fire Resistance**  
  While equipped, you have resistance to fire damage.

- **Smoldering**  
  Once per day, you may cast the Fire Shield spell as an action without requiring material components. You may only choose the 'heated' option when cast this way.

This massive tower shield was forged by the legendary Azer forge masters, the Golden Ring. Soot and ash seem to continuously fall off the shield, leaving black smudges everywhere it goes. Striking the shield in combat awakens it, unleashing bouts of flame that come pouring out of its sharp, irregular angles.

A single small, bright golden ring may be found near the grip. This master's mark always gleams with a soft, otherworldly glow.

# ShadowsScale Dragon Armor of Elemental Rage

**6 AC + DEX Mod (max 2)**  
**Requires attunement.**

- **Dragon Armor**  
  Advantage on saving throws against the Frightful Presence and breath weapons of dragons.

- **Necrotic Resistance**  
  Damage resistance: necrotic.

- **Shadow Scales**  
  Advantage on stealth roles while concealed in shadows.

- **DRAGAR**  
  Once per day, You may focus your senses to find the nearest shadow dragon within 120, or nearest dragon of any other kind within 30mi.

- **Aspect of the Dragon**  
  When you beast shape, you may consume a Rage charge to alter your natural wildshape form into that of a chimeric dragon. Rage counters recharge one/day at first light. Max two Rage counters may be stored within this armor at any time.

  - **Flight Aspect**  
    Your beast form also grows leathery dragon wings appropriate to your new creature's size, You gain flight speed equal to twice your normal movement speed. If your beast form already had flight speed, that flight speed is instead tripled.

  - **Terror Aspect**  
    Your beast form grows dark and terrible, as leathery blue scales cover your body. Upon transforming, humanoid creatures within 20ft of you must make a DC14 will save or be terrified of you until the end of your next turn. The thick scales also grant +1 AC to your beast form.

  - **Marder Aspect**  
    Your beast form grows exaggerated, terrifying claws. When you perform a melee attack with them, your reach increases by 5ft, you gain a bonus +1 on the attack rolls, and you deal an additional 1d8 slashing damage.

  - **Breath Weapon Aspect**  
    Your beast form grows engorged, volatile sacks of chemicals along its neck. You may cast the Breath Weapon as per the DragonBorn racial ability, as if you were a Blue dragon.

This unique armor set was crafted by the legendary dwarven armorer, Morkral. Dark-blue dragon scales are accented by white dragon bone and gold inlays. Impossible shadows seem to dance about the scales, darting this way and that when just out of sight.

Following travels on the Elemental Plane of Fire, this armor was further improved by the legendary Azer forge masters, the Golden Ring. With their work applied, the true spirit of the dragon from within this armor has emerged. The shadows dance with barely contained animosity; the eye sockets glow with a dull red glare. Just to don this armor takes a feat of courage.

A single small, bright golden ring may be found on the lapel. This master's mark always gleams with a soft, otherworldly glow.

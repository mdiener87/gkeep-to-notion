# Tyr's Blade of Judgement and Redemption

    **Created:** 2022-10-27 19:32:29  
    **Last Edited:** 2022-10-27 19:32:41  
    **Labels:** D&D Items & Monster Stats  

    ---

    ## Note Content (HTML)

The blade of this weapon emits a warm light while drawn, extending bright light out 30ft from you, and dim light for an additional 30ft. 

This weapon strikes for +2d6 radiant damage on hit. 
Against fiends and undead monsters, this weapon strikes for +2d8 radiant damage instead. 

Once per long rest, you may choose either Judgement or Redemption. This empowers the blade with the chosen ability, which remains active until replaced.

Judgement:
Allies (including you) within a 30-foot radius around you strike for +1d4 radiant damage. Against fiends and undead monsters, those allies strike for +1d6 radiant damage instead.

Redemption:
Allies (including you) who end their turn within a 30-foot radius of you may choose to regain 1d4 hit points as a free action, or regain 1d6 hit points as a reaction.

=====
The Megged Blade, the namesake weapon of Orc Warchief Shaggon Megged, was once a brutal and terrifying weapon of war. Victims of this weapon found their souls trapped and consumed within the blade, empowering it to ever greater evils. After years of savagery, this weapon's legacy of terror was at last brought to an end by a valourous act. Channeling the judgement of Tyr, the Paladin Gandus purified the blade, freeing its lost souls and banishing the Pit Fiend at the weapon's core. Through this act of valor, Tyr has blessed the blade, that it might yet redeem itself in battle and deed.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Radiant Eclipse, Sword of Eilistraee

    **Created:** 2023-08-03 19:49:42  
    **Last Edited:** 2023-08-10 19:50:08  
    **Labels:** D&D Items & Monster Stats  

    ---

    ## Note Content (HTML)

Radiant Eclipse, Sword of Eilistraee
Weapon (shortsword), Legendary (requires attunement)

Properties:

+3 Weapon, 1D6+3 Slashing Damage

When you attune to Radiant Eclipse, choose two command words. The first invokes the power of Fire. The second, Shadow.

When you draw Radiant Eclipse, you may choose to invoke its Fire command word to empower the blade for the next hour. It gains the following effects and abilities:

Damage Increase: +2D6 Fire damage, +1D6 Necrotic damage

Moonshadow Flame:
Once per Short Rest, you may activate Moonshadow Flame as a bonus action. Until end of turn, Radiant Eclipse gains Reach, increasing its range by 5ft. Additionally, if you critically strike your target with Moonshadow Flame active, it must make a DC 20 Constitution Saving throw. On failure, that creatures takes an additional 8d6 fire damage and 8d6 shadow damage. On success, the creatures saves for half that additional damage.

Nightfall's Balance:
Once per Long Rest, you may activate Nightfall's Balance as a bonus action. You immediately gain all of the benefits of Moonshadow Flame. Additionally, whenever you kill a creature during this turn, you gain temporary hit points equal to half of the total Fire and Necrotic damage you dealt to that creature this turn from Radiant Eclipse (including Moonshadow Flame). 



When you draw Radiant Eclipse, you may instead choose to invoke its Shadow command word to empower the blade for the next hour. It gains the following effects and abilities:

Damage Increase: +1D6 Fire damage, +2D6 Necrotic damage

Shadow Step:
Once per Short Rest, you may activate Shadow Step as a bonus action. You and any carried equipment teleport up to 30 feet to an unoccupied space that you can see. If both you and the targeted space are both in dim light or darkness, the maximum range is increased by 15ft. Upon arriving at the destination, shadows coalesce around you, granting advantage on your next attack roll. 

Dawn's Embrace:
Once per Long Rest, you may activate Nightfall's Balance as a bonus action. You immediately Shadow Step. Additionally, until the start of your next turn, you gain Darkvision out to 45ft. You may also see invisible creatures, and into the Ethereal Realm, out to 45ft.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
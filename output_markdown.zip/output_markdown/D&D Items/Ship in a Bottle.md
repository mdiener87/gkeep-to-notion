# Ship in a Bottle

    **Created:** 2021-10-29 11:36:24  
    **Last Edited:** 2021-10-29 11:36:29  
    **Labels:** D&D 2020, D&D Items & Monster Stats  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Legendary Item

‘Once per week, you may invoke the inscription on this bottle to teleport yourself, and up to 7 willing nearby creatures
(within a 20ft radius of the bottle)., to the Astral Ship Endimyon. Located within the Astral Plane, this ship may be used
to explore the far outer reaches of the cosmos.

Ship in a Bottle cannot be placed within a bag of holding. Forcibly doing so will destroy both Ship in a Bottle and the bag,
inflicting 12010 force damage to each object and nearby creatures within 10ft (DC 20 Dexterity for half damage).

Upon activation, the bottle will Featherfail to the ground.

World ina Bottle

Legendary Item

‘Once per week, you may invoke the inscription on this bottle to teleport yourself, and up to 7 willing nearby creatures,
from the Astral Ship Endimyon and back to wherever Ship in o Bottle is currently located.

World in o Bottle cannot be placed within a bag of holding. Forcibly doing so will destroy both World in a Bottle and the
bag, inflicting 12d10 force damage to each abject and nearby creatures within 10ft (DC 20 Dexterity for half damage).

World in o Bottle is built into the wall within the captains quarters of the Endimyon.

Astral Ship Endimyon

Legendary Vessel

‘A young Galtorah's personal vessel, The Astral Ship Endimyon was built to explore the outer edges of the cosmos. The
ship is partially living, grown from an Astral King's Tree seed. Endimyon recognizes whomever teleports aboard the
vessel through the linked Ship and World Bottles as its implicit captain. The tree responds to requests using Persusaion,
and can help navigate the Astral cosmsos with its ancient knowledge. The ship may be manually helmed, using Dexterity
to control the vessel.

#### ChatGPT Output:
### Legendary Item

- **Ship in a Bottle**

  `Once per week, you may invoke the inscription on this bottle to teleport yourself, and up to 7 willing nearby creatures (within a 20ft radius of the bottle), to the Astral Ship Endimyon. Located within the Astral Plane, this ship may be used to explore the far outer reaches of the cosmos.`

  **Ship in a Bottle** cannot be placed within a bag of holding. Forcibly doing so will destroy both **Ship in a Bottle** and the bag, inflicting 120d10 force damage to each object and nearby creatures within 10ft (DC 20 Dexterity for half damage).

  Upon activation, the bottle will Featherfall to the ground.

### Legendary Item

- **World in a Bottle**

  `Once per week, you may invoke the inscription on this bottle to teleport yourself, and up to 7 willing nearby creatures, from the Astral Ship Endimyon and back to wherever Ship in a Bottle is currently located.`

  **World in a Bottle** cannot be placed within a bag of holding. Forcibly doing so will destroy both **World in a Bottle** and the bag, inflicting 12d10 force damage to each object and nearby creatures within 10ft (DC 20 Dexterity for half damage).

  **World in a Bottle** is built into the wall within the captain's quarters of the Endimyon.

### Legendary Vessel

- **Astral Ship Endimyon**

  `A young Galtorah's personal vessel, The Astral Ship Endimyon was built to explore the outer edges of the cosmos. The ship is partially living, grown from an Astral King's Tree seed. Endimyon recognizes whomever teleports aboard the vessel through the linked Ship and World Bottles as its implicit captain. The tree responds to requests using Persuasion, and can help navigate the Astral cosmos with its ancient knowledge. The ship may be manually helmed, using Dexterity to control the vessel.`

# The Megged Blade

    **Created:** 2022-10-15 15:56:23  
    **Last Edited:** 2022-10-15 16:00:19  
    **Labels:** D&D Items & Monster Stats  

    ---

    ## Note Content (HTML)

+3 Greatsword 2d8 + 3  + 2d6 necrotic damage + (0-6) necrotic damage

Two handed, heavy, exploding critical, soul harvest, curse of the berserker, attuned item

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The Megged Blade
43 Greatsword (2d8 + 3)

Two handed, heavy, Exploding Critical, Soul Harvest, Curse of the Berserker

Exploding Critical
When you critically strike with this weapon, it adds an additional 1D8 damage to the critical damage roll

Soul Harvest

Whenever you kill a creature with this weapon, it gains a Soul charge. You have an additional +1 bonus on your damage
rolls with this weapon for every Soul charge. The Megged blade loses a soul charge daily at dawn, and may not store
more than 5 Soul charges at once (for a maximum 45 bonus from this effect). Killing creatures in this way may bend your
alignment towards evil.

Berserker's Curse

This weapon is Cursed, and becoming attuned to it extends the curse to you. As long as you remain Cursed, you are
unwilling to part with the weapon, keeping it within reach at all times. You also have disadvantage on Attack rolls with
Weapons other than this one, unless no foe is within 60 feet of you that you can see or hear.

Whenever you deal damage to, or take damage from, a creature while this weapon is in your possession, you must
succeed on a DC 15 Wisdom saving throw or go berserk. While berserk, you must use your action each round to Attack
the creature nearest to you with the cursed weapon. If you can make extra attacks as part of the Attack action, you use
those extra attacks, moving to Attack the next nearest creature after you fell your current target. If you have multiple
possible Targets, you Attack one at random. You are berserk until you start Your Turn with no creatures within 60 feet of
you that you can see or hear.

Wicked and evil, stained dark with countless victims blood. Holding this immense weapon in your hands gives you a
palpable sense of power and violence - as if all before you are sheep for the slaughter.

#### ChatGPT Output:
### The Megged Blade
**43 Greatsword (2d8 + 3)**

- Two handed, heavy
- Exploding Critical
- Soul Harvest
- Curse of the Berserker

#### Exploding Critical
When you critically strike with this weapon, it adds an additional 1D8 damage to the critical damage roll.

#### Soul Harvest
Whenever you kill a creature with this weapon, it gains a Soul charge. You have an additional +1 bonus on your damage rolls with this weapon for every Soul charge. The Megged blade loses a soul charge daily at dawn, and may not store more than 5 Soul charges at once (for a maximum +5 bonus from this effect). Killing creatures in this way may bend your alignment towards evil.

#### Berserker's Curse
This weapon is Cursed, and becoming attuned to it extends the curse to you. As long as you remain Cursed, you are unwilling to part with the weapon, keeping it within reach at all times. You also have disadvantage on Attack rolls with Weapons other than this one, unless no foe is within 60 feet of you that you can see or hear.

Whenever you deal damage to, or take damage from, a creature while this weapon is in your possession, you must succeed on a DC 15 Wisdom saving throw or go berserk. While berserk, you must use your action each round to Attack the creature nearest to you with the cursed weapon. If you can make extra attacks as part of the Attack action, you use those extra attacks, moving to Attack the next nearest creature after you fell your current target. If you have multiple possible Targets, you Attack one at random. You are berserk until you start Your Turn with no creatures within 60 feet of you that you can see or hear.

Wicked and evil, stained dark with countless victims' blood. Holding this immense weapon in your hands gives you a palpable sense of power and violence - as if all before you are sheep for the slaughter.
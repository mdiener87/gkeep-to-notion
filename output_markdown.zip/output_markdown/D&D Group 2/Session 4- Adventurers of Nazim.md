# Session 4- Adventurers of Nazim

    **Created:** 2021-10-29 11:44:35  
    **Last Edited:** 2021-10-29 11:44:42  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘With our hero's arriving in Nazim, they have completed their first contract. Now, its time they properly make a name for
themselves as adventurers by interacting with the folk around the city. Along the way, they'll earn more of the state of
this world.

Major problem for Nazim: Monster incursions! The monsters are growing more bold, even attacking the garison at
times. Something must be done. They'll hear rumors of a witch causing problems deep in the swamp marshes around
Nazim. Henry, of "Henry's Fine Wares", wants to contract them to recover a stash of gear he was hoping to sell in town.
Lady Kasumi runs a fortune telling booth near Henry's shop and always overhears / manages to intrude at the right
moment in his life, She is a Hag witch in disguise and been the point runner of a Hag Coven deep in the swamp.

Monster encounters:
Blights (32)
Khou-Tou

[Beasts]

Shadows

Bullywugs (35)
Lizardfolk (204)
Stirge (284)
Cockatrice (42)
Harpy (181)

Dryads (neutral encounter, barter or fight)
Fungus (138) and Myconids (230)

will

-wisp (leads to quicksand pit trap)

Hags (177)

World Problem: Emergent Monsters

‘Something is causing the monsters of the world to become particularly numierous and aggressive. The
Sinnodel swamps were always dangerous, but rarely did entire trade caravans get wiped out! Now it
‘seems to be an all too common occurrence.

‘The kingdom of Primos was founded in a time of such upheavels. Uniting disparate city-states of
Humans, Elves, and Dwarves, it successfully forged a united, cosmopolitan kingdom that could stand
against monsters. After years of battles, peace finally came to the kingdom, and a dwarven king found.
himself in charge of surface dwelling cities for the first time,

This arrangement would not prove wholly politically stable. Now, 300 years later, the kingdom finds
itself under similar circumstances. Lord Steelfist is struggling to maintain political cohesion of the
political settlements, which come under increasing monster attack. The Primos Army finds itself
stretched thin, seemingly surrounded by an enemy that it cannot strike back at.

Witch Coven:
6 Hags
Forward Scout: Lady Kasumi
Leader
4x others undeclared

Lady Kasumi has a hovel in the swap. She will be the boss for tonight and set up the stage for fighting
tthe full witches koven on the next session.

#### ChatGPT Output:
'With our hero's arriving in Nazim, they have completed their first contract. Now, its time they properly make a name for
themselves as adventurers by interacting with the folk around the city. Along the way, they'll earn more of the state of
this world.

Major problem for Nazim: Monster incursions! The monsters are growing more bold, even attacking the garrison at
times. Something must be done. They'll hear rumors of a witch causing problems deep in the swamp marshes around
Nazim. Henry, of "Henry's Fine Wares", wants to contract them to recover a stash of gear he was hoping to sell in town.
Lady Kasumi runs a fortune telling booth near Henry's shop and always overhears / manages to intrude at the right
moment in his life, She is a Hag witch in disguise and been the point runner of a Hag Coven deep in the swamp.

Monster encounters:
- Blights (32)
- Khou-Tou

[Beasts]
- Shadows
- Bullywugs (35)
- Lizardfolk (204)
- Stirge (284)
- Cockatrice (42)
- Harpy (181)

- Dryads (neutral encounter, barter or fight)
- Fungus (138) and Myconids (230)

- Will-o-wisp (leads to quicksand pit trap)

- Hags (177)

World Problem: Emergent Monsters

'Something is causing the monsters of the world to become particularly numerous and aggressive. The
Sinnodel swamps were always dangerous, but rarely did entire trade caravans get wiped out! Now it
seems to be an all too common occurrence.

The kingdom of Primos was founded in a time of such upheavals. Uniting disparate city-states of
Humans, Elves, and Dwarves, it successfully forged a united, cosmopolitan kingdom that could stand
against monsters. After years of battles, peace finally came to the kingdom, and a dwarven king found
himself in charge of surface dwelling cities for the first time,

This arrangement would not prove wholly politically stable. Now, 300 years later, the kingdom finds
itself under similar circumstances. Lord Steelfist is struggling to maintain political cohesion of the
political settlements, which come under increasing monster attack. The Primos Army finds itself
stretched thin, seemingly surrounded by an enemy that it cannot strike back at.

Witch Coven:
- 6 Hags
- Forward Scout: Lady Kasumi
- Leader
- 4x others undeclared

Lady Kasumi has a hovel in the swamp. She will be the boss for tonight and set up the stage for fighting
the full witches coven on the next session.'

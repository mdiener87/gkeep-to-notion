# Session 15 - The Cultists Lair, pt 2

    **Created:** 2021-10-29 11:46:41  
    **Last Edited:** 2021-10-29 11:46:51  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Party continued their adventure into the cultits's dungeon. They cleared several more raoms and are now outside the
boss’ chamber at the close of the session (refer to map notes). They rescued a high-elf NPC (refer to NPC workbook)
whose family is a founding member of the Mage's Crafts Guild in the Elven city to the far north.

#### ChatGPT Output:
Party continued their adventure into the cultists' dungeon. They cleared several more rooms and are now outside the
boss' chamber at the close of the session (refer to map notes). They rescued a high-elf NPC (refer to NPC workbook)
whose family is a founding member of the Mage's Crafts Guild in the Elven city to the far north.

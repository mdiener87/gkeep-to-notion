# Session 16 - The Prince of Nazim

    **Created:** 2021-10-29 11:46:54  
    **Last Edited:** 2021-10-29 11:47:01  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘See Map notes for boss fight.

Loot from salamander + high priest fight:

‘Wicked Ceromonial Blade +1 of concentration (+2 on concetration checks, casts as casting focus)
Robe of Eyes (priests chambers)

Flame Diamond (alchemical component, 300g value if sold)

Demonic Wind Fan (as normal, but demonic whispers echo through the gust of wind)

426, 806, 186

#### ChatGPT Output:
'See Map notes for boss fight.

Loot from salamander + high priest fight:

- 'Wicked Ceremonial Blade +1 of concentration (+2 on concentration checks, casts as casting focus)
- Robe of Eyes (priest's chambers)
- Flame Diamond (alchemical component, 300g value if sold)
- Demonic Wind Fan (as normal, but demonic whispers echo through the gust of wind)

426, 806, 186

# Session 21 - Spreading Corruption

    **Created:** 2021-10-29 11:47:51  
    **Last Edited:** 2021-10-29 11:47:56  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The Corpse Flower has spread pollen far and wide. While the foul undead plant thing was eventually felled, its
corruption has spread throughout the land... and into the Etheral Tear. This tear, with its constantly shifting corridors, is
a maze of damned creatures. Those that have made contact with a spore become enraged, increasing their damage and
potential to hit.

Meanwhile, the Governor is very worried about the situation. The people have filed complaints, and some #FakeNews is
spreading that the Player Party is responsible! The Governor still believes in Sir Girithinvar, but if people think he made a
mistake, he might be forced to dismiss him as a Staff member.

Jocelyn was caught out by a beserking ghost in her last trip through the Ethereal tear. She has her latest infusoin of
magic and energy, but is growing concerned about where this is all heading. Will the PC Party displace her as most
trusted advisor? Will she lose access to the magical energy source she relies on?

Ethereal Tunnel: Random Maze of shifting corrirdors and mobs. Resets at first light every day. Connects to the Shadow
Realm, where an Obelisk of Dispater resides within an upside-down version of Nazim.

‘Armor Upgrades:

Gnomish Engineering Upgrade - Adamantium Armor

Mecha-Engineering adds a +1 Str Modifier while equipped

‘Asa bonus action, may consume a Rocket Jump charge to jump 15ft forward of any combination of
vertical or horizontal movement {but most consume all 15ft of movement). The Armor can store up to
one Rocket Jump charge at any given time. Once consumed, it may be reloaded on a Short or Long rest,
consuming 206P of black powder and 806P of high-grade machine oil.

‘You have disadvantage on Stealth and Acrobatics checks while wearing this armor.

Damacous: Snake Scale Leather Armor

‘You gain resistance to Poison Damage while wearing this armor.
#1 AC rating

‘Advantage on stealth checks in swamp environments

#### ChatGPT Output:
'The Corpse Flower has spread pollen far and wide. While the foul undead plant thing was eventually felled, its
corruption has spread throughout the land... and into the Ethereal Tear. This tear, with its constantly shifting corridors, is
a maze of damned creatures. Those that have made contact with a spore become enraged, increasing their damage and
potential to hit.

Meanwhile, the Governor is very worried about the situation. The people have filed complaints, and some #FakeNews is
spreading that the Player Party is responsible! The Governor still believes in Sir Girithinvar, but if people think he made a
mistake, he might be forced to dismiss him as a Staff member.

Jocelyn was caught out by a berserking ghost in her last trip through the Ethereal Tear. She has her latest infusion of
magic and energy, but is growing concerned about where this is all heading. Will the PC Party displace her as most
trusted advisor? Will she lose access to the magical energy source she relies on?

Ethereal Tunnel: Random Maze of shifting corridors and mobs. Resets at first light every day. Connects to the Shadow
Realm, where an Obelisk of Dispater resides within an upside-down version of Nazim.

'Armor Upgrades:

- Gnomish Engineering Upgrade - Adamantium Armor
  - Mecha-Engineering adds a +1 Str Modifier while equipped
  - As a bonus action, may consume a Rocket Jump charge to jump 15ft forward of any combination of
    vertical or horizontal movement (but must consume all 15ft of movement). The Armor can store up to
    one Rocket Jump charge at any given time. Once consumed, it may be reloaded on a Short or Long rest,
    consuming 20GP of black powder and 80GP of high-grade machine oil.
  - You have disadvantage on Stealth and Acrobatics checks while wearing this armor.

- Damascous: Snake Scale Leather Armor
  - You gain resistance to Poison Damage while wearing this armor.
  - #1 AC rating
  - Advantage on stealth checks in swamp environments

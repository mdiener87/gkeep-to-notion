# Session 9 - Leveling up in Adventure

    **Created:** 2021-10-29 11:45:35  
    **Last Edited:** 2021-10-29 11:45:40  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
This session will likely start with the player's exploring Nazim from a shopping perspective. So far, we only have Henry as
vaguely important NPCs go, so we needed to round out that roster some.

Nazim is a port community, so it's time the players meet the commander of the guard and the growing problems facing
the kingdom: these evil obelisks that are growing in influence and power.

Need to create a better world map..

After some shopping, the players will probably start searching for the new plot threads. This should be found through
their Obelisk connection, which they can investigate to learn more about the world. The destruction of the Sinnodel
‘Swamp obelisk is clear proof of the player's aptitute, and has ingratiated them with the town once they learn of the
deed, Similarly, the Trade Guild has new offers of employment, in competitoin with the Thieves Guild.

‘The Nazim Clearical society can identify the oblisk and give them info about the world.
Black Rose members exist in Nazim and are watching closely... who knows, maybe an assassination attempt is in order?
But nothing so obvious as a hit job - release some monster onto them instead.

Combat potential:

Dungeon Potential:
‘There is a dungeon under Nazim, part of the old city. The BRS has used this dungeon as a base of
operations for years, and might try to lure the players into an unfortunate demise here...

Outcome:
Players encountered an Etin looking for the witches in the swamp. After some back and forth deception,
they ended up facing it when it went to kill the remaining militia members in the swamp. The players
bravely stepped in and easily downed the Etin, saving Commander Lance and her troops.

An Earth elemental was triggered from this fight, and using telepathy the players convinced it they were
friends. At least, until they showed it the remains of the obelisk. The voice of DIS spoke to it, and
enraged the elemental. They had to quiclky destroy the rebuilt obelisk to end its insanity. In the end,
they were able to defeat this without further combat.

Loot: bag of beans
After returning to Nazim, the PCs decided to investigate Lady Kasumi's shop. There, they met the leader
of the Witch Coven, a night hag, A battle ensued, and it was forced to escape with a plane shift spell to

one of the layers of hell. Leaving a raom full of loot!

Loot: wand of the war mage +1, rapier +1, Silver Raven (figurine of wonderous power)

#### ChatGPT Output:
This session will likely start with the player's exploring Nazim from a shopping perspective. So far, we only have Henry as
vaguely important NPCs go, so we needed to round out that roster some.

Nazim is a port community, so it's time the players meet the commander of the guard and the growing problems facing
the kingdom: these evil obelisks that are growing in influence and power.

Need to create a better world map..

After some shopping, the players will probably start searching for the new plot threads. This should be found through
their Obelisk connection, which they can investigate to learn more about the world. The destruction of the Sinnodel
Swamp obelisk is clear proof of the player's aptitude, and has ingratiated them with the town once they learn of the
deed. Similarly, the Trade Guild has new offers of employment, in competition with the Thieves Guild.

The Nazim Clerical society can identify the obelisk and give them info about the world.
Black Rose members exist in Nazim and are watching closely... who knows, maybe an assassination attempt is in order?
But nothing so obvious as a hit job - release some monster onto them instead.

**Combat potential:**

**Dungeon Potential:**
There is a dungeon under Nazim, part of the old city. The BRS has used this dungeon as a base of
operations for years, and might try to lure the players into an unfortunate demise here...

**Outcome:**
Players encountered an Etin looking for the witches in the swamp. After some back and forth deception,
they ended up facing it when it went to kill the remaining militia members in the swamp. The players
bravely stepped in and easily downed the Etin, saving Commander Lance and her troops.

An Earth elemental was triggered from this fight, and using telepathy the players convinced it they were
friends. At least, until they showed it the remains of the obelisk. The voice of DIS spoke to it, and
enraged the elemental. They had to quickly destroy the rebuilt obelisk to end its insanity. In the end,
they were able to defeat this without further combat.

**Loot:** bag of beans
After returning to Nazim, the PCs decided to investigate Lady Kasumi's shop. There, they met the leader
of the Witch Coven, a night hag. A battle ensued, and it was forced to escape with a plane shift spell to

one of the layers of hell. Leaving a room full of loot!

**Loot:** wand of the war mage +1, rapier +1, Silver Raven (figurine of wondrous power)

# Session 12 - The Fanciest Ball

    **Created:** 2021-10-29 11:46:08  
    **Last Edited:** 2021-10-29 11:46:15  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Refer to phone for notes. Assassination attempt on the governor during the galla, will reveal one way or the other a
hidden basement entrance that leads to sewers / eventually to the BRS base of operations.

Result:
Ho boy.

‘The party got ready for the galla and eventually made their way in. The BRS assassin made his move and
tried to kill the Governor. Sir girithivair was able to save his life after the assassin botched his initial
saves. This greatly impressed Lance Pristol and she finally slept with him!

Meanwhile Merias was somewhat forcibly seduced by Visir Jocelyn.

‘The group was able to find a secret entrance to the Nazim Sewers, and that's where we will open today.

#### ChatGPT Output:
Refer to phone for notes. Assassination attempt on the governor during the galla, will reveal one way or the other a
hidden basement entrance that leads to sewers / eventually to the BRS base of operations.

Result:
Ho boy.

'The party got ready for the galla and eventually made their way in. The BRS assassin made his move and
tried to kill the Governor. Sir girithivair was able to save his life after the assassin botched his initial
saves. This greatly impressed Lance Pristol and she finally slept with him!

Meanwhile Merias was somewhat forcibly seduced by Visir Jocelyn.

'The group was able to find a secret entrance to the Nazim Sewers, and that's where we will open today.'

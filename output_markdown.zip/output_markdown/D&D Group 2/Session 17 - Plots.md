# Session 17 - Plots

    **Created:** 2021-10-29 11:47:04  
    **Last Edited:** 2021-10-29 11:47:09  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, there are a few plot threads that are likely to be pursued —

Berrian is at the Governor's manor, telling brave tells of (somewhat creepy) heroism of Sir Girthivar and his,
compatriots. He also has intel from the cultists - the cult was working to find the missing Obelisk of Dis within the
City of Nazim. The cult was surprised this one was proving so elusive to locate,

‘The reason it can't be readily located is that Visir Jocelyn is busy using it to power her magic. While she isn't super
evil in terms of ambition, she is selfish in that she seeks to use the power of the Obelisk to make her the greatest

wizard and advisor to the queen herself. Dispater is quite pleased with this, as his evil slowly seeps into her spells
and leads her soul towards greater damnation.

Flame Diamond - could be used to craft or upgrade armor with a sufficent roll

Governor Donkil is quite impressed at the adventurer's ability to save him and stop evil. He wants to hire them as
his permenant guild,

‘The Mage's Crafts Guild will be grateful to learn of the safe rescue of their prodigal child.

‘The party's patrons are pleased with their performance, and can reward with warnings af plots.

Result:
Governor Donkil offered the PCs a {currently defunct) keep as their own permeant headquarters in Nazim.
‘Whereupon they discovered the abandoned Keep had been used as a smuggler's drop off point, and was in active
use bya shady group who were storing a troll there! Ultimately the PCs let the smugglers go and killed the troll.
‘They are very interested in finding out who in the Trade Guild wants a live troll - and for what purpose.

Jocelyn and Berrian could not be directly interrogated. .as they were busy banging. Awk.
Sir Girthivair gat hammered with Donkil, and they are becoming good friends.

‘The mystery of the second Obelisk of Evil is stil to be resolved...

#### ChatGPT Output:
Coming into this session, there are a few plot threads that are likely to be pursued —

- Berrian is at the Governor's manor, telling brave tales of (somewhat creepy) heroism of Sir Girthivar and his compatriots. He also has intel from the cultists - the cult was working to find the missing Obelisk of Dis within the City of Nazim. The cult was surprised this one was proving so elusive to locate.

- The reason it can't be readily located is that Visir Jocelyn is busy using it to power her magic. While she isn't super evil in terms of ambition, she is selfish in that she seeks to use the power of the Obelisk to make her the greatest wizard and advisor to the queen herself. Dispater is quite pleased with this, as his evil slowly seeps into her spells and leads her soul towards greater damnation.

- Flame Diamond - could be used to craft or upgrade armor with a sufficient roll.

- Governor Donkil is quite impressed at the adventurer's ability to save him and stop evil. He wants to hire them as his permanent guild.

- The Mage's Crafts Guild will be grateful to learn of the safe rescue of their prodigal child.

- The party's patrons are pleased with their performance, and can reward with warnings of plots.

**Result:**
Governor Donkil offered the PCs a (currently defunct) keep as their own permanent headquarters in Nazim.
Whereupon they discovered the abandoned Keep had been used as a smuggler's drop off point, and was in active use by a shady group who were storing a troll there! Ultimately the PCs let the smugglers go and killed the troll.
They are very interested in finding out who in the Trade Guild wants a live troll - and for what purpose.

- Jocelyn and Berrian could not be directly interrogated as they were busy being intimate. Awk.
- Sir Girthivar got hammered with Donkil, and they are becoming good friends.

- The mystery of the second Obelisk of Evil is still to be resolved...

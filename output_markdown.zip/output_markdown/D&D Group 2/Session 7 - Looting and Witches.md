# Session 7 - Looting and Witches

    **Created:** 2021-10-29 11:45:15  
    **Last Edited:** 2021-10-29 11:45:22  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
On the previous scene, the PCs snuck up on Kasumi's hut by rolling to navigate the swamp .They then launched a
surprise attack on her, and she summoned Khu-Tou to defend herself. A pitched battle ensued, leaving an injured - but
victorious - party standing astride a number of dead Khu-Tou. They have not loated or explored anything yet, so that's
where we will start. They will likely discover the witch lair underneath the cabin, leading into the true dungeon,

Result: Players dived into the caves beneath the witch's lair and begun exploring. They've made it
‘through the large cavern of enslaved mushrooms, and faced the Matriarch Khou-Tou. They need to loot
‘the room and beat the remaining dungeon

Hag Alchemical Loat: Khu-Tou Loot:
Potion of animal friendship Tgp

Potion of healing ‘Small Marble figurine of a Dwarf (50g value)
Potion of greater healing axConch

Hag's Weapon Poison Vial
:1d6 poison contact damage

Hag Loot:
Lightening Javelin
2x small diamonds (100g value each)

Hag's Exploding Poison Vial
Make a ranged attack against your chosen target within thrown weapon range. The vial explodes
on contact, spreading poisonous gas across a 10ft radius sphere. The gas lingers for 2 rounds.
Creatures hit by or that that enter the gas must make a DC14 con save or take 1d6 damage and be
poisoned.

#### ChatGPT Output:
On the previous scene, the PCs snuck up on Kasumi's hut by rolling to navigate the swamp. They then launched a
surprise attack on her, and she summoned Khu-Tou to defend herself. A pitched battle ensued, leaving an injured - but
victorious - party standing astride a number of dead Khu-Tou. They have not looted or explored anything yet, so that's
where we will start. They will likely discover the witch lair underneath the cabin, leading into the true dungeon.

**Result:** Players dived into the caves beneath the witch's lair and begun exploring. They've made it
through the large cavern of enslaved mushrooms, and faced the Matriarch Khou-Tou. They need to loot
the room and beat the remaining dungeon.

**Hag Alchemical Loot:**
- Potion of animal friendship
- Potion of healing
- Potion of greater healing
- Hag's Weapon Poison Vial
  - 1d6 poison contact damage

**Khu-Tou Loot:**
- Small Marble figurine of a Dwarf (50g value)
- Conch

**Hag Loot:**
- Lightening Javelin
- 2x small diamonds (100g value each)

**Hag's Exploding Poison Vial**
- Make a ranged attack against your chosen target within thrown weapon range. The vial explodes
  on contact, spreading poisonous gas across a 10ft radius sphere. The gas lingers for 2 rounds.
  Creatures hit by or that enter the gas must make a DC14 con save or take 1d6 damage and be
  poisoned.

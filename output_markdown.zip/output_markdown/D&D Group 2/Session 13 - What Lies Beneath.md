# Session 13 - What Lies Beneath

    **Created:** 2021-10-29 11:46:18  
    **Last Edited:** 2021-10-29 11:46:22  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Dungeon Crawl! The sewers need to be cleared and explored before they can open the entrance to the black rose Result: After some careful exploration and fun moments, the party found the entrance to the cultist
society secret lair. We will see how far we get with all that today. hidden base. Had to defeat giant spiders, swarms of snakes, and a Bearded Devil guarding the entrace.

#### ChatGPT Output:
Dungeon Crawl! The sewers need to be cleared and explored before they can open the entrance to the black rose Result: After some careful exploration and fun moments, the party found the entrance to the cultist society secret lair. We will see how far we get with all that today. hidden base. Had to defeat giant spiders, swarms of snakes, and a Bearded Devil guarding the entrance.

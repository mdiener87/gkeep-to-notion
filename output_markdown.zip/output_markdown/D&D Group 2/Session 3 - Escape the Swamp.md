# Session 3 - Escape the Swamp

    **Created:** 2021-10-29 11:44:25  
    **Last Edited:** 2021-10-29 11:44:30  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming in today the players are getting better at their chrachters, and have advanced to level 2. We will need to double
check that everyone leveled up correctly to start. Narratively, this is the third day that they've been traveling through
the Siannodel Swamps.

Story todo:

siannodel Swamps

This vast expanse of marshes and swamps extends south of the Nailo Forests. This vast expanse of
‘swamps is poorly mapped and considered highly dangerous. The Siannodel Swamps separates the port
city of Nazim from the rest of the kingdom. The nearest city, Caspar, is a large agricultural community.

‘A paved road is under consideration, but monster attacks have thwarted its construction. without a
designated road, travelers are forced to find their own way between the two communities.

City of Nazim

This port community dates back to the first Era of the kingdom, back when the Kingdom was ruled by
Elves. The old city still has touches of Elvish architecture, but most of the rest is clearly human in design
and population.

#### ChatGPT Output:
Coming in today the players are getting better at their characters, and have advanced to level 2. We will need to double
check that everyone leveled up correctly to start. Narratively, this is the third day that they've been traveling through
the Siannodel Swamps.

Story todo:

### Siannodel Swamps

This vast expanse of marshes and swamps extends south of the Nailo Forests. This vast expanse of
swamps is poorly mapped and considered highly dangerous. The Siannodel Swamps separates the port
city of Nazim from the rest of the kingdom. The nearest city, Caspar, is a large agricultural community.

A paved road is under consideration, but monster attacks have thwarted its construction. Without a
designated road, travelers are forced to find their own way between the two communities.

### City of Nazim

This port community dates back to the first Era of the kingdom, back when the Kingdom was ruled by
Elves. The old city still has touches of Elvish architecture, but most of the rest is clearly human in design
and population.

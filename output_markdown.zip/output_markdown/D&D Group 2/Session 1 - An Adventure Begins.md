# Session 1 - An Adventure Begins

    **Created:** 2021-10-29 11:44:07  
    **Last Edited:** 2021-10-29 11:44:12  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Only Joseph has played dungeons and dragons before. So we need to introduce everyone to how actions work, Kingdom of Primos
interacting with the map, etc. We should start them aff on a bit of a railroard, then open the game world up to them Cities:
further. Trade Port: Nazim (human port city)
‘Open Plains City: Caspar {human farming community)
Large Cosmo City: [TBD] [map thd]

Starting scene: Forest City: Hanali (elven / tree city)

Hired as mercenaries to guard a shipment of supplies through the [swampy forest]. These supplies are worth a lot of Capitol: Lutgehr (dwarven / under-mountain city)

money, and there is a commission for their safe return. Unfortunately, the town of Nazim has been under increasing

siege. This important waterfront community would serve as the gateway to further trade, but transporting the goods ‘Queen Dwarven Lord Kathra Steeffist

further into the kingdom has long proved a challenge. >Advised by a Elven Wizard and Human Cleric

‘The kingdom of Primos has three other cities, including its capitol, the ancient dwarven city of Lutgehr. The kingdom of Kingdom is facing political strife; monster attacks have called into question the leadership of Lord
Primos is a just and welcoming kingdom, featuring humans, dwarves, and elves. SteelFist. The Elves are threatening to secede, and a dangerous new crime organization has taken root

throughout the land. The kingdom of Primos is proud and longstanding, but will it weather this storm?

Deeper threat: Dark Tournament?

Starting enemies: Port City of Nazim:
Kuo-Tao 199 Population: “1200
Governor: ‘Lance’
Lizard folk- dwelle in the swamp forest, have their own culture and dislike outsiders. Inn: The Wandering Peagesus
Hag - Bboss directing these particular Kuo-Tao. Innkeeper: Osah Mayham
She has a lair deep in the swamp, players will need to discover its location >Personality: Outspoken and chaotic. She briefly dabled in worshiping a god of chaos, and random
‘Swamp hamlet conceals lair entrance. Deals in exotic trinkets in town, under the name Marie. A hijinks have followed her ever sense. Now she runs the best - or at least most lively - Inn in Nazim.
beautiful and enchanting woman.
Gozes Description: A port city with potential, Nazim is strangled from the rest of the Kingdom and goods aren't
Owlbear flowing as they should. The city has a somewhat somber attitude about it. Humans make up most of the
average people, with a number of tieflings living along the docks in shantys, often working as day
laborers for goods.

‘The city militia has been working on battling back the encroaching wilderness but to limited effect.

#### ChatGPT Output:
Only Joseph has played dungeons and dragons before. So we need to introduce everyone to how actions work, Kingdom of Primos
interacting with the map, etc. We should start them off on a bit of a railroad, then open the game world up to them further.

**Cities:**
- Trade Port: Nazim (human port city)
- Open Plains City: Caspar (human farming community)
- Large Cosmo City: [TBD] [map tbd]

**Starting scene:**
- Forest City: Hanali (elven / tree city)

Hired as mercenaries to guard a shipment of supplies through the [swampy forest]. These supplies are worth a lot of money, and there is a commission for their safe return. Unfortunately, the town of Nazim has been under increasing siege. This important waterfront community would serve as the gateway to further trade, but transporting the goods further into the kingdom has long proved a challenge.

**Capitol:**
- Lutgehr (dwarven / under-mountain city)

**Political Figures:**
- Dwarven Lord: Kathra Steelfist
  - Advised by an Elven Wizard and Human Cleric

The kingdom of Primos has three other cities, including its capitol, the ancient dwarven city of Lutgehr. The kingdom of Primos is a just and welcoming kingdom, featuring humans, dwarves, and elves. Kingdom is facing political strife; monster attacks have called into question the leadership of Lord Steelfist. The Elves are threatening to secede, and a dangerous new crime organization has taken root throughout the land. The kingdom of Primos is proud and longstanding, but will it weather this storm?

**Deeper threat:** Dark Tournament?

**Starting enemies:**
- Port City of Nazim:
  - Kuo-Tao
    - Population: 1200
    - Governor: 'Lance'
  - Lizard folk- dwell in the swamp forest, have their own culture and dislike outsiders.
  - Hag - Boss directing these particular Kuo-Tao.
    - She has a lair deep in the swamp, players will need to discover its location.
    - Swamp hamlet conceals lair entrance.

**Inn: The Wandering Pegasus**
- Innkeeper: Osah Mayham
  - Personality: Outspoken and chaotic. She briefly dabbled in worshiping a god of chaos, and random hijinks have followed her ever since. Now she runs the best - or at least most lively - Inn in Nazim.

**City Description:**
- Nazim: A port city with potential, Nazim is strangled from the rest of the Kingdom and goods aren't flowing as they should. The city has a somewhat somber attitude about it. Humans make up most of the average people, with a number of tieflings living along the docks in shantys, often working as day laborers for goods.

The city militia has been working on battling back the encroaching wilderness but to limited effect.

# World Details

    **Created:** 2021-10-29 11:43:50  
    **Last Edited:** 2021-10-29 11:43:57  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
World Problem: Emergent Monsters

Something is causing the monsters of the world to become particularly numierous and aggressive. The Sinnodel swamps
were always dangerous, but rarely did entire trade caravans get wiped out! Now it seems to be an all too common
occurrence.

‘The Kingdom of Primos was founded in a time of such upheavels. Uniting disparate city-states of Humans, Elves, and
Dwarves, it successfully forged a united, cosmopolitan kingdom that could stand against monsters. After years of battles,
peace finally came to the kingdom, and a dwarven king found himself in charge of surface dwelling cities for the first
time.

This arrangement would not prove wholly politically stable. Now, 300 years later, the kingdom finds itself under similar
circumstances. Lord Steelfist is struggling to maintain political cohesion of the political settlements, which come under
increasing monster attack. The Primos Army finds itself stretched thin, seemingly surrounded by an enemy that it cannot
strike back at...

BBEG - The Black Rose Society

This group has been working in the shadows to locate and claim the various Evil Obelisks. Under the
leadership of Sir William the Bloody, they have quietly grown in influence throughout the realm of
Primos. By activating the Obelisks, they bring Dis' power into the world, increasing his influence through
terror, subjugation, and murder of the realm's citizens.

Religious Objects - Evil Obelisks:

‘These Obsidian Obelisks can be found scattered throughout the world.
Knowledge of them is rare, but their existance cannot be denied. Placed
eons ago when the world was young, they are covered in an Infernal script
that few can read. Those that can learn how to commune with Disparater,
lord of the second layer of Hell. His dark aura can be felt radiating from
them.

Monsters, such as the Hag coven, are susceptible to this evil aura. Areas in
which an active obelisk resides take on a darker, more vile tone, Monsters
become emboldened and powerful, attacking all those that venture close.

#### ChatGPT Output:
# World Problem: Emergent Monsters

Something is causing the monsters of the world to become particularly numerous and aggressive. The Sinnodel swamps were always dangerous, but rarely did entire trade caravans get wiped out! Now it seems to be an all too common occurrence.

The Kingdom of Primos was founded in a time of such upheavals. Uniting disparate city-states of Humans, Elves, and Dwarves, it successfully forged a united, cosmopolitan kingdom that could stand against monsters. After years of battles, peace finally came to the kingdom, and a dwarven king found himself in charge of surface dwelling cities for the first time.

This arrangement would not prove wholly politically stable. Now, 300 years later, the kingdom finds itself under similar circumstances. Lord Steelfist is struggling to maintain political cohesion of the political settlements, which come under increasing monster attack. The Primos Army finds itself stretched thin, seemingly surrounded by an enemy that it cannot strike back at...

## BBEG - The Black Rose Society

This group has been working in the shadows to locate and claim the various Evil Obelisks. Under the leadership of Sir William the Bloody, they have quietly grown in influence throughout the realm of Primos. By activating the Obelisks, they bring Dis' power into the world, increasing his influence through terror, subjugation, and murder of the realm's citizens.

### Religious Objects - Evil Obelisks:

These Obsidian Obelisks can be found scattered throughout the world. Knowledge of them is rare, but their existence cannot be denied. Placed eons ago when the world was young, they are covered in an Infernal script that few can read. Those that can learn how to commune with Disparater, lord of the second layer of Hell. His dark aura can be felt radiating from them.

Monsters, such as the Hag coven, are susceptible to this evil aura. Areas in which an active obelisk resides take on a darker, more vile tone, Monsters become emboldened and powerful, attacking all those that venture close.

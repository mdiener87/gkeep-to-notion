# Session 10 - Shopping, and the Black Rose Society

    **Created:** 2021-10-29 11:45:45  
    **Last Edited:** 2021-10-29 11:45:52  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Starting today, the adventurers will finally (hopeuflly) go on some shopping runs to devieop new gear and supplies. They
will meet more of the key NPCs within the city of Nazim. Commander 'Lance’ has given them a standing invite to come
to the Governor's mansion and meet Governor Vondal Dankil (dwarf gov). Commander Lance is smitten with the players
for their save of her troops in the Sinnadel swamps, but Vondal is harder to win over.

‘The black rose society has been made aware of a certain 'enefable' Merias. Perhaps an untimely invitation to the old city
district is in order...

Result:

Merias and Damacous burned down Lady Kasumi's place, Damacous then looked for magical gear to not
much success, and Melee bought an Alchemists’ fire grenade from the local alchemist. Players noticed
that a suspicious party was observing them in the bar, and Damacous sent his shegolith after them in
pursuit.

This led to an abandoned, broken down keep in the old quadrant of the city. The players busted in and
found the cultists that were eying Merias at the bar! A fight ensued and they managed to take the
leader captive and interrogate him.

From the captured cultist, they learned about the existence of the Black Rose Society - the evil
organization working to bring Dis evil to fruition. They also learned that the cult uses teleporting,
burning messages through fire places to communicate with their splinter cells. A rose has many petals

From the cultist they also found a scroll of Disguise Self, and a Staff of the Adder.

Melee was also able to forge a relationship with a new animal companion in the woods, a Boar she has,
named Brutus.

#### ChatGPT Output:
Starting today, the adventurers will finally (hopefully) go on some shopping runs to develop new gear and supplies. They
will meet more of the key NPCs within the city of Nazim. Commander 'Lance’ has given them a standing invite to come
to the Governor's mansion and meet Governor Vondal Dankil (dwarf gov). Commander Lance is smitten with the players
for their save of her troops in the Sinnadel swamps, but Vondal is harder to win over.

'The black rose society has been made aware of a certain 'ineffable' Merias. Perhaps an untimely invitation to the old city
district is in order...

Result:

- Merias and Damacous burned down Lady Kasumi's place, Damacous then looked for magical gear to not
  much success, and Melee bought an Alchemists’ fire grenade from the local alchemist. Players noticed
  that a suspicious party was observing them in the bar, and Damacous sent his shegolith after them in
  pursuit.

- This led to an abandoned, broken down keep in the old quadrant of the city. The players busted in and
  found the cultists that were eying Merias at the bar! A fight ensued and they managed to take the
  leader captive and interrogate him.

- From the captured cultist, they learned about the existence of the Black Rose Society - the evil
  organization working to bring Dis evil to fruition. They also learned that the cult uses teleporting,
  burning messages through fire places to communicate with their splinter cells. A rose has many petals.

- From the cultist they also found a scroll of Disguise Self, and a Staff of the Adder.

- Melee was also able to forge a relationship with a new animal companion in the woods, a Boar she has,
  named Brutus.

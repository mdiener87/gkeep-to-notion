# Session 20 - Results of Sidequests

    **Created:** 2021-10-29 11:47:36  
    **Last Edited:** 2021-10-29 11:47:44  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Corpse Flower Encounter today, see Session 19 result notes

Result:
‘The party wasn't sure if the Corpse Flower was friend or foe at first, and tried to assess the situation all while it grew in
capability and evil. Soon it lunged forward and attacked Melee, who tried to be clever but ended up being bit! The fight
‘was on and it soon became apparent that the players underestimated exactly how evil and powerful this creature was.
Fed with both a Troll and Gibbering Mouther, the Corpse Flower had more HP and more abilities than normal.

‘The disgusting fight went on for most of the night, as the players set it on fire, doused it in chemical flames, and
irradiated it with a moonbeam. Merias hit it with several powerful blasts from his Lightening Bolt and Fireball spells. In
spite of the combined focus and damage, it still took many rounds to bring down with its immense regeneration abilities.

‘The putred stench drove the townspeople in terror. Damacus and Sir Girthivair would also fall il to its proximate effect.
In the middle of the battle, it released numerous spores, which blinded those that let them get into their eyes. The
spores spread some distance, and would germinate in evil or undead things.

Lance Pristol eventually showed up, and helped coordinate the Militia to seal off the area.

Eventually the creature was felled, but not before everyone save Merias had taken severe blows. Cleaning up the
aftermath, they discovered that the spores had reached both the Arcane Rift and the Graveyard, Pristol, Damacus, and
Girithivair went to the Graveyard to stop the spores from germinating any corpses. Merias went to the Arcane Rift and
observed a very harried Jocelyn emerge from the rift. The Rift itself couldn't quite close correctly, as the pollen seemed
to be affecting the rift in some way.

‘And Finally, Melee went deep into the swamp and successfully transplanted a final bulb of the flower in a hidden
location.

#### ChatGPT Output:
### Corpse Flower Encounter today, see Session 19 result notes

**Result:**
*The party wasn't sure if the Corpse Flower was friend or foe at first, and tried to assess the situation all while it grew in capability and evil. Soon it lunged forward and attacked Melee, who tried to be clever but ended up being bit! The fight was on and it soon became apparent that the players underestimated exactly how evil and powerful this creature was. Fed with both a Troll and Gibbering Mouther, the Corpse Flower had more HP and more abilities than normal.*

*The disgusting fight went on for most of the night, as the players set it on fire, doused it in chemical flames, and irradiated it with a moonbeam. Merias hit it with several powerful blasts from his Lightening Bolt and Fireball spells. In spite of the combined focus and damage, it still took many rounds to bring down with its immense regeneration abilities.*

*The putrid stench drove the townspeople in terror. Damacus and Sir Girthivair would also fall ill to its proximate effect. In the middle of the battle, it released numerous spores, which blinded those that let them get into their eyes. The spores spread some distance, and would germinate in evil or undead things.*

*Lance Pristol eventually showed up, and helped coordinate the Militia to seal off the area.*

*Eventually the creature was felled, but not before everyone save Merias had taken severe blows. Cleaning up the aftermath, they discovered that the spores had reached both the Arcane Rift and the Graveyard, Pristol, Damacus, and Girithivair went to the Graveyard to stop the spores from germinating any corpses. Merias went to the Arcane Rift and observed a very harried Jocelyn emerge from the rift. The Rift itself couldn't quite close correctly, as the pollen seemed to be affecting the rift in some way.*

*And Finally, Melee went deep into the swamp and successfully transplanted a final bulb of the flower in a hidden location.*

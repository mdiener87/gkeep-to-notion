# Session 19 - Tunnels and Collectors

    **Created:** 2021-10-29 11:47:26  
    **Last Edited:** 2021-10-29 11:47:34  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘There is a TG LT chained up by the party. What fate will he meet at their hands? He has already been mind probed by
the Medallion of Thoughts, revealing many details about the Collector and his schemes.

‘They've also learned about Jocelyn's use of the Aether Tunnel (to Shadow Realm), so that is likely what they will
investigate next.

Result:
‘The night session with all the players separating up into their own little side stories.

Melee:
Met a new Tiefling, Shax Glory, whom dealt in shady items. Melee put in a purchase order for an
armor upgrade for Brutus.

Damaus & Melee:
Performed a profane ritual on the captured trades guild member. After a series of religion and
arcane rolls, Damacus opened a portal to his otherwordly god, Yasgodoth (spelling). The poor
captain tried to meet the God's favor, but failed spectacularly. Yasgodoth smited the fool and
transformed him into a Gibbering Mouther. This terrible and terrifying creature resulted in several
rounds of tense, and gory combat for the two players. Eventually it was defeated, and Damacus
put down his first abhorrent creation.

Merias:
Decided it would be a great idea to explore his own sidequest in the Ethereal tear. He discovered
nota side quest, but the main storyline still in waiting! He ventured much further than I expected
him to, and ended up getting surrounded by Specters and Ghosts that haunted this space. He
Mind Probed one with his medallion of thoughts, and discovered that the former soul was
destroyed by a Staute of Dispater. He eventually escaped, thanks to a good use of the Figurine of
the Silver Raven and repeated uses of invisibility.

Sir Girithivar:
‘Went on a ride into the forest rather than watch whatever cruel fate met him with the murdering
duo. He rode through the forest for some time, but ended up not rolling into anything. Eventually,
he came across a small child who was lost and trapped in the forest. Sir Girthivair helped the child
home, and discovered he was being potentially abused by his father. He was eventually returned
home, but Sir Girithivair didn't do much to help the kids situation either. He also met a centaur,
Mindartis, who gave him a flute to contact his people. He learned 'Song of Centaurs’.

‘The players then took some downtime. Damacus and Melee cleaned their keep, then Melee went to the
‘Wandering Pegasus while Damacus slept in the pentagram he created earlier. Merias went from a close
vision of Dispater through his mind probe to... going straight to bed and sleeping directly above a
smashed Obelisk to Dispater. He had terrible nightmares and recovered no spell slots. Sir Girhivair
‘wound up in an impromptu party thrown by Osha Mayham, who saw an opportunity to make lots of
coin!

All of these dead bodies, meanwhile, were fed to their ‘garden’. The players began to grow a plant
monstrosity in their backyard, and they encouraged this activity at every opportunity. They ended up
hunting a prime buck in the forest, and feeding the whole thing to it. While Melee hunted, Merias and
Damacus met up with the centaurs again, meeting Rothenel, He was exasperated at the players’ having
a centaur flute, but was eventually calmed when he saw Girithvair's religious respect for nature. He
‘taught them 'The Song of the Druids' for their flute.

‘As the new morning came, so too did a terrible crunching noise! A Corpse Flower had grown in the
garden they had grown. What fate will it meet? Next time!

#### ChatGPT Output:
‘There is a TG LT chained up by the party. What fate will he meet at their hands? He has already been mind probed by
the Medallion of Thoughts, revealing many details about the Collector and his schemes.

‘They've also learned about Jocelyn's use of the Aether Tunnel (to Shadow Realm), so that is likely what they will
investigate next.

Result:
‘The night session with all the players separating up into their own little side stories.

Melee:
- Met a new Tiefling, Shax Glory, whom dealt in shady items. Melee put in a purchase order for an
armor upgrade for Brutus.

Damaus & Melee:
- Performed a profane ritual on the captured trades guild member. After a series of religion and
arcane rolls, Damacus opened a portal to his otherwordly god, Yasgodoth (spelling). The poor
captain tried to meet the God's favor, but failed spectacularly. Yasgodoth smited the fool and
transformed him into a Gibbering Mouther. This terrible and terrifying creature resulted in several
rounds of tense, and gory combat for the two players. Eventually it was defeated, and Damacus
put down his first abhorrent creation.

Merias:
- Decided it would be a great idea to explore his own sidequest in the Ethereal tear. He discovered
nota side quest, but the main storyline still in waiting! He ventured much further than I expected
him to, and ended up getting surrounded by Specters and Ghosts that haunted this space. He
Mind Probed one with his medallion of thoughts, and discovered that the former soul was
destroyed by a Staute of Dispater. He eventually escaped, thanks to a good use of the Figurine of
the Silver Raven and repeated uses of invisibility.

Sir Girithivar:
- Went on a ride into the forest rather than watch whatever cruel fate met him with the murdering
duo. He rode through the forest for some time, but ended up not rolling into anything. Eventually,
he came across a small child who was lost and trapped in the forest. Sir Girthivair helped the child
home, and discovered he was being potentially abused by his father. He was eventually returned
home, but Sir Girithivair didn't do much to help the kids situation either. He also met a centaur,
Mindartis, who gave him a flute to contact his people. He learned 'Song of Centaurs’.

‘The players then took some downtime. Damacus and Melee cleaned their keep, then Melee went to the
‘Wandering Pegasus while Damacus slept in the pentagram he created earlier. Merias went from a close
vision of Dispater through his mind probe to... going straight to bed and sleeping directly above a
smashed Obelisk to Dispater. He had terrible nightmares and recovered no spell slots. Sir Girhivair
‘wound up in an impromptu party thrown by Osha Mayham, who saw an opportunity to make lots of
coin!

All of these dead bodies, meanwhile, were fed to their ‘garden’. The players began to grow a plant
monstrosity in their backyard, and they encouraged this activity at every opportunity. They ended up
hunting a prime buck in the forest, and feeding the whole thing to it. While Melee hunted, Merias and
Damacus met up with the centaurs again, meeting Rothenel, He was exasperated at the players’ having
a centaur flute, but was eventually calmed when he saw Girithivair's religious respect for nature. He
‘taught them 'The Song of the Druids' for their flute.

‘As the new morning came, so too did a terrible crunching noise! A Corpse Flower had grown in the
garden they had grown. What fate will it meet? Next time!```
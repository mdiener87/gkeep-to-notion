# Session 14 - The Cultists Lair

    **Created:** 2021-10-29 11:46:25  
    **Last Edited:** 2021-10-29 11:46:32  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Statue of dispater
DCIS to knock over
‘ACI6 20HP

This sessfon will focus on the exploration of the Cultist's lair. The Black Rose Society uses it as a base of operations in ‘Scorching ray + 4to hit, 148 +4 fire damage

Nazim — who knows what perils our await our adventurers within such a foul place?

#### ChatGPT Output:
Statue of Dispater  
DC 15 to knock over  
AC 16, 20 HP  

This session will focus on the exploration of the Cultist's lair. The Black Rose Society uses it as a base of operations in Scorching ray + 4 to hit, 1d8 + 4 fire damage  

Nazim — who knows what perils await our adventurers within such a foul place?

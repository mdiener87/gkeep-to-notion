# Session 11 - The Governors Mansion

    **Created:** 2021-10-29 11:46:00  
    **Last Edited:** 2021-10-29 11:46:05  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
3x Players in this session, so we can probably get through lots of content in a hurry. Coming into this session, the PCs Result:

know that the BRS has a meeting at the Governors Mansion in three days. This happens to coincide with the Governors!

Galla, one of the finest annual parties held in the city. The players will likely try to crash this. There they will meet the ‘Well, none of what | expected to happen happened. As is typical. Melee ended up killing a militia

Governors inner circle, and get a better feel for the evil plots overhanging everything... member while skulking around the governor's mansion, but went undetected. She was able to leave a
note implicating that the Trade Guild might have been behind the killing.

‘There is a hidden dungeon within the city the players might access. Reference donjon map. Itis filled with humans
Sir Girithavar meanwhile was on a tour of the mansion from Lance Pristol. He met the very old and
senile governor, who is relying on booze and his advirsors for day to day governance of Nazim,

Merias stayed inside and decrypted two of the documents discovered.
Awitch's hit list of potential targets to cause chaos in Nazim
Ascroll of fireball, that if cast at midnight, is automatically maximized in damage

Notes about the way the evil obelisks work. It seems possible to temporarily draw evil magic fram
‘them, but not on a long term basis without forging a Contract with Dis first.

‘There is (or at least at one point, there was) another obelisk within Nazim itself. The notes were
crude but were pointing to somewhere in the old city.

SG and Melee also ran into Corrin again, of the shop. He has been repeatedly shaked down by the Trade
Guild, and asked the players to intervene. After waiting at night for the thugs to arrive, the players came
out swinging in what at some moments turned into a tense brawl. They dispatched the thugs, and tried

to get Corrin to blame the Black Rose Society for the killings. Its unclear how well he conveyed that, but
he did try to stay true to the script provided.

#### ChatGPT Output:
3x Players in this session, so we can probably get through lots of content in a hurry. Coming into this session, the PCs Result:

- know that the BRS has a meeting at the Governor's Mansion in three days. This happens to coincide with the Governor's Galla, one of the finest annual parties held in the city. The players will likely try to crash this. There they will meet the Governor's inner circle, and get a better feel for the evil plots overhanging everything...
- Well, none of what I expected to happen happened. As is typical. Melee ended up killing a militia member while skulking around the governor's mansion, but went undetected. She was able to leave a note implicating that the Trade Guild might have been behind the killing.

There is a hidden dungeon within the city the players might access. Reference donjon map. It is filled with humans
- Sir Girithavar meanwhile was on a tour of the mansion from Lance Pristol. He met the very old and senile governor, who is relying on booze and his advisors for day to day governance of Nazim.

Merias stayed inside and decrypted two of the documents discovered.
- A witch's hit list of potential targets to cause chaos in Nazim
- A scroll of fireball, that if cast at midnight, is automatically maximized in damage

Notes about the way the evil obelisks work. It seems possible to temporarily draw evil magic from them, but not on a long term basis without forging a Contract with Dis first.

There is (or at least at one point, there was) another obelisk within Nazim itself. The notes were crude but were pointing to somewhere in the old city.

SG and Melee also ran into Corrin again, of the shop. He has been repeatedly shaked down by the Trade Guild, and asked the players to intervene. After waiting at night for the thugs to arrive, the players came out swinging in what at some moments turned into a tense brawl. They dispatched the thugs, and tried to get Corrin to blame the Black Rose Society for the killings. It's unclear how well he conveyed that, but he did try to stay true to the script provided.

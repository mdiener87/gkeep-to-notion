# Misc Combat Rules

    **Created:** 2021-10-29 11:44:00  
    **Last Edited:** 2021-10-29 11:44:02  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Poison on weapons: Lasts 2 hits or 30 minutes without training or equipment. With trait
hits / 4 hours.

Envenomed weapons count as training/poisoners tools automatically.

Long-duration poisons increase these to 6 hits / 1 day.

ing/poisoners tools, can last 4

#### ChatGPT Output:
Poison on weapons: Lasts 2 hits or 30 minutes without training or equipment. With trait
hits / 4 hours.

Envenomed weapons count as training/poisoners tools automatically.

Long-duration poisons increase these to 6 hits / 1 day.

ing/poisoners tools, can last 4

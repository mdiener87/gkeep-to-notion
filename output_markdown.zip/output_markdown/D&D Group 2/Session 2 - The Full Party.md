# Session 2 - The Full Party

    **Created:** 2021-10-29 11:44:17  
    **Last Edited:** 2021-10-29 11:44:22  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Ryan joins the group today, he will make a character and then will do some initial gameplay. We shall see if the players ‘The Goods:

can safely guide the caravan through the swamp. it will take a solid week of travel to make it through the swamps, but ne set of crates from each of the major cities within the kingdom:
sucessful navigation checks can decrease that by 104 days by finding a shortcut. Dwarven weapons, armor and shields. Several complete sets.
Elven silken textiles
Perils: Foods, pottery, and other curious from human city
‘stuck Wagons
Dead ends Total goods value: 30,000g. But it's all marked with the Primos Trade Guild logo. Fencing it would be
Wandering Monsters difficult within the kingdom.

Lost Merchants -trade / help

Monsters encountered:
Giant Toad - They recovered several potions + gold from it
Ko'Tuo Scouts - Gold, Potions

#### ChatGPT Output:
Ryan joins the group today, he will make a character and then will do some initial gameplay. We shall see if the players can safely guide the caravan through the swamp. It will take a solid week of travel to make it through the swamps, but successful navigation checks can decrease that by 1-4 days by finding a shortcut.

**The Goods:**
- Dwarven weapons, armor, and shields. Several complete sets.
- Elven silken textiles
- Foods, pottery, and other curios from human cities

**Perils:**
- Stuck wagons
- Dead ends
- Wandering monsters
- Lost merchants - trade/help

**Monsters encountered:**
- Giant Toad - They recovered several potions + gold from it
- Ko'Tuo Scouts - Gold, Potions

**Total goods value:** 30,000g. But it's all marked with the Primos Trade Guild logo. Fencing it would be difficult within the kingdom.

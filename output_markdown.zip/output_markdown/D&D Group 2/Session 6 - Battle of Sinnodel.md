# Session 6 - Battle of Sinnodel

    **Created:** 2021-10-29 11:45:02  
    **Last Edited:** 2021-10-29 11:45:10  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
On the previous chapter, Ryan was out leaving it of the party of 3 to take on the swamp in search of Henry's gear. The PC
party fought their way through Khou-Tau, exploring deeper into the swampy depths than ever before. along the way,
they also encountered a Will-o-Wisp and defeated its sand-trap. Finally, they came across Henry's goods (3x crates) and
noticed a KT ambush in wait. Melee used Animal Friendship to charm a CR 5! Giant Crocodile, and the ensuing fight
turned into an immediate bloodbath for the KT. Interrogating captured KT over the night revealed they are definitely
‘working for some kind of witch...

So this session opens with them still deep in the Sinnodel swamps. If they wish to free the swamps of corruption, they'll
need to find and defeat the Hag coven at the heart of the swamps...

Figh
2x hags:
Lady Kasumi - Green Hag
Lady Maiko - Green Hag.

Lady Kasumi guards the front of the witch's coven. She roams the swamps with her invisibility and will be expecting the
PC's intervention, having already earned a bit of a name for themselves in Nazim. Other's have foolishly wandered this
dlose before and she has defeated them with ease. Why would these be any different?

Setup: Lady Kasumi will attempt to first trick the players using her illusory appearance. This probably won't work but she
will sell it better by being ‘tied up" with a minor illusion and threatening khou-tou around her. She has built a pitfall trap
in-front of her (4 squares, DC1S spot DC13Reflex save, 10ft deep 106 falling damage, slippery walls, DC13 to climb out).

Fight:
2K KT
ix Hag

Monster encounters:
Blights (32)

Khou-Tou

[Beasts]

Shadows

Bullywugs (35)

Lizardfolk (204)

Stirge (284)

Cockatrice (42)

Harpy (181)

Giant Scorpion (327)

Giant Spider (IiM328 / PH306)
Giant Toad (MM329)

Ghouls / Ghasts (148)

Dryads (neutral encounter, barter or fight)
Fungus (138) and Myconids (230)

‘Will-o-wisp (leads to quicksand pit trap)

Hags (177)

#### ChatGPT Output:
On the previous chapter, Ryan was out leaving it of the party of 3 to take on the swamp in search of Henry's gear. The PC
party fought their way through Khou-Tau, exploring deeper into the swampy depths than ever before. along the way,
they also encountered a Will-o-Wisp and defeated its sand-trap. Finally, they came across Henry's goods (3x crates) and
noticed a KT ambush in wait. Melee used Animal Friendship to charm a CR 5! Giant Crocodile, and the ensuing fight
turned into an immediate bloodbath for the KT. Interrogating captured KT over the night revealed they are definitely
working for some kind of witch...

So this session opens with them still deep in the Sinnodel swamps. If they wish to free the swamps of corruption, they'll
need to find and defeat the Hag coven at the heart of the swamps...

### Fight
- **2x hags:**
  - Lady Kasumi - Green Hag
  - Lady Maiko - Green Hag.

Lady Kasumi guards the front of the witch's coven. She roams the swamps with her invisibility and will be expecting the
PC's intervention, having already earned a bit of a name for themselves in Nazim. Others have foolishly wandered this
close before and she has defeated them with ease. Why would these be any different?

#### Setup:
Lady Kasumi will attempt to first trick the players using her illusory appearance. This probably won't work but she
will sell it better by being 'tied up' with a minor illusion and threatening khou-tou around her. She has built a pitfall trap
in front of her (4 squares, DC15 spot DC13 Reflex save, 10ft deep 1d6 falling damage, slippery walls, DC13 to climb out).

### Fight:
- 2K KT
- 1x Hag

### Monster encounters:
- Blights (32)
- Khou-Tou
- [Beasts]
- Shadows
- Bullywugs (35)
- Lizardfolk (204)
- Stirge (284)
- Cockatrice (42)
- Harpy (181)
- Giant Scorpion (327)
- Giant Spider (MM328 / PH306)
- Giant Toad (MM329)
- Ghouls / Ghasts (148)
- Dryads (neutral encounter, barter or fight)
- Fungus (138) and Myconids (230)
- Will-o-wisp (leads to quicksand pit trap)
- Hags (177)

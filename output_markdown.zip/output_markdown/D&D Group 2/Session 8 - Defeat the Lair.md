# Session 8 - Defeat the Lair

    **Created:** 2021-10-29 11:45:25  
    **Last Edited:** 2021-10-29 11:45:32  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Players are still in the dungeon. Need to loot the Matriach, explore the dungeon, and beat the final boss!

Result:

‘The summoning portal activated, and a spined devil was surprised to see the PC party. It tried to communicate about the
‘deal’ of selling Kho-Tou eggs, but the negotiation failed. Merias announced himself as the ‘new management" by name
directly, and the other side sent some demon Dretchs to deal with the intrusion.

After putting the demons down, the players explored the rest of the dungeon. They soon encountered the second Green
Hag, where Melee launched a surprise attack. The battle was fierce, and soon the Hag was put down. Looting the room
revelaed adaminte armor, a Cloak of Protection, and various potions.

A large, evil obelisk lay at the center of the underground Witches’ cavern. The PCs could not quite figure out what it was
for, so they destroyed it. This lifted the Demon Curse from the swamp, returning the monster and animal population to
‘normal’ (previous state: dire}.

#### ChatGPT Output:
Players are still in the dungeon. Need to loot the Matriach, explore the dungeon, and beat the final boss!

Result:

‘The summoning portal activated, and a spined devil was surprised to see the PC party. It tried to communicate about the
‘deal’ of selling Kho-Tou eggs, but the negotiation failed. Merias announced himself as the ‘new management’ by name
directly, and the other side sent some demon Dretchs to deal with the intrusion.

After putting the demons down, the players explored the rest of the dungeon. They soon encountered the second Green
Hag, where Melee launched a surprise attack. The battle was fierce, and soon the Hag was put down. Looting the room
revealed adamantine armor, a Cloak of Protection, and various potions.

A large, evil obelisk lay at the center of the underground Witches’ cavern. The PCs could not quite figure out what it was
for, so they destroyed it. This lifted the Demon Curse from the swamp, returning the monster and animal population to
‘normal’ (previous state: dire).'''

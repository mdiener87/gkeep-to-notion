# Session 5 - Witch Hunt?

    **Created:** 2021-10-29 11:44:45  
    **Last Edited:** 2021-10-29 11:44:57  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The Lady Kasumi plotline didn't do very well last time. The player's weren't able to figure out she was a
Hag, and I didn't have much idea how to bait them in the order they met her. So coming into today, the
PCs have a deal with Henry to head back into the swamp and retrieve his magical weapons. Henry does
have connections to the black market within Nazim, and the PCs might be able to meet the Thieves
Guild through him if they so desire, Are the PCs good guys or bandits? They run strongly Chaotic Neutral
50 far in their dealings -maybe turn them into a merc campaign?

‘Anyways, the players are likely to jump into Henry's quest, and that's when we can get some goad dice
rolling in.

>>Print out a random map of the ‘swamp! at a high relief level. The players will need to navigate this
map, avoid traps and encounters, and find Henry's gear as the primary loot. They might also run into
Kasumi - what could she be doing out here???

Other potential encounters:
Lost child
Dryad - Neutral Encounter
Military Patrol - (DC10 they've heard of the players)

‘Swamp setting is clearly a manifestation of my own not knowing wif to do with this campaign. Are they
monster hunting / [Emergent Monsters]? Are they political activists / [Kingdom Split]? Are they sea-side
adventures and mercs [Pirate Campaign]? illitdk. Compared to my main campaign this one feels a lot
more aimless. Maybe that's the reality of 4 sessions vs 40.

Reading back, by session 4 | had given the PC other hooks to go out and explore the world. By the end of
tonight the players should have the agency to pick the direction of their campaign better than ‘farming
‘the swamp for xp’. As a port city, Nazim opens up the map if the players want to go adventuring
overseas.

Monster encounters:
Blights (32)
Khou-Tou

[Beasts]

Shadows

Bullywugs (35)
Lizardfolk (204)
Stirge (284)
Cockatrice (42)
Harpy (181)

Dryads (neutral encounter, barter or fight)
Fungus (138) and Myconids (230)

will

Hags (177)

Map Keypoints:
:a halfsunken chest can be found in an abandoned caravan. Khou-Tou lurk nearby

Will-o-wisps lead to a quicksand pit trap

: Dryads - Spirits of the Swamp. Can be bartered with or fought

Signs of wandering monsters are present through this area. Players can avoid / try to ambush / be
ambushed by said monsters in this area.

5: A ‘Totally not lost’ military patrol is in this area. Likely in combat with monsters.

H:
‘A Harpy coven has set up roost in the trees above the swamp in this area. Lady Kasumi has switched
tactics and enlisted these Harpies aid to ambush the players, knowing the Khou To won't be sufficent by
themselves. Lady Kasumi won't be present here, she doesn't like to get involved.

kK:
Lady Kasumi is out tending to her monsters and visiting the Hag coven. The players could totally run into
her and that would be awkward. Lady Kasumi won't be able to maintain cover for long and will ikely
turn into a fight.

-wisp (leads to quicksand pit trap)

#### ChatGPT Output:
'The Lady Kasumi plotline didn't do very well last time. The players weren't able to figure out she was a
Hag, and I didn't have much idea how to bait them in the order they met her. So coming into today, the
PCs have a deal with Henry to head back into the swamp and retrieve his magical weapons. Henry does
have connections to the black market within Nazim, and the PCs might be able to meet the Thieves
Guild through him if they so desire. Are the PCs good guys or bandits? They run strongly Chaotic Neutral
so far in their dealings - maybe turn them into a merc campaign?

Anyways, the players are likely to jump into Henry's quest, and that's when we can get some good dice
rolling in.

>> Print out a random map of the 'swamp' at a high relief level. The players will need to navigate this
map, avoid traps and encounters, and find Henry's gear as the primary loot. They might also run into
Kasumi - what could she be doing out here???

Other potential encounters:
- Lost child
- Dryad - Neutral Encounter
- Military Patrol - (DC10 they've heard of the players)

Swamp setting is clearly a manifestation of my own not knowing what to do with this campaign. Are they
monster hunting / [Emergent Monsters]? Are they political activists / [Kingdom Split]? Are they sea-side
adventures and mercs [Pirate Campaign]? I don't know. Compared to my main campaign this one feels a lot
more aimless. Maybe that's the reality of 4 sessions vs 40.

Reading back, by session 4 I had given the PC other hooks to go out and explore the world. By the end of
tonight the players should have the agency to pick the direction of their campaign better than 'farming
the swamp for xp'. As a port city, Nazim opens up the map if the players want to go adventuring
overseas.

Monster encounters:
- Blights (32)
- Khou-Tou

[Beasts]
- Shadows
- Bullywugs (35)
- Lizardfolk (204)
- Stirge (284)
- Cockatrice (42)
- Harpy (181)

- Dryads (neutral encounter, barter or fight)
- Fungus (138) and Myconids (230)

- Hags (177)

Map Keypoints:
- A half-sunken chest can be found in an abandoned caravan. Khou-Tou lurk nearby
- Will-o-wisps lead to a quicksand pit trap
- Dryads - Spirits of the Swamp. Can be bartered with or fought
- Signs of wandering monsters are present through this area. Players can avoid / try to ambush / be
ambushed by said monsters in this area.
- A 'Totally not lost' military patrol is in this area. Likely in combat with monsters.
- A Harpy coven has set up roost in the trees above the swamp in this area. Lady Kasumi has switched
tactics and enlisted these Harpies' aid to ambush the players, knowing the Khou To won't be sufficient by
themselves. Lady Kasumi won't be present here, she doesn't like to get involved.
- Lady Kasumi is out tending to her monsters and visiting the Hag coven. The players could totally run into
her and that would be awkward. Lady Kasumi won't be able to maintain cover for long and will likely
turn into a fight.

- wisp (leads to quicksand pit trap)

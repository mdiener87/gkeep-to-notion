# Session 18 - Evil in the Air

    **Created:** 2021-10-29 11:47:14  
    **Last Edited:** 2021-10-29 11:47:21  
    **Labels:** D&D Group 2  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
What is the mystery of the second Obelisk? How did the BRS not know where it could be located? What is the Trade
Guild up to anyways?

Second Obelisk - Located on a demi-plane within Nazim. Jocelyn knows about its location and has been siphoning power
from the Obelisk to fuel her own spells and feed her knowledge about the city and its denizens. This slow corruption is
also part of Dispater's plans. The plane is not easy to access, and exists behind a shifting series of haunted corridors
within the Etheral plane. Exiting the corridors successfully will arrive at the Shadow Realm version of Nazim - where the
second Obelisk lies.

Jocelyn isn't evil persay, she is just greedy and a bit corrupted. Her soul might still be saved, or she might just get killed
along the way. What will the party decide?

‘The Trade Guild has their own machinations in place. They are buying powerful monsters and researching ways with
which they might be subjected... And unleashed. The Trade Guild has a Trade Enforcement division, and they are
clamoring to become offical Protectors of the Realm by royal decree. if they can prove the worthlessness of the Nazim
Militia, they might have an opportunity...

Result:

Players found Havilar within the city; she is a Golden Dragonborn Sorcerer and trades in magical items and spells. They ended up buying a spell scroll
from her, but couldn't reach agreement on price for anything else. They did learn from her that Jocelyn isn't as powerful as she advertises herself to be.
‘She seems to have a patron for her magical power, and has been regularly running off to a tear in the ethereal realm that's located in the Old City of
Nazim.

Girithivar and Melee went to a fancy dinner with Lance and Governor Donkil. Lance has her eyes set on a new powerful sword the TG got their hands
on, but knows she could never afford it.

‘The Trades Guild members showed up to buy the troll as expected. A fight broke out, but the TG members were quickly charmed and incapacitated
between Damacus' Hypnotic Pattern and a Hold Person scroll. The fight seemed over before it started.... Until the Helmed Horror showed up. The
players scrambled to fight it, horrifed to learn that many of their best spells harmlessly bounced off of it. They defeated it in the end and then killed the
remaining TG guards.

‘The TG Captain was mind probed by the Medallion of Thoughts. They learned more about the collector, the mysterious buyer that was funding the
collection effort of the troll. He is apparently rich and powerful, and interested in acquiring powerful unique artifacts and specimens. The captain's fate
is not yet decided -he is bound and captured within the player's Keep (now damaged again in the fighting).

#### ChatGPT Output:
**What is the mystery of the second Obelisk? How did the BRS not know where it could be located? What is the Trade Guild up to anyways?**

**Second Obelisk** - Located on a demi-plane within Nazim. Jocelyn knows about its location and has been siphoning power from the Obelisk to fuel her own spells and feed her knowledge about the city and its denizens. This slow corruption is also part of Dispater's plans. The plane is not easy to access, and exists behind a shifting series of haunted corridors within the Ethereal plane. Exiting the corridors successfully will arrive at the Shadow Realm version of Nazim - where the second Obelisk lies.

Jocelyn isn't evil per se, she is just greedy and a bit corrupted. Her soul might still be saved, or she might just get killed along the way. What will the party decide?

‘The Trade Guild has their own machinations in place. They are buying powerful monsters and researching ways with which they might be subjected... And unleashed. The Trade Guild has a Trade Enforcement division, and they are clamoring to become official Protectors of the Realm by royal decree. If they can prove the worthlessness of the Nazim Militia, they might have an opportunity...

**Result:**

Players found Havilar within the city; she is a Golden Dragonborn Sorcerer and trades in magical items and spells. They ended up buying a spell scroll from her, but couldn't reach agreement on price for anything else. They did learn from her that Jocelyn isn't as powerful as she advertises herself to be. ‘She seems to have a patron for her magical power, and has been regularly running off to a tear in the ethereal realm that's located in the Old City of Nazim.

Girithivar and Melee went to a fancy dinner with Lance and Governor Donkil. Lance has her eyes set on a new powerful sword the TG got their hands on, but knows she could never afford it.

‘The Trades Guild members showed up to buy the troll as expected. A fight broke out, but the TG members were quickly charmed and incapacitated between Damacus' Hypnotic Pattern and a Hold Person scroll. The fight seemed over before it started.... Until the Helmed Horror showed up. The players scrambled to fight it, horrified to learn that many of their best spells harmlessly bounced off of it. They defeated it in the end and then killed the remaining TG guards.

‘The TG Captain was mind probed by the Medallion of Thoughts. They learned more about the collector, the mysterious buyer that was funding the collection effort of the troll. He is apparently rich and powerful, and interested in acquiring powerful unique artifacts and specimens. The captain's fate is not yet decided - he is bound and captured within the player's Keep (now damaged again in the fighting).

# Session 10 - On Moving Companies

    **Created:** 2021-10-29 11:39:32  
    **Last Edited:** 2021-10-29 11:39:39  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Small crew coming into this session, Which means we might actually have a chance at some real narrative advancement.
‘Which is a bit of a problem as I'm not sure where to take this plat.

Beer and meditation help with all things. Including this one.
We are going the Steins; Gate route of time travel.

Without the Order's realization, they have already affected the world line. By removing the Sibriex demon from the
mirror, they have changed the attractor field of the Mirror of Prophecy. In the Alpha timeline, Lord Galtorah went insane
from the mirror’s use. While it was assumed this was an inevitable side effect of time magic, it was really the result of
the Sibriex demon corrupting the mirror. Prince Zelphar originally entrapped the demon into the mirror, in what proved
to bea successful attempt to kill his father. What Zelphar did not account for was the depth of hatred the High elves of
Siraculum would hold for him. Rather than acknowledge Zelphar as Prince acedent, he was banished. The Monarchy was
transferred through marriage to the human Maryn family. Zelphar failed in his bid for power, and has waited for
hundreds of years for his revenge. His demonic patron, the Lolth, gave him unnaturally long life in the slow-moving
realm of the demonic planes.

At least, that's what occurred in the Alpha timeline.

‘The Beta timeline will be realized once the Order activates the mirror. It doesn't really matter where they try to go. The
attractor field is so far in the past, and af such an immense change, that the events they shift into will be dramatically
different than they had expected.

In the beta timeline, Zelphar's original attempt with the Sibriex now mysteriously fails. The Demon seems to die shortly
after its entrapment within the mirror. Zelphar is forced to more extreme measures. He directly murders his father, and
his half-sister, who would otherwise have married into the Moryn family (human). This act of brutality shocks the young
kingdom, and they reject Zelphar's rule, After a brutal civil war, the ruling high elves prevail, and kill Zelphar and his
drow consort.

‘The “Alluin Republic" is established. Lacking a strong and wise leader, it's federal government proves weak. While it
holds together through the various disasters, the recent events proved to be true calamity. Without a Shade of Galtorah
to unite the level 1 party members, the Order of Sun and Moon never convenes.

‘When the Orc invasion finally occurs, the result is truly devastating. Half of the kingdom falls under the control of the
Ores. An uneasy cease-fire occurs following Kaladan's invasion. Again lacking the order, Kaladan successfully captures
Alluin. He is widening the rift between dimensions, hoping his mother might join him in this fertile, weak world.

More or less regardless of what exact time the party decides to travel to, these will be the ongoing events, due to the
powerful changes of the beta attractor field timeline.

How will the party restore the events to the alpha timeline? Or can they engineer a happier ending in the mythical
Gamma timeline?

Results:

‘The Order was able to use druidic magic to transport the Chest of Holding to the top of Galtorah's Keep. They then used
‘Wind Walk to scout out the original area of Valzumin's Lake. There they deployed the reality marble, which unsealed
vValzumins stronghold into the very waters they first found it.

‘They drug the mirror deep within its safe, underwater confines. They struggled to removed the mirror originally. Kaetus
and Gandus went off to find a library, but found only books written in Elven, which neither spoke. They did fine one
book, written in Common, that seemed to have overlapping recorded versions of history contained within. Kaetus also
channeled Galtorah, who seemed to have no recollection of having met Gandus before.

‘The party returned to the mirror, and finally succeeded in extracting the mirror from the box of holding. Ureausa held up
the text to the mirror, and saw that only the weird, alternate timeline was recorded - one in which a Prince Zelphar

murded Galtorah, instead of letting him go insane to time magic.

What could this mean? Find out next time on D&DI;

#### ChatGPT Output:
> 'Small crew coming into this session, which means we might actually have a chance at some real narrative advancement.
> 'Which is a bit of a problem as I'm not sure where to take this plot.
>
> Beer and meditation help with all things. Including this one.
> We are going the Steins; Gate route of time travel.
>
> Without the Order's realization, they have already affected the world line. By removing the Sibriex demon from the
> mirror, they have changed the attractor field of the Mirror of Prophecy. In the Alpha timeline, Lord Galtorah went insane
> from the mirror’s use. While it was assumed this was an inevitable side effect of time magic, it was really the result of
> the Sibriex demon corrupting the mirror. Prince Zelphar originally entrapped the demon into the mirror, in what proved
> to be a successful attempt to kill his father. What Zelphar did not account for was the depth of hatred the High elves of
> Siraculum would hold for him. Rather than acknowledge Zelphar as Prince acredent, he was banished. The Monarchy was
> transferred through marriage to the human Moryn family. Zelphar failed in his bid for power, and has waited for
> hundreds of years for his revenge. His demonic patron, the Lolth, gave him unnaturally long life in the slow-moving
> realm of the demonic planes.
>
> At least, that's what occurred in the Alpha timeline.
>
> 'The Beta timeline will be realized once the Order activates the mirror. It doesn't really matter where they try to go. The
> attractor field is so far in the past, and of such an immense change, that the events they shift into will be dramatically
> different than they had expected.
>
> In the beta timeline, Zelphar's original attempt with the Sibriex now mysteriously fails. The Demon seems to die shortly
> after its entrapment within the mirror. Zelphar is forced to more extreme measures. He directly murders his father, and
> his half-sister, who would otherwise have married into the Moryn family (human). This act of brutality shocks the young
> kingdom, and they reject Zelphar's rule. After a brutal civil war, the ruling high elves prevail, and kill Zelphar and his
> drow consort.
>
> 'The "Alluin Republic" is established. Lacking a strong and wise leader, its federal government proves weak. While it
> holds together through the various disasters, the recent events proved to be a true calamity. Without a Shade of Galtorah
> to unite the level 1 party members, the Order of Sun and Moon never convenes.
>
> 'When the Orc invasion finally occurs, the result is truly devastating. Half of the kingdom falls under the control of the
> Orcs. An uneasy cease-fire occurs following Kaladan's invasion. Again lacking the order, Kaladan successfully captures
> Alluin. He is widening the rift between dimensions, hoping his mother might join him in this fertile, weak world.
>
> More or less regardless of what exact time the party decides to travel to, these will be the ongoing events, due to the
> powerful changes of the beta attractor field timeline.
>
> How will the party restore the events to the alpha timeline? Or can they engineer a happier ending in the mythical
> Gamma timeline?
>
> Results:
>
> 'The Order was able to use druidic magic to transport the Chest of Holding to the top of Galtorah's Keep. They then used
> 'Wind Walk to scout out the original area of Valzumin's Lake. There they deployed the reality marble, which unsealed
> Valzumin's stronghold into the very waters they first found it.
>
> 'They dragged the mirror deep within its safe, underwater confines. They struggled to remove the mirror originally. Kaetus
> and Gandus went off to find a library, but found only books written in Elven, which neither spoke. They did find one
> book, written in Common, that seemed to have overlapping recorded versions of history contained within. Kaetus also
> channeled Galtorah, who seemed to have no recollection of having met Gandus before.
>
> 'The party returned to the mirror, and finally succeeded in extracting the mirror from the box of holding. Ureausa held up
> the text to the mirror, and saw that only the weird, alternate timeline was recorded - one in which a Prince Zelphar
>
> murdered Galtorah, instead of letting him go insane to time magic.
>
> What could this mean? Find out next time on D&D!'

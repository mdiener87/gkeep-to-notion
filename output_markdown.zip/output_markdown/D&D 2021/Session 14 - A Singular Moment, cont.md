# Session 14 - A Singular Moment, cont

    **Created:** 2021-10-29 11:40:26  
    **Last Edited:** 2024-11-14 17:56:42  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Demonic Padded Leather Armor +2

You can understand and speak abyssal while wearing this armor.

Your unarmed strikes with your hands turn into magic Weapons that deal slashing damage, with a +1 bonus to Attack Rolls and Damage Rolls and a damage die of 1d10.

Wearing this armor gives off a distinct and evil demonic aura.

---

Demon Horned Adamantium Chain Mail +2
You gain resistance to poison damage while wearing this armor.

While you wear this armor, any Attackers who strike you with natural weapon attacks in melee range take 2d6 piercing damage in return unless they succede on a DC14 dexterity saving throw.

While you wear this armor, any attackers that you can see who strike you with ranged missle weapons take 2d6 fire damage in return unless they succede on a DC14 dexterity saving throw. 

Wearing this armor gives off a distinct and evil demonic aura.

>>An evil Horned evils's spirit now resides within this armor. If the armor is destroyed, the demon's spirit will be released. Wearing this armor exposes the user to the devil's malignant presence over time. 

------------------------------

Valzumin's Mineraturized Crossbow
- no longer heavy
- the fast reload on Arcane explosion is now a bonus action instead of a reaction
- The weapon now additionaly bears the signature mark of the (free agent) Flame Myrmidon Lavar near the crossbow's grip.



----

Lavar's Enhanced Molten Shield of Smoldering Obsidian
+When struck in combat, you now return 3d8 fire damage instead of 2d8. 

..This shield was further enhanced by the (free agent) Flame Myrmdion Lavar. His signature mark now sits just to the right of Golden Rign's Mark. 


----


Mozran  - ghost mafia membership

Animated Shield
DMG
p151
Armor (shield), major tier, very rare (requires attunement)
6 lb.	AC +2
While holding this shield, you can speak its command word as a bonus action to cause it to animate. The shield leaps into the air and hovers in your space to protect yo
u as if you were wielding it, leaving your hands free. The shield remains animated for 1 minute, until you use a bonus action to end this effect, or until you are incapacitated or die, at which point the shield falls to the ground or into your hand if you have one free.

Found On: Magic Item Table H
Source: DMG, page 151. Available in the SRD.



ghost mafia - a shrine of protection lies in the lobby of the tower. The ghost's have not been very active of late. What could they want or be doing?



Fey Ghosts -
Welcome to Tranquility Tower!

1) Please, no murdering anyone! This is a safe place :)
2) No personal attacks on another's charchter. That's mean!
3) All sales are final!
4) If you break it, you buy it!
5) Violators will be banned from the premises for all eternity!

Thank you, Tranquility Tower Management

Iracard - Winter Eladrin (Ghost)
Yanmorn - Iracard's Brother

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
Finishing the Astral plane jaunt through time travel. Game will end traveling back in time through the astral portal.

Party Set up Mozran with the Ghost Mafia (aka, Iracard - a Winter Eladrin who was helping enforce security in this place
for his brother). In Exchange, they received an Animated Shield.

‘They also received all of the magical items they comissioned on the previous session.

Next time - Alluin in the Third Age!

#### ChatGPT Output:
Finishing the Astral plane jaunt through time travel. Game will end traveling back in time through the astral portal.

Party Set up Mozran with the Ghost Mafia (aka, Iracard - a Winter Eladrin who was helping enforce security in this place
for his brother). In Exchange, they received an Animated Shield.

They also received all of the magical items they commissioned on the previous session.

Next time - Alluin in the Third Age!

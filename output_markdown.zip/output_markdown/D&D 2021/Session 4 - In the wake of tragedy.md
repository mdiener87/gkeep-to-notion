# Session 4 - In the wake of tragedy

    **Created:** 2021-10-29 11:38:19  
    **Last Edited:** 2021-10-29 11:38:24  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Princess Rose is dead. Assasinated by someone, or something, impersonating Pvt. Kennan. The King is beside himself. His
Kingdom lies in ruins from the wars. With his daughter's death, he no longer has the strength to carry on. As news of this
tragedy carries across the land, a dark mood grips the people. Is this the breaking point of the Kingdom?

Prince Zelphar is beside himself. His loyal servant, llitran, has not only succesfully ended his lineage, but discovered that
Galtorah never destroyed the Mirror of Prophecy as he was led to believe. His agents are already on the prowl,
attempting to find the keep that hides this mirror.

Zelphar's time to strike is soon at hand. He wishes to declare himself King. For centruries, he has watched as usrurpers
have led the Kingdon. He will send word to the King, and to each city Governor, informing them that the lineage of
Moryn, and the lordship of Humans, will soon come to its natural end. He is ready, by birthright, to claim the thrown and
reform the Government, with the Drow Elves retaking their place in the world.

Result:

Party followed ghostly, ethereal footsteps down into the dungeons of Alluin, and through a secret door. There, they
encountered spiders and phase spiders living in their webs throughout the tunnels. Dispatching the spiders was easy
enough, and the tunnels soon led to another hidden door. The door was trapped, and Dorc smashed a phase spider into
it, triggering poison darts. Kaetus' fire elemental melted through the door and opened it, revealing a troope of Drow
soldiers.

Kaetus hit them with a fireball, vaporizing the lesser drow archers. The Drow inquisitor was slightly tougher, but Zephyr
made easy work of him with repeated hits and a stunning strike. Taking him prisoner, the PCs were able to intimidate
him into revealing that the assassin was llitrain, working for Prince Zelphar. Located in the Tower of Bithiyra, a place that
the unfaithful cannot find.

Kaetus spared his life when Dorc snapped his neck, only to then burn his face off with Burning Hands.
‘The party returned to the throne room, and informed the king of their findings. The King is near dispair, and considering
relinquishing his rule to Floriana as he grieves. Trynicuss has ordered the Drow tunnels sealed, and a bounty placed on

lltran’s head.

‘The party plans to immediately depart and secure the Mirror of Prophecy before llitrain can get her hands on it...

#### ChatGPT Output:
Princess Rose is dead. Assassinated by someone, or something, impersonating Pvt. Kennan. The King is beside himself. His
Kingdom lies in ruins from the wars. With his daughter's death, he no longer has the strength to carry on. As news of this
tragedy carries across the land, a dark mood grips the people. Is this the breaking point of the Kingdom?

Prince Zelphar is beside himself. His loyal servant, Iltiran, has not only successfully ended his lineage, but discovered that
Galtorah never destroyed the Mirror of Prophecy as he was led to believe. His agents are already on the prowl,
attempting to find the keep that hides this mirror.

Zelphar's time to strike is soon at hand. He wishes to declare himself King. For centuries, he has watched as usurpers
have led the Kingdom. He will send word to the King, and to each city Governor, informing them that the lineage of
Moryn, and the lordship of Humans, will soon come to its natural end. He is ready, by birthright, to claim the throne and
reform the Government, with the Drow Elves retaking their place in the world.

Result:

Party followed ghostly, ethereal footsteps down into the dungeons of Alluin, and through a secret door. There, they
encountered spiders and phase spiders living in their webs throughout the tunnels. Dispatching the spiders was easy
enough, and the tunnels soon led to another hidden door. The door was trapped, and Dorc smashed a phase spider into
it, triggering poison darts. Kaetus' fire elemental melted through the door and opened it, revealing a troop of Drow
soldiers.

Kaetus hit them with a fireball, vaporizing the lesser drow archers. The Drow inquisitor was slightly tougher, but Zephyr
made easy work of him with repeated hits and a stunning strike. Taking him prisoner, the PCs were able to intimidate
him into revealing that the assassin was Iltiran, working for Prince Zelphar. Located in the Tower of Bithiyra, a place that
the unfaithful cannot find.

Kaetus spared his life when Dorc snapped his neck, only to then burn his face off with Burning Hands.
The party returned to the throne room, and informed the king of their findings. The King is near despair, and considering
relinquishing his rule to Floriana as he grieves. Trynicuss has ordered the Drow tunnels sealed, and a bounty placed on
Iltiran’s head.

The party plans to immediately depart and secure the Mirror of Prophecy before Iltiran can get her hands on it...

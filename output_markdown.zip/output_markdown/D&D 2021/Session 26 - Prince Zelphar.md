# Session 26 - Prince Zelphar

    **Created:** 2021-10-29 11:42:55  
    **Last Edited:** 2024-11-14 17:32:49  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

9/16/21 Gameplay notes


The prince zelphar fight!

At the start of combat, the party cleared out two Elite Drow warriors in the side hallways. Kipla killed the first Drow unexpectedly, accidentally inflicting Valzumin's explosion damage on allies!

The party confronted the boss. Princess Gwen stepped forward, acosting Zelphar and demanding he surrender to justice!


Zelphar danced all around the fight, using his legendary actions to teleport about and stab opponents. He opened the battle with top of turn order priority, rushing forward and stabbing the princess twice! This damage inflicted over 100% hp, sending the princess to death saving throws!

During the battle, drow archers constantly rained down shots. All of which was redirected to Dorc's cursed shield. A few of these attacks hit, but Droc shrugged off the damage of these bolts, and their poison.

Gandus conjured his Hellfire steed, and used multiple spells to buff his defenses and healing. He started healing his allies, but struggled to find melee range against Zelphar to inflict damage.

Kipla landed some excellent attacks, including the final blow for an incredible 101 critical damage! (Including explosion damage, which killed a drow warrior and damaged Zephyr).

Ureausa repeatedly bank'ed Zelphar, and used her Twilight Shroud to help remove the poison Zelphar repeated inflicted on her allies.

Skittles repeatedly drew on the power of the Ring of Whispers. Each time, an attack that missed suddenly struck true. Skittles strength grew exponentially, and now has the strenght of a strong man!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘At long last, the Order has finally caught up to the BBEG - Prince Zelphar. The party has been chasing this guy, in one way
or another, for nearly 18 months now. Let's make it a good show.

The fight:

‘Two stage fight - Prince Zelphar of the 3rd age, and Prince Zelphar of the main timeline. Each has different tricks up their
sleeve. This is designed to be a hard encounter. The Party might very well get TPKd here. I want there to be a sense of
danger in this fight. Players that are killed in the past might be saved in the future on the Endimyon. Their astral souls
can go on a quest to re-incorporate. However, there will be both gear and XP penalties for doing so.

Prince Zelphar of the 3rd Age
HP 320

ACB

Speed 4oft

STR +5 DEX +6 CON 45 INT +6 WIS #5 CHA +6

‘Saving throws DEX +10, CON +10, WIS +10

Skills,

Deception +12, insight +12, Perception +15, Persuasion +15
Damage Immunity Poison

Damage Resistances - Fire, Ice, Lightning (Ring of Three Elements)

‘Shapechanger - Giant Spider

Innsate spellcasting: DC17, CHA
At will 3x a day each:

Charm person, Crown of Madness, Detect Magic, dispell magic, minor image, major image, darkness, project image,
darkness

Legendary Resistance 3x a Day (3/3 remaining}

Actions
Multiattack 2 - Zelphar's Rapier
+13 to hit, 4d6 piercing + 6 damage

‘Target's struck by this rapier make any CON saves against poison inflicted by it with disadvantage.
‘This rapier is always considered magically poisoned. Ifa poison is added to the weapon, the rapier poison will also still
apply.

Rapier's Poison On Hit, target must make a DC18 CON saving throw or take 2d8 poison damage. Half damage on save.

Zelphar's Poison: On hit, target must make a DC18 CON saving throw or become poisoned with Zelphar's poison. While
poisoned in this way, at the end of round, you take 4d8 poison damage plus lose 1412 maximum HP. Maximum health
lost in this way can only be regained by using Greater Restoration to heal the damaged tissue. If you are killed as a result
of maximum HP becorning 0 or less, your soul is transported to Lolith's Domain, the Spiderweb Pits, and you cannot be
brought back to life through normal means.

Bonus Actions: Greater Healing Potion x3 (3/3)

Reaction: Parry/Riposte

Zelphar my parry a melee attack he can see, gaining +5AC. If an attack is blocked, he may make a single melee attack
against his attacker.

Legendary Actions: 3

Shadow Stab - Misty step up to 30ft, then you may make up to 1 melee attack.

Cast a Spell - Zelphar Casts a spell from his spell list

Stealth - Drow magic conceals your presence. Until end of round, you become invisible, may make a stealth check

with Advantage, and move up to half your move speed in distance

‘Summon Ally (2 actions) - Summot
Terrorweb spiders (106)
Drow Agents (148) (up to 4x Drow Archers and 4x Drow Elite Warriors)
Naga (from prior boss fight in this chamber)
Mommy {tlitrain)
Random Demons

Zelphar of Main Timeline:
‘As above, but +100HP, and gain all spells and abilities as per Drow Favored Consort

‘The prince zelphar fight!
‘At the start of combat, the party cleared out two Elite Drow warriors in the side hallways. Kipla killed the first Drow
unexpectedly, accidentally inflicting Valzumin's explosion damage on allies!

‘The party confronted the boss. Princess Gwen stepped forward, acosting Zelphar and demanding he surrender to
justice!

Zelphar danced all around the fight, using his legendary actions to teleport about and stab opponents. He opened the
battle with top of turn order priority, rushing forward and stabbing the princess twice! This damage inflicted over 100%
hp, sending the princess to death saving throws!

During the battle, drow archers constantly rained down shots. All of which was redirected to Dore's cursed shield. A few
of these attacks hit, but Droc shrugged off the damage of these bolts, and their poison.

Gandus conjured his Hellfire steed, and used multiple spells to buff his defenses and healing. He started healing his.
allies, but struggled to find melee range against Zelphar to inflict damage.

Kipla landed some excellent attacks, including the final blow for an incredible 101 critical damage! (Including explosion
damage, which killed a drow warrior and damaged Zephyr}.

Ureausa repeatedly bank'ed Zelphar, and used her Twilight Shroud to help remove the poison Zelphar repeated inflicted
on her allies.

Skittles repeatedly drew on the power of the Ring of Whispers. Each time, an attack that missed suddenly struck true.
Skittles strength grew exponentially, and now has the strenght of a strong man!

Zelphar loot:
(On 3rd age body: Zelphar's Rapier

1000gp in pocket

‘On modern age body: Book of Vile Darkness
2000gp in pocket

#### ChatGPT Output:
‘At long last, the Order has finally caught up to the BBEG - Prince Zelphar. The party has been chasing this guy, in one way
or another, for nearly 18 months now. Let's make it a good show.

**The fight:**

‘Two stage fight - Prince Zelphar of the 3rd age, and Prince Zelphar of the main timeline. Each has different tricks up their
sleeve. This is designed to be a hard encounter. The Party might very well get TPKd here. I want there to be a sense of
danger in this fight. Players that are killed in the past might be saved in the future on the Endimyon. Their astral souls
can go on a quest to re-incorporate. However, there will be both gear and XP penalties for doing so.

**Prince Zelphar of the 3rd Age**
- HP 320
- ACB
- Speed 40ft
- STR +5 DEX +6 CON 45 INT +6 WIS #5 CHA +6
- Saving throws DEX +10, CON +10, WIS +10
- Skills:
  - Deception +12, Insight +12, Perception +15, Persuasion +15
- Damage Immunity: Poison
- Damage Resistances: Fire, Ice, Lightning (Ring of Three Elements)
- Shapechanger: Giant Spider
- Innate spellcasting: DC17, CHA
  - At will 3x a day each:
    - Charm person, Crown of Madness, Detect Magic, Dispel Magic, Minor Image, Major Image, Darkness, Project Image, Darkness
- Legendary Resistance 3x a Day (3/3 remaining)

**Actions**
- Multiattack 2 - Zelphar's Rapier
  - +13 to hit, 4d6 piercing + 6 damage
  - Target's struck by this rapier make any CON saves against poison inflicted by it with disadvantage.
  - This rapier is always considered magically poisoned. If a poison is added to the weapon, the rapier poison will also still apply.
- Rapier's Poison: On Hit, target must make a DC18 CON saving throw or take 2d8 poison damage. Half damage on save.
- Zelphar's Poison: On hit, target must make a DC18 CON saving throw or become poisoned with Zelphar's poison. While
  poisoned in this way, at the end of round, you take 4d8 poison damage plus lose 1/12 maximum HP. Maximum health
  lost in this way can only be regained by using Greater Restoration to heal the damaged tissue. If you are killed as a result
  of maximum HP becoming 0 or less, your soul is transported to Lolth's Domain, the Spiderweb Pits, and you cannot be
  brought back to life through normal means.

**Bonus Actions:**
- Greater Healing Potion x3 (3/3)

**Reaction:**
- Parry/Riposte
  - Zelphar may parry a melee attack he can see, gaining +5AC. If an attack is blocked, he may make a single melee attack
    against his attacker.

**Legendary Actions: 3**
- Shadow Stab - Misty step up to 30ft, then you may make up to 1 melee attack.
- Cast a Spell - Zelphar Casts a spell from his spell list
- Stealth - Drow magic conceals your presence. Until end of round, you become invisible, may make a stealth check
  with Advantage, and move up to half your move speed in distance
- Summon Ally (2 actions):
  - Terrorweb spiders (1d6)
  - Drow Agents (1d8) (up to 4x Drow Archers and 4x Drow Elite Warriors)
  - Naga (from prior boss fight in this chamber)
  - Mummy (1d4)
  - Random Demons

**Zelphar of Main Timeline:**
- As above, but +100HP, and gain all spells and abilities as per Drow Favored Consort

**The prince Zelphar fight!**
- At the start of combat, the party cleared out two Elite Drow warriors in the side hallways. Kipla killed the first Drow
  unexpectedly, accidentally inflicting Valzumin's explosion damage on allies!
- The party confronted the boss. Princess Gwen stepped forward, accosting Zelphar and demanding he surrender to
  justice!
- Zelphar danced all around the fight, using his legendary actions to teleport about and stab opponents. He opened the
  battle with top of turn order priority, rushing forward and stabbing the princess twice! This damage inflicted over 100%
  hp, sending the princess to death saving throws!
- During the battle, drow archers constantly rained down shots. All of which was redirected to Dore's cursed shield. A few
  of these attacks hit, but Droc shrugged off the damage of these bolts, and their poison.
- Gandus conjured his Hellfire steed, and used multiple spells to buff his defenses and healing. He started healing his
  allies, but struggled to find melee range against Zelphar to inflict damage.
- Kipla landed some excellent attacks, including the final blow for an incredible 101 critical damage! (Including explosion
  damage, which killed a drow warrior and damaged Zephyr).
- Ureausa repeatedly flanked Zelphar, and used her Twilight Shroud to help remove the poison Zelphar repeatedly inflicted
  on her allies.
- Skittles repeatedly drew on the power of the Ring of Whispers. Each time, an attack that missed suddenly struck true.
  Skittles strength grew exponentially, and now has the strength of a strong man!

**Zelphar loot:**
- On 3rd age body: Zelphar's Rapier
  - 1000gp in pocket
- On modern age body: Book of Vile Darkness
  - 2000gp in pocket

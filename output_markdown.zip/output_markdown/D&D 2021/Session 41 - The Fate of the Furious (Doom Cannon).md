# Session 41 - The Fate of the Furious (Doom Cannon)

    **Created:** 2022-03-10 18:37:22  
    **Last Edited:** 2022-03-10 22:30:31  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Didn't run the boss fight yesterday, maybe today is a good chance to do so at a loser DC.

Otherwise, party needs to decide what they'll do about the Doom Cannon. Likely will try to destroy it, but this time without arming all the warheads and vaporizing Borrend in the process.

The question then becomes, what next? What is the party's next move? Return to their timeline? Try to kill the dragon in the past? This might be a shorter / RP / planning session depending if I run the boss fight and what the party ends up doing.

---

Gameplay notes 3/10/22

Ila the Handsome knows Esepha the Enchanted. Esepha somehow conned Ila into the ring. This ring then found its way into Kaladan's possession. 

Earth elemetnal myrmidon - Pebble
Can be summoned by his summoning stone once every 48 hours
Not much personality yet


Party took careful pains to explore the doom cannon structure. They found 1 armed shell in the fire control center, and 3 more in the armory on the next level below. The party took the time to examine the tools and instruments and discovered there were purpose built equipment to service the shells. With Dorc's ability to read Dwarven, he assisted Kipla in selecting the tools that would give her an advantage in opening and disarming the warheads.

Kipla summoned Ila the handsome, asking him to disarm the warheads. Ila had no idea how to do this, but instead offered to teleport them to a different dimension. Turns out, Ila the Handsome has ties to Esepha the Enchanted, and he wouldn't mind paying tribute to the powerful Djinn with a gift of a few weapons of mass destruction. Everyone shot this idea down. Kipla instead sent him deeper into the complex to find her shinies. 

She made expert work of the first casing. Inside was a magical core of some kind, surrounded by gnomish gears and explosives. Kaetus hit with Dispel Magic, and removed the enchanted gas portion of the warhead. He would go on to repeat this process on the other warheads.

The party went deeper into the complex, exploring sublevel 2. In it, they found partially assemebled weapons, and a gas tank that was available to help charge their warhead. Kipla summoned Istantar, who, besides teasing Dorc and Gandus with the wickedness of her sexuality, could somewhat read Gnomish. She helped Kaetus decipher the instructions on the tank. Kaetus set them all to the sealed setting, while Istantar instead proposed using the weapon to seed destruction and chaos throughout the realm. Such an opportunity would let the Order seize power as the ultimate authority in the realm. While Kipla was tempted, the party turned her plan down.

Ila came back with a large pile of Gold, and a stone of elemental myrmidon summoning. Kaetus demonstrated how to use this by concentrating on the stone and summoning the myrmidon 'pebble'. Without much immediate need for him, he released the summon, who returned to his original stone form.

The party returned to the surface level, and Kaetus disarmed the magical portion of the original warhead. He granted the party Wind Walk, and everyone took flight. Kaetus flew to a nearby ledge at maximum range, and hit the Doom Cannon with Earthquake. The cannon, and its subteranean complex, collapsed and was totally destroyed. Some secondary explosions cooked off, but nothing to the degree or danger as the Party's original attempt to do so in the future.

With their task complete, the party set course for Alluin, with a plan to return to the future and face their now altered fates there.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 34 - A Relaxing Day at the Beach!

    **Created:** 2021-12-16 19:08:36  
    **Last Edited:** 2021-12-16 19:08:45  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Gameplay Notes 12/16

Today is a special, and long desired, beach day episode! The order was victorious over Ilitran and her remaining drow forces. Zephyr has been saved, and everyone is in need of a little R&R! Princess Gwen will recommend the party head to the beaches of Selevarum! This island is home to the High Elves of the kingdom, and has never been properly explored!


Beach Challenges:

Volleyball against [team name]

First to 5 scores

D8 for sector hit. 

On a good hit, group by 2s, increasing in distance.

On a 'bad' hit, 1-4 is a team sector movement of the ball.

Roll a skill check (athletics, acrobatics, arcane) to hit the ball. Total roll scores less than 10 can fly back randomly towards your team. If you are within 3 of the DC check, roll the D6 with disadvantage (biased towards hitting your teams zone) and this counts as a hit.

Base DC to hit the ball is 5 + (3 * number of consecutive hits).

Special Moves: (+DC to hit, +DC to return, +Sector Modification)

Power Shot: +3/+3+0  If succesfull, the ball shoots forward at an incredible rate, adding an additional +3 DC check to hit the ball. Power Shot Requires an Athletics roll.

Spike Shot: +5/+5/0. If succesfull, the ball shots forward with a guranteed hit in the enemies closest zone. Only Athletics and Acrobatics may use this move.

Far Shot: +2 / +2 / +2. You cannot be in the front row to use this move. Any skill check.

Trick Shot: +2 / + 4 / -2. Requires an Arcane skill check.

Called Shot: +1 / -1. You may declare your target sector and skip the D8 Roll. If you fumble the hit, hits your equivelant sector. Any skill check.

Arcane Setup: +2 / -2 / 0. You may only target your side of the net with this shot. Requires an Arcane skill check


'The Owlbear Dodgers' 
Elred Iarwraek - Front, +5 Str, +3 Dex, +1 Arcane - Jock Bro
Solana Erlamin - Center, +3Str, +5Dex, +1 Arcane - Bitchy and superior
Hagduin Naena - Back, +1Str, +3Dex, +5 Arcane - Overly Smart, sarcastic

Play for a trophy signed by none other than Lord Galtorah himself. Hologram on activation will say "This is my favorite Volleyball team in Selevarum" in a bored intonation. 





Best of 3 games


----------------------


Sandcastle competition
4 Rounds of Sandcastle building. Winner is the highest total score. Describe the skill involved as you roll.
	Structure: Any Str check 
	Features: Any Int Check 
	Details: Any Wis check 
	Presentation: Any Cha check 
	
Winner: 500G

NPC entries
young girl (+5 on cha, +1 with wis)
teenage boy (+3 on str)
Old Man (rolls with advantage)
Happy Couple (+1 all rolls)

-----------------------

Beach BBQ
May buy from beach vendors or use Survival to craft your own tasty Beach BBQ!
Eating a hearty portion of beach BBQ will count as a long rest, plus restore missing attribute scores


--------------------


Princess Gwen

Flirting hard with Kaetus this session. Will try to take him to the old woods temple she first learned magic at. She will try to convince Kaetus to stay in this time with her and abandon the thought of returning to the future. Maybe roll a simple combat encounter if we need more content.

If Kaetus refuses, she will offer a pendant with [stats] so he will always remember her.
Note: Galtorah's bracer only has the shield spell left in it. By Galtorah not dying and/or going insane, he never places his spirit into his bracer. It only is a magical shielding bracer now.


--

No high elves council. No appropriate map and its a chill sesh not a heavy RP sesh

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 2 - The Mirror of Prophecy (or not?)

    **Created:** 2021-10-29 11:37:54  
    **Last Edited:** 2021-10-29 11:38:04  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Today: Probably the Sibriex fight. If that doesn't occur for some reason, they'll probably be returning to Galtorah and the
rest of the kingdom. It's time to crank up the Narzugon asa backup plan for the action today.

Sibriex - see web stats

‘The Mirror if they activate it - this could get wild. Be ready to channel some steins; gate stuff here. Will they get to the
world timeline that it all ends well on?

‘Also, each use of the mirror has the chance to reveal another trap from Prince Zelphar. Or to encounter other planar /
‘temporal enemies.

Result:

‘The Party wasn't ready to really fuck around with the mirror of prophecy. After searching the keep's library for help on
its operation (or notes on the Sibrex demon) they elected to instead head back up to the surface and catch up on the.
state of the world, The Narzugon had struck. A waiting message from Floriana indicated he attacked the Black Scar
Garrison and destroyed it. Pvt. Kennan was able to get Floriana out, but just barely. They were holed up in a small
mountain cabin, and the Narzugon is closing in.

‘The Order rushed into action. They found the Narzugon on the ground, accompanied by his Nightmare steed and 3 Hell
Hounds. The hounds rushed the cabin, trying to fell Florina and her last defender. The Narzugon engaged the party. It
‘was a pitched battle, as the Narzugon hit like a truck and his armor deflected every blow the party sent his way. He
skipped through to the ethereal realm, and came out to strike Kaetus again. Gandus tried to fight him, only for the
Narzuon to positively blap his hitpoints with 3 powerful blows.

Ureasua took her turn, and used Divine Word. The Narzugon failed his save, rolled with advantage, and he was instantly
banished back to the Nine Hells. She then completed the double kill with a Toll of the Dead on the injured Nightmare.

Dore rushed in and delivered a series of blows - including a critical hit -to the final Hell Hound, felling the creature and
ending combat.

#### ChatGPT Output:
Today: Probably the Sibriex fight. If that doesn't occur for some reason, they'll probably be returning to Galtorah and the
rest of the kingdom. It's time to crank up the Narzugon as a backup plan for the action today.

*Sibriex* - see web stats

‘The Mirror if they activate it - this could get wild. Be ready to channel some *Steins;Gate* stuff here. Will they get to the
world timeline that it all ends well on?

- Also, each use of the mirror has the chance to reveal another trap from Prince Zelphar. Or to encounter other planar /
  temporal enemies.

**Result:**

‘The Party wasn't ready to really mess with the mirror of prophecy. After searching the keep's library for help on
its operation (or notes on the Sibrex demon) they elected to instead head back up to the surface and catch up on the
state of the world. The Narzugon had struck. A waiting message from Floriana indicated he attacked the Black Scar
Garrison and destroyed it. Pvt. Kennan was able to get Floriana out, but just barely. They were holed up in a small
mountain cabin, and the Narzugon is closing in.

‘The Order rushed into action. They found the Narzugon on the ground, accompanied by his Nightmare steed and 3 Hell
Hounds. The hounds rushed the cabin, trying to fell Florina and her last defender. The Narzugon engaged the party. It
was a pitched battle, as the Narzugon hit like a truck and his armor deflected every blow the party sent his way. He
skipped through to the ethereal realm, and came out to strike Kaetus again. Gandus tried to fight him, only for the
Narzuon to positively blap his hitpoints with 3 powerful blows.

Ureasua took her turn, and used Divine Word. The Narzugon failed his save, rolled with advantage, and he was instantly
banished back to the Nine Hells. She then completed the double kill with a Toll of the Dead on the injured Nightmare.

Dore rushed in and delivered a series of blows - including a critical hit -to the final Hell Hound, felling the creature and
ending combat.

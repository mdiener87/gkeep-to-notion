# Session 35 - Roll 2022

    **Created:** 2022-01-13 19:05:02  
    **Last Edited:** 2022-01-13 22:27:12  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

The party has completed their mini-vacation at Selevarum. They return now to the castle - are they returning home? Or do they stop and pay a visit to stop the doom cannon? We know the answer to this. The party just can't stop meddling in the timeline!

Of course, they should realize that they have already meddled in Borrend's affairs one too many times. They raised the spectre of Knucklestep Shappin, insane Gnome and leader of Borrend. While they did 'slay' this specter before it could wonder off and cause too much damage, his evil and potent spirit is not so easily quelled. Wandering the astral plane, alone and fragmented, it came by chance through the portal the party has torn open in space and time. It too now seeks to alter the past, and secure Borrend's unlimited future!


United with this future spirit, Knucklestepp knows that something weird has gone on. The Drow they keep tabs on have all but disapeared. News of assasination attempts and political unrest in Alluin has swept across the kingdom. Knucklestepp senses his chance to make Borrend not just a secure city state, but a leader of the land! His army is now infusing itself with the toxic gasses from beneath the city. This 'small death' as he calls it, is the catalyst for releasing their spirits just as he has.

[Duregar units]
+
[on death, summon another spirit]

// Keep track of spirits, they'll all come back in the fight with Knucklestepp.

KS has declared Borrend the uncontested free leader, rising up against elven tyranny. What can the order to do stop such evil?



======

DnD notes 1/13/22

An RP session that discussed the matter of both returning to the future, and the growing threat of the doom cannon in Borrend. After much discussion, the party has decided to further interefere in the past and destroy the cannon, and/or kill Knucklestepp Shapin.

Borrend history - Zephyr rolled a nat 20:
	KS has dedicated the entire enconomy and effort of Borrend into his vision of the doom cannon. While the weapon nears completion, it has come at the loss of economic growth and opportunity for its people. A loss of education, growth, and prosperity has gripped the city. KS is very old, history recalls him dying of natural causes - with the doom cannon falling into obscurity and disuse. 

Kaetus -> Gave Galorah his bracer, which was combined with Galorah's current temporal bracer. This fused the item into a single Bracer, from beyond time. It now gives a one time ability for Time Stop!

Zephyr -> Handed in Galorah's Journal. Galorah granted Zephyr the use of Zelphar's Edge, and confirmed it had no traps or curses upon it. He also gave him Do'seks's Skeletal Head, which Galorah will study.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
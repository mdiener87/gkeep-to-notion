# Session 21 - Galtorah's Keep, in the Third Age

    **Created:** 2021-10-29 11:41:52  
    **Last Edited:** 2024-11-14 17:52:44  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)



*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party decided not to return to Alluin with the princess. Instead, they have gone to Galtorah's keep. This will force a
confrontation with Zelphar. But first, the party must get to him!

In their way stands Ilitrain. This boss fight was avoided previously but she will be waiting for them here in the keep.

Galtorah lives - but not really. Zelphar flung his body through the Mirror of Time, so that he might live out his dying
moments forever. Zelphar has access to the mirror, and has seen the order's arrival. He knows to fight these interlopers
with maximum firepower.

Monsters:
Uitrain

Sleep Aura - As per the Sleep Spell for effect. WIS Save, DC 13 outside the maze, DC15 inside the maze, DC19 facing
illitrain. The Sleep Aura checks at the end of combat, and any time a creature takes more than 10 damage from a single
source. If a Character saves from the damage check, they are immune to further damage checks until the end of the
round. Only up to 2 creatures can become sleeped at the same time from the end of round effect.

+#2on the check near gwen while she channels energy against the effect,

Drow Agents (kobold fight club these but not too time consuming)
Terror Spiders
~-As per Phase Spider, but bite damage is necrotic instead of piercing. is Abberant and Fiend (Demon) instead of a
beast. Has less HP (50%) but constantly respawns. Poison damage from the bite adds half that much to the
resulting sleep spell DC check. Any damage from this unit forces a sleep spell check, if active,

#### ChatGPT Output:
‘The party decided not to return to Alluin with the princess. Instead, they have gone to Galtorah's keep. This will force a
confrontation with Zelphar. But first, the party must get to him!

In their way stands Ilitrain. This boss fight was avoided previously but she will be waiting for them here in the keep.

Galtorah lives - but not really. Zelphar flung his body through the Mirror of Time, so that he might live out his dying
moments forever. Zelphar has access to the mirror, and has seen the order's arrival. He knows to fight these interlopers
with maximum firepower.

**Monsters:**
- Uitrain

  - **Sleep Aura** - As per the Sleep Spell for effect. WIS Save, DC 13 outside the maze, DC15 inside the maze, DC19 facing
  Ilitrain. The Sleep Aura checks at the end of combat, and any time a creature takes more than 10 damage from a single
  source. If a Character saves from the damage check, they are immune to further damage checks until the end of the
  round. Only up to 2 creatures can become sleeped at the same time from the end of round effect.

  - **+2 on the check near Gwen** while she channels energy against the effect,

- **Drow Agents** (kobold fight club these but not too time consuming)
- **Terror Spiders**
  - As per Phase Spider, but bite damage is necrotic instead of piercing. is Abberant and Fiend (Demon) instead of a
  beast. Has less HP (50%) but constantly respawns. Poison damage from the bite adds half that much to the
  resulting sleep spell DC check. Any damage from this unit forces a sleep spell check, if active.

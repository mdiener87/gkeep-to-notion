# Session 15 - The Third Age

    **Created:** 2021-10-29 11:40:36  
    **Last Edited:** 2021-10-29 11:40:40  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
(Okay so struggling with major writer's block here. | have no idea what | want from this.
We need to step back a little and write to ourselves Michael. Come on.

‘We are using Steins; Gate time travel rules (sort of). While the Order originally wanted to go back to stop themselves
from destroying Borrend in the Doom Cannon Incident, their objective has now changed. The target instead is to prevent
the murder of Gattorah. His son, Prince Zelphar, is said to have delivered the blow. He kills not only Galtorah, but his
Sister Gwen as well. This causes the Beta timeline, which has devastated the Kingdom (somewhat unbeknownst to the
party but hey).

‘The Original timeline, Alpha, had Galtorah go insane from the use of the mirror. Instead, it was the Sibriex demon in the
mirror that led to Galtorah's insanity. His mind fractured, and through the mirror's demonic possession, his shade was
left to haunt the lands.

‘So what do we actually want from this first session?

Zephyr rolled an 89 on the Temporal Teleport roll when he activated the mirror. This means they are on target spatially
and temporally.

This first session | want to open a bit dramatically. | want them to feel the consequences of messing with Time. | want
them to immediately be thrust into some epic combat. Later RP can introduce King Galtoraha and the current 3rd age
Kingdom.

#### ChatGPT Output:
(Okay so struggling with major writer's block here. I have no idea what I want from this.
We need to step back a little and write to ourselves Michael. Come on.

'We are using Steins; Gate time travel rules (sort of). While the Order originally wanted to go back to stop themselves
from destroying Borrend in the Doom Cannon Incident, their objective has now changed. The target instead is to prevent
the murder of Gattorah. His son, Prince Zelphar, is said to have delivered the blow. He kills not only Galtorah, but his
Sister Gwen as well. This causes the Beta timeline, which has devastated the Kingdom (somewhat unbeknownst to the
party but hey).

'The Original timeline, Alpha, had Galtorah go insane from the use of the mirror. Instead, it was the Sibriex demon in the
mirror that led to Galtorah's insanity. His mind fractured, and through the mirror's demonic possession, his shade was
left to haunt the lands.

'So what do we actually want from this first session?

Zephyr rolled an 89 on the Temporal Teleport roll when he activated the mirror. This means they are on target spatially
and temporally.

This first session I want to open a bit dramatically. I want them to feel the consequences of messing with Time. I want
them to immediately be thrust into some epic combat. Later RP can introduce King Galtoraha and the current 3rd age
Kingdom.'

# Session 31 - Galtorah's Secret

    **Created:** 2021-11-18 22:33:22  
    **Last Edited:** 2024-11-14 17:25:32  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Gameplay notes 11/18/21


This was an RP session! Zephyr's rescue mission will be delayed until the next night.

Gandus and Dorc tortured the prisoner. Dorc held her captive while Gandus inflicted her with repeated strikes from his long-held Slaad claws. This inflicted her with Chaos Phage - a Slaady death that terrified her. She eventually panicked and told Gandus that Illitrain would likely have teleported to a nearby cave. Gandus reached out to heal ... but instead healed Dorc. His other hand reached for his blade, and slashed the captive drown with his blade. Killing her instantly.

Kaetus talked with Omipitar some. Omipitar asked Kaetus to investigate what happened to his men. HIs medical checks revealed that the elven soldiers were totally wasted away. Omipitar tried to pray to them and couldn't - their souls seemed to be totally missing from his spiritual awareness.

Kaetus also used Heal on Kipla, trying to cure her of Zelphar's max HP damage. While he succeeded in restoring her HP, he was not succesful at removing the max hp burn.

Kaetus used Divination to ask Habakuk how to heal the poison. He was shown a series of images that revealed how Zelphar developed his poison, using the Slaad toxin as a base. It was finally 'blessed' by Ilitran's kiss, which perfected his concotion. The treatment to this poison seems to lie in this kiss. 

With the prisoner dispatched, Galtorah was asked to return to the room. Galtorah knew the location described by the captured prison. But before the party was teleported off to the caves, Kaetus pressed Galtorah on the true family history behind Zelphar. And.. he revealed them. Revealed that he raped (or was raped) by Ilitran. That Ilitran gave birth to his first born son. And this secret shame would alter the history of the kingdom.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 30 - Battle in the Throne Room

    **Created:** 2021-11-11 21:57:26  
    **Last Edited:** 2021-11-11 22:00:28  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Today, the players will be starting off in the Alluin Thrown Room. Kaetus is disguised as Zelphar, and has infiltrated the drow war party to help set up an ambush. Roll from last week notes.


---


Gameplay notes 11/11

The game session started with Kipla and Kaetus starting a surprise round. Kipla started off with a Valzumin's crossbow bolt, shooting the Demon Queen in the back! Kaetus follwed that up with a fireball, blasting the demon queen and many of the drow. The drow archers were all instantly vaporized.

Zephyr and Dorc burst into the room. Full combat began. The Demon Queen rolled highest initiative, and tried to dominate kipla to kill her friends. Luckily, she resisted the effect.

Kaetus transformed himself into a terrifying fire elemental. His presence burend the nearby drow to a crisp, and forced a third nearby one to flee (who would run through Dorc and trigger his sentinel attack). 

Kipla found herself face to face with a Drider that was hiding on a nearby statue. It jumped down and did a full attack, dropping her to 4 hp. 

Zephyr flew in the thick of combat. Giant Terror Spiders surrounded him, but he was not worried. He would strike back and forth, using Action Surge to ko two spiders in the same turn.

Dorc rushed to Kipla's aid. He slashed at the Drider, and then used his Shield feat to knock the creature away. Kipla would back up to safety, without realizing that she actually backed up into a phased out Terror Spider! The creature rematieralized and attacked her with advantage - but luckily, Kipla dodged and weaved and avoided the attacks which would certainally kill her. Dorc would come in to kill the Spider for kipla, and then absorb crossbow bolts aimed at her with his cursed shield.

Zephyr flew up to help the battle in the center. He would go on to kill the Drider with a deflected crossbow bolt from one of the elite soldiers. The Drider would die to friendly fire, a look of shock on its face.


It took two turns to occur, but The Demon Queen finally got her Eyebite spell to go off. She succesfully panicked Kaetus, getting his burning elemental form out of her face and gaining a small amount of breathing room.

Zephyr would fly up and try to stun the Demon Queen. She chose to resist his stun, but her ally could not. A final Drow Elite came up to help guard her queen, and succesfully grappled Zephyr.

On her final turn, the Drow Queen teleported out, touching her two adjacent allies. The second of which was still grappling Zephyr. While he had a chance to escape the effect, he once again failed his save and teleported out along with the escaping Drow!


The final drow elite found itself up against Dorc and Zephyr. While it fought well, it was no match for Dorc, who quicly put it in a grapple. Kipla and Dorc stayed its life - they might need it to know where Zephyr was just taken!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
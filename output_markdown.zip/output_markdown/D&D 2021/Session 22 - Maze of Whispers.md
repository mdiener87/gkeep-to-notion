# Session 22 - Maze of Whispers

    **Created:** 2021-10-29 11:42:05  
    **Last Edited:** 2024-11-14 17:41:33  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

8/29/21

Gameplay notes:

Ureausa and Kaetus investigated the teleportation circle. Kaetus determined that it likely targets Alluin. Kaetus tried to dispell the circle, but couldn't beat the DC

Dorc investigated the room to the south and determined that its thouroughly ransacked. The Drow clearly were looking for something but didn't find it here

Investigating the main room, Kaetus and Dorc found the central diaz to be eminanting sleep magick. He hit it with an 8th level dispell magick, silencing it.

Ureausa casted tiny hut, and the party quickly fell asleep without a watch set.

Upon their awakening, the party found themselves surrounded by spiders! Once the magick hut forcefield dropped, combat began. The boys dived into combat, quickly cleaving the spiders to pieces.

Kaetus wolfs' used their powerful noses out of combat to sniff out a hidden passageway in the wall. Dorc smashed into it with a STR check, revealing stairs deeper into the structure.


--

The next level was unknown to princess Gwyn. A seeming maze lied before the party. Invisible barriers of magick blocked their advance. Gandus struck the first one with his blade of molten magick, disentegrating it. Kaetus came upon the second and dropped it with a dispell magick. 

Some more drow lied up ahead. Dorc charged through on a mounted dire wolf and destroyed them.

A larger barier now lies before the party. What lies beyond it? FInd out next time on D&D!

Monsters:
giant snake skeleton

AC 16
HP 220
Saving throws STR + 10, CON + 7, Dex + 5
Damage immune: poison
damage resistance: cold, fire
damage vuln: bludgeoning

Multiattack:
Claws: +12 to hit, reach 10ft, one target: 4d6 + 8 bludgeoning + 4d6 necrotic

Abilities:

Poison Blast (recharge: 5-6):

As fireball, but poison damage

Loot:
shadowfell brand tattoo (knowledge on design pattern)
Ring of Animal Influence
Do'sek's Skeletal Head
	Drow magic still eminates from this large head. With a mixture of Drow, Yuan-Ti, and minitoar features, it is clearly that of an experiemntal chimera.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming in from last night, players need to find way to navigate to this level of the keep. The maze is dark and must be
explored. Drow mirrors of enchantment regularly line the hallways. Players must find a way to get through them. If
struck and broken, the PC will have to resist a curse being placed upon them,

‘The maze also has the sleep enchantment as fram the prior room, but at increased DC (DC 15)

C20, SHP. Resistance vs not magical weapons

pe1a—
INT: LURKING FEAR Failure spawns an illusionary monster. 1HP, hits for half damage
‘WIS: SLEEPY TIME Falls asleep upon teleporting

CON: WITHERING Suffer an exhaustion level. Caps at 3 stacks from this effect

CHA: SHAME First 3 Rolls in this chamber are taken at disadvantage

DEX: VERTIGO: Move at half speed in this chamber

Chambers can have Drow themed monsters

‘Once clear, they can proceed further into the keep

Result:

Ureausa and Kaetus investigated the teleportation circle. Kaetus determined that it likely targets Alluin. Kaetus
tried to dispell the circle, but couldn't beat the DC

Dore investigated the room to the south and determined that its thouroughly ransacked. The Drow clearly were
looking for something but didn't find it here

Investigating the main room, Kaetus and Dorc found the central diaz to be eminanting sleep magick. He hit it
with an 8th level dispell magick, silencing it

Ureausa casted tiny hut, and the party quickly fell asleep without a watch set.

Upon their awakening, the party found themselves surrounded by spiders! Once the magick hut forcefield
dropped, combat began. The boys dived into combat, quickly cleaving the spiders to pieces.

Kaetus wolfs' used their powerful noses out of combat to sniff out a hidden passageway in the wall. Dorc
smashed into it with a STR check, revealing stairs deeper into the structure.

The next level was unknown to princess Gwyn. A seeming maze lied before the party. Invisible barriers of
magick blocked their advance. Gandus struck the first one with his blade of molten magick, disintegrating it
Kaetus came upon the second and dropped it with a dispell magick.

Some more drow lied up ahead. Dorc charged through on a mounted dire wolf and destroyed them.

A larger barrier now lies before the party. What lies beyond it? Find out next time on D&D!

#### ChatGPT Output:
Coming in from last night, players need to find way to navigate to this level of the keep. The maze is dark and must be
explored. Drow mirrors of enchantment regularly line the hallways. Players must find a way to get through them. If
struck and broken, the PC will have to resist a curse being placed upon them,

- The maze also has the sleep enchantment as from the prior room, but at increased DC (DC 15)

- C20, SHP. Resistance vs not magical weapons

  - INT: LURKING FEAR Failure spawns an illusionary monster. 1HP, hits for half damage
  - WIS: SLEEPY TIME Falls asleep upon teleporting
  - CON: WITHERING Suffer an exhaustion level. Caps at 3 stacks from this effect
  - CHA: SHAME First 3 Rolls in this chamber are taken at disadvantage
  - DEX: VERTIGO: Move at half speed in this chamber

Chambers can have Drow themed monsters

Once clear, they can proceed further into the keep

Result:

Ureausa and Kaetus investigated the teleportation circle. Kaetus determined that it likely targets Alluin. Kaetus
tried to dispel the circle, but couldn't beat the DC

Dore investigated the room to the south and determined that it's thoroughly ransacked. The Drow clearly were
looking for something but didn't find it here

Investigating the main room, Kaetus and Dorc found the central diaz to be emanating sleep magick. He hit it
with an 8th level dispel magick, silencing it

Ureausa cast tiny hut, and the party quickly fell asleep without a watch set.

Upon their awakening, the party found themselves surrounded by spiders! Once the magick hut forcefield
dropped, combat began. The boys dived into combat, quickly cleaving the spiders to pieces.

Kaetus wolfs' used their powerful noses out of combat to sniff out a hidden passageway in the wall. Dorc
smashed into it with a STR check, revealing stairs deeper into the structure.

The next level was unknown to princess Gwyn. A seeming maze lied before the party. Invisible barriers of
magick blocked their advance. Gandus struck the first one with his blade of molten magick, disintegrating it
Kaetus came upon the second and dropped it with a dispel magick.

Some more drow lied up ahead. Dorc charged through on a mounted dire wolf and destroyed them.

A larger barrier now lies before the party. What lies beyond it? Find out next time on D&D!

# Session 8 - Ogloxon the Sibriex

    **Created:** 2021-10-29 11:39:02  
    **Last Edited:** 2021-10-29 11:39:17  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Bossfight warning

Coming into today's session, the party has made an unusual choice to split. Zephyr, Dork, and Gandus have elected to
remain inside the demi-plane at the heart of Galtorah's keep. Meanwhile, the rest of the party attempts to take a long
rest on the other side of the mirror wall so as to recover spell slots. What will happen?

‘Ogtoxon is old. And has been within the Mirror of Prophecy now for a long time. He has seen the streams of fate and
knows of the possibility for this encounter. He wishes most fervently to escape the mirror. To spread his unending
corruption throughout the mortal realm. The surge of magic that created Galtorah's Maze also let Ogloxon extend his
tentacles into this world. While he himself cannot escape without assistance, he can now at least corrupt this area.

Result:

‘The round started split, with the spell casters trying to regain spell slots in the material world. The Tiny Hut held the
rutterkin back, but Kaetus and Ureasua had to make saving throws to sleep through the racket.

Meanwhile, in the inner sancutm, Obloxon tempted the three party members. His tentacles slowly broke through the
barriers. Gandus found the temptations unnerving, and Prayed to the Raven Queen to bless him with shortsighted rage.

‘When the Long rest ended, Kaetus and Ureausa had to make a bee-line to the mirror portal. Kaetus cast a Tidal Wave to
help slow the rutterkin down, and then hopped through. Ureausa found the rutterkin surrounding her, but she easily
bashed the rutterkin in her away to the side. Kaetus' protection spell protected her from attacks of opportunity as she
got through the portal.

‘Those two found the party engaged in a prolonged battle against tentacles. Ureausa and Kaetus were also tempted by
‘Ogloxon, but resisted the effect.

Ureausa used her Divine intervention, using the power of Wujet to unleash the demon from its entrapped position
within the mirror. The Sibriex demon emerged. His power unleashed. A boss fight began!

‘The fight was a long one. The Sibriex demion's warp poison addled several party members, nearly killing Dore and
crippling Gandus. Feeble Mind hit Zephyr, reducing his intellect and charisma to 1 each.

It was a long fight. Most of the party had taken heavy damage by the ending. Once the Sibriex was weakened, Gandus
hit it with a powerful Divine Smite, inflicting 100 damage in an incredible coup de grace. The blow vaporized the demon,
and all his tendrils and abysall wretches. This impressed Tyr, who finally spoke to Gandus, and granted him a permenant
boon of Demon Slaying.

As the demon melted away, loot, and the mirror, remained behind. What secrets lies within the mirror? What epic loot
was the demon hoarding? Find out next time!

#### ChatGPT Output:
### Bossfight warning

Coming into today's session, the party has made an unusual choice to split. Zephyr, Dork, and Gandus have elected to
remain inside the demi-plane at the heart of Galtorah's keep. Meanwhile, the rest of the party attempts to take a long
rest on the other side of the mirror wall so as to recover spell slots. What will happen?

Ogtoxon is old. And has been within the Mirror of Prophecy now for a long time. He has seen the streams of fate and
knows of the possibility for this encounter. He wishes most fervently to escape the mirror. To spread his unending
corruption throughout the mortal realm. The surge of magic that created Galtorah's Maze also let Ogloxon extend his
tentacles into this world. While he himself cannot escape without assistance, he can now at least corrupt this area.

**Result:**

The round started split, with the spell casters trying to regain spell slots in the material world. The Tiny Hut held the
rutterkin back, but Kaetus and Ureasua had to make saving throws to sleep through the racket.

Meanwhile, in the inner sanctum, Obloxon tempted the three party members. His tentacles slowly broke through the
barriers. Gandus found the temptations unnerving, and Prayed to the Raven Queen to bless him with shortsighted rage.

When the Long rest ended, Kaetus and Ureausa had to make a bee-line to the mirror portal. Kaetus cast a Tidal Wave to
help slow the rutterkin down, and then hopped through. Ureausa found the rutterkin surrounding her, but she easily
bashed the rutterkin in her away to the side. Kaetus' protection spell protected her from attacks of opportunity as she
got through the portal.

Those two found the party engaged in a prolonged battle against tentacles. Ureausa and Kaetus were also tempted by
Ogloxon, but resisted the effect.

Ureausa used her Divine intervention, using the power of Wujet to unleash the demon from its entrapped position
within the mirror. The Sibriex demon emerged. His power unleashed. A boss fight began!

The fight was a long one. The Sibriex demon's warp poison addled several party members, nearly killing Dore and
crippling Gandus. Feeble Mind hit Zephyr, reducing his intellect and charisma to 1 each.

It was a long fight. Most of the party had taken heavy damage by the ending. Once the Sibriex was weakened, Gandus
hit it with a powerful Divine Smite, inflicting 100 damage in an incredible coup de grace. The blow vaporized the demon,
and all his tendrils and abyssal wretches. This impressed Tyr, who finally spoke to Gandus, and granted him a permanent
boon of Demon Slaying.

As the demon melted away, loot, and the mirror, remained behind. What secrets lie within the mirror? What epic loot
was the demon hoarding? Find out next time!

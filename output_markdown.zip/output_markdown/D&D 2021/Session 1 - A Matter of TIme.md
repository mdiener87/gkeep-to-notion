# Session 1 - A Matter of TIme

    **Created:** 2021-10-29 11:37:42  
    **Last Edited:** 2021-10-29 11:37:49  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party has vansquished the Naga boss in the final battle of 2020. They have yet to loot the room, nor treat Disa, nor
investigate the powerful magical mirror that remains in this final chamber.

Loot:
‘Tome of Leadership & Influence

Double Bladed Scimitar +2 | Nine Lives Stealer
Robe of Eyes

16k GP
15 Gemstones, each worth 5006P:

Alexandrite {transparent dark green) x3
‘Aquamarine (transparent pale blue-green x4
Black Pearl (opaque pure black) x2

Blue Spinel (transparent deep blue) x3
Peridot {transparent rich olive green)

Topax (transparent golden yellow) x2

Dissa:
She is going to fall unconscious but is otherwise OK. IS going to be pissed and probably blame Darc for everything when
she comes to. She was kidnapped during the 2019/2020 time skip on a walk outside Borrend. The Naga had fortold that
her life as a bartering chip may come in handy.

‘The Mirror of Prophecy

This powerful artifiact is the crowning Jewl of Lord Galtorah's research. It allows one to peer - even step - through time.
‘The use of the mirror eventually led Galtorah mad, as he could never find a way to prevent the extinction level event he
saw looming over the land.

Using the mirror: After a DC20 Arcane check, the mirror activates. The user may probe the mirror, scanning the cosmos
for threads of time that they wish to learn of. The Multiverse is composed of competing timelines and probabilities - the
mirror allows these probabilities to be reviewed, and even alter which world time line the user is presently at. Upon first
activation, the present time node is locked in as that user's reference return paint.

To review a world timeline, roll a D100 + Arcane skill. The result is how ‘accurate' the review of the specified time line is.
Note that all timelines revealed by the mirror are real - only their probabilistic distance to the user is up for question. If
reviewing events from other planes of existence, this roll is made at disadvantage.

To alter a world timeline, roll two checks of D100 + Arcane skill The first result pertains to how closely the user arrives,
to the physical space specified (as per Teleport). The second dice result pertains to how closely in time the user arrives
to the temporal space specified. Note that the Mirror of Prophecy cannot be used to travel to any ather plane of
existence than the one it currently resides.

To return to your original time of reference (here, and now), make a DC20 Arcane check with an activated mirror.
Prince Zelphar studied under Galtorah. He knows the mirror's secrets, and has laid a trap within the mirror. Upon first
activation, his ghostly presence will emerge and taunt the party. He knows what they are up to. He knows this trap has
only 33.33% chance (repeating, of course) of killing the party. But he is a betting man.

‘The trap summons a Sibriex demon...

Result:

Players were able to ascertain that there was indeed a demon trapped within the mirror. They learned it’s a powerful
Sibriex demon, but did not want to summon it tonight.

Got loot and leveled up.

Dore Escorted Disa back up to the town of Galtorah

Ureasua considered feeding the Soul Stone to the snake, but has so far thought it might be a bad idea to do so. She also
recovered a Large naga fang from the slain Naga

Zephyr found shattered remains of an old soul stone in lord Galtorah's living quarters

#### ChatGPT Output:
'The party has vanquished the Naga boss in the final battle of 2020. They have yet to loot the room, nor treat Disa, nor
investigate the powerful magical mirror that remains in this final chamber.

### Loot:
- **Tome of Leadership & Influence**
- **Double Bladed Scimitar +2 | Nine Lives Stealer**
- **Robe of Eyes**
- **16k GP**
- **15 Gemstones, each worth 500 GP:**
  - Alexandrite (transparent dark green) x3
  - Aquamarine (transparent pale blue-green) x4
  - Black Pearl (opaque pure black) x2
  - Blue Spinel (transparent deep blue) x3
  - Peridot (transparent rich olive green)
  - Topaz (transparent golden yellow) x2

### Disa:
She is going to fall unconscious but is otherwise OK. Is going to be pissed and probably blame Darc for everything when
she comes to. She was kidnapped during the 2019/2020 time skip on a walk outside Borrend. The Naga had foretold that
her life as a bartering chip may come in handy.

### The Mirror of Prophecy
This powerful artifact is the crowning jewel of Lord Galtorah's research. It allows one to peer - even step - through time.
The use of the mirror eventually led Galtorah mad, as he could never find a way to prevent the extinction level event he
saw looming over the land.

#### Using the mirror:
- After a **DC20 Arcane check**, the mirror activates. The user may probe the mirror, scanning the cosmos
  for threads of time that they wish to learn of. The Multiverse is composed of competing timelines and probabilities - the
  mirror allows these probabilities to be reviewed, and even alter which world timeline the user is presently at. Upon first
  activation, the present time node is locked in as that user's reference return point.

- To review a world timeline, roll a **D100 + Arcane skill**. The result is how 'accurate' the review of the specified time line is.
  Note that all timelines revealed by the mirror are real - only their probabilistic distance to the user is up for question. If
  reviewing events from other planes of existence, this roll is made at disadvantage.

- To alter a world timeline, roll two checks of **D100 + Arcane skill**. The first result pertains to how closely the user arrives,
  to the physical space specified (as per Teleport). The second dice result pertains to how closely in time the user arrives
  to the temporal space specified. Note that the Mirror of Prophecy cannot be used to travel to any other plane of
  existence than the one it currently resides.

- To return to your original time of reference (here, and now), make a **DC20 Arcane check** with an activated mirror.
  Prince Zelphar studied under Galtorah. He knows the mirror's secrets, and has laid a trap within the mirror. Upon first
  activation, his ghostly presence will emerge and taunt the party. He knows what they are up to. He knows this trap has
  only 33.33% chance (repeating, of course) of killing the party. But he is a betting man.

  The trap summons a Sibriex demon...

#### Result:
Players were able to ascertain that there was indeed a demon trapped within the mirror. They learned it's a powerful
Sibriex demon, but did not want to summon it tonight.

Got loot and leveled up.

Dore escorted Disa back up to the town of Galtorah.

Ureasa considered feeding the Soul Stone to the snake but has so far thought it might be a bad idea to do so. She also
recovered a Large naga fang from the slain Naga.

Zephyr found shattered remains of an old soul stone in Lord Galtorah's living quarters.

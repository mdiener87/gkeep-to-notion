# Session 27 - Prince Zelphar of the Modern Era

    **Created:** 2021-10-29 11:43:00  
    **Last Edited:** 2024-11-14 17:32:15  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Session 9/30/21 notes

A LONG fight against Prince Zelphar of the Modern Age

He sat up on Galtorah's statue for most of the fight. He rained down a variety of spells on the party - Chain LIghtening, Cone of Cold, Fireball, Shatter, and such. Princess Gwen was fully killed between the AoE effects and spider allies.

Kaetus Maelstrom did not produce the desired effects - more of his allies were swept into this riptide than enemies.

Skittles was killed several times through this fight. However, each time, the Ring of Whispers brought him immediatley back to life. The long term effects of this are unclear.

Gandus was early on captured in Otulik's Resilient Sphere. His Molten blade could not hit the sphere to disenchant it, leaving him out of the fight until Kaetus later removed the spell with a fourth level dispell magic.

Counterspells flew fast and often in this battle. Zelphar tried twice to counterspell effects, but failed the rolls each time. Gandus tried to counterspell the resielent sphere, but also failed. They just aren't the same as they are in the 3rd era.

Ureasua banked Zelphar repeatedly and used her Toll of the Dying on him. Her melee attacks against Drow allies were not effective - but neither could the drow hit her. Her twilight shrowd was used to remove the poison. 

Dorc had to climb up to fight Zelphar while he was atop the statue. His initial attempt to grapple Zelphar failed. Zelphar then made a STR check to kick him off the statute, and actually succeeded. The damage was more to Dorc's pride than anything else, but its rare for Dorc to fail STR checks. Many of his initial flametounge attacks also missed, but he eventually started impaling Zelphar with damage.

Zephyr landed the final blow on Zelphar. He came in with dual critical hits on the spear and talons, exactly equaling the boss HP and killing Zelphar of the Modern Age!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
ALONG fight against Prince Zelphar of the Modern Age
He sat up on Galtorah's statue for most af the fight. He rained down a variety of spells on the party - Chain Lightening,
Cone of Cold, Fireball, Shatter, and such. Princess Gwen was fully killed between the AoE effects and spider allies.

Kaetus Maelstrom did not produce the desired effects - more of his allies were swept into this riptide than enemies.
Skittles was killed several times through this fight. However, each time, the Ring of Whispers brought him immediatley
back to life. The long term effects of this are unclear.

Gandus was early on captured in Otulik's Resilient Sphere. His Molten blade could not hit the sphere to disenchant it,
leaving him out of the fight until Kaetus later removed the spell with a fourth level dispell magic.

Counterspells flew fast and often in this battle. Zelphar tried twice to counterspell effects, but failed the rolls each time.
Gandus tried to counterspell the resielent sphere, but also failed. They just aren't the same as they are in the 3rd era.

Ureasua banked Zelphar repeatedly and used her Toll of the Dying on him, Her melee attacks against Drow allies were
not effective - but neither could the drow hit her. Her twilight shrowd was used to remove the poison.

Dorc had to climb up to fight Zelphar while he was atop the statue. His initial attempt to grapple Zelphar failed. Zelphar
then made a STR check to kick him off the statute, and actually succeeded. The damage was more to Dorc's pride than
anything else, but its rare for Dorc to fail STR checks. Many of his initial flametounge attacks also missed, but he
eventually started impaling Zelphar with damage.

Zephyr landed the final blow on Zelphar. He came in with dual critical hits on the spear and talons, exactly equaling the
boss HP and killing Zelphar of the Modern Ag

#### ChatGPT Output:
**ALONG fight against Prince Zelphar of the Modern Age**  
He sat up on Galtorah's statue for most of the fight. He rained down a variety of spells on the party - Chain Lightning,  
Cone of Cold, Fireball, Shatter, and such. Princess Gwen was fully killed between the AoE effects and spider allies.

- Kaetus Maelstrom did not produce the desired effects - more of his allies were swept into this riptide than enemies.  
- Skittles was killed several times through this fight. However, each time, the Ring of Whispers brought him immediately  
  back to life. The long term effects of this are unclear.

Gandus was early on captured in Otulik's Resilient Sphere. His Molten blade could not hit the sphere to disenchant it,  
leaving him out of the fight until Kaetus later removed the spell with a fourth level dispel magic.

Counterspells flew fast and often in this battle. Zelphar tried twice to counterspell effects, but failed the rolls each time.  
Gandus tried to counterspell the resilient sphere, but also failed. They just aren't the same as they are in the 3rd era.

Ureasua banked Zelphar repeatedly and used her Toll of the Dying on him. Her melee attacks against Drow allies were  
not effective - but neither could the drow hit her. Her twilight shroud was used to remove the poison.

Dorc had to climb up to fight Zelphar while he was atop the statue. His initial attempt to grapple Zelphar failed. Zelphar  
then made a STR check to kick him off the statue, and actually succeeded. The damage was more to Dorc's pride than  
anything else, but it's rare for Dorc to fail STR checks. Many of his initial flametongue attacks also missed, but he  
eventually started impaling Zelphar with damage.

Zephyr landed the final blow on Zelphar. He came in with dual critical hits on the spear and talons, exactly equaling the  
boss HP and killing Zelphar of the Modern Age.

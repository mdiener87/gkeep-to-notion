# Session 38 - Morning Hangovers

    **Created:** 2022-02-03 18:31:24  
    **Last Edited:** 2022-02-03 21:49:40  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

The party has successfully snuck into Borrend as Koalas. Yep, that happened. Koala Dorc has poisoned Knucklestepp Shapin, killing him in his sleep. Meanwhile, the rest of the party has gotten drunk, and many of the Koalas have been sold as pets. The Polymorph spell only lasts for 24 hours, so this is going to be an awkward morning...

Party is going to be waking up drunk and hungover. Everyone's fluffy pets are now not so fluffy tall people. The big boss is dead. Yea, this is going to go so well!

--

gameplay notes 2/3/2022

Shorter session tonight, lots of network issues.

The party found themselves waking up, drunk and groggy, as koalas. Some initial checks were made by the koalas to extract themselves from their various rooms and cuddling situations. Gandus did not succeede, and wound up cuddling with his Stone Circle druid. The others looked about, trying to find one another. After a few short minutes, the final energy of the Animal Shapes spell ended, and everyone reverted back to human form.

Gandus compensated by misty stepping out of his cuddles and casting invisibility. Kaetus and Zephyr turned into lizards to evade detection. They would go on to meet up with Kipla, and hunker with her while Gandus found his way to them.

Gandus, meanwhile, had other ideas. He tracked down Murrak Stoneskin, and had a very aggressive word with him. Attacking with advantage from invisibility, he blasted Murrak with Eldritch blast and threatened him to abandon the doom cannon. Explaining that he is the hand of god, Tyr, Murrak and Borrend would be judged if the weapon were to be completed and used. Murrak explained it was all KS' idea, and that he is now missing. Gandus cast invisibility and promptly disapeared once again.


Having connected with Kaetus and the rest of the gang, they Wind Walked and proceeded towards the doom cannon. 

Meanwhile, Dorc explored a cave system to escape KS bedchamber. He found an earth elemental on his path, and then navigated around it by exploring, and spelunking, through an underwater portion of the cave instead. He was able to escape the area without combat, and find his way towards the doom cannon as well.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 42 - Back to the Future

    **Created:** 2022-04-07 19:42:51  
    **Last Edited:** 2022-07-28 18:45:26  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Need to wrap things up with Galtorah and the past.

Then party will attempt to return to the future

Gameplay notes 4/7/22

Kaetus informs Galtorah of the Blue Shadow Dragon threat
>Kaladan
>Sister
>Onyx Mountain

>Tinethra lives on as Esepha the Enchanted
>The Aether Flame can open the portal to the Shadow Realm

>Dragons on the move in the Astral Plane

General Omimiptor has link to Brathrizard
	> Brathrizard was on a secret mission from Tinethra, only survivor
	> Claimed the Tinethra and Royal Knights were on personal missions of greed, and not justice
	> Forsook his vows publically and abandoned Alluin
	
	> Order of the Phoenix, drowned in Ashes
	> OthP were dedicated to Habbakuk
	
>Kaetus takes Princess Gwen up onto the Endimyon. He finally makes a move, and they spend an astral week amongst the stars making sweet, sweet love
>Kaetus used the Enlarge spell on himself for maximum... effect
>Kaetus gives Princess Gwen a flower crown with Druidic Magic from the branches of the Endimyon Astral Tree


>Kaetus does not let Princess Gwen try to join the party into the future when she asks to.
> The party return to the original temporal portal, and step through. Except for Kaetus. He turns back at the last moment, and returns to Alluin, his new home.
>He remains in the past with Princess Gwen and Galtorah, ending his Characther.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 33 - Rescue Zephyr! (pt 2)

    **Created:** 2021-12-09 18:37:41  
    **Last Edited:** 2024-11-14 17:25:04  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Tonight will start with the final battle for Zephyr. The party has fought through these Drow caves, and have no come upon the final chamber. Illitran and her final minions are holed up in this central chamber. Can the party save Zephyr from his grisly fate?


Drow Pentagram:
Upon entering the area the first time in a round, or a round ending while the player is within the pentagram: DC18 CON check or suffer 1d8 max HP burn and 1 ATTR point loss (1d6 for atr)

Pentagram Projector: AC18, 20HP, resistant to non-magical damage. All Must be destroyed to remove the pentagram. -2 CON Save DC for each destroyed projector. Dispell magic or Counterspell on a projector can also disable it (counts as 5th level spell)

Zephyr: chained within pentagram. DC16 lock to pick, AC15, 5HP chain
Zephyr: Imbued with Drow shadow magic. Counts as 'confusion' spell. 5th level spell to dispell from Zephyr. Or ends after 3 rounds of freedom from the Pentagram.


---

Gameplay notes 12/9


Zephyr started at the center of a large quantity of drow forces. Large spiders, and their spider webs, surrounded the chamber. Illitrain was flanked by elite guards, protecting her. Illitran used Giant Insect to enlarge the spiders further, granting them extra HP and advantage on their attacks. 

The party pressed forward, determiend to save their avian friend. Kaetus used fireball to blast spiders before transforming into Draconic Transformation. His free breath weapon destroyed two Drow Towers, weakening the drow pentagram. However, Illitrain succesfully hit him with a Dispell Magic, removing the effect before he could do much more damage.

Dorc pushed the next tower over with a pure strength check. It toppled and further weakened the effect.

Gandus summouned his healing aura, and started healing and buffing his allies. His molten blade felled spiders as he pressed his assault.

Kipla had to be careful with Valzumin's crossbow. She targeted Illitrain with it twice, inflicting heavy ranged damage. She would later switch it up to the short sword to finish off nearby spiders.

Zephyr would go on to cast Shatter on himself. This destroyed the chains that bound him to the torture magic, allowing him to move about freely. He first retreated to his allies, where upon he got healed up. He would then proceed to fly across the room, finding his gear on a bench located in the far corner of the room. A Drow elite warrior would try to tackle him, and failed. Kaetus replied by shoving some Sleeping Ackonite in her mouth - she failed a WIS save and fell asleep! 

Kaetus found himself at the center of the battle, and surounded by giant spiders! His health got low but the spiders weren't able to drop him to 0. He would go on to cast sanctuary, deflecting some later spider attacks back towards the nearby Zephyr.

Illitrain, senseing defeat, turned invisible. Gandus was able to use his divine sense to track her putrid, demonic smell. While he couldn't immediatley attack her, he was able to maintain his zone of control. Illitrain reacted by trying to assassinate Kipla. However, unfortunatley, both of her surprise attacks missed! She had to use a legendary action just to land some damage. Kipla got low - but didn't drop.

Dorc would come up and finish the gang-bang of Illitrain with three final thrusts. The demon was finally vanquished.

As her essence slowly evaporated, Kaetus made an Arcane check with the shards of the Soul Stone that once held the Spirit Naga from Galtorah's Sanctum. He tried to imprison Illitrain in these shards. However.. he rolled a nat1! Instead of imprisoning Illitrain, the shards reacted to her remaining demonic energy and summoned a bone naga! It took a surprise round action and hit Gandus, Dorc, and Kaetus with a Lightning Bolt!

Gandus, tired of these freaking demons, swung. He pumped his final spell slot into his attack, and one shot the newly summoned Demon!

N++ notes:

Giant Spiders: Double HP, +5 attack range, rolls with advantage, doubles to hit effect rating and flat damage bonus, +5DC con saving throw on poison




Illitran
HP 300
AC 15
Spell Save 17
Spell Attack  +10

Legendary Resists: 2/2

Lengdary Actions: 3/3
	Cast a Spell: 2 action
	Summon 1d4 Spiders: 2 Actions
	Attack: 1 Actions
	
Spells:
All spells at 5th level, 1/5 Spell Slots

Cantrips (at will): chill touch, eldritch blast, mage hand, poison spray

1st–5th level (3 5th-level slots): conjure animals (spiders only), crown of madness, dimension door, dispel magic, fear, fly, giant insect, hold monster, insect plague, invisibility, vampiric touch, web, witch bolt

1/day each: dominate monster, etherealness, eyebite

-- 

At will: detect thoughts, web

1/day: dominate person


Saving Throws: STR+1 | DEX+6 | CON +7 | INT +9 | CHA + 8


Attacks:

Poisonous Touch (Humanoid Form Only). Melee Weapon Attack: +8 to hit, reach 5 ft., one target. Hit: 28 (8d6) poison damage.

Bite (Giant Spider Form Only). Melee Weapon Attack: +7 to hit, reach 5 ft., one target. Hit: 12 (2d8 + 3) piercing damage, and the target must make a DC 15 Constitution saving throw, taking 26 (4d12) poison damage on a failed save, or half as much damage on a successful one. If the poison damage reduces the target to 0 hit points, the target is stable but poisoned for 1 hour, even after regaining hit points, and is paralyzed while poisoned in this way.


Slam (Bite in Spider Form). Melee Weapon Attack: +6 to hit, reach 5 ft. (10 ft. in demon form), one target. Hit: 5 (1d6 + 2) bludgeoning (piercing in spider form) damage plus 21 (6d6) poison damage.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
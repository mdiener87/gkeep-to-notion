# Session 25 - Approaching the Battle

    **Created:** 2021-10-29 11:42:37  
    **Last Edited:** 2024-11-14 17:35:42  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Gameplay Notes 9/9/21


The party continued to explore the maze of whispers. Further hallways to the south led only to more spider fights. Princess Gwen, and the rest of the party, grew tired of these spider conflicts. Istantar, the Ring of Whispers, spoke to kipla, and offered her to escape this maze and go loot the elves. Kipla agreed, and the ring took her out of the maze.. right back to the entrance!


The party took a short rest here, as they took stock of the situation. Kipla further negotiated with the ring, which argued against pressing deeper into the dungeon owing to the fact Zelphar is kind of its boss. Or at least, a departmental head in the Drown organizational pantheon. Dorc used his ring of animal influence to talk to Skittles, speaking its weird koala grunting language. Skittles revealed that it is feeling stronger and more powerful than before, and has lost all fear. But still, only really wants to be next to Kipla. 


Kipla further attuned to the ring, and gained its passive + spell casting benefits. She negotiated that the ring could take zelphar's power, if it agreed to help take her there and fight it. After the short rest, Kipla used the Ring of Whispers to activate the mirror and teleport the party to the maze exit.


The party reached the lava filled chamber. Pressing forward, they met Ghizza, the Dreaming and Iasille, the Lucky. Djini hijinks ensued. The two Djini were under contract by Zelphar to block the way, but they were open to negotiating a new contract with Princess Gwen. They tried to get Ila the Handsome renamed to Ila the Ordinary, and offered kaetus a jewl-encrusted bowl in recompense. Ila took great offense to this, and demanded to fight the Djini rather than capitulate. Gwen offered the Djini only a day's labor, instead of the hundreds of years of work on the original contract. The Djini accepted the new contract, deciding that the siblings can work out their problems and follow whichever contract wins out.


The party now is about to face Prince Zelphar. Next time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Things to note coming into tonight:

* Ring of Whispers on Kipla. This will be a new, recurring plot point.
© Give her a bonus on the rolls for her Charchter sheet
= Skittles is now part Fiend. it can use magical items with profficencey and has 1 attunement slot. This is another big
ongoing plot point to keep in mind,

‘The party will probably quickly find their way out of the maze, Most of the encounters are cleared up already.
Remaining rooms:

+ Spider-filled hallways.

* Lava chamber

‘The hallways likely won't take too long to clear. Roll random loot for the side chambers if the party investigates them.

‘The lava chamber should be a more interesting encounter. It features the two genies first encountered in Galtorah's
Maze. Djini (Ghizza the Dreamy) and a Marid (lasille the Lucky).

Their contract has been favorably modified by Prince Zelphar, and in exchange for reducing their contracted time, have
agreed to stop the party from interfering with Zelphar's work.

‘The contract contains a hidden rider - if the Genies fail, they will be bound for double the length of service! An insight
check into the contract can find this out. The party might be able to persuade the genies not to fight by refusing
Zelphar's terms and returning to their original contract with Galtorah.

Otherwise, it's a genie fight. if we need to make it more interesting, have them summon myrmidons to their cause for
some hitpoint baddies.

Session will end with the party at the entrance to Galtorah's Inner sanctum. This will be the encounter vs. Prince
Zelphar - a full boss fight! That will be run on the next session,

#### ChatGPT Output:
‘Things to note coming into tonight:

* Ring of Whispers on Kipla. This will be a new, recurring plot point.
* Give her a bonus on the rolls for her Character sheet
* Skittles is now part Fiend. It can use magical items with proficiency and has 1 attunement slot. This is another big ongoing plot point to keep in mind.

‘The party will probably quickly find their way out of the maze. Most of the encounters are cleared up already.
Remaining rooms:

+ Spider-filled hallways.
+ Lava chamber

‘The hallways likely won't take too long to clear. Roll random loot for the side chambers if the party investigates them.

‘The lava chamber should be a more interesting encounter. It features the two genies first encountered in Galtorah's Maze. Djinni (Ghizza the Dreamy) and a Marid (Iasille the Lucky).

Their contract has been favorably modified by Prince Zelphar, and in exchange for reducing their contracted time, have agreed to stop the party from interfering with Zelphar's work.

‘The contract contains a hidden rider - if the Genies fail, they will be bound for double the length of service! An insight check into the contract can find this out. The party might be able to persuade the genies not to fight by refusing Zelphar's terms and returning to their original contract with Galtorah.

Otherwise, it's a genie fight. If we need to make it more interesting, have them summon myrmidons to their cause for some hitpoint baddies.

Session will end with the party at the entrance to Galtorah's Inner sanctum. This will be the encounter vs. Prince Zelphar - a full boss fight! That will be run on the next session.

# Session 6 - Within the Maze

    **Created:** 2021-10-29 11:38:39  
    **Last Edited:** 2021-10-29 11:38:44  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Refer to last session's notes, Players are within Galtorah's Maze, a defense barrier that was automatically erected once
no living creatures were present within his Keep. Can the Party reach the mirror in time?

Refer to the Gsheets doc of map order

First encounter: Retrievers. Kaetus saw these hiding in the trees up ahead. After conferring with the party, they elected
to send out Ila the Handsome to distract the Retrievers. While he took some minor attacks from them as they chased, lla
succeeded in luring the Retrievers down the wrong path before casting invisibility.

Second Encounter: This road was guarded by two genies, a Djini (Ghizza the Dreamy) and a Marid (lasille the Lucky).
‘They were under contract by Galtorah to protect this stretch of the maze. Gandus confidently stepped out and
commanded them that he was escorting Galotrah and not to be interefered with. Kaetus channeled Galtorah, who
convinced the Gennies that it was, indeed, Galotrah and to stand asside. tla caught up, and Ghizza recognized him as la
the Mediocre. In truth, they were both striking beautiful Djini. However, the party elected to side with Ila, and a
dejected Ghizza deflated and fled in shame. lasile was instructed to stand guard for another 48 hours, and then her
contract would be fuffilled.

Third encounter: Ice forest. The frozen lake has nesting Frost Salamanders, which Dorc quickly discovered as he stepped
into it and the first lunged out to attack. After dispatching this creature, the party was left with a number of different
chests, in different sizes, scattered across the map. Each chest turned out to be a mimic. A trick the party quickly caught
on ta, but never directly attacked the mimics first (thinking they might indeed be real chests). Each mimic contained a
‘small silver key, and the party obtained all 6. They took a short rest in the middle of this.

Distrubing the water halfway through led to anather Frost Salamander to attack. This one burrowed underground and
suprrised kipla with lots of attacks. It then used its immense range of Frost Breath, hitting Dorc and Zephyr. Kaetus
ended the combat with a Polymorph, turning it into a turtle. Zephyr flew up to the flight ceiling and then kick it to the
horizon, where it vanished like team rocket.

The final, Dire Mimic, contained 580 gold, a ring of x-ray vision (yet unidentified), and the final small key (total 6).

Greater Dire Mi
Large Monstrosity (shapechanger), Neutral Large Monstrosity (shapechanger), Neutral

AC: 16 (natural armor) AC: 18 (natural armor)

Hit Points: 155 Hit Points: 200

Speed: 20 Speed: 20

Str: 20 (+5), Dex 14 (+2), Con 19 (+4), Int 6 (3), Wis 16 (+3), Cha 9 (-1) Str: 24 (47), Dex 14 (+2), Con 19 (+4), Int 6 (-3), Wis 16 (+3), Cha 9 (-1)

Skills: Stealth +7 Skills: Stealth +7

Damage immunities: Acid Damage immunities: Acid

Condition Immunities: Prone Condition Immunities: Prone

‘Senses: Darkvision 60 ft, passive perception 13, ‘Senses: Darkvision 60 ft, passive perception 13,

Languages: Languages:

Challenge CR 8 (3900 XP) Challenge CR 8 (3900 XP)

‘Shapechanger: The mimic can use its action to polymorph into an object or into its true, amorphous form. It’s ‘Actions: Pseudopod x1, Bite x2

statistics are the same in each form. Any equipment it is wearing or carrying isn’t transformed. It reverts to its ‘Shapechanger: The mimic can use its action to polymorph into an object or into its true, amorphous
‘true form ifit dies form. It’s statistics are the same in each form. Any equipment itis wearing or carrying isn’t
‘Adhesive (Object Form Only). The mimic adheres to anything that touches it. A huge or smaller creature transformed. It reverts to its true form if it dies.

adhered to the mimicis also grappled by it (Escape DC 18) Ability checks made to escape this grapple have Adhesive (Object Form Only). The mimic adheres to anything that touches it. A huge or smaller
disadvantage. creature adhered to the mimic is also grappled by it (Escape DC 18) Ability checks made to escape this
False Appearance (Object Form Only). While the mimic remains motionless, itis indistinguishable from an grapple have disadvantage.

ordinary object. False Appearance {Object Form Only). While the mimic remains motionless, it is indistinguishable
Grappler The mimic has advantage on attack rolls against any creature grappled by it from an ordinary object.

Actions: Multiattack. The mimic makes two attacks, one with its pseudopod and one bite attack. ifthe mimic Grappler The mimic has advantage on attack rolls against any creature grappled by it

is grappling a creature it makes two bite attacks against that creature instead. Actions: Multiattack. The mimic makes two attacks, one with its pseudopod and one bite attack. If
Pseudopod. Melee Weapon Attack: +8 to hit, reach 5ft, one target Hit: (13) 2d8 +5 bludgeoning damage. If the mimic is grappling a creature it makes two bite attacks against that creature instead.

the mimic is in object form, the target is subject to its Adhesive Trait. Pseudopod. Melee Weapon Attack: +12 to hit, reach Sft, one target Hit: (13) 2d8 +8 bludgeoning
Bite, Melee Weapon Attack: +8 to hit, reach 5ft, one target Hit: (13) 2d8 +5 piercing damage + (8) 2d8 Acid damage. If the mimicis in object form, the target is subject to its Adhesive Trait.

acid damage. Bite. Melee Weapon Attack: +12 to hit, reach Sft, one target Hit: (13) 2d8 +8 piercing damage + 448,
Comment ‘Acid acid damage.

Comment

#### ChatGPT Output:
Refer to last session's notes, Players are within Galtorah's Maze, a defense barrier that was automatically erected once
no living creatures were present within his Keep. Can the Party reach the mirror in time?

Refer to the Gsheets doc of map order

First encounter: Retrievers. Kaetus saw these hiding in the trees up ahead. After conferring with the party, they elected
to send out Ila the Handsome to distract the Retrievers. While he took some minor attacks from them as they chased, Ila
succeeded in luring the Retrievers down the wrong path before casting invisibility.

Second Encounter: This road was guarded by two genies, a Djini (Ghizza the Dreamy) and a Marid (Lasille the Lucky).
They were under contract by Galtorah to protect this stretch of the maze. Gandus confidently stepped out and
commanded them that he was escorting Galotrah and not to be interfered with. Kaetus channeled Galtorah, who
convinced the Genies that it was, indeed, Galotrah and to stand aside. Ila caught up, and Ghizza recognized him as Ila
the Mediocre. In truth, they were both strikingly beautiful Djini. However, the party elected to side with Ila, and a
dejected Ghizza deflated and fled in shame. Lasille was instructed to stand guard for another 48 hours, and then her
contract would be fulfilled.

Third encounter: Ice forest. The frozen lake has nesting Frost Salamanders, which Dorc quickly discovered as he stepped
into it and the first lunged out to attack. After dispatching this creature, the party was left with a number of different
chests, in different sizes, scattered across the map. Each chest turned out to be a mimic. A trick the party quickly caught
on to, but never directly attacked the mimics first (thinking they might indeed be real chests). Each mimic contained a
small silver key, and the party obtained all 6. They took a short rest in the middle of this.

Disturbing the water halfway through led to another Frost Salamander to attack. This one burrowed underground and
surprised Kipla with lots of attacks. It then used its immense range of Frost Breath, hitting Dorc and Zephyr. Kaetus
ended the combat with a Polymorph, turning it into a turtle. Zephyr flew up to the flight ceiling and then kicked it to the
horizon, where it vanished like team rocket.

The final, Dire Mimic, contained 580 gold, a ring of x-ray vision (yet unidentified), and the final small key (total 6).

Greater Dire Mimic
Large Monstrosity (shapechanger), Neutral

- AC: 18 (natural armor)
- Hit Points: 200
- Speed: 20
- Str: 24 (+7), Dex 14 (+2), Con 19 (+4), Int 6 (-3), Wis 16 (+3), Cha 9 (-1)
- Skills: Stealth +7
- Damage immunities: Acid
- Condition Immunities: Prone
- Senses: Darkvision 60 ft, passive perception 13,
- Languages:
- Challenge CR 8 (3900 XP)
- Shapechanger: The mimic can use its action to polymorph into an object or into its true, amorphous form. Its statistics are the same in each form. Any equipment it is wearing or carrying isn’t transformed. It reverts to its true form if it dies.
- Adhesive (Object Form Only): The mimic adheres to anything that touches it. A huge or smaller creature adhered to the mimic is also grappled by it (Escape DC 18). Ability checks made to escape this grapple have disadvantage.
- False Appearance (Object Form Only): While the mimic remains motionless, it is indistinguishable from an ordinary object.
- Grappler: The mimic has advantage on attack rolls against any creature grappled by it.
- Actions: Multiattack. The mimic makes two attacks, one with its pseudopod and one bite attack. If the mimic is grappling a creature, it makes two bite attacks against that creature instead.
- Pseudopod: Melee Weapon Attack: +12 to hit, reach 5 ft, one target. Hit: (13) 2d8 +8 bludgeoning damage. If the mimic is in object form, the target is subject to its Adhesive Trait.
- Bite: Melee Weapon Attack: +12 to hit, reach 5 ft, one target. Hit: (13) 2d8 +8 piercing damage + (8) 2d8 acid damage.

# Session 3 - Breaking Points

    **Created:** 2021-10-29 11:38:09  
    **Last Edited:** 2021-10-29 11:38:14  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Today - probably some RP stuff
‘Ongoing threads -

Gith Soul Stone - Gith will probably come collect their stone at some point soon
‘The Mirror of Prophecy - the Naga that ruled the roost is gone. What sort of creatures have been waiting for this
opportunity? The Drow maybe...

Drow Conspiracy - With the Narzugon banished, their primary means of capturing the princess and wounding the order
has failed. It is now time for a more direct intervention.

‘Which leads us to Floriana... maybe this is time for a trap. Could she be a shapechanger instead? And be killed off screen
in the Gartison base attack? Probably too cheap a death for a main character. But the private? There we go

If they can kill princess Rose, the line of Moryn, human kingdom of Dawn, will fail. The Power within the Tower of
Bithyra will finally awake. Prince Zelphar will have suceeded.

Make the Private impersonated by Ilitran, Won't necessarily come up today, but that’s the plan,

Result:

‘The party summoned Giant Eagles, and flew Floriana and Pvt Kennan to Alluin. There they rested up and performed
minor actions around the castle. Zephyr tried to decrypt the Journal in the Alluin Castle Library, where he met the very
attracted Bethany - intern librarian. She enjoyed his attempt to work on the puzzle of the journal, and his exotic
plumage. Zephyr decided not to join her in a study area .

‘Skipla put a fish in Elyris' bed chamber, while she was asleep in the room!
Kaetus put 120g into the pot involving what Asathra's relationship status with General Trynicus really is.

A long debriefing with the King occurred. They informed him of the events of Borrend, Galothra's Keep, and the attack
on Black Scar Garrison. The Order did not come clean on their involvement with the events within Borrend. Everyone
concluded that these events {involving the demon attacks and corrupt leadership in Borrend) were orchestrated by the
shadow dragons still lurking in the universe.

‘As the meeting wraped up, the king retired to his bed chambers to consider these matters. Princess Rose approached
Kaetus, and shyly started flirting with him. Kaetus asked her to join him on a walk. As they walked towards the exit, arms
in hand... Prvt Kennan unsheathed his sword and stabbed the Princess, His surprise round swung with advantage, and he
struck her for 111 poison damage. This over-killed her by more than 100% max HP, ending her life instantly. Floriana and
Kaetus both tried to heal the princess, but only succeeded in buying her enough time to whisper that she'd have liked to
join Kaetus on that walk.

‘The assassin rolled top of the turn order, promtly cast Ethereainess, and disapeared. Gandus and Zephyr rushed to the
king and began a protection detail. Floriana took command of the castle and locked it down, searching for the assassin.
No attempt on the king Kaetus, in his grief, immediatley cast Reincarnate on the princess' body. The roll for the new
species resulted in Hill dwarf.

#### ChatGPT Output:
### Today - probably some RP stuff

#### Ongoing threads:

- **Gith Soul Stone** - Gith will probably come collect their stone at some point soon
- **The Mirror of Prophecy** - the Naga that ruled the roost is gone. What sort of creatures have been waiting for this
opportunity? The Drow maybe...
- **Drow Conspiracy** - With the Narzugon banished, their primary means of capturing the princess and wounding the order
has failed. It is now time for a more direct intervention.

Which leads us to Floriana... maybe this is time for a trap. Could she be a shapechanger instead? And be killed off screen
in the Gartison base attack? Probably too cheap a death for a main character. But the private? There we go.

If they can kill princess Rose, the line of Moryn, human kingdom of Dawn, will fail. The Power within the Tower of
Bithyra will finally awake. Prince Zelphar will have succeeded.

Make the Private impersonated by Ilitran. Won't necessarily come up today, but that’s the plan.

#### Result:

- The party summoned Giant Eagles, and flew Floriana and Pvt Kennan to Alluin. There they rested up and performed
minor actions around the castle. Zephyr tried to decrypt the Journal in the Alluin Castle Library, where he met the very
attracted Bethany - intern librarian. She enjoyed his attempt to work on the puzzle of the journal, and his exotic
plumage. Zephyr decided not to join her in a study area.
- Skipla put a fish in Elyris' bed chamber, while she was asleep in the room!
- Kaetus put 120g into the pot involving what Asathra's relationship status with General Trynicus really is.

A long debriefing with the King occurred. They informed him of the events of Borrend, Galothra's Keep, and the attack
on Black Scar Garrison. The Order did not come clean on their involvement with the events within Borrend. Everyone
concluded that these events (involving the demon attacks and corrupt leadership in Borrend) were orchestrated by the
shadow dragons still lurking in the universe.

As the meeting wrapped up, the king retired to his bed chambers to consider these matters. Princess Rose approached
Kaetus, and shyly started flirting with him. Kaetus asked her to join him on a walk. As they walked towards the exit, arms
in hand... Pvt Kennan unsheathed his sword and stabbed the Princess. His surprise round swung with advantage, and he
struck her for 111 poison damage. This over-killed her by more than 100% max HP, ending her life instantly. Floriana and
Kaetus both tried to heal the princess, but only succeeded in buying her enough time to whisper that she'd have liked to
join Kaetus on that walk.

- The assassin rolled top of the turn order, promptly cast Etherealness, and disappeared. Gandus and Zephyr rushed to the
king and began a protection detail. Floriana took command of the castle and locked it down, searching for the assassin.
No attempt on the king. Kaetus, in his grief, immediately cast Reincarnate on the princess' body. The roll for the new
species resulted in Hill dwarf.

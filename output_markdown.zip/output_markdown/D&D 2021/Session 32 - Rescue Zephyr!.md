# Session 32 - Rescue Zephyr!

    **Created:** 2021-12-02 18:54:13  
    **Last Edited:** 2024-11-14 17:25:27  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Today will focus on the rescue of Zephyr. He was captured by the remaining Drow forces in the last battle. Zephyr will be rolling saves  during the party's encounters to find out how bad in shape he is when they finally get to him. This could, potentially, be lethal. 


Illitran's Torture:
DC 18 CON Save or take 1d8 max HP damage and lose 1 attribute point (roll 1d6 for attribute point lost)

When confronted, if still alive, Zephyr will be under the 'Confusion' effect. This can be removed via Dispell Magic (5th level spell).


gameplay notes 12/2/21

Session started with the party teleporting via Galtorah to the drow complex that they suspected Zephyr was held. A drow spotted their arrival - but Kaetus spotted the Drow. His quick thinking hit it with Command, forcing silence upon it. Kaetus then followed it up with Pass Without a Trace, allowing the party to stealth and enter the trees.

By the time the Drow regained her senses, the party she spotted had dissapeared. She blinked. What just happened?

That gave the party enough time to sneak up on the drow, and finish her off before an alert could go off.

The party continued their stealth advance, moving along the left side of the map. They spotted various drow and spiders; dispatching the former as needed while avoiding the later. They would spot a Drow Priestess of Lolth in the center of the map. This high end Drow would surely put up a good fight.

The party worked hard to avoid her. Dorc and Gandus made noise dropping down to the next level, but quick thinking of 'bird sounds' from the party convinced the Drow both times that nothing was afoot. The party made it into the cave entrance - only a single spider followed Kaetus into the cave. It was promptly squished once out of sightline from the drow sentries.

--

Inside the cave, the party faced Drow and Spiders. The archers landed some good initial hits on Dorc, firing from concealed positions. Drow Shadowblades teleported forward - fighting Dorc and Kipla. Kipla quickly seemed to be in trouble, but Gandus used Daylight spell to blind all of the drow in the vicinity. He then sauntered forward, as an invisible terminator.

Kaetus pressed forward on the left path. While crossing a bridge, a concealed drown, beyond the light of daylight, set off her trap. She detonated the bridge. Kaetus failed the dex save to jump to his safety, and he fell into the pit. Only to emerge with Dragon Form, flying up and blasting her with his new breath weapon. He would go about the map as an ascended being, blasting all that stood before him.

All the while, Zephyr was rolling CON save after CON save. The torture from Illitrain continued to burn his MAX HP and Attribute Scores. Can the party save him in time? Their inner chamber lies just ahead. Find out next time, on DnD!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
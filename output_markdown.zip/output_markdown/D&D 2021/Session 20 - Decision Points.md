# Session 20 - Decision Points

    **Created:** 2021-10-29 11:41:42  
    **Last Edited:** 2021-10-29 11:41:47  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘As usual, the party did not play to my expectations and went right where I thought they might go left. By not returning
to Alluin castle, they have bypassed the illirain boss fight. ilitran has taken over the castle, The royalty and command
structure has been imprisoned. The Drow were not nearly this aggressive in the original Alpha timeline - they thought
that Zelphar would be able to convince the Elven High Council in Selveraum that he should lead. instead, the party's
presence has convinced Zelphar that far more direct action is required.

Zelphar killed the King in Galtorah's Keep. He has access to the Mirror of Prophecy, and is actively working to understand
the true nature of the party - and where they've hidden Princess Gwen. without her death, Zelphar knows he can never
truly ascend to King as rightful heir. Even now, his agents scour the country - seeking the Princess so that she might
finally be dealt with.

If party goes into Valzumin's stronghold... there should be an interaction with the existing stronghold, That is too much
identical, reality warping magick. It's not designed to go fractal. Have fissures in reality start to open, with random
elementals spawning and attacking everything, One reality marble must die for the other to live. A party member can try
to have their marble win the fight by channeling Arcane energy (DC20) into their orb as an action. At end of round, each
reality marble contests the other for primacy. Even - party wins, Odd - 3rd age marble wins. 7 rounds to victor.

If party goes to Galtorah's stronghold - they will encounter drow agents searching for them.

If they go to Alluin, they will encounter Illitrain.

Does princess gwen know the true story of Galtroah? - yes. She knows that

gameplay notes 6/23

Took a short rest near valzumins lake
party traveled from valzumins lake to the forests nearby the GK entrance
‘They encountered some trolls in the forest. Kaetus turned ane into a cow with Polymorph, and the party walked along

‘They found the entrance to GK. Kaetus channeled galtorah
A trap was triggered, poisoning Kaetus/Galtorah,

‘An energy field appeared between the status, damaging everyone in it at end of round
‘AYochlol demon spawned, and continued to spawn, attacking the party

After destorying the statues, the corrupted energy field was removed

Afterwords Princess Gwen worked with Kipla's dagger to open the elevantor

#### ChatGPT Output:
‘As usual, the party did not play to my expectations and went right where I thought they might go left. By not returning
to Alluin castle, they have bypassed the illirain boss fight. Ilitran has taken over the castle, The royalty and command
structure has been imprisoned. The Drow were not nearly this aggressive in the original Alpha timeline - they thought
that Zelphar would be able to convince the Elven High Council in Selveraum that he should lead. Instead, the party's
presence has convinced Zelphar that far more direct action is required.

Zelphar killed the King in Galtorah's Keep. He has access to the Mirror of Prophecy, and is actively working to understand
the true nature of the party - and where they've hidden Princess Gwen. Without her death, Zelphar knows he can never
truly ascend to King as rightful heir. Even now, his agents scour the country - seeking the Princess so that she might
finally be dealt with.

If party goes into Valzumin's stronghold... there should be an interaction with the existing stronghold, That is too much
identical, reality warping magick. It's not designed to go fractal. Have fissures in reality start to open, with random
elementals spawning and attacking everything, One reality marble must die for the other to live. A party member can try
to have their marble win the fight by channeling Arcane energy (DC20) into their orb as an action. At end of round, each
reality marble contests the other for primacy. Even - party wins, Odd - 3rd age marble wins. 7 rounds to victor.

If party goes to Galtorah's stronghold - they will encounter drow agents searching for them.

If they go to Alluin, they will encounter Illitrain.

Does princess Gwen know the true story of Galtroah? - yes. She knows that

gameplay notes 6/23

Took a short rest near Valzumin's lake
party traveled from Valzumin's lake to the forests nearby the GK entrance
‘They encountered some trolls in the forest. Kaetus turned one into a cow with Polymorph, and the party walked along

‘They found the entrance to GK. Kaetus channeled galtorah
A trap was triggered, poisoning Kaetus/Galtorah,

‘An energy field appeared between the statues, damaging everyone in it at end of round
‘A Yochlol demon spawned, and continued to spawn, attacking the party

After destroying the statues, the corrupted energy field was removed

Afterwords Princess Gwen worked with Kipla's dagger to open the elevator

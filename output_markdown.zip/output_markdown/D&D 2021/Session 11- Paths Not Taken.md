# Session 11- Paths Not Taken

    **Created:** 2021-10-29 11:39:44  
    **Last Edited:** 2021-10-29 11:39:52  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Refer to previous session notes for world timelines. Going to do this one kinda on the fly as | really don't know what the
players are going to do yet.

Party found a map containing the locaiton of the Beaconport Abyss

Result: Players further explored Valzumins stronghold. They split into two groups, then met back in the middle in
Valzumin's heavily fortified inner sanctum.

Gandus and Kipla went on their own venture, first coming to a forest arboritum. & Shield Golem attacked them, but was
easily dispatched.

Zephyr and Kaetus went to the surface to further conceal the forthress. Kaetus cast [spell] to conceal the terrain as a
desert, He then turned into an octopus and removed one of the four crystals powering the Dome of Farce above the
floating coral platform. Water rushed in and sealed off the platform and docking umbelical.

They all met up at opposite ends of Valzumins Arcane Sanctum. They breached the fortified walls, and fought an Iron
Golem and Four Iron Snakes. IT was a gruelling, long fight, but the order prevailed. And now, treasure abounds! What
loot surrounds them? Find out next time on DnD!

#### ChatGPT Output:
Refer to previous session notes for world timelines. Going to do this one kinda on the fly as I really don't know what the
players are going to do yet.

Party found a map containing the location of the Beaconport Abyss.

Result: Players further explored Valzumin's stronghold. They split into two groups, then met back in the middle in
Valzumin's heavily fortified inner sanctum.

- Gandus and Kipla went on their own venture, first coming to a forest arboretum. A Shield Golem attacked them, but was
easily dispatched.

- Zephyr and Kaetus went to the surface to further conceal the fortress. Kaetus cast [spell] to conceal the terrain as a
desert. He then turned into an octopus and removed one of the four crystals powering the Dome of Farce above the
floating coral platform. Water rushed in and sealed off the platform and docking umbilical.

They all met up at opposite ends of Valzumin's Arcane Sanctum. They breached the fortified walls, and fought an Iron
Golem and Four Iron Snakes. It was a grueling, long fight, but the order prevailed. And now, treasure abounds! What
loot surrounds them? Find out next time on DnD!

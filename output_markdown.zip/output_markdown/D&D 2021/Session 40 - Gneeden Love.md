# Session 40 - Gneeden Love

    **Created:** 2022-03-03 18:41:46  
    **Last Edited:** 2024-11-14 17:19:53  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

The party has begun to convince the Stone Circle druids that they are 1) from the future and 2) the Doom Cannon should be immediately halted. This improbable result might lead to a cease fire. The Order has taken the field, pushing out from the mine cart cave entrance to approach the Cannon itself. They are now in position to strike the weapon itself, if they can get close enough. 

When they get to the cannon, they'll meet LS's daughter - Gnedden. This young genius mechanic is making the final tweaks to bring the weapon operational. She is the lead engineer of the project, and one that the party will need to convince to cancel. While she is not evil, she is chaotic, and a big boom from a big cannon would be the culmination of her life's work to date.

If the party convinces her to abandon the project, KS's Shade will appear. A powerful incarnation of his evil, Mr. Shadow will appear, and take possession of Gnedden. From there, KS will try to order the Druids to detain the order, and fire the weapon. The party will need to find a way to save Gnedden (or not) and banish Mr. Shadow if they wish to ultimately stop the cannon's usage. 

---


Gameplay Notes 3/3/2022

GM note - decided not to run the Mr. Shadow boss fight. It proved unncessary and more interesting things happened


Party continued their fight around the Doom Cannon. Without Zephyr present, it proved hard to convince the stone circle druids that the party was indeed from the future. Instead they lost the will to fight one by one, as the party cut through their ranks and defeated their stone myrmidon summons. 

As the final stone circle druid surrendered, a new face emerged from within the Doom Cannon itself. A pink haired gnome, she loudly demanded to know what all the ruckus was about. Gandus warned that the Doom Cannon would bring about disaster if it were completed. Dorc performed a feat of strength - tossing the remains of a destroyed myrmidon towards the doom cannon. This impressed the gnome, who asked for Dorc to come inside as she had a bolt that she needed tightened to bring the cannon online.

Dorc, always happy to help a lady tighten a bolt, happily accepted the request. Inside, he further impressed her with a Nat20 athletics roll. He tried to persuade her to give up her goals to complete the weapon, informing the gnome, Gneeden, that Knucklestep was dead. She turned, tears welling in her eyes, and asked if her Dad was really dead.

Dorc's persuasion did not go well from here. He declined to join her in completing her goal of tigthening that final bolt, and thereby completing the weapon. He declined to finish seducing her, and thereby likely become Broc's father (or perhaps grandfather). Instead, he picked her up, walked her to the edge of the chasm, and threw Gneeden into the abyss. Palpetine style.

Gneeden's shield guardian attempted to intervene. Unfortunatley, Dorc won the initiative check. He threw Gneeden into the abyss. The Guardian rushed forward, and attempted to jump off the cliff after its master. Dorc hit it with Sentinel. Nat 20. He pineed the Guardian to the ground, forcing it to stay and fight him rather than to try to save its master. Enraged, the Golem tried to force Dorc off the cliff, but failed the opposed strength check.

The order jumped into action. With his dragon wings earth elemental, Kaetus quickly reached Dorc and joined him in the fight against the Shield Guardian.  It quickly found itself outmatched. Nearly destroyed, it activated a self destruct, unleashing a 4th level Fireball centered upon itself. Dorc rolled a Not20 on his Dex save, while Earth Ele kaetus ate full damage. The platform they were all standing on exploded, and both Kaetus and Dorc fell into the abyss. 

Luckily, Kaetus still had flight speed, and he grabbed Dorc during his fall. The party met up in the Doom Cannon control room, and contemplated how to disable it once and for all....


Missing notes from N++:
The Mr. Shadow encounter

Monsters:


Druids: Arch Druid but cap spells at 6th level
+
Earth Elemental Myrmidons

Oaken bolter deffensive turrets (controlled by AI, owned by Gnedden)



Mr Shadow
Shade
Medium undead , any evil alignment

Armor Class 17 (Natural Armor)
Hit Points 135 (18d8 + 54)
Fly Speed 30 ft.

STR 11 (+0) DEX 16 (+3) CON 16 (+3) INT 20 (+5) WIS 14 (+2) CHA 16 (+3)

Saving Throws CON +10, INT +12, WIS +9
Skills Arcana +19, History +12, Insight +9, Perception +9
Damage Resistances Acid, Fire, Lightning, Thunder; Bludgeoning, Piercing, and Slashing from Nonmagical Attacks
Damage Immunities Poison; Bludgeoning, Piercing, and Slashing from Nonmagical Attacks
Condition Immunities Charmed, Exhaustion, Frightened, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained
Senses Truesight 120 ft., Passive Perception 19
Languages Common plus up to five other languages
Challenge 21 (33,000 XP)
Proficiency Bonus +7

Legendary Resistance (3/Day). If Mr Shadow fails a saving throw, it can choose to succeed instead.

Spellcasting. 

Mr Shadow is an 18th-level spellcaster. Its spellcasting ability is Intelligence (spell save DC 18, +10 to hit with spell attacks). 

Cantrips (at will): mage hand, prestidigitation, ray of frost

1st level (4 slots): detect magic, magic missile, shield, thunderwave

2nd level (3 slots): acid arrow, detect thoughts, invisibility, mirror image

3rd level (3 slots): animate dead, counterspell, dispel magic, fireball

4th level (3 slots): blight, dimension door

5th level (3 slots): cloudkill, scrying

6th level (1 slot): disintegrate, globe of invulnerability

7th level (1 slot): finger of death, plane shift



Actions
Withering Touch. Melee Spell Attack: +10 to hit, reach 5 ft., one creature. Hit: 6d6 necrotic damage. The target must succeed on a DC 18 Wisdom saving throw or be feared for 1 minute. While feared, the unit may only take actions to run and hide from Mr. Shadow The target can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success. If a target's saving throw is successful or the effect ends for it, the target is immune to the fear effect for the next 24 hours.

Legendary Actions
The lich can take 3 legendary actions, choosing from the options below. Only one legendary action option can be used at a time and only at the end of another creature's turn. The lich regains spent legendary actions at the start of its turn.

Cantrip. The lich casts a cantrip.

Necrotic Touch (Costs 2 Actions). The lich uses its Necrotic Touch.

Soul Possession (Costs 3 Actions). Mr Shadow attempts to invade the soul of another creature:

One humanoid that the ghost can see within 5 feet of it must succeed on a DC 18 Charisma saving throw or be possessed by the ghost; the ghost then disappears, and the target is incapacitated and loses control of its body. The ghost now controls the body but doesn't deprive the target of awareness. The ghost can't be targeted by any attack, spell, or other effect, except ones that turn undead, and it retains its alignment, Intelligence, Wisdom, Charisma, and immunity to being charmed and frightened. It otherwise uses the possessed target's statistics, but doesn't gain access to the target's knowledge, class features, or proficiencies.

The possession lasts until the body drops to 0 hit points, the ghost ends it as a bonus action, or the ghost is turned or forced out by an effect like the dispel evil and good spell. When the possession ends, the ghost reappears in an unoccupied space within 5 feet of the body. The target is immune to this ghost's Possession for 24 hours after succeeding on the saving throw or after the possession ends.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
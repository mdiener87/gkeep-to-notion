# Session 37 - Koality Time

    **Created:** 2022-01-27 18:53:12  
    **Last Edited:** 2024-11-14 17:22:26  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Koala party mode! The party is infiltrating Third Age borrend as.. polymorphed Koalas. This can only end well..

gameplay notes 1/27/22

Alpic, and the troope of traveling Koalas, infiltrated Borend. With such adorable kritters in tow, they easily convinced the people they came across of the need for a Koala circus! Murrak Stoneskin, Knucklestepp's right-hand dwarf had to be convinced, but even he was not cold hearted enough to refuse the circus for the people of borrend. 

Knucklestepp then made an appearance, having heard the commotion in his city. He was very difficult to convince, and Murrak had to drop the bid for the circus for KS to come around on the concept. Eventually KS relented, thinking that he could always gas and kill the koala troope if here were not impressed. The event would be held in the main gas extraction chamber, which is large enough to hold a thousand members of Borrend.

Murrak took a particular interest in Skittles. He found its demonic aura to be 

Alpic ordered costumes for the troope, disguising Skittles as a regular koala and Koala_Dorc as a demonic one.

The night came, and with it, the circus. A grand crowd gathered in the chamber. Knucklestepp looked down from on high, with his stone circle druidds gathered on the outstretched fingers of the stone, statue hand in the center of the chamber. Alpic gathered her koala, and put on a show...

First was acrobatic tricks and coreographed dances. Next, was a triangle of koala with Alpic jumping up onto the top! Finally, and in the most impressive act, Curious Koala Kaetus wrote 'borrend' in common in the dirt after being directed by Alpic. The crowd went wild. The koala are intelligent! They can understand words! Even Knucklestepp was impressed.

A bidding war for the Koalas immediatley broke out. Knucklestepp bought a Koala for Murrak. Murrak bought 'skittles' (actually Dorc) for Knucklestepp. Most of the koalas wound up sold at various price points. A party broke out and everyone got smashed. Espically Dorc, who rolled an uncharistierc and flat Nat1 on his Con save.

--

Knucklestepp took his newfound koala purchase to bed. Alpic realized that Dorc did not have the poison for his nefarious deed, and quickly ran over and subtly sleight-of-handed the unconsious Dork the poison.. by slapping it right up his butt. Knucklestepp never noticed a thing. Dorc did though.

In his bed chambers, Knucklestepp took to cuddling koala Dorc. In his drunked stuper, he popped the crystal vial of poison out of his bumb, and had the drunk KS sip the poison from Dorc's tiny little fingers. The poison seeped into the Koala skin, and did enough damage to revert the polymorph. Luckly Dorc's main body saved against the poison. He looted his staff, and a fair amount of gold from KS' body and bedchamber. Not wanting to go out through the main door as a dwarf/orc, he instead squeezed into a poorly sealed crevice, leading deeper into the mountain complex.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
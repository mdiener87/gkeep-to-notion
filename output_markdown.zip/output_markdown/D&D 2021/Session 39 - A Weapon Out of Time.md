# Session 39 - A Weapon Out of Time

    **Created:** 2022-02-10 19:05:14  
    **Last Edited:** 2022-02-10 23:00:48  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

The party is headed to the doom cannon. This time, in the past. They hope to stop its final construction, destroying it in the past to prevent disaster from unfolding in the future. They will meet Brock's mom, Gnedden, a young and brilliant gnome engineer, in charge of the weapon. It is nearing completion. Can the Order prevent it from going system ready?

This will be complicated by the fact that KS' Shadow is still very much alive. The vile poison his body was killed with has only fed its hatred, and now it seeks vengeance on the party and the usage of his weapon!

KS' Shadow - As Wraith, Ghost, and Skull Lord
+
Stone Druid Order + Rock elementals
+
Occasional gnomish weapon

--


gameplay notes 2/10/22

The party started on the borrend map. However, exhausted from their drinking efforts, they decided not to head straight into battle. They instead backtracked into the cave Dorc found, the one with the elemental. 

Kaetus cautiously approached, and noticed that the elemental was staring into the lake. In it he saw a red gem. He dived down as an otter, and retrieved the gem. Handing it to the elemental, he plugged it into its skull. With its eye restored, the elemental agreed to let the party rest in the cave. They all took long rests, only hearing the elemental moving about... and shouts of surprise coming from deep in borrend.


With a rest under them, they once again approached the cannon. However, it seems to have been reinforced over the night. The party engaged from the stealth, and Kipla vaporized a defense turret with a critical sneak attack. Unfortunatley, Dorc was too close to the resulting blast, and she hit him hard with force damage.

Fighting their way out of the tunnels, the party discovered a large map... filled with clockwork defense turrets. They pelted from long range, and while they rolled with disadvantage, their sheer numbers and decent +hit rating proved a tangible threat throughout the battle.

Stone Circle druids also charged forth. Their bound earth elemental myrmidons crashed into the party. Kaetus became a flying earth elemental as well, meeting the elementals in the field of battle.

The party cut through many automated defenses and a bound elemental. Zephyr flew up to a stone circle druid, and offered it to parlay. He explained that they are here from the future, and are trying to destroy the weapon before it. Despite rolling at disadvantage, Zephyr's words range true, and the druid considered his words.

What will happen next? Find out next time on DnD!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 19 - Killing Time

    **Created:** 2021-10-29 11:41:34  
    **Last Edited:** 2021-10-29 11:41:39  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, all level 13 players have leveled up.

‘The party is currently returning to Alluin via Kaetus Airways. They are transporting the Princess Gwen, whom has just
survived an attack on her life via a swarm of giant spiders. The Order was succesfull from saving her from this grisly
demise. The attack has Drow written all over it. King Galtorah is still missing. What awaits them back at the castle? And
what is the real motive behind these plots?

Illitran awaits them at the castle. She is (or was) Prince Zelphar's mother. A Drow Princess herself, she was defeated and
captured by Galtorah during a clandestine conflict that saw Galtorah and the High Elves the victor. Illitran, in her
moment of defeat, was raped (her words) by Galtorah. Not only was she taken prisoner, she was impregnated by her
captor.

Galtorah will dispute this, While he will admit to copulating with her, he later realized that he had been manipulated.
llitran used Drow hypnosis magick to enflame his lust and drive him to fully claim her in victory. He feels that he was the
one raped in this encounter.

llitrain would die during child birth. The perfect captive - she delivers a half-High Elf, half drow Prince who can rightly
claim two thrones and unite the kingdom. Then, she dies. Her position in Drow society could not be used as political
leverage as a hostage. For such devotion, llith, the Drow Demon Goddess, blessed Illitrain in death, such that she might
return as a powerful Drow Demon.

Prince Zelphar has been tipped off that something weird is up. He opened the mirror of prophecy, and discovered the
Order of Sun and Moon. He learned their weaknesses, their strengths, and most of all - their crazy combat power. He
knows he must take matters into his own hands to defeat not only his father, but these new temporal interlopers.

Illtrain has stormed the castle, along with a team of Drow agents. Ilitrain has enfused the castle with powerful sleeping
magick, and from those stuck in her web she is extracting their psychic energy to summon phantasmal Terror Spiders
with which to assautt the party.

Princess Gwen can shield the party from the sleep magick, but only if they don't take damage or the Princess takes
damage (>5). The Drow magic feeds off of pain, fear, and terror. Fighting in combat only amplifies your drowsiness. As
the party goes up through the castle, the strenght of this sleep spell DC increases.

The fight:

‘The Party might have to fight up through the castle, Though its possible they will just fly to the throne room and
therefore confront illitrain directly. They don't need to fight through trash.

Monsters:
Uitrain

Sleep Aura - As per the Sleep Spell for effect. WIS Save, DC 15 outside the castle, DC17 inside the castle, DC19 facing
illitrain. The Sleep Aura checks at the end of combat, and any time a creature takes more than 10 damage from a single
source. If a Character saves from the damage check, they are immune to further damage checks until the end of the
round. Only up to 2 creatures can become sleeped at the same time from the end of round effect.

Agnar, the Ambitious

Drow Agents (kobold fight club these but not too time consuming)

Terror Spiders
~-As per Phase Spider, but bite damage is necrotic instead of piercing. is Abberant and Fiend (Demon) instead of a
beast. Has less HP (50%) but constantly respawns. Poison damage from the bite adds half that much to the
resulting sleep spell DC check. Any damage from this unit forces a sleep spell check, if active,

Session recap:
The party did not return to ALluin. Sensing a plot fo destory the Jedi, the Order fook the princess to Valzumin's
Lake - the one place they figured is safe. There, Kaetus tried to Scry Galtorah - only to witness (in a glitched
‘sensor flipping between his bracer and Galtorah himesif) the murder of Galtorah to Prince Zelpharl

He was able fo memorize the exchange between them. This convinced Princess Gwen that her Brother really
is trying to murder the family.

The party camped by the lakeside overnight. They did not summen Valzumin's platforms. During the long rest,
the Princess woke up screaming on second watch that something was observing her. This did not really
concern Dore, who slapped her (half strength) and calmed her down.

During Fourth watch, Zephyr caught sight of something approaching in the distance, from the other side of the
lake. He had spotted an approaching troop fo Draegloth Demons, and he sounded the alarm and flew into
combat. The Draegloth's were not much of a fight against the order, and were shortly dispatched. Kaetus
stayed close by the princess for the whole fight, ensuring nothing could harm her. THe princess mostly tried to
put on the armor Kaetus gifted her, but failed under pressure to don i

As dawn of this new day broke over the battlefield, the party realized this location was no longer safe. Where
will they go now with the princess? Find out next time - on DND!

#### ChatGPT Output:
Coming into this session, all level 13 players have leveled up.

'The party is currently returning to Alluin via Kaetus Airways. They are transporting the Princess Gwen, whom has just
survived an attack on her life via a swarm of giant spiders. The Order was successful from saving her from this grisly
demise. The attack has Drow written all over it. King Galtorah is still missing. What awaits them back at the castle? And
what is the real motive behind these plots?

Illitran awaits them at the castle. She is (or was) Prince Zelphar's mother. A Drow Princess herself, she was defeated and
captured by Galtorah during a clandestine conflict that saw Galtorah and the High Elves the victor. Illitran, in her
moment of defeat, was raped (her words) by Galtorah. Not only was she taken prisoner, she was impregnated by her
captor.

Galtorah will dispute this. While he will admit to copulating with her, he later realized that he had been manipulated.
Illitran used Drow hypnosis magick to enflame his lust and drive him to fully claim her in victory. He feels that he was the
one raped in this encounter.

Illitrain would die during childbirth. The perfect captive - she delivers a half-High Elf, half-Drow Prince who can rightly
claim two thrones and unite the kingdom. Then, she dies. Her position in Drow society could not be used as political
leverage as a hostage. For such devotion, Illith, the Drow Demon Goddess, blessed Illitrain in death, such that she might
return as a powerful Drow Demon.

Prince Zelphar has been tipped off that something weird is up. He opened the mirror of prophecy, and discovered the
Order of Sun and Moon. He learned their weaknesses, their strengths, and most of all - their crazy combat power. He
knows he must take matters into his own hands to defeat not only his father, but these new temporal interlopers.

Illtrain has stormed the castle, along with a team of Drow agents. Illitrain has infused the castle with powerful sleeping
magick, and from those stuck in her web she is extracting their psychic energy to summon phantasmal Terror Spiders
with which to assault the party.

Princess Gwen can shield the party from the sleep magick, but only if they don't take damage or the Princess takes
damage (>5). The Drow magic feeds off of pain, fear, and terror. Fighting in combat only amplifies your drowsiness. As
the party goes up through the castle, the strength of this sleep spell DC increases.

The fight:

'The Party might have to fight up through the castle, Though it's possible they will just fly to the throne room and
therefore confront Illitrain directly. They don't need to fight through trash.

Monsters:
Illitrain

Sleep Aura - As per the Sleep Spell for effect. WIS Save, DC 15 outside the castle, DC17 inside the castle, DC19 facing
Illitrain. The Sleep Aura checks at the end of combat, and any time a creature takes more than 10 damage from a single
source. If a Character saves from the damage check, they are immune to further damage checks until the end of the
round. Only up to 2 creatures can become slept at the same time from the end of round effect.

Agnar, the Ambitious

Drow Agents (kobold fight club these but not too time consuming)

Terror Spiders
  - As per Phase Spider, but bite damage is necrotic instead of piercing. Is Aberrant and Fiend (Demon) instead of a
    beast. Has less HP (50%) but constantly respawns. Poison damage from the bite adds half that much to the
    resulting sleep spell DC check. Any damage from this unit forces a sleep spell check, if active,

Session recap:
The party did not return to Alluin. Sensing a plot to destroy the Jedi, the Order took the princess to Valzumin's
Lake - the one place they figured is safe. There, Kaetus tried to Scry Galtorah - only to witness (in a glitched
sensor flipping between his bracer and Galtorah himself) the murder of Galtorah to Prince Zelphar.

He was able to memorize the exchange between them. This convinced Princess Gwen that her Brother really
is trying to murder the family.

The party camped by the lakeside overnight. They did not summon Valzumin's platforms. During the long rest,
the Princess woke up screaming on second watch that something was observing her. This did not really
concern Dore, who slapped her (half strength) and calmed her down.

During Fourth watch, Zephyr caught sight of something approaching in the distance, from the other side of the
lake. He had spotted an approaching troop of Draegloth Demons, and he sounded the alarm and flew into
combat. The Draegloth's were not much of a fight against the order, and were shortly dispatched. Kaetus
stayed close by the princess for the whole fight, ensuring nothing could harm her. The princess mostly tried to
put on the armor Kaetus gifted her, but failed under pressure to don it

As dawn of this new day broke over the battlefield, the party realized this location was no longer safe. Where
will they go now with the princess? Find out next time - on DND!

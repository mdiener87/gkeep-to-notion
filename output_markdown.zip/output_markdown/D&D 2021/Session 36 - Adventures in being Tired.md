# Session 36 - Adventures in being Tired

    **Created:** 2022-01-20 18:50:43  
    **Last Edited:** 2022-01-20 22:39:01  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Not much energy tonight, nor much prep. Let's see if we can't get a fun little adventure in for our players all the same.

The party - heading to Borrend of the Third Age to stop Knucklestepp Shapin and his WIP Doom Cannon. 

--

DND session notes 1/20/22

Players examined the vial from Zelphar's chest pocket. With the help of new NPC [Selphie Xyrkrana], a chemist in the castle, they determined its a powerful poison infused with shadow magic. It would be difficult to heal from, and would likely wither and disintegrate.

Selphie did not know about any magical shops in Alluin that would interest the party.

Kaetus then proposed an innovative infiltration strategy. Rather than flying in on eagles, or using a wind walk based approach, he proposed a radical new take. He proposed to use Animal Shapes, a new spell in his arsenal. Using this, he would wild shape the whole party into Koalas. It was a plan so rediculous that the party had no choice but to enact it. 

Using Lord Galtorah's teleportation circle, Galtorah teleported the party towards Borrend. They arrived in a nearby canyon on the outskirts of the city. Kaetus enacted his plan, and koala-fied himself and Zephyr. Led by the amazing Koala trainer 'Alpik', Kipla herded her troope up the canyon. 

They were blocked by a group of young dwarfs guarding the canyon. They were under orders to block the way and prevent any 'tall people' from getting close. The Koalas quickly went on a charm offensive. With a good bluff from 'Alpik', they quickly convinced the young dwarfs to let her proceede to sell the Koalas at borrend. The dwarfs instructed a very young Thradal to lead them to borrend.

At the gates of borrend, a similar scene plaid out. Suspect dwarf and gnome defenders quickly gave into the cuddly charm. The gates of borrend were quickly opened, and Kipla and her Koalas entered the city...

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 12 - Spoils of War

    **Created:** 2021-10-29 11:40:05  
    **Last Edited:** 2024-11-14 17:57:29  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Loot:

Valzumin's Tome of Greater Arcanum:
After studying this tome for 48 cumulative hours, you gain +1 attuned item slots.
This effect is lost if you are reduced to 0 hit points or less, your INT score drops below 10, or you otherwise die.


Valzumin's Elven Plate Armor +2 (requires Attunement) 
You have resistance to Force damage and psychic damage while wearing this armor.
If you would take 3  or less damage, this damage is reduced to 0 instead.


Valzumins Arcane Crossbow +3 (Requires Attunement)
Ammunition (bolts), Heavy, Loading, Two-Handed, Ranged (150/600)
Bolts from this weapon emit a distinct and loud ringing blast on impact.
On hit, deals an additional 1d6 force damage and 1d6 thunder damage. 
Creatures you kill with this weapon explode, dealing 6d6 force damage in a 15ft radius. If this explosion kills a creature, you may reload this crossbow as a reaction. 

This immense crossbow was once the preferred weapon of the Elven Warlord Valzumin. It is said entire squads of troops would fall to a single demonstration of its terrible power.

1x Crossbow Bolt of Slaying (Fiend)


		5th Level Spell scroll (Telekinesis)
4th level spell scroll (Mordenkainen's Private Sanctum)
3rd Level Spell scroll (Magic Circle)
3rd Level Spell scroll (Catnap)

		Potion of Gaseous Form
Potion of Fire Giant Strength
		Potion of Invulnerability


Golem:
		2x Arcane Power Rods (Large)(Valzumin)
1x Oil of Slipperiness
10x Precision Mechanical Parts

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
Going to start off with looting tonight from the previous battle. This Valzumins inner sanctum, so it should have some
good stuff. The Tome of Greater Arcanum is the big prize but can roll for other items and spell scrolls.

Otherwise, we will finally interact with the mirror. Prepare for loading screens and making this up as we go. Refer to
mirror notes for world timelines and usage.

Result: Players looted the keep, and found amazing gear! Including Valzumin's personal set of heavy Armor and his,
Crossbow. These powerful items were accompanied by spell scrolls and potions they found in the various corners. The
center of this chamber was a large master control for the various operations throughout Valzumin's stronghold.

‘The party briefly visited the arboritum. Kaetus determined he could not use the tree for transport via plants, but could
not determine why.

‘The last portion of the session focused on The Mirror of Prophecy and the workings of time. Zephyr consulted the
history from the Elven High Council (of the third era) and determined that the branching timelines seemed to occurr
when Galtorah's daughter, Gwynnestri Galtorah, was murdered, Within several weeks, Galtorah himself was similarly
murdered. Prince Zelphar tried to claim the throne, but was rejected by the council. His play at power resulted in
Zelphar himself being hunted down and killed,

Order of elven lords:
vValzumin (first era)(warlord who forged the kingdom)
Tinethra (second era(artificer who abandoned the throne)
Galtorah(third era)(golden age of the kingdom until he died)

Kaetus channeled Galtorah (beta timeline) who finally had a useful conversation. With Zephyr and Ureasua to help him
‘work through things, they leamed much about the history of the world. Galtorah foresaw the Doom Cannon explosion
and could not prevent it. Worse, he saw how this climatic event would inevitably lead to Savaran's invasion - and
conquering - of the mortal world.

Galtorah's final action while channeling was to show the mirror's own reflection of major users who have interacted
with the mirror thus far. It was mostly Galtorah. Then, towards the very end, it changed. Zelphar's face emerged, and
promptly glitched. Then the Sibriex Demon, who promptly glitched. Lastly, Ureausa.

‘The party has pieced together that the removal of the Sibriex demon represented a ‘major usage’ of the mirror. They are
still putting it all together but realize that this timeline must hinge upon the murder of Gwynnestri and/or Galtorah by
Prince Zelphar.

Zephyr, using the history book as a guideline, tried making an arcane check on the mirror. He succefsully revealed the
Alluin of the third age, with Galotarh, King, ruling. He linked hands with his compatriots, touched the mirror... and got
sucked through the ethereal portal.

‘The Order in the Third Age - next time, on D&D!

#### ChatGPT Output:
Going to start off with looting tonight from the previous battle. This Valzumin's inner sanctum, so it should have some
good stuff. The Tome of Greater Arcanum is the big prize but can roll for other items and spell scrolls.

Otherwise, we will finally interact with the mirror. Prepare for loading screens and making this up as we go. Refer to
mirror notes for world timelines and usage.

Result: Players looted the keep, and found amazing gear! Including Valzumin's personal set of heavy armor and his
crossbow. These powerful items were accompanied by spell scrolls and potions they found in the various corners. The
center of this chamber was a large master control for the various operations throughout Valzumin's stronghold.

The party briefly visited the arboretum. Kaetus determined he could not use the tree for transport via plants, but could
not determine why.

The last portion of the session focused on The Mirror of Prophecy and the workings of time. Zephyr consulted the
history from the Elven High Council (of the third era) and determined that the branching timelines seemed to occur
when Galtorah's daughter, Gwynnestri Galtorah, was murdered. Within several weeks, Galtorah himself was similarly
murdered. Prince Zelphar tried to claim the throne, but was rejected by the council. His play at power resulted in
Zelphar himself being hunted down and killed.

Order of elven lords:
- Valzumin (first era)(warlord who forged the kingdom)
- Tinethra (second era)(artificer who abandoned the throne)
- Galtorah (third era)(golden age of the kingdom until he died)

Kaetus channeled Galtorah (beta timeline) who finally had a useful conversation. With Zephyr and Ureasua to help him
work through things, they learned much about the history of the world. Galtorah foresaw the Doom Cannon explosion
and could not prevent it. Worse, he saw how this climatic event would inevitably lead to Savaran's invasion - and
conquering - of the mortal world.

Galtorah's final action while channeling was to show the mirror's own reflection of major users who have interacted
with the mirror thus far. It was mostly Galtorah. Then, towards the very end, it changed. Zelphar's face emerged, and
promptly glitched. Then the Sibriex Demon, who promptly glitched. Lastly, Ureausa.

The party has pieced together that the removal of the Sibriex demon represented a 'major usage' of the mirror. They are
still putting it all together but realize that this timeline must hinge upon the murder of Gwynnestri and/or Galtorah by
Prince Zelphar.

Zephyr, using the history book as a guideline, tried making an arcane check on the mirror. He successfully revealed the
Alluin of the third age, with Galotarh, King, ruling. He linked hands with his compatriots, touched the mirror... and got
sucked through the ethereal portal.

The Order in the Third Age - next time, on D&D!

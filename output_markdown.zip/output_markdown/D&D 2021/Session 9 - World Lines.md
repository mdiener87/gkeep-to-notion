# Session 9 - World Lines

    **Created:** 2021-10-29 11:39:22  
    **Last Edited:** 2021-10-29 11:39:24  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Ina ferocious battle, the Order has defeated the Sibriex OgLoxan. His foul corpse now slowly melts away, leaving the
Mirror of Prophecy once again within the party's grasp.

I'm not sure how today's session is going to go. We just got off a big boss battle, so players need downtime to rest, heal
up, and figure out how to use the Mirror. Once they do, I'm sure their first instinct will be to use it to correct the events
that transpired in Borrend.

Play it casual and RP heavy. This will set up how the following encounters will go with the Mirror.

To return to their ‘current’ world time, they'll need to access their mirror again. Depending on when they go to, it might
be in very strange places indeed...

Result:

Chill night, late start.
Party spent a lot of time wrangling the mirror into the Chest of Holding. Then they used Ankleosauraus Kaetus to
transport Dore, the mirror, and the rest of the party through the mirror wall back into the real world. They fought their
way through the rutterkins, and have moved the mirror halfway through the lava. They took a long rest here, preparing
spells to transport the mirror and the party back to civilization.

#### ChatGPT Output:
In a ferocious battle, the Order has defeated the Sibriex OgLoxan. His foul corpse now slowly melts away, leaving the
Mirror of Prophecy once again within the party's grasp.

I'm not sure how today's session is going to go. We just got off a big boss battle, so players need downtime to rest, heal
up, and figure out how to use the Mirror. Once they do, I'm sure their first instinct will be to use it to correct the events
that transpired in Borrend.

Play it casual and RP heavy. This will set up how the following encounters will go with the Mirror.

To return to their ‘current’ world time, they'll need to access their mirror again. Depending on when they go to, it might
be in very strange places indeed...

Result:

- Chill night, late start.
- Party spent a lot of time wrangling the mirror into the Chest of Holding. Then they used Ankleosauraus Kaetus to
transport Dore, the mirror, and the rest of the party through the mirror wall back into the real world. They fought their
way through the rutterkins, and have moved the mirror halfway through the lava. They took a long rest here, preparing
spells to transport the mirror and the party back to civilization.

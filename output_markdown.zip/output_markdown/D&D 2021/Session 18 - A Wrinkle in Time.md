# Session 18 - A Wrinkle in Time

    **Created:** 2021-10-29 11:41:22  
    **Last Edited:** 2024-11-14 17:49:30  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

alaunkiira alemtor
Elwin Omapetor

Session notes: 8/29/21??date may be incorrect




Session Recap:

Alaunkiira Alemtor came and saw the party during the predawn morning. She introduced herself as Galtorah's Consort, and tried to earn the party's trust. Despite her ability to pass their insight checks, none of the party seemed eager to trust her. She did hint that Galtorah was not available in the castle, and actually on off some secret mission to see his Son, Zelphar.

She insisted that the party leave Princess Gwen out of her schemes, then left after it seemed that she could not make any progress on learning the identity of the party. 


In the morning they were summoned to the throne room, where the party met Elwin Omapetor, the elven general that rules Alluin in Galtorah's absence. A trusted confident, he personally wanted to evalute the party. Once the Order determiend they could trust him, they let slip that they are from the future, sent on mission to save Galtorah and Princess Gwen's life. 

During this meeting, Alaunkiira tried to sneak in while invisible. Zephyr was able to see her through the invisibity field, rushed forward, and grabbed her. Elwin summoned guards to carry her out, reprimending her for the breach in protocol. Before they could arrest her, however, she used Misty Step to free herself from Zephyr's grasp. She ran into a nearby room and became invisible again.

Kaetus and Zephyr gave pursuit. As an air elemental, Kaetus moved the air violently in the first room, revealing Alaunkiira. Zephyr promptly hit her with the Hold Person before she could cast more magick. Elwin had her escorted out and arrested. 

Meanwhile, Gandus ran to the Princess' bedroom. But, she was not there! Elwin revealed she was likely outside the castle, practicing magic in nearby fields. She found Alluin to be much too stuffy to concentrate on her arcana. Frustrated but undetered, the Order quickly cast Wind Walk and gave cloudy chase to find her.

When the Order caught up to her, in a nearby clearing outside the city, they found her position surrounded by Giant Spiders. The order rushed forward and became to re-materialize from cloud form. A process that took a solid minute, while they could only sit and watch the events unfold around them. Most of the spiders went for the materializing party members. They had little luck with the heavy plate armor of Gandus and Dorc. Uraeusa took a little damage and shrugged off the poison. Zephyr, however, became quite the tasty snack and took signifcant damage from this endevaor. 

Princess Gwen did not do well. She was unable to hold the remaining spider back with Hold Monster, and it eventually bit her enough to kill her in combat. Kaetus was able to Spare the Dying this time, and save the Princess from a gruesome end to the spiders.

The party made short work of their spiders. Kaetus hit it with the blight. Gandus, the blade of molten magic. Dorc stabbed his. Ureausa inflicted wounds + bankhed the head for a killing blow. Kipla tried out her new weapon, missed, and vaporized a nearby grove of trees!

At the end, the party was able to heal the princess, and restore her to life. Kaetus summoned birds and they returend to the castle, where the Princess Gwen promised to furhter discuss the true parentage of Zelphar and the Drow plots against the family.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
Note to self: clean up notes for sessions 16 + 17 tonight so they don't get lost going forward.

Coming in to tonight's session, the Players are in the Alluin castle, in the 3rd age of the Kingdom. Gandus has worn
vValzumin's battle armor, and led the group charging into the castle on pomp and circumstance, The Castle isin an
uproar. Noone has any idea who this ‘Valzumin' really is. Valzumin's death is recorded by history... although no body was
ever found. Nor was his distinctive armor and crossbow ever recovered.

Princess Gwen has snuck into the floor of the castle that has been graciously assigned to these guests. There, the party
revealed themselves as time travelers from the future. Their evidence was convincing, but the very concept proved
overwhelming to young Gwen. She fled the room, trying to sort out here thoughts on the matter.

Meanwhile, King Galtorah is nowhere in the castle. Publically, this is because he is in the Elven city of Silaverum. In
reality, he is meeting a drow envoy and his (bastard) son in secret. Zelphar is demanding his father recognize his lineage,
and the rejoining of house Drow into public policy.

‘The Drow within the castle have no use for interlopers in this critical moment. Whoever they are, they are trouble, and
should be dealt with... quietly. Before word of their strange arrival can reach Galtorah's ears and further complicate the
situation!

(Galtorah will refuse his son's request. This will set in mation the events leading to Gwens and Galtorah's murders}.
(Zelphar already tried to use the Sibriex demon to drive his father insane, roughly a few weeks ‘ago’. This plot failed, for
some undetermined reason. Forcing Zelphar to beg one more time for recognition... Or else)

Tonight:

Start off with some Drow plots. Allunkira is going to make an appearance. One of the king's Consorts has been keeping
an eye on the party. She will also try to show up like Princess Gwen did, and secretly pump the party for information.
She will trade the secret that Galtorah is not really on a diplomatic trip. That only she know's how to reach the King on
his present quest, for knowledge of the party's mission. If she gets the feeling the party can't be used against Galtorah,
she will send in the assassination squad.

In the next morning, Elwin Omapetor will meet the party. He is the King’s Elven General, appointed as Alluin's Guardian
in the King's absence. A stern and straightforward Elven military commander, he has no use for deception and will
demand to know who the party is and how they dare barge into the castle in such a manner.

-> If the party can convince him, he will have the ability to summon Galtorah. Galtorah will want to meet in a secure
location away from the Castle to test these adventurers himself.

#### ChatGPT Output:
Note to self: clean up notes for sessions 16 + 17 tonight so they don't get lost going forward.

Coming in to tonight's session, the Players are in the Alluin castle, in the 3rd age of the Kingdom. Gandus has worn
Valzumin's battle armor, and led the group charging into the castle on pomp and circumstance. The Castle is in an
uproar. No one has any idea who this 'Valzumin' really is. Valzumin's death is recorded by history... although no body was
ever found. Nor was his distinctive armor and crossbow ever recovered.

Princess Gwen has snuck into the floor of the castle that has been graciously assigned to these guests. There, the party
revealed themselves as time travelers from the future. Their evidence was convincing, but the very concept proved
overwhelming to young Gwen. She fled the room, trying to sort out her thoughts on the matter.

Meanwhile, King Galtorah is nowhere in the castle. Publicly, this is because he is in the Elven city of Silaverum. In
reality, he is meeting a drow envoy and his (bastard) son in secret. Zelphar is demanding his father recognize his lineage,
and the rejoining of house Drow into public policy.

'The Drow within the castle have no use for interlopers in this critical moment. Whoever they are, they are trouble, and
should be dealt with... quietly. Before word of their strange arrival can reach Galtorah's ears and further complicate the
situation!

(Galtorah will refuse his son's request. This will set in motion the events leading to Gwen's and Galtorah's murders).
(Zelphar already tried to use the Sibriex demon to drive his father insane, roughly a few weeks 'ago'. This plot failed, for
some undetermined reason. Forcing Zelphar to beg one more time for recognition... Or else)

Tonight:

Start off with some Drow plots. Allunkira is going to make an appearance. One of the king's Consorts has been keeping
an eye on the party. She will also try to show up like Princess Gwen did, and secretly pump the party for information.
She will trade the secret that Galtorah is not really on a diplomatic trip. That only she knows how to reach the King on
his present quest, for knowledge of the party's mission. If she gets the feeling the party can't be used against Galtorah,
she will send in the assassination squad.

In the next morning, Elwin Omapetor will meet the party. He is the King’s Elven General, appointed as Alluin's Guardian
in the King's absence. A stern and straightforward Elven military commander, he has no use for deception and will
demand to know who the party is and how they dare barge into the castle in such a manner.

-> If the party can convince him, he will have the ability to summon Galtorah. Galtorah will want to meet in a secure
location away from the Castle to test these adventurers himself.

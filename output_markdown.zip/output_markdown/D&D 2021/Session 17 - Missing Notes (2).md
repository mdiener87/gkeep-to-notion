# Session 17 - Missing Notes (2)

    **Created:** 2021-10-29 11:40:58  
    **Last Edited:** 2024-11-14 17:53:01  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Game Notes 5/19/21

For today

Drow sneak attack on the party?

They might meet Galtorah in the castle


Remind the players - what is their mission in this time travel land?
	Prevent Galtorah's murder?
	How will that change the timeline?
		Drow currently think Kaetus is Galtorah - his scent is all over Kaetus 
	
	Who has access to the mirror currently?
	What will Zelphar do once he learns about the Party?
	
	
	What is Galtorah up to right now?
		-> On business in Seleveraum, and should be back in a few days
		

Sepherina - Gandus Diva


Party started the day in the Cunning Potato. Zephyr started trying to get some intel from the bar, which was packed with people talking about Galtorah being in the market. Gandus came out wearing Valzumin's armor, which immediatley created a scene. A throng of people started chasing him, and the party, through the street. A whole commotion occured. They had to demand the crowd leave them alone and book it to get away.

They then tried to find any kind of secret entrance to the castle. Despite Zephyr's guess, they could not find any way into the 'drow tunnels' that they know lie under the castle. Or at least will one day lie under the castle. They couldn't find an entrance. 

Kaetus tried channeling Galtorah's bracer. Weird feedback occured, and Kaetus was left screaming weird, broken phrases about time travel. Some medical slaps broke him out of it.

The party got bored trying to sneak their way in. They changed tactics, and charged forth in full bling. They bluffed their way past the castle guards, who had no idea how to deal with a Lord Valzumin suddenly ridding up and demanding in. They quickly agreed to take him to some quarters while they awaited Galtorah to return to the castle.

Inside their rooms, Zephyr found an enchanced oil lamp with a Clairvoyance spell cast upon it. He left it outside in the hallway.

While discussing what their next move should be, princess Gwen snuck into the floor to talk to the party. There, they revealed their identity as adventurers from the future. Their evidence was convincing. Overwhelemed, she rushed out of the room.

Kaetus and Gandus read some books, and Zephyr took up watch.

FIN!

Zephyr - has started to decrypt Galtorah's Journal. Can read the first couple chapters.
	NEED CONTENT FOR THIS


Secret's of Galtorah's Journal, Pt. 1

- The first chapters chronicle's Galtorah's first adventures in the planes
- He often talks of spirits, or visions, he has while on the vessel. Some of these are even Humans and other races seemingly manning the vessel. He doesn't seem to know what to make of these visions, but finds it disturbing.
- He mentions at one point he grew Endimyon over several decades from a sapling. The sloop is of his own design and craftsmanship, though he admits in one section that Lord Valzumin drew up the initial concept of an astral ship.

-You learn of the following locations in the astral plane:
	- A secret Githyanki trading post where Galtorah made lots of profit!
	- The secret lair of mindflayer cultists that nearly ate Galtorah's Brain!
	- A rogue asteroid hurtling through space. A powerful elemental guards it that Galtorah decided to steeer clear of
	- Astral portal locations that lead to the capitol cities of the Earth, Fire, Air, and Water Elemental Planes
	- Astral portal locations that returns one to the Material plane. Although Galtorah doesn't note where in the material plane it lands

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
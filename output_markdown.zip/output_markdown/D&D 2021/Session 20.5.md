# Session 20.5

    **Created:** 2024-11-14 17:45:08  
    **Last Edited:** 2024-11-14 17:45:26  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

8/5/2021

8/5 notes

galtorah:
hp: 21

gwen:
HP 50 (30)
HP Die (short rest)
9/9
spell slots:
1: 4/4
2: 3/3
3: 3/3
4: 3
5: 2

health potions remaining:
normal: 2
greater: 1


Skittles:
severe puncture wounds
	-2CON
	-1STR
	
	
8/5 gameplay notes:

party took to the elevator down into GK
They encountered the sleep aura, and Princess Gwen almost promptly fell asleep!
Opening the door, they found a drow party waiting for them!
Combat ensued, but the spider's were knocking out people with their venom. Kipla fell asleep..
And Skittles stepped forward on the attack!

A Spider tried to attack the sleeping Kipla, but couldn't overcome Kaetus' warding effect! So instead, it attacked.. Skittles!
Skittles was one shot and instantly killed by the spider


Kaetus quickly used Reviviy to bring Skittles back to life before Kipla even noticed her faithful companion could be killed

The party pressed foward, fighting through waves of spiders, until eventually they cleared the map of drow and spider alike

Next time on D&D - how to advance through the dungeon deeper!?

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
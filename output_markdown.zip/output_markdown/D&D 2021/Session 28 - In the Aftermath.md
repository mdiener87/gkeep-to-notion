# Session 28 - In the Aftermath

    **Created:** 2021-10-29 11:43:17  
    **Last Edited:** 2021-11-04 22:35:33  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Gameplay Notes 10/28


Kaetus and Gandus started session with medical checks on Princess Gwen. They were able to remove the residual poison from her, and heal her enough she is no longer in danger.

The party's attention then turned to the mirror. Galtorah lay just beyond, slowly dying in the astral space beyond.

The party came up with a rescue plan. Kaetus secured a rope to himself, which Dorc grabbed, and Gandus tied the end to his steed (quite poorly). 

Kaetus, channeling Galtorah's bracer, cast an arcane check with advantage and succesfully opened the astral portal. He stepped through. And found Galtorah floating off the ground. He was further away than the rope could reach. 

Kaetus summoned giant eagles, which he succesfully commanded to swoop and rescue Galtorah from his floating, dying predicatement. 

This maneuver did not go unnoticed. Lurking amongst the rocky islands in this area were Mindwitness beholders. They floated forward, revealing themselves, locking eyes on Kaetus. 

Kaetus roughly grabbed Galtorah off the eagle. Changing his concetration, he cast Enhance ability, giving himself the strength he needed to carry Galtorah back through the portal.

On the other side, the party made ready. Dorc and Zephyr were ready to attack any that came forward. Gandus tried casting Shatter, but failed an Arcane check that would let it pass through the mirrors event horizon. Instead, it exploded on the party, and killed Galtorah.

Ureausa revivified Galtorah, and crucially, in the same turn, removed his poison before max HP damage could kill him. Kaetus used Arcana to close the portal, but he only moderatly succeeded - it would take a full round to close.

This gave the Hentai Boys the round they needed to close the gap. Two made it through before the portal closed on them.

They materizliaed in the real world, and the party sprung on them. Dorc killed one in a single turn, using Action Surge to impale it 6 times in rapid succession. Zephyr did not one shot his target, but did stun it up so that it could be beat down and eliminated safely.

With the room secured, the party was able to meet Lord Galtorah in the flesh for the first time. He commended the party for the skill, bravery, and Kaetus in particular for his ability to bend time. Galtorah never considered this possibility - only that it could be used for prophecy. Princess Gwen entreated Kaetus to stay here, in the 3rd age, with her. Galtorah began to hatch a plan for the party to deal with the doom cannon before it could become operational.

The sands of time are shifting unpredictablly. Who knows what the future now holds? Find out next time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
So | haven't really known what to do here. The party just defeated the big bad in the past, and skipped all of the Tower
of Bithyra. We need to figure out the consequences of the timeline.

First and most pressing - Lord Galtorah is currently dying within the Mirror of Prophecy. He is poisoned by the second
effect of Zelphar's poison, and his MAX HP is now down to 12. He will die in moments if not treated. Galtorah was not
really present for the rest of the timeline up to the present, so if he survives, this is a major departure.

Galtorah Branching:
* Dies in Mirror - Negative outcome. Removes the haunted specter from Galtorah's Bracers on Kaetus
* Dies in World - Neutral outcome. Will enchant his bracer with his essence right before passing, thereby granting
continuing with Kaetus
= Survives in Mirror - Chaotic outcome. Will need to see how this comes about.
= Survives in World - Good outcome, but not without changes. Galotrah's leadership will echo through the ages,
improving life in the kingdom. However, it will come at other costs [tbd]
© This will largely prevent the Orc invasion from going as badly.
© Because the Orc invasion was contained, the Kingdom is more prepared to fight Kaladan's Dragon Uprising
© Kaladan still comes out on top, and a bloody civil war ensues
© Critically, in this timeline, Esepha the Enchanted does not have the Aether Flame stolen by Aiden. He is alive
and fully intact. [sure about this?]

Princess Gwen - Survived. Branching:
* will try to romance Kaetus for everything he and the order have done
© ->if successful, chaotic outcome. Does Kaetus stay behind and live his life out with a Princess in the 3rd age?
© Does he bang her and run? -> Potential pregnancy, he might father a future ruler of the kingdom
+ Will reveal, if asked, the complicated dynamics of Lord Galtorah's family. How Prince Zelphar came to be.

llitrain - Currently Alive - Branching:
* Forder returns back to Alluin this session, they have a chance to hunt down and eliminate illitrain and other
remaining Drow forces. Good outcome
+ Iforder does not, these forces will escape and seek revenge at some later time. Negative outcome
© ilitrain is enough to still cause the modern age upheaval of Borrend -> Doom Cannon firing.

Knucklestep Shappin - Currently Alive - Branching

Kaetus mentioned the potential for interfering with the Doom Cannon's initial construction,
‘What on Earth would that do?
Borrend in its current state is closed off and xenphobic. The initial Circle of Stone Druids are led by the evil
Knuclestepp Shappin. They wish to build an unstoppable weapon to secure Borrend's independent status and
collect tribute from the tall, arogant elves of Alluin.

* If they go for this, we'll need a proper dungeon. Need some prep time

* Honestly though, order should be above level for this fight. They are from the future, with magical items collected
from throughout the cosmos. It would be innapropriate if the 3rd era Borrend army could stand toe to toe.

* Knucklestep was an evil, powerful druid. His potent soul lasted long into the future. So this unit is ok to be a boss.
He is not afraid of using the toxic chemical gas to kill people.

This pure chaos if the party interferes.

Upon returning to the real world, we need to calculate everything that has gone differently.

Bonus potential content:

Astral plane schenanagains

3 rooms to clear:

Gap - large gap exists between these islands. How to get across?
Craters - Random mobs

Islands - Random Mobs?

#### ChatGPT Output:
'''So I haven't really known what to do here. The party just defeated the big bad in the past, and skipped all of the Tower
of Bithyra. We need to figure out the consequences of the timeline.

First and most pressing - Lord Galtorah is currently dying within the Mirror of Prophecy. He is poisoned by the second
effect of Zelphar's poison, and his MAX HP is now down to 12. He will die in moments if not treated. Galtorah was not
really present for the rest of the timeline up to the present, so if he survives, this is a major departure.

Galtorah Branching:
* Dies in Mirror - Negative outcome. Removes the haunted specter from Galtorah's Bracers on Kaetus
* Dies in World - Neutral outcome. Will enchant his bracer with his essence right before passing, thereby granting
continuing with Kaetus
= Survives in Mirror - Chaotic outcome. Will need to see how this comes about.
= Survives in World - Good outcome, but not without changes. Galotrah's leadership will echo through the ages,
improving life in the kingdom. However, it will come at other costs [tbd]
© This will largely prevent the Orc invasion from going as badly.
© Because the Orc invasion was contained, the Kingdom is more prepared to fight Kaladan's Dragon Uprising
© Kaladan still comes out on top, and a bloody civil war ensues
© Critically, in this timeline, Esepha the Enchanted does not have the Aether Flame stolen by Aiden. He is alive
and fully intact. [sure about this?]

Princess Gwen - Survived. Branching:
* will try to romance Kaetus for everything he and the order have done
© ->if successful, chaotic outcome. Does Kaetus stay behind and live his life out with a Princess in the 3rd age?
© Does he bang her and run? -> Potential pregnancy, he might father a future ruler of the kingdom
+ Will reveal, if asked, the complicated dynamics of Lord Galtorah's family. How Prince Zelphar came to be.

Ilitrain - Currently Alive - Branching:
* Forder returns back to Alluin this session, they have a chance to hunt down and eliminate Ilitrain and other
remaining Drow forces. Good outcome
+ If Forder does not, these forces will escape and seek revenge at some later time. Negative outcome
© Ilitrain is enough to still cause the modern age upheaval of Borrend -> Doom Cannon firing.

Knucklestep Shappin - Currently Alive - Branching

Kaetus mentioned the potential for interfering with the Doom Cannon's initial construction,
‘What on Earth would that do?
Borrend in its current state is closed off and xenophobic. The initial Circle of Stone Druids are led by the evil
Knucklestep Shappin. They wish to build an unstoppable weapon to secure Borrend's independent status and
collect tribute from the tall, arrogant elves of Alluin.

* If they go for this, we'll need a proper dungeon. Need some prep time

* Honestly though, order should be above level for this fight. They are from the future, with magical items collected
from throughout the cosmos. It would be inappropriate if the 3rd era Borrend army could stand toe to toe.

* Knucklestep was an evil, powerful druid. His potent soul lasted long into the future. So this unit is ok to be a boss.
He is not afraid of using the toxic chemical gas to kill people.

This pure chaos if the party interferes.

Upon returning to the real world, we need to calculate everything that has gone differently.

Bonus potential content:

Astral plane shenanigans

3 rooms to clear:

Gap - large gap exists between these islands. How to get across?
Craters - Random mobs

Islands - Random Mobs?'''

# Session 29 - Moving a Mirror (again)

    **Created:** 2021-11-04 18:37:14  
    **Last Edited:** 2024-11-14 17:29:30  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

The party is likely to continue to mess around in the third age. They want to prevent the Borend disaster from ever ocuring. To accomplish this, they'll need to stop the insane Knucklestepp Shappin from completing his ultimate weapon.

At this point in time, KS is in full control of Borend. Their people are xenophobic and distrust the high elves of Alluin. Their druids likely won't be too much of a challenge for the party, but they have powerful elementals to bring to bear as well.

Gameplay Notes 11/4/2021


Much of the game today focused on how to secure the mirror and where to take it. Lord Galtorah offered to teleport everyone to Alluin Keep. Ila the Handsome offered to take everyone 'somewhere less drab'. Galtorah summoned his other Djini to help protect the mirror - only to discover that Princess Gwen had modified their contract and they would only work through the end of the day.

Kipla also brough forth Istantar - an incredibly hot drow demon. This caused a lot of drama with Gandus and Galtorah, who did their parts to try to dispatch the demon immediatley. Kipla saw the problem and withdrew the demon back to its ring. But its influence remains, whispering to Kipla.

Valzumin's Stronghold and Tinethra's Manor were both discussed. However at the end, the party decided to take Galtorah's offer to teleport to his hidden teleportation circle within Alluin keep.

Zephyr used his Robe of Eyes to check out the area ahead. They saw 3 drow, in positions designed to guard against the entrance to the room. 


----

Gameplay Notes 11/4


Much of the game today focused on how to secure the mirror and where to take it. Lord Galtorah offered to teleport everyone to Alluin Keep. Ila the Handsome offered to take everyone 'somewhere less drab'. Galtorah summoned his other Djini to help protect the mirror - only to discover that Princess Gwen had modified their contract and they would only work through the end of the day.

Kipla also brough forth Istantar - an incredibly hot drow demon. This caused a lot of drama with Gandus and Galtorah, who did their parts to try to dispatch the demon immediatley. Kipla saw the problem and withdrew the demon back to its ring. But its influence remains, whispering to Kipla.

Valzumin's Stronghold and Tinethra's Manor were both discussed. However at the end, the party decided to take Galtorah's offer to teleport to his hidden teleportation circle within Alluin keep.

Zephyr used his Robe of Eyes to check out the area ahead. They saw 3 drow, in positions designed to guard against the entrance to the room. 

This chamber is hidden, and gave the party time to prepare. Kaetus decided to use Disguide Self, becoming one Prince Zelphar. Ila the Handsome used greater image on Kaetus, transforming his gear and equipment to that of Zelphar's.

Ghiza the Dreamy used Greater Image on Ureausa, transforming her clothing into rags and chains. She will be 'Zelphars prisoner'.

'Zelphar', escorting his 'prisoner', walked boldly into the Drow war party that has occupied the throne room. There, he convinced the drow to gather round as he was about to tell them a story of victory over his enemies...




This chamber is hidden, and gave the party time to prepare. Kaetus decided to use Disguide Self, becoming one Prince Zelphar. Ila the Handsome used greater image on Kaetus, transforming his gear and equipment to that of Zelphar's.

Ghiza the Dreamy used Greater Image on Ureausa, transforming her clothing into rags and chains. She will be 'Zelphars prisoner'.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
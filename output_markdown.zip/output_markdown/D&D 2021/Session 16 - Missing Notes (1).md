# Session 16 - Missing Notes (1)

    **Created:** 2021-10-29 11:40:48  
    **Last Edited:** 2024-11-14 17:53:43  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Ilsis - Naga Spirit staff of the Adder


Do many portals open here?
How Far are we from alluin?
What year and season is it?

Game Notes 5/5/21

knucklestep sheppin is alive and currently building the doom cannon
The town of Galtorah does not yet exist
The western settlements do not yet exist
El Enna is tiny and not yet a bustling city
Valzumin's Keep is still there
Alluin has a dome of force around the city


Ureausa reconected with her God


Smithy - Sean MacBride
	Ordered horsehoes - 300g worth
	
Bartender - Maison Sanders
Sir Dorc - slain many beasts
Madam Uraeusa - 



The Cunning Potato - human slums tavern
Front for the fledging thieves guild

Party has had a long rest
Will pick up on the next morning at the Cunning Potato

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
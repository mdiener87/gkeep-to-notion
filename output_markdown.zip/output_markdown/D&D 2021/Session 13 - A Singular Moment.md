# Session 13 - A Singular Moment

    **Created:** 2021-10-29 11:40:16  
    **Last Edited:** 2024-11-14 17:57:01  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Bonus Round Adventure:

Play this similarly to the Galtorah maze section.
Leaving a tile square rolls randomly the next square.
Players must reach the end again to leave by stepping through the portal

Zones:
Vigil (large tower):
	Trading outpost by [race]
	Notable Charachters:
		Githyanki Pirate Yerreg  [armors]
		Lavar, Fire Myrmidon (Free Agent) [forges and enhances weapons]
		Cloaker Mozran (top of tower, mysterious moans in abandoned room)(high stealth check, might result in combat [willing to trade magical items]

Solitude (Astral Tavern):
	[shady charachters of varying humanoid races]
		[one will try to pick pocket the charachters]
		[a shady one will leave immediatley. It is alerting the dragons to the players, who may ambush when they leave]
	Gamposhteras Crisvys black female dragonborn (evil)[barkeep] [sells astral food with positive or negative effects]
	
		
		
Statue (large statue)
	[Deathlock master mind + additional mobs]
	[probably combat but might be able to find way to rest his soul]
		>>his party lost their souls in battle with a lich ages ago


Ruins (sprawling ruins with two smaller towers)
	[feuding demons vs devils]
	Demon leader - Beg'thinnauth
	Devil leader - Bur'ginaal
	players could unite them, or pick one side to fight, or fight both sides if they choose

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
This is a bit of a filler episode. The party found themsleves in the astral plane. Two portals were immediatley visible -
one, back towards Valzumin's Keep. The other, towards a 3rd age alluin.

‘The party first came across Demons and Devils in a shouting match. They seemed to be arguing over some treasure that
both sides desired. Zephyr's attempts to settle things with a game of beach volleyball were unproductive. Kaetus,
growing frustrated with the negotations, stepped in with Reverse Gravity. Almost all of the targets were thrown
upwards, off into space, blasting off into the infinite multiverse. Despite perception checks, they could not be seen
again.

‘The ‘treasure! they fought over was Kaetus own body. His Dragonscale armor was still (mostly) in tact, but he had not
the heart to loot himself. Kipla declined as well, finding nothing particularly shiny on his body.

‘The ruins around the area seemed to distorted elven statues of some kind. The remains of the city of Alluin could just
barely be made out.

‘The party ventured futther, reaching Tranquility Tower. Here, they met three traders - Yerreg, the Gith Pirate. Lavar, a
(free ageint) fire elemental myrmidon. And finaly Mozran, a cloaker aberation.

‘The party traded for new armors with Yerreg. Improved weapons from Lavar. And nothing much came from Mozran,
who desired gold and/or blood for a magical ring he kept in his mouth. He seemed to know and fear Gandus, whom.

Mozran thought was already decesased.

Next time - get the loot, and either further adventures in the Astral plane or hit the main storyline once again!

#### ChatGPT Output:
This is a bit of a filler episode. The party found themselves in the astral plane. Two portals were immediately visible - 
one, back towards Valzumin's Keep. The other, towards a 3rd age alluin.

‘The party first came across Demons and Devils in a shouting match. They seemed to be arguing over some treasure that 
both sides desired. Zephyr's attempts to settle things with a game of beach volleyball were unproductive. Kaetus, 
growing frustrated with the negotiations, stepped in with Reverse Gravity. Almost all of the targets were thrown 
upwards, off into space, blasting off into the infinite multiverse. Despite perception checks, they could not be seen 
again.

‘The ‘treasure’ they fought over was Kaetus' own body. His Dragonscale armor was still (mostly) intact, but he had not 
the heart to loot himself. Kipla declined as well, finding nothing particularly shiny on his body.

‘The ruins around the area seemed to distorted elven statues of some kind. The remains of the city of Alluin could just 
barely be made out.

‘The party ventured further, reaching Tranquility Tower. Here, they met three traders - Yerreg, the Gith Pirate. Lavar, a 
(free agent) fire elemental myrmidon. And finally Mozran, a cloaker aberration.

‘The party traded for new armors with Yerreg. Improved weapons from Lavar. And nothing much came from Mozran, 
who desired gold and/or blood for a magical ring he kept in his mouth. He seemed to know and fear Gandus, whom 
Mozran thought was already deceased.

Next time - get the loot, and either further adventures in the Astral plane or hit the main storyline once again!

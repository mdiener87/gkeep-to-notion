# Session 23 - Maze of Whispers (2)

    **Created:** 2021-10-29 11:42:17  
    **Last Edited:** 2024-11-14 17:39:04  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

8/26/21 gameplay Results:

Party continued to investigate the mirror of whispers. Where on the prior session the party destroyed the mirrors with force or Dispell Magic. This time, with Zephyr's assistance on some arcane rolls, they decided to instead try to use the mirrors. This had the result of randomly teleporting the user (and any others who joined hands) to another mirror within the maze. 

The first activation sent them 'backwards' through the maze, winding up in a small room full of spiders! Zephyr and Dorc quickly dispatched them before anything could happen.

Eventually the party teleported down to the SE corner of the map. There they found a large room with a giant skeleton on a table at the back of it. Gandus wasn't going to take any chances, and launched a salvo of eldritch blasts at the skeleton. It turned out to be an undead skeleton, and his attack inflicted damage and awoke it from its slumber!

The skeleton was a large chimera of some kind. It has Drow, Yuan-Ti, and minotour features. As the skeleton stood up, a host of spiders streamed out of its chest cavity!

Princess Gwen wasn't having any of this spider nonesenese. She unleashed a fireball that hit all the enemies. Her damage was high enough to vaporize the spiders regardless of their DEX check. The Skeleton Chimera saved. It had surprising speed and agility for an undead construct.

The Skeleton returned fire with its own large poison blast, hitting the party and inflicting damage. However, everyone was able to make the save.

The fight came into melee range. The giant skeleton got off one more attack, hitting for some damage to Dorc and critting Zephyr before falling to Gandus' attack.


Investigating the Skeleton found:
shadowfell brand tattoo (knowledge on design pattern)
Ring of Animal Influence
Do'sek's Skeletal Head 
	(Drow magic still eminates from this large head. With a mixture of Drow, Yuan-Ti, and minitour features, it is clearly that of an experimental chimera.)


--

Teleporting again, the party entered a new hallway. However, many party members fell asleep to the sleep enchantment after using the mirror. Two drow members came across the party, and one escaped through the mirror while the other set up an ambush. It didn't end well for that dude. Activating the mirror teleported them into a nearby dead-end of a hallway.

Growing tired of the maze, Gandus and Dorc teamed up with the power of friendship to koolaid main their way through a nearby wall. They smashed through it, revealing a drow library or workshop of some kind. Drow and Spiders launched their attack, but stood no real chance against the party and were soon dispatched.

This room is not yet looted (potions and spell scrolls). A good investigate check will reveal a ring of mirror control that allows for precise use of the mirrors. 

items:

On tables:


healing potions x2
potion of climbing
potion of greater healing x1

spell scroll first level x2
	Cure Wounds
	Unseen Servant
	
Spell Scroll second level x1
	Arcane Lock
	
Spell Scroll 5th Level
	Contagion

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The Party is advancing towards the final confrontation against the evil Prince Zelphar. But first, they must reach him. He
lies beyond the Maze of Whisper:

Refer to last session notes for maze details.

After maze are trapped, but otherwise empty hallways. Chances to roll to investigate the roams. Can find loot / spiders /
traps / dead bodies

Beyond these hallways lies the volcanic entrance that obscures the Keep's Sanctum. Retrievers will attempt to kidnap
the princess at this juncture. Meanwhile, a re-tasked pair of genies block the way: Djini (Ghizza the Dreamy) and a Marid
(lasille the Lucky).

Final confrontation beyond the mirror:

Idea 1:

Prince Zelphar introduces the Order of the Eclipse - a sort of evil-version of the party that has come back to prevent the
Princes' murder by the Ordre of Sun and Moon! They are convinced of the Prince and have gone to great lengths to
return to the past to save their future! Zelphr will take the opportunity to exist stage left (teleporter? Or the mirror
itself?) while the two parties battle it out!

Idea 2:
Future Zelphar follows the party back and confronts them after 3rd Age Zelphar dies.

Session Result:

8/26 gameplay Results:

Party continued to investigate the mirror of whispers. Where on the prior session the party destroyed the
mirrors with force or Dispell Magic. This time, with Zephyr's assistance on some arcane rolls, they decided to
instead try to use the mirrors. This had the result of randomly teleporting the user (and any others who joined
hands) to another mirror within the maze.

The first activation sent them ‘backwards’ through the maze, winding up in a small room full of spiders! Zephyr
and Dorc quickly dispatched them before anything could happen

Eventually the party teleported down to the SE comer of the map. There they found a large room with a giant
skeleton on a table at the back of it. Gandus wasn't going to take any chances, and launched a salvo of
eldritch blasts at the skeleton. It turned out to be an undead skeleton, and his attack inflicted damage and
awoke it from its slumber!

The skeleton was a large chimera of some kind. It has Drow, Yuan-Ti, and minotour features. As the skeleton
stood up, a host of spiders streamed aut of its chest cavity!

Princess Gwen wasr't having any of this spider nonesenese. She unleashed a fireball that hit all the enemies.
Her damage was high enough to vaporize the spiders regardless of their DEX check. The Skeleton Chimera
saved. Ithad surprising speed and agility for an undead construct.

The Skeleton returned fire with its own large poison blast, hitting the party and inflicting damage. However,
everyone was able to make the save.

The fight came into melee range. The giant skeleton got off one more attack, hitting for same damage to Dore
and critting Zephyr before falling to Gandus' attack.

Investigating the Skeleton found:
shadow/ell brand tattoo (knowledge on design pattern)
Ring of Animal Influence
Do'sek’s Skeletal Head
(Drow magic still eminates from this large head. With a mixture of Drow, Yuan-Ti, and minitour features,
itis clearly that of an experimental chimera.)

Teleporting again, the party entered a new hallway. However, many party members fell asleep to the sleep
enchantment after using the mirror. Two drow members came across the party, and one escaped through the
mirror while the other set up an ambush. It didn't end well for that dude. Activating the mirror teleported them
into a nearby dead-end of a hallway.

Growing tired of the maze, Gandus and Dorc teamed up with the power af friendship to koolaid main their way
through a nearby wall. They smashed through it, revealing a drow library or workshop of some kind. Drow and
Spiders launched their attack, but stood no real chance against the party and were soon dispatched.

This room is not yet looted (potions and spell scrolls). A good investigate check will reveal a ring of mirror
control that allows for precise use of the mirrors.

#### ChatGPT Output:
‘The Party is advancing towards the final confrontation against the evil Prince Zelphar. But first, they must reach him. He
lies beyond the Maze of Whisper:

Refer to last session notes for maze details.

After maze are trapped, but otherwise empty hallways. Chances to roll to investigate the rooms. Can find loot / spiders /
traps / dead bodies

Beyond these hallways lies the volcanic entrance that obscures the Keep's Sanctum. Retrievers will attempt to kidnap
the princess at this juncture. Meanwhile, a re-tasked pair of genies block the way: Djini (Ghizza the Dreamy) and a Marid
(Iasille the Lucky).

Final confrontation beyond the mirror:

Idea 1:

Prince Zelphar introduces the Order of the Eclipse - a sort of evil-version of the party that has come back to prevent the
Princes' murder by the Order of Sun and Moon! They are convinced of the Prince and have gone to great lengths to
return to the past to save their future! Zelphar will take the opportunity to exit stage left (teleporter? Or the mirror
itself?) while the two parties battle it out!

Idea 2:
Future Zelphar follows the party back and confronts them after 3rd Age Zelphar dies.

Session Result:

8/26 gameplay Results:

Party continued to investigate the mirror of whispers. Where on the prior session the party destroyed the
mirrors with force or Dispel Magic. This time, with Zephyr's assistance on some arcane rolls, they decided to
instead try to use the mirrors. This had the result of randomly teleporting the user (and any others who joined
hands) to another mirror within the maze.

The first activation sent them ‘backwards’ through the maze, winding up in a small room full of spiders! Zephyr
and Dorc quickly dispatched them before anything could happen

Eventually the party teleported down to the SE corner of the map. There they found a large room with a giant
skeleton on a table at the back of it. Gandus wasn't going to take any chances, and launched a salvo of
eldritch blasts at the skeleton. It turned out to be an undead skeleton, and his attack inflicted damage and
awoke it from its slumber!

The skeleton was a large chimera of some kind. It has Drow, Yuan-Ti, and minotaur features. As the skeleton
stood up, a host of spiders streamed out of its chest cavity!

Princess Gwen wasn't having any of this spider nonsense. She unleashed a fireball that hit all the enemies.
Her damage was high enough to vaporize the spiders regardless of their DEX check. The Skeleton Chimera
saved. It had surprising speed and agility for an undead construct.

The Skeleton returned fire with its own large poison blast, hitting the party and inflicting damage. However,
everyone was able to make the save.

The fight came into melee range. The giant skeleton got off one more attack, hitting for same damage to Dorc
and critting Zephyr before falling to Gandus' attack.

Investigating the Skeleton found:
- shadow/elf brand tattoo (knowledge on design pattern)
- Ring of Animal Influence
- Do'sek’s Skeletal Head
  (Drow magic still emanates from this large head. With a mixture of Drow, Yuan-Ti, and minotaur features,
  it is clearly that of an experimental chimera.)

Teleporting again, the party entered a new hallway. However, many party members fell asleep to the sleep
enchantment after using the mirror. Two drow members came across the party, and one escaped through the
mirror while the other set up an ambush. It didn't end well for that dude. Activating the mirror teleported them
into a nearby dead-end of a hallway.

Growing tired of the maze, Gandus and Dorc teamed up with the power of friendship to koolaid man their way
through a nearby wall. They smashed through it, revealing a drow library or workshop of some kind. Drow and
Spiders launched their attack, but stood no real chance against the party and were soon dispatched.

This room is not yet looted (potions and spell scrolls). A good investigate check will reveal a ring of mirror
control that allows for precise use of the mirrors.

# Session 5 - Galtorah's Maze

    **Created:** 2021-10-29 11:38:29  
    **Last Edited:** 2024-11-14 17:59:54  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Not sure where these are from, somewhere in here:

Galtorah's Travel Diary
Astral Plane Mechanics, non-condensed version
Out of This Places to Get a Drink
A Short History of Mindflayers

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
Illtrain has learned far too much about the Order's plans. The Drow now know the location of the Mirror of Prophecy. It,
along with Galtorah's Keep, were thought lost for centuries. Now, the Drow must make their move. But it's not quite
that simple...

Gk has multiple defense mechanisms. In the event the entire keep is unoccupied for over a day, it protects itself with a
forest labyrinth. Drow are presently lost in this maze. The maze is also guarded by powerful Elementals, Sword Wraiths,
and [third encounter type]. The Party tried to protect the keep with just such a maze themselves. Galtorah took things to
a while new level.

Need:
Forest map templates

Escaping the maze requires a succesful navigation check when exiting. You need 3 successes amongst 5 attempts to exit.
Failure will cause you to exit the maze where you entered.

Encounter types:

Drow Assasination
Drow Retriver squad
Minotaur Pack
Elemental Swarm,
Sword Wraiths
Constructs ftypes:]

Result:

Really good session. The party used Transport Via Plants to teleport directly to Galtorah's Keep. Kaetus encountered
unexpected turbulence, but an Arcane check kept his spell on target. When the player's materialized, they found
themselves in a bright, beautiful forest. One unlike they'd ever been on their travels.

‘They started exploring the environment and discerning the rules. Gandus swung his sword at rocks and checked for
disturbances in their shape. Zephyr used the Robe of Eyes to scan the ethereal plane (finding that there is no
corresponding location}, and determined there is a maximum flight ceiling. Ureausa banished Dore, who popped back
into existence in the town of Galtorah. Before the minute was up, she ended the spell, returning him to their (enchanted
demiplane) and confirming that they are somewhere near the material realm, but not quite at home.

Kaetus tried to channel Lord Galtorah, who indicated (through static) that they are already at his keep. Kipla summoned
Hla, and had him escort her through the forest. Zephyr used his Robe of Eyes to discern the forest paths, and determined
that heading south seemed more appropriate than East (1/3 map cleared).

‘The party ventured South. There, they found a party of Drown, waiting in Ambush. la was sent up to eradicate Drow,
but was hit by a poisoned bolt and prompty fell asleep!

‘The party scrambled up the embarkment and a battle broke out. The Drow Priestes used Insect Swarm, and the Drow
Mage turned an elite warrior invsibile. They really never stood a chance against the order. Dore struck the priestess 3
times, the first two attacks were critical hits. Ureasua Bonked the formerly invisible warrior to death with a critical blow
from the spiritual weapon. Gandus' Frightening Smite and the Blade of Magic cut the Drow mage down. Kipla woke la
up, and having gotten some beauty sleep, went into a rage. He struck the drow thrice, the third attack a critical hit. He
left the drow in a small crater.

‘The party looted some gold from the Drow, but they didn't have much on them. lla used Creation and re-formed orders
from llitran on the Drow Priestess. They instructed the Drow to find the Mirror of Prophecy and return it to the Tower of

Bithyra at any cost, and kill all they encountered in the vicinity of the keep.

‘The party now decides which direction to head next... On the next session of D&D!

#### ChatGPT Output:
Illtrain has learned far too much about the Order's plans. The Drow now know the location of the Mirror of Prophecy. It,
along with Galtorah's Keep, were thought lost for centuries. Now, the Drow must make their move. But it's not quite
that simple...

Galtorah's Keep has multiple defense mechanisms. In the event the entire keep is unoccupied for over a day, it protects itself with a
forest labyrinth. Drow are presently lost in this maze. The maze is also guarded by powerful Elementals, Sword Wraiths,
and [third encounter type]. The Party tried to protect the keep with just such a maze themselves. Galtorah took things to
a whole new level.

**Need:**
- Forest map templates

Escaping the maze requires a successful navigation check when exiting. You need 3 successes among 5 attempts to exit.
Failure will cause you to exit the maze where you entered.

**Encounter types:**
- Drow Assassination
- Drow Retriever squad
- Minotaur Pack
- Elemental Swarm
- Sword Wraiths
- Constructs [types:]

**Result:**

Really good session. The party used Transport Via Plants to teleport directly to Galtorah's Keep. Kaetus encountered
unexpected turbulence, but an Arcane check kept his spell on target. When the players materialized, they found
themselves in a bright, beautiful forest. One unlike they'd ever been on their travels.

They started exploring the environment and discerning the rules. Gandus swung his sword at rocks and checked for
disturbances in their shape. Zephyr used the Robe of Eyes to scan the ethereal plane (finding that there is no
corresponding location), and determined there is a maximum flight ceiling. Ureausa banished Dore, who popped back
into existence in the town of Galtorah. Before the minute was up, she ended the spell, returning him to their (enchanted
demiplane) and confirming that they are somewhere near the material realm, but not quite at home.

Kaetus tried to channel Lord Galtorah, who indicated (through static) that they are already at his keep. Kipla summoned
Hla, and had him escort her through the forest. Zephyr used his Robe of Eyes to discern the forest paths, and determined
that heading south seemed more appropriate than East (1/3 map cleared).

The party ventured South. There, they found a party of Drow, waiting in Ambush. Hla was sent up to eradicate Drow,
but was hit by a poisoned bolt and promptly fell asleep!

The party scrambled up the embankment and a battle broke out. The Drow Priestess used Insect Swarm, and the Drow
Mage turned an elite warrior invisible. They really never stood a chance against the order. Dore struck the priestess 3
times, the first two attacks were critical hits. Ureausa Bonked the formerly invisible warrior to death with a critical blow
from the spiritual weapon. Gandus' Frightening Smite and the Blade of Magic cut the Drow mage down. Kipla woke Hla
up, and having gotten some beauty sleep, went into a rage. He struck the drow thrice, the third attack a critical hit. He
left the drow in a small crater.

The party looted some gold from the Drow, but they didn't have much on them. Hla used Creation and re-formed orders
from Illtrain on the Drow Priestess. They instructed the Drow to find the Mirror of Prophecy and return it to the Tower of
Bithyra at any cost, and kill all they encountered in the vicinity of the keep.

The party now decides which direction to head next... On the next session of D&D!

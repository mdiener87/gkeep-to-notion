# Session 7 - The Way Out

    **Created:** 2021-10-29 11:38:49  
    **Last Edited:** 2021-10-29 11:38:57  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Skipped last week to work on Novelis. So let's make this a fun session.

‘The party is approaching the end of the maze. They have found six small silver keys from the mimic chests in the
previous room. This maze needs a satisfactory conclusion, and then a return to the ‘real! world.

Final enconter: corrupted unicorn. tt guards the gate out, and has gone insane from looking into the mirror and
encountering the Sibriex Demon.

Stats: AS per Black Unicorn

Every time this enemy is defeated, it's corpse spawns two new unicorns at the end of the round. This counts as a 6th
level spell effect and can be countered or dispelled, If the evil within a clone can be purged, that clone will disappear.

‘The gate has 6 key slots. It takes an arcane or sleight of hand check, de 18, to insert and activate a key. All 6 must be
inserted and activated before the gate will open. The corrupted unicorn cannot follow through the gate.

‘Once through the gate, they will be back in Galtorah's inner keep zone.

(OgLoxon - Sibriex

Result:

Kaetus sensed magic coming from the depths of the icy lake. Gandus sensed a powerful evil aura radiating from the
same locaiton. Dorc threw his unidentified ring into the lake, and an Ice Devil emerged. Long story short, they got into’a
strength performance standoff. Dorc won. The Ice demon sunk down into the ice. Kaetus turned into a water elemental,
and made a survival check to keep Dorc and Zephyr alive within his bubble, He descended.. And Dorc proceeded to have
sex with the Ice demon. Within him. It was awkward, And lasted 4 hours.

Dore received an unidentified Ice Shard afterword. It appears to have properties of an loun Stone.

‘The Next Zone contained a corrupted Unicom. It was easily enough dispatched... until its deceased body cloned itself
and came back double, And then each deceased clone came back double again. It quickly became a problem.

‘The party was having problems inserting the keys, which required an arcane check. Ureasua cast Tiny Hut, as a 7th level
spell, which | allowed her to cast instantly as a result. With less stress, they were able to take the time to insert the keys
and open the door. All the while the corrupted unicorn was multiplying, again and again, outside the force barrier. With
the gate opened, they stepped through. Ureasua made an incredible sleigh of hand check as she stepped through, and
grabbed a key and took it with her. Slamming the portal shut behind her and succesfully stepping through.

‘The party landed in the innermost sanctum of Galtorah’s Keep. An obvious ambience of evil pervaded from the next
room. A powerful demon lay lurking. Zephyr, Dork, and Gandus went through the mirror portal into the rest of the keep.
‘They encountered rutterkins, which they easily dispatched. Those 3 decided to take a short rest in the inner sanctum,
while the spell casters took a long rest outside. What is the effect of this... Next time on D&D!

#### ChatGPT Output:
‘Skipped last week to work on Novelis. So let's make this a fun session.

‘The party is approaching the end of the maze. They have found six small silver keys from the mimic chests in the
previous room. This maze needs a satisfactory conclusion, and then a return to the ‘real’ world.

Final encounter: corrupted unicorn. It guards the gate out and has gone insane from looking into the mirror and
encountering the Sibriex Demon.

Stats: As per Black Unicorn

Every time this enemy is defeated, its corpse spawns two new unicorns at the end of the round. This counts as a 6th
level spell effect and can be countered or dispelled. If the evil within a clone can be purged, that clone will disappear.

‘The gate has 6 key slots. It takes an arcane or sleight of hand check, DC 18, to insert and activate a key. All 6 must be
inserted and activated before the gate will open. The corrupted unicorn cannot follow through the gate.

‘Once through the gate, they will be back in Galtorah's inner keep zone.

(OgLoxon - Sibriex

Result:

Kaetus sensed magic coming from the depths of the icy lake. Gandus sensed a powerful evil aura radiating from the
same location. Dorc threw his unidentified ring into the lake, and an Ice Devil emerged. Long story short, they got into
a strength performance standoff. Dorc won. The Ice demon sunk down into the ice. Kaetus turned into a water elemental,
and made a survival check to keep Dorc and Zephyr alive within his bubble. He descended... And Dorc proceeded to have
sex with the Ice demon. Within him. It was awkward. And lasted 4 hours.

Dorc received an unidentified Ice Shard afterward. It appears to have properties of an Ioun Stone.

‘The Next Zone contained a corrupted Unicorn. It was easily enough dispatched... until its deceased body cloned itself
and came back double. And then each deceased clone came back double again. It quickly became a problem.

‘The party was having problems inserting the keys, which required an arcane check. Ureasua cast Tiny Hut, as a 7th level
spell, which I allowed her to cast instantly as a result. With less stress, they were able to take the time to insert the keys
and open the door. All the while the corrupted unicorn was multiplying, again and again, outside the force barrier. With
the gate opened, they stepped through. Ureasua made an incredible sleight of hand check as she stepped through, and
grabbed a key and took it with her. Slamming the portal shut behind her and successfully stepping through.

‘The party landed in the innermost sanctum of Galtorah’s Keep. An obvious ambiance of evil pervaded from the next
room. A powerful demon lay lurking. Zephyr, Dork, and Gandus went through the mirror portal into the rest of the keep.
‘They encountered rutterkins, which they easily dispatched. Those 3 decided to take a short rest in the inner sanctum,
while the spell casters took a long rest outside. What is the effect of this... Next time on D&D!

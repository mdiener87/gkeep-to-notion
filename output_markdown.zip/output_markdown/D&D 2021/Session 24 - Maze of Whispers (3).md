# Session 24 - Maze of Whispers (3)

    **Created:** 2021-10-29 11:42:27  
    **Last Edited:** 2024-11-14 17:37:58  
    **Labels:** D&D 2021  

    ---

    ## Note Content (HTML)

Gameplay Notes: 9/2/21

The Ring of Whispers 

Princess Gwen has promised Kipla some form of Power in 3rd Age Alluin

Zephyr looted:
	5x Sleeping Aconite (a plant favored by the drow for its use in poisons)
	


---

Party begain by looting the library. Kipla promptly grabbed the ring of whispers, and gave up another magical item to attune to it. The ring seems to whisper tidings to her, and the full extent of its powers are unclear. Kipla got into an argument with herself as Ila the Handsome felt jealous at Kiplas attention to this new magical ring.

The ring helped lead the party through a mirror to a hallway with a treasure chest. While trapped, Kipla easily disabled the trap and locked and found 450g and a staff of insects inside. The staff is still unidentified.

Activating the mirrors agian, this time Kipla had the party arrive at the dead center of the maze. A drow party was here, and combat immediatley ensued. Kaetus went first and hit many of the enemy party with the Confusion spell. Zephyr stunned up the Inquisitor and Mage, preventing them from taking actions. The drow were dispatched easily enough, but not without losses - Skittles was once again killed in combat by a spider!

Distraught at the loss of her friend, Kipla turned to the whispering power of the drow ring. It infused Skittles with its power and brought him back to life! Skittles is now part fiend and may use magical items with profficencey.


During combat, Kipla unleashed a powerful bolt from Valzumin's Crossbow. It missed the Drow target, and instead blew a hole in a wall. Inside the small chamber were spiders. Many spiders.As they came pouring out towards the party, Gandus hit the mass with Shatter, killing 6 enemies at once in a Killamanjaro! 

The inquisior dropped  a Drow Shield of Shadows. THe mage droped gloves (thieves gloves) which are still unidentified.

Up next - how to escape this maze of whispers!?

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘This session is stll leading up to the Prince Zelphar fight. Party needs to find a way out of the Maze of Whispers to
advance to the next area,

Maze of whispers:

Room - unlooted (roll loot)
+

Ring of Whispers (cursed - yochlol demon [Istantar Begdruzod]) (attuned)
While wearing this ring, you gain the following benefits:
#1 onall Arcane, Stealth, Deception, and Sleight of Hand Checks. Things bonus is increased to +2 if you are in dim light or
darkness.
‘You may navigate Drow Shadow Mirrors
‘The ring has 3 Whisper charges, refreshed at midnight. You may expend a Whisper charge to cast one of the following
spells:
* Darkness
Detect Thoughts
Faerie Fire
Minor Illusion
Web

Skittles has been magically bound and brought back to life through the power of this ring.
Skittles is now type Beast, Fiend

Hallways:
* Trapped rooms
* spiders
* Random loot

Lava Chamber:
* a Djini (Ghizza the Dreamy) and a Marid (Iasille the Lucky)
* Door to the inner sancutm

Gameplay Notes: 9/2

The Ring of Whispers
Princess Gwen has promised Kipla some form of Power in 3rd Age Alluin to make up for concealing the truth
about Skittles’ first death.
From the center of the maze, Zephyr looted:
5x Sleeping Aconite (a plant favored by the drow for its use in sleep poisons)

Party began by looting the library. Kipla promptly grabbed the ring of whispers, and gave up another magical
item to attune to it. The ring seems to whisper tidings to her, and the full extent of its powers are unclear. Kipla
got into an argument with herself as lla the Handsome felt jealous at Kiplas attention to this new magical ring.

When Kaetus activated the mirror to try telpeorting to the next area, Kipla, using her new ring, helped lead the
party through a mirror to a hallway with a treasure chest. While the chest was trapped, Kipla easily disabled the
trap and lock. She found 450g and a staff of insects inside. The staff is still unidentified

Activating the mirrors again, this time Kipla had the party arrive at the dead center of the maze. A drow party
was here, and combat immediately ensued. Kaetus went first and hit many of the enemy party with the
Confusion spell. Zephyr stunned up the Inquisitor and Mage, preventing them from taking actions. The drow
were dispatched easily enough, but not without losses - Skittles was once again killed in combat by a spider!
Distraught at the loss of her friend, Kipla turned to the whispering power of the drow ring. It infused Skittles with
its power and brought him back to life! Skittles is now part fiend and may use magical items with proficiency.

During combat, Kipla unleashed a powerful bott fram Vaizumin's Crossbow. It missed the Drow target, and
instead blew a hole in a wall. Inside the small chamber were spiders. Many spiders As they came pouring out
towards the party, Gandus hit the mass with Shatter, killing 6 enemies at once in a Killamanjarol

The inquisitor drapped a Drow Shield of Shadows. The mage dropped gloves (thieves gloves) which are sfill
unidentified

Up next - how to escape this maze of whispers!?

#### ChatGPT Output:
‘This session is still leading up to the Prince Zelphar fight. Party needs to find a way out of the Maze of Whispers to
advance to the next area,

**Maze of Whispers:**

**Room** - unlooted (roll loot)

**Ring of Whispers** (cursed - yochlol demon [Istantar Begdruzod]) (attuned)
While wearing this ring, you gain the following benefits:
+1 on all Arcane, Stealth, Deception, and Sleight of Hand Checks. This bonus is increased to +2 if you are in dim light or
darkness.
You may navigate Drow Shadow Mirrors.
The ring has 3 Whisper charges, refreshed at midnight. You may expend a Whisper charge to cast one of the following spells:
- Darkness
- Detect Thoughts
- Faerie Fire
- Minor Illusion
- Web

Skittles has been magically bound and brought back to life through the power of this ring.
Skittles is now type: Beast, Fiend

**Hallways:**
- Trapped rooms
- Spiders
- Random loot

**Lava Chamber:**
- A Djini (Ghizza the Dreamy) and a Marid (Iasille the Lucky)
- Door to the inner sanctum

**Gameplay Notes: 9/2**

The Ring of Whispers:
Princess Gwen has promised Kipla some form of Power in 3rd Age Alluin to make up for concealing the truth about Skittles’ first death.
From the center of the maze, Zephyr looted:
5x Sleeping Aconite (a plant favored by the drow for its use in sleep poisons)

Party began by looting the library. Kipla promptly grabbed the ring of whispers, and gave up another magical item to attune to it. The ring seems to whisper tidings to her, and the full extent of its powers are unclear. Kipla got into an argument with herself as Ila the Handsome felt jealous at Kipla’s attention to this new magical ring.

When Kaetus activated the mirror to try teleporting to the next area, Kipla, using her new ring, helped lead the party through a mirror to a hallway with a treasure chest. While the chest was trapped, Kipla easily disabled the trap and lock. She found 450g and a staff of insects inside. The staff is still unidentified.

Activating the mirrors again, this time Kipla had the party arrive at the dead center of the maze. A drow party was here, and combat immediately ensued. Kaetus went first and hit many of the enemy party with the Confusion spell. Zephyr stunned the Inquisitor and Mage, preventing them from taking actions. The drow were dispatched easily enough, but not without losses - Skittles was once again killed in combat by a spider! Distraught at the loss of her friend, Kipla turned to the whispering power of the drow ring. It infused Skittles with its power and brought him back to life! Skittles is now part fiend and may use magical items with proficiency.

During combat, Kipla unleashed a powerful bolt from Vaizumin's Crossbow. It missed the Drow target, and instead blew a hole in a wall. Inside the small chamber were spiders. Many spiders. As they came pouring out towards the party, Gandus hit the mass with Shatter, killing 6 enemies at once in a Killamanjaro!

The inquisitor dropped a Drow Shield of Shadows. The mage dropped gloves (thieves gloves) which are still unidentified.

Up next - how to escape this maze of whispers!?

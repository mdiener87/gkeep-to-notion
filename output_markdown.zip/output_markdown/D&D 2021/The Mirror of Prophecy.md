# The Mirror of Prophecy

    **Created:** 2021-10-29 11:43:27  
    **Last Edited:** 2021-10-29 11:43:32  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Using the mirror: After a DC20 Arcane check, the mirror activates, The user may probe the mirror, scanning the cosmos
for threads of time that they wish to learn of. The Multiverse is composed of competing timelines and probabilities - the
mirror allows these probabilities to be reviewed, and even alter which world time line the user is presently at. Upon first
activation, the present time node is locked in as that user's reference return point.

To review a world timeline, roll a D100 + Arcane skill. The result is how ‘accurate’ the review of the specified time line is.
Note that all timelines revealed by the mirror are real - only their probabilistic distance to the user is up for question. If
reviewing events from other planes of existence, this roll is made at disadvantage.

To alter a world timeline, roll two checks of D100 + Arcane skill. The first result pertains to how closely the user arrives,
to the physical space specified (as per Teleport). The second dice result pertains to how closely in time the user arrives
to the temporal space specified. Note that the Mirror of Prophecy cannot be used to travel to any ather plane of
existence than the one it currently resides.

To return to your original time of reference (here, and now), make a DC20 Arcane check with an activated mirror.

‘We are going the Steins; Gate route of time travel.

Without the Order's realization, they have already affected the world line. By removing the Sibriex demon from the
mirror, they have changed the attractor field of the Mirror of Prophecy. In the Alpha timeline, Lord Galtorah went insane
from the mirror’s use. While it was assumed this was an inevitable side effect of time magic, it was really the result of
the Sibriex demon corrupting the mirror. Prince Zelphar originally entrapped the demon into the mirror, in what proved
to bea successful attempt to kill his father. What Zelphar did not account for was the depth of hatred the High elves of
Siraculum would hold for him. Rather than acknowledge Zelphar as Prince acedent, he was banished. The Monarchy was
transferred through marriage to the human Maryn family. Zelphar failed in his bid for power, and has waited for
hundreds of years for his revenge. His demonic patron, the Lolth, gave him unnaturally long life in the slow-moving
realm of the demonic planes.

At least, that's what occurred in the Alpha timeline.

‘The Beta timeline will be realized once the Order activates the mirror. It doesn't really matter where they try to go. The
attractor field is so far in the past, and af such an immense change, that the events they shift into will be dramatically
different than they had expected.

In the beta timeline, Zelphar's original attempt with the Sibriex now mysteriously fails. The Demon seems to die shortly
after its entrapment within the mirror. Zelphar is forced to more extreme measures. He directly murders his father, and
his half-sister, who would otherwise have married into the Moryn family (human). This act of brutality shocks the young
kingdom, and they reject Zelphar's rule, After a brutal civil war, the ruling high elves prevail, and kill Zelphar and his
drow consort.

‘The “Alluin Republic" is established. Lacking a strong and wise leader, it's federal government proves weak. While it
holds together through the various disasters, the recent events proved to be true calamity. Without a Shade of Galtorah
to unite the level 1 party members, the Order of Sun and Moon never convenes.

‘When the Orc invasion finally occurs, the result is truly devastating. Half of the kingdom falls under the control of the
Orcs, An uneasy cease-fire occurs following Kaladan's invasion. Again lacking the order, Kaladan successfully captures
Alluin. He is widening the rift between dimensions, hoping his mother might join him in this fertile, weak world.

More or less regardless of what exact time the party decides to travel to, these will be the ongoing events, due to the
powerful changes of the beta attractor field timeline.

How will the party restore the events to the alpha timeline? Or can they engineer a happier ending in the mythical
Gamma timeline?

#### ChatGPT Output:
Using the mirror:
After a DC20 Arcane check, the mirror activates. The user may probe the mirror, scanning the cosmos for threads of time that they wish to learn of. The Multiverse is composed of competing timelines and probabilities - the mirror allows these probabilities to be reviewed, and even alter which world timeline the user is presently at. Upon first activation, the present time node is locked in as that user's reference return point.

To review a world timeline, roll a D100 + Arcane skill. The result is how ‘accurate’ the review of the specified timeline is.
Note that all timelines revealed by the mirror are real - only their probabilistic distance to the user is up for question. If
reviewing events from other planes of existence, this roll is made at disadvantage.

To alter a world timeline, roll two checks of D100 + Arcane skill. The first result pertains to how closely the user arrives,
to the physical space specified (as per **Teleport**). The second dice result pertains to how closely in time the user arrives
to the temporal space specified. Note that the Mirror of Prophecy cannot be used to travel to any other plane of
existence than the one it currently resides.

To return to your original time of reference (here, and now), make a DC20 Arcane check with an activated mirror.

"We are going the Steins; Gate route of time travel."

Without the Order's realization, they have already affected the world line. By removing the Sibriex demon from the
mirror, they have changed the attractor field of the Mirror of Prophecy. In the Alpha timeline, Lord Galtorah went insane
from the mirror’s use. While it was assumed this was an inevitable side effect of time magic, it was really the result of
the Sibriex demon corrupting the mirror. Prince Zelphar originally entrapped the demon into the mirror, in what proved
to be a successful attempt to kill his father. What Zelphar did not account for was the depth of hatred the High elves of
Siraculum would hold for him. Rather than acknowledge Zelphar as Prince regent, he was banished. The Monarchy was
transferred through marriage to the human Maryn family. Zelphar failed in his bid for power, and has waited for
hundreds of years for his revenge. His demonic patron, the Lolth, gave him unnaturally long life in the slow-moving
realm of the demonic planes.

At least, that's what occurred in the Alpha timeline.

The Beta timeline will be realized once the Order activates the mirror. It doesn't really matter where they try to go. The
attractor field is so far in the past, and of such an immense change, that the events they shift into will be dramatically
different than they had expected.

In the beta timeline, Zelphar's original attempt with the Sibriex now mysteriously fails. The Demon seems to die shortly
after its entrapment within the mirror. Zelphar is forced to more extreme measures. He directly murders his father, and
his half-sister, who would otherwise have married into the Moryn family (human). This act of brutality shocks the young
kingdom, and they reject Zelphar's rule. After a brutal civil war, the ruling high elves prevail, and kill Zelphar and his
drow consort.

The “Alluin Republic" is established. Lacking a strong and wise leader, its federal government proves weak. While it
holds together through the various disasters, the recent events proved to be a true calamity. Without a Shade of Galtorah
to unite the level 1 party members, the Order of Sun and Moon never convenes.

When the Orc invasion finally occurs, the result is truly devastating. Half of the kingdom falls under the control of the
Orcs. An uneasy cease-fire occurs following Kaladan's invasion. Again lacking the order, Kaladan successfully captures
Alluin. He is widening the rift between dimensions, hoping his mother might join him in this fertile, weak world.

More or less regardless of what exact time the party decides to travel to, these will be the ongoing events, due to the
powerful changes of the beta attractor field timeline.

How will the party restore the events to the alpha timeline? Or can they engineer a happier ending in the mythical
Gamma timeline?

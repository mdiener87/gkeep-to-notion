# Session 13 - Secrets of the Upper Floors

    **Created:** 2023-04-06 20:27:40  
    **Last Edited:** 2023-04-20 20:49:26  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Players will finish the governors mansion dungeon today. On the second floor are not only more monsters, but they can find evidence of the cult's next plays. In short, they are converting the citizen cultists of the kingdom into terrifyingly powerful Abishai monsters. This capability was granted from the Heart of the Dragon, which the players can find evidence of in the upper levels.


===

Result:

Players fought their way through the hidden enemies lurking in the shadows of their perpetual darkness. Gandus used his blade an opposed spellcasting ability check to empower his blade's normal bright light to be of sufficient power to turn back the magical darkness before him. Kaetus eventually got tired of this Darkness and used Daylight again, this time targeting Dorc's helmet instead of a stationary point. This quickly burned away the remaining darkness and turned Dorc into a mobile lighthouse.

With the minions defeated, the party explored the mansion some and discovered a few healing potions in a raided supply cabinet. 
 
The gang then entered the Governor's room itself. Inside were 4 meregon soldiers and a more powerful Nalfeshnee. There meregon were quickly cut down, and the Nalf., sensing itself outnumbered, activated the teleportation circle and beamed out.

On the desk, Zephyr and Kaetus found research notes indicating the Cult was attempting to encode their own teleportation circle with a cultist-style VPN. Their notes were also researching how to teleport into deeper layers of reality, such as the Shadowfell and the Nine Hells.

Along with these research notes, lay a mysterious and powerful amulet known as the Shadow Sigil. What will the party do with it? Find out next time!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
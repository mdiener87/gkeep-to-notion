# Session 21 - The Moonfire Foundry

    **Created:** 2023-07-13 19:56:29  
    **Last Edited:** 2023-08-03 20:01:41  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Continuing the Elistraee Temple dungeon today. They are likely to get to the Moonfire Foundry and its two Genies

Female Efreeti:
Name: Zara, the Fierce
Personality: Zara is a formidable and proud Efreeti, known for her fiery temperament and unwavering determination. She exudes confidence and radiates power, often taking charge and asserting her dominance. Though her temper can be volatile, she is fiercely loyal to those she deems worthy and will go to great lengths to protect them.

Male Marid:
Name: Aris, the Serene
Personality: Aris is a calm and serene Marid, known for his composed demeanor and tranquil presence. He possesses a deep understanding of the ebb and flow of the elements, and his wisdom is highly regarded among his kind. Aris is a patient listener and a voice of reason, often mediating conflicts and seeking harmonious resolutions.

Remember, these are just suggestions, and you can customize the names and personalities to fit your world and campaign. Feel free to add more details and quirks to make these genies unique and memorable within your setting.


Other monsters:
Phase Spiders: Triple all their stats. If they bite, add a strong sleeping poision
DC 18 CON, failure -> Enchanted Sleep for up to 8 hours. Re-rolled once per hour.



========

Gameplay notes 7/13/23

Party decided to press on through the small, locked corridor rather than face off against the spiders. 
Zephyr investigated the helmed horrors' in the room, and found a key in a hidden compartment within one of their armored gauntlets
The key went to the lock in the corridor. It also had a magical component to it - looking for a matching magical signature. He channeled his energy through Zelphar's Edge, and the drow magic was seen as a friend. The door unlocked.

Through the narrow passageways they came to the Moonfire Foundry. This amazing creation, the work of Zara the Fierce (Efreeti) and Aris the Serene (Marid). They are bound to Enistraee, under contract to forge the perfect fusion of Drow and Elven energy. Enistraee has passed, but the magic of her contract remains. The two genies work tirelessly to fulfill their burden, but have so far not succeeded.

After learning about the power of the Moonfire Foundry, the party are intrigued at the potential for reforging and combining magical items. Dorc proposed offering his 'services' in exchange for a one-time side-hustle purchase of the Moonfire Foundry being used to fuse his two swords together. After some Dorc persuasion checks, the two genies accepted. The rest of the party left as quickly as possible as Dorc got to 'work'

The party is interested in the side-quest for Enistraee, and started searching around for a path to her temple. They returned to the original room, and decided to search along the far wall that had been skipped on their first arrival. Zephyr failed to spot the trap on the stairs, and triggered a similar poison needle trap that he had disabled on the other staircase! Zephyr was looking down the barrel at over 60 poison damage, plus a paralysis effect, when the party realized that Hero's Feast made them immune to poison for the duration. Zephyr stood up, brushed himself off, totally unaffected!

In the far bookshelf, Kaeuts found the following:

Kaeuts found a Bag of Holding (uncommon, dmg 153)
	Spell Scroll (Incendiary Cloud) (very rare, dmg 200)
	Dust of Disappearance (uncommon, dmg 166)
	Potion of Fire Breath (uncommon, dmg 187)

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 12 - Victory and Danger Alike

    **Created:** 2023-03-30 19:44:10  
    **Last Edited:** 2023-04-06 23:10:04  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Coming into the game, the party has vanquished the Blue Abishai Cobaltar Orexijandilin. This new opponent proved a difficult fight. Casting numerous spells from invisibility, Cobaltar was a hell of a fight!

Today's session will focus on loot, licking some wounds, taking stock of the situation. Further content for today includes:

An inbound teleport of cultists into Gildas held position.

Exploring the upper level of the mansion. This contains multiple black abishai, along with the potential for merrogon and otherworldly creatures from the Shadow Realm.  At the top of mansion lies a Shadow Sigil. This necklace allows access to the hidden, altered, and otherwise secured teleport network.


Blue Abishai Items:
Staff of Thunder and Lightning


To find in the mansion:

Shadow Sigil
* Allows access to the Shadow Cult Teleportation Circle Network. These teleportation circles are encrypted and only available to those bearing a Shadow Sigil
* Once per day, You may use the Shadow Sigil as a Shadow Marble for purposes of communication, as per the Sending spell.
* Once per long rest, you may expend a Spell Slot 5th level and make an Arcane Check to activate a teleportation Circle you can see within 30ft of you. This activation behaves as per the Teleport Spell. 

* You may optionally attune to this item. If you do, you may use the Twilight's Embrace ability once per long rest
* Twilights Embrace: This ability can only be activated in dim light or darkness and lasts for up to one hour. If you enter bright light, this bonus is lost until you return to the darkness. While you benefit from Twilight's Embrace, you gain +2 INT and +2 DEX



============


Gameplay notes:
Party looted the Blue Abishai Boss and then headed back to the main area. Gandus investigated the civilians and found a large amount of gold + jewelrey on them. They encountered two cultists eating in the dining room. They stood absolutley no chance.

The party then explored the left side of the map. A number of 'civilians' were there, waiting for their turn to ascend. The party judged them.. harshly. It was a massacre. However, one civilian escaped unnoticed an managed to escape the map.

OSM then headed upstairs. An oppressive blackness awaited them. Kaetus cast the Daylight spell, burning away the shadows along most of the main hallways they could see within LOS. It also exposed two monsters, which Gandus determined were fiendish in nature. The draconic looking one is clearly a hybrid dragon/demon, and this fact incensed Gandus. He hit it with everything he had, inflicting massive damage and vaporizing the monster on the spot.

Next time - further explorations of the mansion!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 23 - Errata and Etc 

    **Created:** 2023-08-10 20:03:36  
    **Last Edited:** 2023-10-12 19:40:51  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Continuing the Eilistraee temple tonight. Party may reach the mini-boss at the top of the temple, or maybe reach Eilistraee if they can break through a wall of force.

The arachnomancer is : Zoren Starweaver
He is the final pupil of Eilistraee. Despondent, he is the final leader of his dwindling people. He had hoped to continue to entreat the elves and drow to heal the ancient wounds and return to a harmonious reunion. However, the Drow under Illitran have rebuffed the cause and attempted to kill them on sight.

The Elven council was kinder, up to a point. They dedicated the mountain and its holy shrine Lunaris Peak to Eilistraee cause, calling it a nature preserve in public records. Not wanting to provoke further conflict between elf and drow, this act of generosity was quietly suppressed. Eilistraee's temple was sealed and accessible only to those who knew how to uncover its entrance. 

Now Zoren is lost, the last to know Eilistraee personally. He teters between nihilistic destruction, and dedicating his few remaining followers to joining the Drow or Elves and forsaking their heritage. 

Gameplay Notes 8/10/23

Party decided to get creative to escape from the dungeon they found themselves in. Using Kaetus' Control Water* spell, he redirected the flow of water through the large pipe that was coming through the room they found themselves exploring. The party explored through the tube, and then used a different mode of Control Water to siphon themselves up the pipe. Elyrss volunteered to go first, but was unable to make the skill check necessary to jump out of the vortex and into a side access chamber she discovered. She took several rounds of bludgeoning damage before Zephyr zoomed up to help her.

With the party all at the top, they crept through the tunnel they found themselves in. This side access chamber quickly came to the surface of ... somewhere. Daylight shone through the grates of the lid.

Emerging, they found themselves in a forest grove. A number of monuments were in a circle around the clearing. The largest of which, magiclaly enchanted against decay, was dedicated to Lady Elistrae. Dorc presented her namesake blade, and a hidden entrance deeper into the mountain appeared into the ground.

The party looked out across the island, and observed:
- the gith airships hold a tight defensive formation around the astral portal
- the mindrazor flying around the city in chaotic, low flying ways
- a dragon detection was used. A draconic ping was discovered coming from Tienethra's Manor

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
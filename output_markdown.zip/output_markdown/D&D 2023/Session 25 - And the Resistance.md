# Session 25 - And the Resistance

    **Created:** 2023-09-07 19:38:53  
    **Last Edited:** 2023-09-07 19:39:12  
    **Labels:**   

    ---
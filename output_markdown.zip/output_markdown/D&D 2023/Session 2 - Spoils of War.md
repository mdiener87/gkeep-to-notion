# Session 2 - Spoils of War

    **Created:** 2023-01-26 19:50:39  
    **Last Edited:** 2023-01-26 19:52:07  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Game session 1/12/23

Player Reserved Items:

Dorc: Demon Horden Adamantium Chainmail
Kaetus: Dragon Scale Mail (Shadow Blue)
Zephyr: Zelphar's Edge

Stolen Items:

Dorc: Belf of Fire Giant Strength 
Kaetus: Staff of Fire & Tome of Evil
Zephyr: Robe of Eyes 


Gameplay notes: 1/12/23

Gandus succesfully deceived Cardar into thinking the polymorph spell was a True(TM) polymorph and not some parlor trick. Cardar fell for it, and famished as he was, promptly took a bite out of the polymorph monstrosity/rabit. The creature instantly reverted into its true form. Cardar wanted none of it, and used his shadow step ability to teleport up the stairs and run.

The creature attacked quintus, who was able to use shield to succesfully block the incoming damage. He then used invisibility to escape the creature and run upstairs.

Gandus, dissapointed Cardar still lived, also used invisibility to ignore the monstrosity and escape the scene.

Quintus dropped his invisibility, and walked out alongside Cardar to present the Heart of the Dragon to Sethrikar. Gandus maintained his invisibility, instead choosing to watch. Cardar summoned Sethrikar with a Dragon Claw War Horn. Together, Quintus and Cardar presented the Heart of the Dragon to Sethrikar.

Quintus, however, held the Heart back. He asked Sethrikar for vengeance against the Gith in exchange. Seth asked him to reveal himself from beneath the cloak. Quintus did, revealing his powerful gear and his stature. Clearly a hero of some form, and not a mere cultist. Sethrikar was pleased. He asked for Quintus' devotion of loyalty. And quintus granted it. 

Sethrikar promoted Quintus to his personal attendant and champion. Taking the Heart of the Dragon, he declared great this in store for Quintus and to join him in his crusade to free the kingdom. To cardar, he granted Chipahua and its surrounding lands to govern as lord in Sethrikar's stead.

Sethrikar then picked up Quintus, alongside the heart, and flew off.

With the dragon's departure, Gandus then proceeded to execute Cardar. He rolled a nat 20 from charging while invisible, dealing 50 damage and instnatly killing Cardar before he even knew what hit him. Gandus claimed a potion of heroism and Cardar's unique war horn as loot.

Next time - will the party escape the Mind Razor and escape? What will happen to Quintus? NExt time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
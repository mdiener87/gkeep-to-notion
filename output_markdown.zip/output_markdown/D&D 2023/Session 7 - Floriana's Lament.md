# Session 7 - Floriana's Lament

    **Created:** 2023-02-15 23:12:13  
    **Last Edited:** 2023-02-23 20:35:35  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Session 2/15/23

Floriana's Lament

The party has (sort of) reunited in Alluin. Gandus and Darkryss is currently in the city, but not at the castle as they have decided to puruse weird side plots rather than try to reunite more directly. Gothryss is trying to slut it up with the leader of The Nightstalker's Guild - Kosha Recrab. This hard and sultry half-elf was unimpressed by Gandus stiff demeanor and refusal to drink. Gothryss, however, was more fun and more her type.

Zephyr, Dorc, and Kaetus have convinced the city guard that they are impossibly, improbably, the heroes of legend - the Order of Sun and Moon. The dynamic trio convinced the guards to take them to the castle gardens, where status of the fallen heroes now stand. The resemblance to Kaetus and Dorc was not just unncanny - it was dead on. The three were escored off-screen to go meet Floriana, whom is in command of the realm.

---

Floriana is not in a good headspace. The Kingdom, as usual, is in a dire situation. Half the kingdom has been occupied by Orcs. The other half is quickly slipping further and further into open allegiance towards the Dragon Cult. Gith airships have raided every town and taken many of the Kindom's treasures and people captive. Floriana was never supposed to be in charge of the Kingdom. In the Prime timeline, the Elven leadership eventually transfered to a human monarchy following the elven Council following the Rites of Divinity and proclaiming the Moryn family King. 

In this timeline, Kaetus marriage to Gwenestry offered a new pathway of leadership. Gwenestry would rule as Queen following the retirement of Galtorah. Her son Quintus, would be prince and heir to the kingdom. The Moryn family is still politically influential, but the Elven Council was taken hostage during the Gith occupation of Selevarum. With Gwenestry hostage and Kaetus and Quintus both missing, the kingdom found itself in a crisis of leadership during wartime. 

This has led to a number of interim rulers. Many of whom have failed, been deposed of, killed by enemies internal and external alike. Floriana, the finest knight of the Royal Guard, had leadership thrust upon her by General Trynnicus. Recognizing Floriana was both popular, well known, and a fierce defender of justice. She was granted the titles Knight Regent of the Kingdom of Dawn, and Lord Commander of the Royal Guard.

Floriana is not in a good headspace. Her Vizir Oriana is still a secret dragon cult flunky. General Trynnicus is a loyal servant, but military victory has eluded his leadership time and again. Floriana despairs as her people suffer. Alluin no longer has the military power to launch a new campaign to try to free people under occupation, nor push out the invading forces. Borrend is safe and secure - and for once, a loyal member of the Compact of Dawn - but lacking a Doom Cannon, have no offensive firepower that can tip the tides of battle. Floriana sits alone on a throne she did not earn, leading a kingdom she cannot save.


==========================

Note: Quintus has the collapsed Reality Marble. Which within Valzumin's Stronghold, lies the Mirror of Prophecy

Figure out what's going on with Gildas in this timeline

==========================

Gameplay Notes 2/15/23

Long RP session tonight. Starting with Dorc, Zephyr, and Kaetus - they followed the city guards into the throne room, as they had convinced the guards that they were indeed the order of sun and moon. General Trynnicus quickly made a nat 20 roll and realized that Dorc was indeed his old from long before. Vizir Oriana was far more skeptical. She hit Dorc with a dispel magic, assuming that he is some form of illusion or shape shifting. Obviouslly, it failed. She then used Detect Thoughts, probing the minds of each of the charachters, trying to learn their secrets and whom they really are. She found only various flavors of noble hero in them.

Disgusted, she backed off and allowed the audience with Floriana to proceed. She went to go find her.

--

Darkryss was busy flirting with, and seducing, Kosha. She was seeking to trade sex for information about the cult. Kosha was pretty adamant to not mix work and fun, demanding real treasure for the information Elyrss sought. Following some impressive roles, Elyrss took Kosha to bed, and made a high performance check as she intimatley and slowly slept with Kosha. Kosha had a fantastic time, but when Elyrss tried to ask about the Order of Sun and Moon during pillow talk, Kosha lost it in laughter. Frustrated, Elyrss gathered her clothes, found Gandus, and left.

The two set off for the castle. Once again, nobody took notice of them despite their very obvious and powerful armor and demeanor. They eventually came up to the castle gates, and Elyrss tried to persuade the guards to let them pass to meet Floriana. This persuasion failed, and eventually Gandus had to step in with his military credentials to get their passage to the throne room.

--

The meeting with Floriana was emotional. Besieged, tired, depressed, for the first time in a long while, Floriana had hope for her kingdom and people. Oriana did not introduce the order, prefering to let Floriana make that assertation herself. She rolled a nat 20, recognized Dorc and Kaetus, and realized that the Kingdom's heroes had returned.

Enter Gandus and Elyrss.

It was awkward. Elyrss and Floriana were engaged, when Elyrss perished in the battle against Kaladan. Floriana was pissed, and despratley wanted to fight it out with Elyrss that she would live and never send word to that fact. She put this selfish emotion behind her, and instead beseached the Order for their help. The kingdom needs heroes, and they are the finest hereos of all time. The city of El Enna was being torn apart in a three way battle between the Kindom, the Cult, and the Orc/Gith forces. The Kingdom's army was depleted, and could no longer launch offensive action.

The order, naturally, accepted this challenge.

Party words - the demon Brathrizard still exists in this timeline. Floriana warned them to take care, they had no information as to its whereabouts.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 11 - An Adjective in an Adjectively Way

    **Created:** 2023-03-23 19:34:51  
    **Last Edited:** 2023-03-23 23:28:50  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Boss conflict, see last notes 

Result:

This was an epic fight. There were a lot of high level spells thrown by both the Abishai and the Party. The Abishai dropped high level spells from the start, with a chain lightening starting off combat. A lightening bolt and cone of cold were also thrown at the party, striking most, if not all players, with every attack.

The party, unable to see their foe to start, prioritized the dragon eggs scattered around the room. They didn't have much HP but did have high AC, and some attacks failed to hit on the first try. Zephyr helped peel one out of the egg with an accidental double nat 1, but it was killed before it could take an action. 

Another egg hatched at the end of round, the only one to live that long. Dorc, however, quickly killed it off before it could make an action. 

Kaetus helped the party stay up with a 9th level healing spell, and then his Draconic Transformation allowed him to see the creature through invisibility. 

Elryss broke out her high level spell in the form of FlameStrike, but despite hitting the creature and rolling great damage, discovered that he is immune to fire. 

Zephyr was able to improvise a potted plant as a weapon. He dumped four squares worth of soil out of it, and the final dumping landed on the Abishai and revealed his outline through invisibility.

Elyrss next spell was able to do enough damage to break invisibility concentration. 

The Abishai retretreated, but only far enough to cast another cone of cold. His rage blinded him to his need to retreat. While he damaged the party, he was vulnerable, and surrounded by the Draconic Kaetus and Zephyr.

Dorc took to the skies, rolling a Nat 20 on an athletics check and hurling himself through the air to the 30ft flying height of his foe. He successfully grappled him in the air, and proceeded to pile drive him back into the ground. This triggered attacks of opportunity from Draconic Kaetus and Zphyr, and did enhanced falling damage on impact with the ground. Between the three hit combo-party-combo-attack, they felled their enemy and cleared the combat encounter!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 24 - The Occupation

    **Created:** 2023-08-24 19:20:43  
    **Last Edited:** 2023-08-24 23:01:02  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

The party is trying to get across Selevarum island to reach the high council chambers. In their way, are numerous challenges. Refugees, spys, gith patrols, running firefights. And worst of all ... a rising number of warp demons. The mindrazor swoops by at close altitude, gith demons dropping in its wake.


--

Gameplay Notes 8/24/23

The party headed down the hill near Illestrae's Temple. They quickly encountered an occupied Elven Village, with several gith visible. They were clearly hurting the townspeople. While the party discussed their strategy, Zephyr took to wing. He surprised his comrades by flying down and launching a surprise attack on the first two visible Gith members. He stunned and killed them both in record time - just for more Gith to emerge from the homes to investigate the commotion. 

A full scale fight soon broke out. Several gith knights took up their arms against Zephyr, who took several hits. Dorc sled down the hill Legolas style with an Athletics check, and used the shadowstep ability from his new sword to get into the fray. 

A gith psionic tried to use telekinies on Zephyr then Dorc, and failed both. She eventually hit Kaetus, and set him up to plummet down the well. Dorc was able to come in and save Kaetus in time, and soon the fight was cleaned up in the Party's favor.

A member of the resistance shot firebolts at the Gith end of round, and it didn't go well for him. Dorc's cursed shield redirected the bolt to him instead of a Gith.. and then the automatic pain reflection caused the poor Elf to burst into flames. A quick medical check by Zephyr, plus a healing potion, saved the man's life after combat ended. 

Talking with the villagers, they gained contact with the resistance. They learned many people had been abducted by the gith, not to mention their material treasures. To cut off the Portal Generator might strand those people in the astral plane. 

The villagers give the party a potion that, when exposed to flame, would send a brilliant signal into the sky. The rebellion would know its time to rise up. Next time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
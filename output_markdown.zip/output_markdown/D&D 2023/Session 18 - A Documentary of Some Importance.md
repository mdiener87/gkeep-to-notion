# Session 18 - A Documentary of Some Importance

    **Created:** 2023-06-06 20:06:54  
    **Last Edited:** 2024-03-13 20:07:04  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Gameplay NOtes 6/6/23

Session was an RP session. Everyone got laid lol. Elyriss and Floriana decided to sleep in late. Really late. They both got plenty of 'rest', although not much resting was had.

Dorc tried to learn the Draconic word for 'Romance'. After several attempts, Dorc was still struggling to learn the true meaning of the word. The General offered to give him a hands on demonstration. Dorc agreed to the Generals' seduction attempt. The General won the initiative roll, and took the Top position - a first for Dorc. In the end, he learned a new word in Draconic - Vorstag!

Vizir Orianna was late as well. After being pressed, she informed the others she had spent the morning catching up with Zephyr. Yes, catching up...

The party discussed the Selevarum Report. After discussion, it was agreed by all that the Portal Device described in the Report must be dealt with immediately. They have a day to prepare, and then Orianna will attempt to teleport them all to the closed and dark teleportation circle in the Selevarum Council Chambers.

Next time - the Return to Selevarum!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
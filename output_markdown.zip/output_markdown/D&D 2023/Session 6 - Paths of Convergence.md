# Session 6 - Paths of Convergence

    **Created:** 2023-02-15 19:30:08  
    **Last Edited:** 2023-02-15 23:12:10  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Running on a Tuesday today so we can get additional players into the game this week

Our players are uniting at the Capitol city - Alluin. After several sessions in which they have all been separate, their stories are all finally converging.

This will introduce the current world state - floriana as defacto leader of the realm. King Moryn was killed by Kaladan. The heir to the throne, Princess Rose, is missing in action. Facing a gap in politicla leadership, Florina assumed military control. She is colder, harder, and more bitter than the Florina the players knew from the prime timeline.

Gameplay Notes 2/7/23

Armor recovered from the Mind Razor belong to Sir Alasdair Tolmach. A knight in the Alluin Army

The Nightstalker's Guild -
Led by a hard half-elf woman named Kosha Recrab
	Intense, greedy, out for a good fight and a good fuck
	favorite drink - Dragonfire Whiskey
Ruhnir Bhene - barkeep, Scottish/drunk accent
has an outstanding bounty on Githyanki and Orc Scalps


Gandus started a bar fight after successfully intimidating the fuck out of the barkeep at the Nightstalker's guild. He was a bit too succesfull - the bar took note. The music stopped. The drinking ended. A group of mercs stood up and surrounded Gandus and Elryiss. Neither of whom noticed until they turned to leave. 

Elryiss tried to throw a punch at one of them. It landed poorly, and didn't hit the fighter's AC. Weapons were drawn, initiatives were rolled. The first fighter rolled well, and succesfully grappled Gandus. The second tried to stab him, but couldn't pierce Gandus' shielded AC. Gandus was quickly tired of this. He hit the grappler with Command, ordering him to grovvel. The fighter had nowhere near the Wis save neccessary to beat that. He groveled and begged forgivness. Gandus made a free intimidation check, and quickly the bar fight backed down.

A woman, clearly in charge, approached. She demanded to know who the two troublemakers were in her favorite establishment. Loosely in charge, Kosha Recrab heads the Nightstalker Bounty Hunter group. Pays bounties, negotiates deals, and keeps the peace. She never bought Gandus' explanation for what a 'new to town' military man was doing here in a tavern instead of his quarters at the castle. Elryiss, meanwhile, went for the flirt angle hard. She needed help finding her friends, and was willing to 'pay' to access the information she seeked. After Gandus refused Kosha's free drink, she took it, focused on Elyriss, and dismissed the brooding hulk.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 8 - RP With Floriana

    **Created:** 2023-03-01 19:31:19  
    **Last Edited:** 2024-11-14 16:53:49  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Session 8 - On the Offensive

Florian has tasked the party with liberating the city of El Enna. The Kingdom needs a win. it needs heroes and hope and a reclaiming of things lost. El Enna, the largest, most populated city in the Kingdom, is in the middle of an ongoing gurillea conflict. The Orcs had claimed half the city, with the Alluin forces eeking out a tenuous hold on the other half.

However, I don't want to play a second go around of clearing orcs from a city. The Orc army is simply not a powerful enough enemy at this point. 

The Orc army is in mysterious retreat. 

-- Gameplay Result --
Party RPd with Floriana, General Trynicus, and Vizir Oriana. Zephyr ended up banging Oriana, and converting her a bit back towards the hope of the light. Kaetus conjured a Heroes Feast, using a goblet from his own wedding in the past of the 3rd age of the Kingdom. This resulted in an improved +5 hp to the normal +10, for a total of +15 total bonus HP. This healed Dorc of his STD as well, which had him quickly reaching for Gildas for a little parley to keep the disease intact.

The team made final preperations and were ready to launch their attack on the cult in El Enna

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
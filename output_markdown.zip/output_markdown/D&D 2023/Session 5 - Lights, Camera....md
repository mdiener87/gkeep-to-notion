# Session 5 - Lights, Camera...

    **Created:** 2023-02-02 18:42:05  
    **Last Edited:** 2023-02-02 22:36:31  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Going to try recording tonight maybe? Oh noz! 

Alex and Evan won't be here. That leaves Kaetus + Dorc + Elyrss for tonight's session.

Kaetus and Dorc are in route back to Alluin. Kaetus has touched base with Quintus, resulting in the infamous 'Daddy' incident which has left Kaetus confused and concerned. 

Gandus has met Elyriss, but not revealed that he knows who she represents. This Elyriss is from this timeline, and not the prime timeline. She is leading a band of rebels in The Guardian Range, the immense mountain range that separates Alluin from the Crystal Desert. 

 Only 3 players so probably a shorter RP game. Maybe we can bring the party back together again.

Meanwhile, the Dragon cult is on the move. They are launching a Major offensive against the remaining orcs held out in the Weeping Forest. The Gith on the Mindrazor have their hands full with an emerging Kerrigan type situation, and won't be available to respond as quickly as they might normally. 


====

Gameplay Notes 2/2/23

Shorter RP session tonight

Dorc, Kaetus, and Zephyr rode north towards Alluin. Kaetus used the ring of sending to call Gandus. IN that call, they discussed that Gandus had found this timelines version of Elryiss. Gandus promised to bring her with him to Alluin and re-unite the party.

Meanwhile, Gandus met with Elyriss at her rebel outpost in the Guardian Range. Gandus had an intense, private conversation with Elyriss. He explained that the Order still lives, that he is a member of it, and returned from the past to this future. That his Order created a terrible disaster with the Doom cannon that had to be undone. Gandus knew Elryiss, and knew she had a 'happy ending' in his original timeline. Elryiss didn't really understand how this was possible, but knew Gandus was speaking the truth. If only for her own vegeance, she agreed to join Gandus, return to Alluin, and meet the current version of the Order.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
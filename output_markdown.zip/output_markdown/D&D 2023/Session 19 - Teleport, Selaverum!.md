# Session 19 - Teleport, Selaverum!

    **Created:** 2024-11-14 16:48:56  
    **Last Edited:** 2024-11-14 16:49:18  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Gameplay 6/29

Going to have the players teleport into the Temple of Eilistraee. Eilistraee (pronounced: /ˈaɪlɪsˌtraɪi/ EYEL-iss-TRY-ee[16]) was the chaotic good drow goddess of beauty, song, dance, freedom, moonlight, swordwork, and hunting, within the drow pantheon known as the Dark Seldarine. She was the patroness and protector of the few dark elves who longed to return to the surface and live there, at peace with other races, and to abandon the endless conflicts and intrigues that dominated the lives of most drow.[1][18][2][4][13][12] She was often referred to as the The Dark Maiden, the Lady of the Dance, or Lady Silverhair,[1][18][2][4] and sometimes The Dark Dancer, among other titles[5] Briefly, she was known as The Masked Lady, when her faith subsumed that of the Masked Lord Vhaeraun, her divine brother,[7][8] while the Seven Sisters nicknamed her Darkfire of Love.[9] Eilistraee pronounced her own name /ˈaɪlɪsˌtraɪi/ EYEL-iss-TRY-ee,[16] but her name has been mispronounced variously as /ˈilɪsˌtreɪji/ EEL-iss-TRAY-yee,[4] /ilˈɪstreɪi/ eel-ISS-tray-ee,[2] /ilɪsˈtreɪi/ eel-iss-TRAY-ee,[1] /aɪlɪsˈtreɪji/ eyel-iss-TRAY-yee,[18] while Elminster Aumar, Qilué Veladorn, and the rest of the Seven Sisters pronounced it /aɪlˈɪstri/ eyel-ISS-tree, even when addressing the goddess face to face.[23]

https://forgottenrealms.fandom.com/wiki/Eilistraee


This temple is technically Chaotic Good at heart. However, the party has to realize this. The Drow in the temple are able to be reasoned with, and consider themselves allies of the surface world. However, they are basically a forgotten legacy of the island. Their contact with the Elven council was always spotty at best, and with the Gith invasion, they have taken shelter in the UnderDark beneath the Island. A few still pay devotion to the temple. The temple has a long-forgotten teleport circle that the party will find themselves inadvertantly activating.

The lower level has the Moon Forge - a Drow invention, it slowly saturates spring mountain water with the touch of the moon. This energied water is used to power an enchanted blast forge with the ability to work magical items. It can magically enhance, change, or deconstruct existing magical items. The forge requires a large amount of its moon-touched water to operate; It can store up to three Reforge worth of energy, and it regains one Reforge per month. An Arcane check is required to use the Moon Forge, plus any other checks to actually perform the work. 

The Drow could be convinced to operate the forge as well, if the party goes about diplomacy.



====== Gameplay Notes 6/29/23

This was an RP prep session. A lot of gameplay for Zephyr, who has been out for several weeks. Zephyr had excellent rolls for Dave, who never failed a roll or created a scene. Zephyr would go on to gain Proficiency in Animal Handling with regards to Wretched SorrowSworn creatures. Zephyr would go out with General Trinykiss in search of a golden chalice worth 1k GP. The general had an idea, and wanted to introduce him to a dwarven blacksmith he knew of in town. Trinykiss would go on to introduce Zephyr to Elara Stonefire, a talented blacksmith that specializes in intricate and ornate works. After some banter - and negotiation - Zephyr secured the purchase of two of these monstrously sized gilded chalices. At 1k gold each + the commission fee, it was no cheat purchase. The first was a rush order job, and Zephyr proceeded to fill it with beer from the local tavern. Soon he was everyone's friend (at least, everyone who could get past their distaste and fear of Dave), as Zephyr offered everyone on his way back home free drinks from the gigantic chalice. 

Zephyr would go on to wake up his friends - along with much of the rest of the castle. A veritable kegger was underway! Kaetus worked his magic and a heroe's midnight brunch was served! Buffs, and friendship, were shared all around. 

Other prep... Kaetus studied the Selavarum report in more detail to ensure he hadn't missed any details. The situation was worrying, and time is of the essence!



=====


NPCS in Alluin:

Elara Stonefire: A talented blacksmith who specializes in crafting intricate and ornate pieces. Elara's creations are not only durable and practical but also feature exquisite designs and engravings. She has a keen eye for detail and is highly sought after for custom-made weapons and decorative armor.


=====

'Dave' Wretched SorrowSworn:
Small Monstrosity, Typically Neutral Evil

Armor Class 15 (natural armor)
Hit Points 30 
Speed 40 ft.

STR 10 (0)
DEX 12 (+1)
CON 10 (0)
INT 5 (-3) 
WIS 6 (-2)
CHA 5 (-3)

Damage Resistances Bludgeoning, Piercing, and Slashing while in Dim Light or Darkness
Senses Darkvision 60 ft., Passive Perception 8
)
Proficiency Bonus +2

Abilities:

Pack Tactics. The sorrowsworn has advantage on an attack roll against a creature if at least one of the sorrowsworn’s allies is within 5 feet of the creature and the ally isn’t incapacitated. 

Actions
Bite. Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 6 (1d10 + 1) piercing damage, and the sorrowsworn attaches to the target. While attached, the sorrowsworn can’t attack, and at the start of each of the sorrowsworn’s turns, the target takes 6 (1d10 + 1) necrotic damage.

The attached sorrowsworn moves with the target whenever the target moves, requiring none of the sorrowsworn’s movement. The sorrowsworn can detach itself by spending 5 feet of its movement on its turn. A creature, including the target, can use its action to detach the sorrowsworn.


Necrotic Surge - Recharge (6):
The Wretched Sorrowsorn can channel its inner darkness, unleashing a surge of necrotic energy in a devastating area-of-effect attack. This energy drains life force, causing damage and potentially weakening enemies hit by the blast. All creatures in a 20ft radius around the Wretched SorrowSworn must make a DC 14 CON saving throw. Those creatures that fail take 2d6 Necrotic damage and have disadvantage on WIS and CON saves until the start of the Sorrowsorn's next turn. Creatures that pass the saving throw take 1d6 Necrotic damage instead. The Wretched SorrowSworn heals for half of the damage inflicted through this ability.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
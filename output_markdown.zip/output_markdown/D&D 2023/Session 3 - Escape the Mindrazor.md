# Session 3 - Escape the Mindrazor

    **Created:** 2023-01-26 19:52:28  
    **Last Edited:** 2023-01-26 19:53:29  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

New Chipahua / Civilian Leadership:
Naexi Iarnala - dragon cultist elf female leader - taking charge of the chipahua lands following cardar's disapearance


Knight's (royal guard) gear within high evidence lockup:
Spell Scroll (Arcane Eye) (rare, dmg 200)
Elixir of Health (rare, dmg 168)
Potion of Water Breathing
Alluin Plate Armor +2 - Mariner's Enchantement - Requires Attunement

Earth Ele Kaetues was just barely able to hit the Commendant to break her concentration on the wall of force which blocked Kaetus and Dorc's escape

Gith Interrogation Commendant Is afflicted by Sibriex Warp Demon Poison from Zephyr. 

The 3 waywird birds were able to escape and take flight. A Gith Cutter is in pursuit.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 22 - Pimpin Ain't Easy

    **Created:** 2023-07-20 20:11:29  
    **Last Edited:** 2023-08-10 20:34:21  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Dorc rolls when the party returns to him. He may choose the order of these checks, I will narrate the outcomes.

The DC for these stars at DC 16, and Increases +1 for each subsequent roll. Failing a roll increases the cumulative failure penalties chart. 


*Charisma (Persuasion or Performance) Check: PASSED
During this session, the player must engage in captivating conversation and mesmerizing performances to maintain the genies' interest and trust. A successful Charisma check would help the player establish rapport with the genies and keep them engaged in the interaction.

*Intelligence (Arcana or History) Check:
The genies might test the player's knowledge of magical lore, history, or the intricacies of the elemental planes. A successful Intelligence check demonstrates the player's understanding of magical concepts or the ability to recall crucial information that might be relevant to their conversation.

*Dexterity (Sleight of Hand) Check:
In a moment of magic or intrigue, the player might be challenged to perform a delicate task using sleight of hand. This could involve impressing the genies with a subtle display of elemental magic or deftly manipulating objects with finesse.

*Wisdom (Insight) Check:
The genies may have their own hidden motivations or secrets. A Wisdom (Insight) check allows the player to discern the genies' true intentions or emotions, providing valuable insight into the dynamic of the encounter.

*Constitution Save:
As the session extends, the player might face physical or mental exhaustion from the intensity of the interaction. A Constitution save represents their ability to endure the draining effects and maintain focus during the extended and demanding conversation.

Strength (Athletics) Check: PASSED
The ability to go further and harder. Satisfying all in the party.


Failure Chart:
1) DC of future rolls increased by 1. 
2) Heroes Feast Buff Removed
3) Cursed with Magic Addiction. You make saving throws against magical spells and effects at disadvantage. 
4)  DC of future rolls increased by 1. Fae's Seduction Blessing Stolen.
5) Bound to one of the Genies (roll). You have formed a magical pact with this Genie, and your release will only come at their discretion. They may ask favors of you from time to time. Failure to comply will be met with consequences. 

Dorc will also suffer a level of Exhaustion for each level of failure. 

In Exchange, Dorc may fuse his blades in the Moonfire Forge. This will take the session worth of gameplay to work the Genie magick.


---
Eilistraee's Final wish: 
Revive a Forgotten Ritual: Eilistraee's teachings encompass dance, music, and song. The players must discover a forgotten or lost ritual of Eilistraee's faith, one that has the potential to unit Drow and Elves in celebration. By reviving and performing the ritual, they can reignite the fading magic of Eilistraee's shade and rekindle hope not just among her followers, but also hope for eventual unification of these divergent races.

Eilistraee can teach her song and dance, but it must be performed at the Selevarum High Council and the Tower of Bithyra to truly free set her shade at ease. 


Gameplay notes:

Forgot to write these down. lol woops
Party (sans Dorc) tried to ignore the terrible squelching sounds coming from the Genie's forge. Instead, they pushed north, finding and fighting spiders through the hall. Zephyr and Kaetus took point, with Zephyr using his newfound dust of invisibility to try to hide and set up an ambush on the lurking phase spiders.

He drew one out, but two more lingered and hid. They ambushed Zephyr and did inflict some piercing damage. The party quickly jumped into action and squished the remaining spidres. They found some gold pieces in the room, but not much more for loot.

Dorc finally finished up. He failed 4 of the 6 saving throws. 5 would have sold his soul to the genies, and 6 would have killed him. As it stood, he still took significant penalties. But for his reward, he received a powerful blade that merged his two swords of opposite alignment.

The genies granted the party rest in exchange for a story. Good berries were handed out, and an epic tale of heroism told. Through this exchange of information, the genies let slip that [DRAGON MAMA] had actually tried to overthrow Tiamat. For her attempt, she was banished to the Shadow Plane, a land without life or gold or followers or glory, for all eternity.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
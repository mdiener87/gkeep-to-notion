# Session 16 - A Building Tsunami

    **Created:** 2023-05-11 19:23:06  
    **Last Edited:** 2024-03-13 20:07:41  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

The Party finds itself victorious. El Enna is liberated. The Cultists in the city have been routed, the Gith have mysteriously withdrawn, and the Orcs have suffered a devastating blow by a mysterious airship. Is this all good news? 


Probably an RP setup session Plot points:

Gith:
Gith are withdrawing all over the kingdom. 
The Mindrazor has been taken over by the [zerg]. [Kerrigan] is in control
The original command staff evacuated successfully, including the captain which has all of the equipment he stole from the evidence locker. 
The gith cannot shut down the portal from their side. Its really awkward. They have pulled many ships back to guard the entrance and retreat back into the Astral plane. The party is over!


The Mindrazor is growing and releasing terrible monstrosities. The ship itself has been corrupted, along with much of its crew and compliment of cutters. The corruption continues to mutate and spread. Soon, it will begin to corrupt Selevarum.


Orcs:
They still have encampments on the Eastern side of the map, but they have been pretty much wiped out. With their Gith allies fleeing, the Orcs have run out of support. 

Shadow Cult:
Kippla + Isabel, utilizing the stolen Cutter, wiped out the main Orc encampment
The cult is growing in power and influence. While pushed out of El Enna, their victories elsewhere mount. 


============

Gameplay notes:

This RP session focused on the players maintenance actions over El Enna. They escorted those survivors who wished to return to Alluin to safety in the Gov mansion within El Enna. Gildas had posted his men around the perimeter to secure the compound, so no cleanup had been dealt with. The party oversaw a burial detail and cleanup, with Kaetus using Move Earth (??) to create a large grave in the nearby garden. 

With the survivors fed and rested, the party got themselves a badly needed long rest as well.

Contact was made with Oriana to detail the situation regarding refugees taken to the capitol. Oriana was glad to help, and arranged to begin transportation circle activations once per hour the following morning.

When it came time to teleport the refugees, the party decided to put an old plan into re-use. They used a Zone of Truth from Gandus to compel and interrogate all of the refugees. Meanwhile, Kaetus used Detect Magick to search for weapons or artifacts - an improvement over their old methodology to event security. 

While most of the security screening went without incident, a peculiar situation did occur. Some refugees were more argumentative than deemed appropriate, and denied boarding. Kaetus also caught the smell of some foul and dark magic, but he wasn't able to locate the source of it. Kaetus used the Foresight spell, and could see that the teleportation circle also responded with some errant dark magic. However, his daylight spell he cast in reaction did not reveal any shadowy types lurking about.  With the situation resolved, The party beamed out to Alluin. 

[[DM note - two Dragon Cult spies have now successfully infiltrated alluin using the invisibility spell]] (playing them as an Oni template for now)

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
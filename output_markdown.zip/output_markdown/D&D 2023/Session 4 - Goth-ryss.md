# Session 4 - Goth-ryss

    **Created:** 2023-01-26 19:53:55  
    **Last Edited:** 2023-02-02 22:23:59  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

No real notes. Goth-ryss is replacing Kipla, whom joined the Dragon cult for real.

The waywird birbs still have a gith airship tracking them. 

Gandus will meet Goth-ryss on his way back to Alluin, in the foothills above Chipahua.


----

Gameplay notes 1/26/23


Dorc and Kaetus escaped the Mind Razor. A Gith Cutter was in pursuit. In this contested environment, the fleeing giant eagles would need to get 3 advantages against the airship to escape. Meanwhile, if the airship could get 3 advantages, it would be in telekinesis range and grab the party. 

The birds dove towards the water, and made an acrobatics check to pull up at close range. The airship tried to match. It rolled a nat 1, then failed its emergency handling check. It crashed into the water and instantly ended combat.

---

Meanwhile, Gandus found himself alone, ruminating on the past battles. Slowly making his way back towards Alluin, he felt abandonded by both his allies and his gods. His Diva was giving him the silent treatment. In curt snipets, she reminded him that Tyr is a good of justice and mercy - not murder.

The Raven Queen was much more enthused by his actions in Chipahua. She praised Gandus, and quietly led him to another on a path of vengeance. When he reached a clearing in the mountains, the distinct sound of battle could be heard.

He came upon this timeline's version of Elyris fighting cultists. While she had felled 3, 5 more stood ready to fight. Elyris found herself a bit overwhelmed, which only gave Gandus more time to shine. He cut through the cult without issue. When united, Elyris introduced herself (whom Gandus recongized) and she led him to her rebel base of operations. 

Finally, Kaetus used the ring of sending to call Quintus during a long rest. The dramatic phone call ended with Quintus declaring his path of vengeance - the Order, however right and just and good it is - was not on the same page. Quintus needed vengeance against the Gith, at any cost. Kaetus also used some of his remaining diamond dust to restore Dorc's missing strength stat back to full health.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
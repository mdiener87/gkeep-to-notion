# Session 1 - Lost in the Matrix

    **Created:** 2023-01-26 19:50:00  
    **Last Edited:** 2024-11-14 16:57:11  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Gameplay Notes 1/5/23

This session was all about the waywird birbs, captured on the Mind Razor 
They were in a dream within a dream, and had to work their way through the psychic interrogation world to survive
They met up with Timeworn Kaetus, whom the Gith have had captured for years now. 
After escaping the holding cells, they decided to stay on the ship and look for their gear.

They found their gear in the evidence lockers, but some of it was missing. The Gith captain took certain items for themselves! The players were given the option to reserve one attuned item that could not be taken. But the Captain would claim at least one other item for himself.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
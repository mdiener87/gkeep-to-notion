# Session 14 - What lies behind doorway #2

    **Created:** 2023-04-20 20:20:25  
    **Last Edited:** 2023-04-20 23:13:38  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Minimal prep coming into today but that's okay. Continue storyline where we left off. Party has defeated the immediate cultist HQ in El Enna. They have disabled the teleport circle ((to hell)), and have defeated the Anibashi that were present on site. 

Probably mostly RP. Can throw shadow cultists at Gildas group if necessary.

News will soon reach the party  that the Orcs have suffered a major blow. Apparently a gith Airship reigned terrifying firepower down upon the Orc primary encampment, located to the North of El Enna. Rather than use the ships cannon, the fire was accomplished by what appeared to onlookers as a single, diminutive warrior...

Also, that plot line with the MindRazor hasn't been forgotten. That ship will be lost to the warp poison. The Commandant of the vessel has been corrupted and warped into a terrifying demon with psychic powers. The Gith will soon reconsider whether this whole venture is worthwhile...


===

gameplay notes 4/20/23

Kaetus and Zephyr were very cautious with the Shadow Sigil. Kaetus Detect Magic revealed that the magic within is dark and complex, and that it can't be guranteed that attuning to it won't have unintended consequences. Zephyr, initially excited to attune to the item, decided to hold back on that for now.

Party explored the SW area of the 2nd floor of the governors mansion. This area was filled with Sorrowsorn (not yet determiend what they are by the party). The first was a small group of the Wretched. Gandus cut them down at range without issue.

The party pressed further down the hall. The room to the right was absolutley filled with Wretched Sorrowsorn. The party could cut them down easily enough, and their attacks proved inneffective against the party's high AC. However, the room to the south went unexplored - and far more powerful Hungry Wretched burst out and began attack. Kaetus found himself in the middle of the fray, and was quickly bitten and double grappled by the new intruders.

Luckily, while the numbers were against the OSM, the skill in battle was not. The sorrowsorn were cut down round after round. While the Hungry got some hits in, and had the HP to take a few of their own, the battle was quickly decided with the OSM prevailing over a hallway of carnage.

In the middle of all of this, Zephyr took the time to try to tame one of the Wretched. He succeded on a series of survival and animal handling rolls, and soon found himself making a new friend. He even took the time to feed it the cursed chimeric drow/minotaur skull that he had retrieved from the Maze of Whispers. What consequences will this act hold?

Find out next time, on D&D!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
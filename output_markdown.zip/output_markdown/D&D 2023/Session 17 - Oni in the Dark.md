# Session 17 - Oni in the Dark

    **Created:** 2023-05-25 18:52:20  
    **Last Edited:** 2024-03-13 20:34:46  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

There has been a lot of focus spent on El Enna for the last several sessions. The party is victorious, the strike team killed the dragon cult in El Enna and the Orcs are in retreat. They have rescued survivors, and restored Kingdom Control over the entirety of the city. Oriana has just beamed the remaining refugees, and the party has returned to Alluin.

We know that a large orc encampment, located in the woods to the North of El Enna, has been devastated by a single Githyanki Airship. It was seen firing a barrage of rockets.

Meanwhile, the Gith have been withdrawing from all over the kingdom. What could this mean?


The Zerg infestation of Selevarum is underway. The dragon cult is aware of the situation, and have spotted an opportunity of their own: The Githyanki Portal Device, which they used to create the stable aperture to their pirate base in the Astral Plane, is now up for grabs. The Gith have redeployed their fleet to guard the portal. They are terrified of these infected Gith making it through the portal and infesting their civilization.

Their headquarters in Selevarum have gone dark. They can't shut down the portal, and they are attempting to abandon their stake in the material realm.

The Dragon Cult are making a mad dash for the Portal Device. Brathrizard, Narzugon, has taken personal command of this detachment. He leads a detachment of cultists, demons, and Abishai. Quintus is also there, his thirst for vengeance against the Gith insatiable. 



This will probably be a set up RP session. 

Alluin is now in possession of:
Title: "The Selavarum Report: The Githyanki Portal Device and Planar Connectivity"
Author: Elowen Starbloom
Blurb: A groundbreaking examination of the Githyanki Portal Device's role in interplanar connectivity. Scholars examine the device's interface with the multiverse, the intricacies of manipulating planar harmonics, and the implications for trade, warfare, and exploration. Gain a deeper understanding of the shifting fabric of reality.

It explains that this portal device has a unique magical signature that can precisely pierce the veil of reality. WIth this device, it is possible to create a stable planar in the nearby sky. This portal can connect directly to any known dimension. It appears to be stable for arbitrarily long periods of time, but requires a significant energy expenditure to create the first portal. 

The downside, if there is to be such a thing considered for such a powerful device, is that the portal is opened TOWARDs the Portal Device, not FROM. So to open a portal to their base, the Githyanki must first take the Portal Device to the desired plane and space, and activate it from the other side. Their base in the Astral Plane has a corresponding Astral Anchor which the Portal Device locks onto, and draws open the portal from. 

The Astral Anchor is now a permenant feature of the Githyanki base and was never designed to be deactivated. WIth the Portal Device out of their contorl, the Gith are struggling to know their next steps past to maintain the blockade.

The Gith will soon send a strike force, led by the Captain of the MindRazor himself, to retrieve and/or destroy the Portal Device.



[[Other Notes]]
Zephyr has been out for several sessions. He is busy training Dave (was that the name?) which can be a new abyssal pet for him. Dave is mutating as a result of that skull he was fed.

Quintus has told Sethrikar much. The dragon is now aware of Tinithera's Manor, and has traveled to the Manor to secure it in the name of the dragon. Extravagant, remote, and well defended - it is the perfect place to establish a new draconic lair.

[[For Derick]]
Need a series of battlemaps for the Elven Council of Selevarum. This grand chamber serves as the original source of democracy and leadership in the lands of Dawn. It is here the Gith most intentionally seized and used as their most secure base of operations. The Gith Portal Device is - or was - located here... and everyone is racing to find it.




Gameplay Notes 5/25

The Order arrived with the refuges. They were still on guard from their security detail in El Enna, and took that serious edge into their return to the castle. The party split into two parts: Kaetus and Gandus stayed with Oriana to protect her as she tended to the latest batch of refugees. Elyris and Dorc went to check on Floriana.

Kaetus and Gandus did a good job securing Floriana, and nothing dramatic happened. Kaetus worked through premonitions - one involving him receiving a book, and the other, of a burglarly in the castle.

Dorc and Elryss spoke with Elryss and General Trynicus. Dorc quickly excused himself, and Trynicus wisely joined him on a patrol of the grounds. Elyrss and Floriana awkwardly caught up, but they navigated the situation well and Floriana thawed towards Elyris. They decided to go on a private walk together and chat.

Dorc and Kaetus came upon the burgled room. Dorc and Trynicus caught the perps in the act - two refugees! The battle quickly revealed more - the thieves could turn invisible. An awkward situation occured where Dorc's blade got stuck in one following a double nat 1 roll. Dorc turned the situation to his advantage, however, using the Flame Tounge's blade to flicker on and off and help reveal the location of the Oni.

One eventually escaped, while the caught member was made Feebleminded by Kaetus. The party proceeded to turn him into a pin cushion. Dorc investigated the body, and found a manuscript that the Oni had stolen - Title: "The Selavarum Report: The Githyanki Portal Device and Planar Connectivity"

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
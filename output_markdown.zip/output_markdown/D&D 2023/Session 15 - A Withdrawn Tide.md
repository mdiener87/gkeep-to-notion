# Session 15 - A Withdrawn Tide

    **Created:** 2023-05-04 20:12:14  
    **Last Edited:** 2023-05-11 19:32:00  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

See some of the previous notes for today's session. The last session turned into a bunch of combat against the wretched - terrible shadowfell monsters who have lost their soul. In this case, through their attempt to achieve immortality through a soul graft to a demonic dragon egg. These guys didn't have what it takes and they suffered as a result. 

Gameplay Notes 5/4

Mostly an RP session. Game started out with the party fully exploring the rest of the governor's mansion. There were some more Allips and Shadow Ele in the northern room that still had yet to be cleared. One got a surprise attack on Dorc, which only enraged the Dwarf/Orc. He proceeded to drop over 100 dmg into it on his round, and then rolled a nat 20 on a free intimidation check. The other baddies in the room panicked, revealed themselves, and tried to flee. A whole bunch of sentinel checks were invoked by the party, and only one small Allip managed to sneak away. It was quickly cleared up by Gildas' group.

The party took a short rest and regained some HP. Gildas brought forth a scroll from Floriana that was hastily written. It indicated the Gith had been seen withdrawing their forces from all over the kingdom. The Orcs had suffered a massive blow to a single Gith airship that was seen raining some form of rockets down on their encampment. Suddenly, the tide in the war has shifted.

The party made their way out of the mansion and towards the group on the western side of the city that had held out. Despite being on guard for enemies, the city sections they passed through were totally empty. They found themslves in an empty, if devestated, city. A handful of citizens greeted them on their journey.

Arriving to the western edge of the city, where Alluin-friendly forces held out, they were challenged by lookouts who suspected the party as Gith spies. A quick pose from Dorc cleared up any confusion - this was the Order of Sun and Moon! A throng of people soon enveloped the party as they came into camp. Gandus took an assesment of the lot, and quickly stepped into the void of leadership they were facing. He set about picking up their morale and discipline. Good berries and other medical treatments were delivered, healing the injured fighters in body and soul.

Some fighters, their battle won, elected to return to Alluin via the liberated transportation circle. Others, determined to protect their home, stayed on.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 20 - Secrets of Eilistraee Temple

    **Created:** 2023-07-06 20:06:28  
    **Last Edited:** 2024-03-13 20:05:49  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Run the Elistraee Temple encounter planned for last session today.


---


Gameplay Notes 7/6/23

The party teleported to selavarum. However, they wound up in a weird, dusty room. Some investigation from the party revealed their inbound teleport to be Drow in make. The name 'Eilistraee' could be found in the Drow writing of the teleport circle's runes.

Gandus helmet was lit up, helping to reveal a tripwire on the stairs. Dorc smashed into the wall below the steps, and Zephyr used his Staff's Lightning ability to damage the pneumatic pressure system that powered the trap. Gandus used a shield to bash down some straggler spikes, and the party ascended towards the door.

Zephyr determined that this door too is trapped. After some debate (and an extraneous table), Kaetus realized he could use Stone Shape to create a passage through the wall and avoid the door and its trapped mechanism entirely. The party moved up!

The next room had only one exit, despite Zephyr's looking for hidden passages and entrances. The room beyond had two Helmed Horrors. A once upon a time boss, these have been downgraded to mook status and were dispatched in a single turn. 

Zephyr found a locked door to the East. Kaetus explored further north and found a giant spider resting in the next room! Despite moving a bit recklessly, he managed to make a stealth check at disadvantage and avoid aggroing it tonight.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
# Session 10 - Meet the Abishai 

    **Created:** 2023-03-09 20:27:09  
    **Last Edited:** 2023-03-30 19:46:55  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

Continuing combat from last session. 


Result:

The party gave Gildas the ring of sending, and had him and his men secure the teleportation room. Zephyr heard someone creeping up on the door into the room. He convinced the voice from the other side that there was no need for sandwhiches in the room. Once he heard the body turning to walk away, Zephyr pounced, and instantly stabbed and killed a young lad working within the hallway. 

Beyond the antechamber was a kitchen. Zephyr could spy two cooks working, making food and tending to beverages. Zephyr struck out on a surprise round, incapacitating one with non-lethal damage, but accidentally killing the second with an abundance of non-lethal. The room also had three cultist warriors in it. The party quickly poured in and dispatched the warriors. 

Beyond the kitchen, they found the large fouier, and recognized the building as the Governor's Mansion of El Enna. To the south, the party could hear general conversation. To the east, a worrying amount of draconic chanting. They headed east.

A locked door blocked their path. Dorc smashed against it once, twice, and finally broke through it on the third attempt. Two dragon cultists stood guard. There was no surprise round prepped, and so combat began at once. Kaetus unfortunately missed with his Primal Savagery, accidentally hitting - and critting - Elyrss for significant damage.

Dorc and Gandus quickly dispatched the two cultist warriors. After assembling in position, Zephyr used Shatter as a breaching charge against the doors. The blew apart, and the party was faced with an unexpected scene - numerous dragon eggs filled the room. Near each of them, a dead KoD civilian. The dragon eggs were clearly from a blue dragon, but warped, corrupted, and twisted with demonic energy. 

Zephyr was having none of it. He tried to hit the room with Fireball. Just as the spell was released, it was countered. A demonic voice filled the room. It was expecting the order, and greatly displeased at their attempt to kill these children. They could not see the source of the sound, or the counter spell. How will they face this new threat?

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
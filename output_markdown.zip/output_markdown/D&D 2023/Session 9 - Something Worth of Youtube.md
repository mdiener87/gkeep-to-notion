# Session 9 - Something Worth of Youtube

    **Created:** 2023-03-02 23:41:15  
    **Last Edited:** 2023-11-08 19:36:06  
    **Labels:** D&D 2023  

    ---

    ## Note Content (HTML)

A combat scenario worthy of song. The party is transporting into a hot situation. This needs to be a combat encounter worth their time.

Haven't decided how to play this yet. I want to up the stakes of the campaign and bring some heat. Do they transport into the Shadow Realm? Face Brathrizard? 

What is the Heart of the Dragon? What is it doing? That needs to be seen/felt in this episode for sure. => It allows for the creation of Abishai. Those supremely loyal cultists may be reborn in the glory of the dragon, forfetting their souls to serve the dragon clan as vessels.

Shadow mom tired to usurp tiamat and steal her power. For this, she was cursed and imprisoned on the shadow plane. From there, her hunger only grows whilst having nothing of value to saitiate it. Her longing is to be free at last, and turn the material plane into her ultimate buffett. 

She has, or had, a mate. Undecided what it is/was. Was involved in the scheme vs. Tiamat.

Creating Abishai is something only tiamat can normally do. Perhaps the dragon did succeeded in stealing some of tiamat's power...

Brathrizard is directly working with the dragons as part of this little devil/dragon alliance. 

===

Result

The party did their final prep on the strike team. Oriana cast Scrying, and determined that their teleport locaiton had 4 dragonborn cultists nearby it. General Trynicus was persuaded giving up a valuable family ruby to Kaetus for spellcasting components if needed. Oriana then teleported the party to their destination. All of them went at once, no waves to this. Just a mass teleport of Alluin Power.

The dragon born cultists had no chance. The party went into full form, and between Gildas' men and the Order itself, was able to nearly wipe all of the cultists in the resulting surprise round. The remaining warrior was in a Hold Person effect, and at the bottom of a massive turn order against him. He stood no chance.

Zephyr, landing the killing blow, tried to list for signs of trouble from the stairs. Instead, he noticed shadows shifting along the wall. He hit those shadows with a Thunder Wave, and revealed a Shadow Elemental chilling on the wall. He cried out to the party of danger - and with perception checks, noticed that they were surrounded by shadow creatures.

Kaetus cast Daylight up on the roof, illuminating even more unseen shadow creatures. A large brawl broke out.

The Allips were unaffected by the bright light. Their maddness, however, had trouble against the heroes benefiting from the Heroes Feast. Their wisdom saves were all against Advantage, and they had real trouble landing their spells against the party.

The Shadow Elementals have light sensitivity and were heavily blinded by the Daylight. The one landed a Constrict against Zephyr, and managed to choke the bird the entire sequence of combat. That was the only real success - they were otherwise taking attacks at advantage and turning their only hits into misses with the blinding light.

Gandus at one point missed an elemental with advantage, rolling two nat 1s and then failing to recover the bad attack with a bonus roll. He instead threw his Sword of Judgement into the constricted Zephyr.

With the shadows dealt with, the party finds itself in a quiet, and brightly lit, room. What lies in wait for them up the stairs?.... find out next time!

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*
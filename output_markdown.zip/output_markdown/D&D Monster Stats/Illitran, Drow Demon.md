# Illitran, Drow Demon

    **Created:** 2021-10-29 11:43:40  
    **Last Edited:** 2021-10-29 11:43:42  
    **Labels:** D&D 2021  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
As Yocoloith + Drow Arachnomancer abilities + total HP
Legendary resistance 1/day to choose to pass a failed save
Legendary Actions: 3 per Round
Cast a spell (Ist - 3rd level - 1 Action per spell level)
Compell Demon (2 Actions)

If it targets a Terror Spider, gains advantage on this attack roll
Attack (1 Action)

Illtrain's sleep effect can be disrupted per round. If she takes 20 or more damage per round, she must make a

concentration check 8 + (1/2 dmg taken) or the sleep effect at end of round will not be applied. If she looses by more
than 5, all terror spiders are stunned for the next round.

#### ChatGPT Output:
**As Yocoloith + Drow Arachnomancer abilities + total HP**
- Legendary resistance 1/day to choose to pass a failed save
- Legendary Actions: 3 per Round
  - Cast a spell (1st - 3rd level - 1 Action per spell level)
  - Compell Demon (2 Actions)

  If it targets a Terror Spider, gains advantage on this attack roll
  - Attack (1 Action)

  Illtrain's sleep effect can be disrupted per round. If she takes 20 or more damage per round, she must make a

  concentration check 8 + (1/2 dmg taken) or the sleep effect at end of round will not be applied. If she looses by more
  than 5, all terror spiders are stunned for the next round.

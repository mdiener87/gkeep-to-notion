# Shadows Fall ++ - Monster Notebook

    **Created:** 2021-10-29 11:24:27  
    **Last Edited:** 2022-07-07 21:50:44  
    **Labels:** D&D Items & Monster Stats, D&D 2018, 2019  

    ---

    ## Note Content (HTML)

s fashadow

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Shadow Warrior - Dragon Born
CRS,

AC 18

HP 80

Speed: 30ft

‘STR: 15 (+2) DEX: 12 (+1) CON: 14 (+2) INT: 11 (+0) WIS: 14 (+2) CHA 16 (+3)
Skills: Athletics + 8, Perception +6, Stealth + 6, Deception +6. Intimidate +4

Traits:
‘Shadow Faith: Adds CHA score to hit (in stats), and adds 1d6 necrotic damage on damage rolls
Actions:

Multi-attack: 2

Longsword +8 to hit, 1d845/vers/1d10#5
Shortsword: +8 to hit, 1d6+5

Crossbow: #8 to hit, 1d10+4

‘Shadow Step: (recharge: 5-6) The cultist magically teleports, along with any equipment it is wearing or carrying, up to
40 ft. to an unoccupied space it can see. It may make a single attack on an adjacent creature

‘Shadow Warlock - Dragon Born
CR:6

AC 16
HP 50

Speed: 30ft

‘STR: 10 (+0) DEX: 12 (+1) CON: 12 (+1) INT: 12 (#1) WIS: 11 (+0) CHA 18 (+4)

Skills: Deception +4, Persuasion +4, Arcane +4, Religion +2, Stealth +4, Deception +4

Resistance: Necratic, Lightening

Traits

Dark Devotion - advantage vs. charmed or frightened

Pact of the Blade - Shadow Reaping Scythe (+1d8 necrotic damage on weapon hit)

Boons: Armor of Shadows {free mage armor as a bonus action -> AC15)
Dark One's Luck - Once per rest, may add 1010 to an ability check or saving throw rolls' total.
Thirsting Blade - You gain +1 attacks when you attack with your pact weapon

Actions:
Reaper's blade: +5 to hit, 1d8+5 + 1d8 necrotic

‘Spellcasting: 7th level spell-caster, Spell Save DC 15, +6 to hit with spelll attacks
Spell Slots:
Spells Known: &

Cantrips: Chill touch, Blade Ward, Eldritch Blast

Spelts:

Level 4:

Confusion https://app.roll20.net/compendium/dndSe/Confusion#tcontent

Black Tentacles httpsi//app.roll20.net/compendium/dnd5e/Black%20Tentaclesiicontent

Level 3:
‘Vampiric Touch https://app.roll20.net/compendium/dndSe/Vampiric%20Touch#content

fapp.roll20.net/compendium/dndSe/Shatter#tcontent
Darkness https://app.roll20.net /compendium/dnd5e/Darkness#content
Ray of Enfeeblement https://app.roll20.net/compendium/dnd5e/Ray%200f%20Enfeeblement#tcontent

Level 1
Hellish rebuke https://app.roll20.net/compendium/dnd5e/Hellish#20Rebuke#tcontent
Shield https://app.roll20.net/compendium/dnd5e/Spells:Shield/#h-Shield

Eternal Flame Priest
Medium humanoid (human), neutral evil

‘Armor Class 12 (15 with mage armor)

Hit Points 52 (8d8+16)

Speed 30t.

STR 12 (#1) DEX 15 (#2) CON 14 (+2) INT 10 (0) WIS 11 (0) CHA 16 (+3)

Damage Resistances fire
Skills Deception +5, Intimidation +5, Religion +2
Languages Common, ignan

Challenge 3 (700 xP)

Spellcasting. The priest is a 5th-level spelicaster. its spellcasting ability 1s Charisma (spell save DC 15, +5
to hit with spell attacks). It knows the following sorcerer spells:

Cantrips (at will): control flames, create bonfire, fire bolt, light, minor illusion
Ast level (4 slots): burning hands, expeditious retreat, mage armor

2nd level (3 slots): blur, scorching ray

3rd level (2 slots}: fireball

Actions
Dagger. Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 20/60 ft,, one target. Hit: 4 (1d4
+2) piercing damage

Shadow Elemental
Large Elemental, neutral evil

CR:6

ACIS

HP 130

Speed: Soft

STR: 11 (+0) DEX: 18 (+4) CON: 18 (+4) INT: 14 (#2) WIS: 10 (+0) CHA 6 (-2)

Damage Immunity: Necrotic, Fire

Damage Resistance: bludgeoning, piercing, slashing from non-magical weapons

Damage Vulnerability: Radiant

Condition Immunity: exhaustion, grappled, paralyzed, petrified, poisoned, prone, restrained,
unconscious

Language: Umbral [shadow language]

Skills: Stealth +6, grapple modifier +6

MultiAttack: 2

‘Shadow Form: The elemental can move through a space as narrow as 1 inch wide without squeezing.
While in shadow, it may attempt to hide as a free action, and may move along any corporeal surface or
wall without a skill check.

Dark Sight: The shadow elemental may see into darkness, even magical darkness, out to 120ft

Light Sensitivity: While in bright light, the Shadow Elemental has disadvantage on attack and skill rolls
and attack roles have advantage vs. the Shadow Elemental.

‘Actions:
Slam: #6 to hit, 5ft range, 2d8 +6 dmg bludgeoning

Constrict: Melee weapon attack +6 to hit, 1d6+6 necrotic damage. If the target is a large or smaller
creature, the Shadow Elemental may attempt a free grapple with advantage (grapple +6). Creatures
grappled by the Shadow Elemental are unable to breathe and begin to suffocate (p.183). As an action, a
creature within 5ft of the elemental can pull a creature so constricted out of it by succeeding on a DC 16
STR check. x

‘The shadow elemental may simultaneously constrict one large, or two medium, or four small creatures.

ShadowFire Elemental
Large Elemental, neutral evil

CR:

ACIS

HP 130

Speed: Soft

STR: 11 (+0) DEX: 18 (+4) CON: 18 (+4) INT: 14 (#2) WIS: 10 (+0) CHA 6 (-2)

Damage Immunity: Necrotic, Fire

Damage Resistance: bludgeoning, piercing, slashing from non-magical weapons

Damage Vulnerability: Radiant

Condition Immunity: exhaustion, grappled, paralyzed, petrified, poisoned, prone, restrained,
unconscious

Language: Umbral [shadow language], Ignan

Skills: Stealth +6, grapple modifier +6

MultiAttack: 2

‘Shadow Form: The elemental can move through a space as narrow as 1 inch wide without squeezing.
While in shadow, it may attempt to hide as a free action, and may move along any corporeal surface or
wall without a skill check.

Fire Form: The elemental can move through a space as narrow as 1 inch wide without squeezing. A
creature that touches the elemental or hits it with a melee attack while within 5 ft. of it takes 5 (1410)
fire damage. In addition, the elemental can enter a hostile creature's space and stop there. The first
time it enters a creature's space on a turn, that creature takes 5 (1010) fire damage and catches fire;
until someone takes an action to douse the fire, the creature takes 5 (1410) fire damage at the start of
each of its turns.

Dark Sight: The shadow elemental may see into darkness, even magical darkness, out to 120ft

Actions:

Slam: +6 to hit, Sft range, 2d8 +6 dmg fire damage
Engulf: (Recharge 4-6}: Each creature in the elemental's space must make a DC 15 Strength saving
throw. Ona failure, a target takes 13 (2d8 + 4) fire damage. If it is Large or smaller, itis also Grappled
(escape DC 14). Until this grapple ends, the target is Restrained and unable to breathe unless it can
breathe water. If the saving throw is successful, the target is pushed out of the elemental's space.

‘The elemental can grapple one Large creature or up to two Medium or smaller creatures at one time. At
the start of each of the elemental's turns, each target Grappled by it takes 13 (2d8 + 4) bludgeoning
damage. A creature within 5 feet of the elemental can pull a creature or object out of it by taking an
action to make a DC 14 Strength and succeeding.

Lightening Elemental
Large elemental, neutral

‘Armor Class 13.
Hit Points 102 (12d10 + 36)
‘Speed 07, fly 90 t. (hover)

STR DEX = CON sINT- WIS HA
10 (+0) 20(45) 16(43) 6{-2) 1040) 7(-2)

Damage Resistances bludgeoning, piercing, and slashing from nonmagical attacks
Damage Immunities lightning, thunder, poison

Condition Immunities exhaustion, grappled, paralyzed, petrified, poisoned, prone, restrained, unconscious
‘Senses darkvision 60 ft, passive Perception 10

Languages Primordial

‘Challenge 5 (1,800 xP)

Lightning Form. The elemental can move through a space as narrow as 1 inch wide without squeezing. A creature that
‘touches the elemental or hits it with a melee attack while within 5 feet of it takes 5 (1010) lightning damage. In addition,
the elemental can enter a hostile creature's space and stop there. The first time it enters a creature's space on a tum,
‘that creature takes 5 (1410) lightning damage and must make a DC13 Constitution saving throw or be stunned until the
end of its next turn or until it takes damage.

‘Mlumination. The elemental sheds bright light in a 10-foot radius and dir light in an additional 30 feet.

ACTIONS

‘Multiottack. The elemental makes two arch attacks.

‘Arch. Melee Weapon Attack: 48 to hit, reach 10 ft, one target. Hit: 14 (2d8 + 5) lightning damage.

‘Stormwave (Recharge 4-6). Each creature in the elemental's space must make a DC 13 Constitution saving throw. On a
failure, a target takes 15 (3d8 +2) lightning damage and is paralysed until the end of its next turn or until it takes
damage.

If the saving throw is successful, the target takes half the lightning damage and isn’t paralysed

From <https://wwaw.dandwik.com/viki/lightning Elemental (Se Creaturel>

Fire Elemental
Large elemental, neutral

Armor Class 13

Hit Points 102 (12410436)

Speed 50 ft.
‘STR10 (+0) DEX 17 (+3) CON16 (+3)INTS (-2)WIS10 (+0}CHA7 (-2)

Damage Resistance Bludgeoning, Piercing, and Slashing From Nonmagical
Attacks

Damage Immunities Fire, Poison

Condition Immunities Exhaustion, Grappled, Paralyzed, Petrified, Poisoned,
Prone, Restrained, Unconscious

Senses Darkvision 60 Ft,, passive Perception 10
Languages Ignan

Challenge 5 (1,800 XP)

Fire Form. The elemental can move through a space as narrow as 1 inch wide
‘without squeezing. A creature that touches the elemental or hits it with a melee
attack while within 5 ft. of it takes 5 (1410) fire damage. In addition, the
elemental can enter a hostile creature's space and stop there. The first time it
enters a creature's space on a turn, that creature takes 5 (1410) fire damage
and catches fire; until someone takes an action to douse the fire, the creature
takes 5 (1410) fire damage at the start of each of its turns.

Mumination. The elemental sheds bright light in a 30-foot radius and dim light
in an additional 30 ft..

Water Susceptibility. For every 5 ft. the elemental moves in water, or for every
gallon of water splashed on it, it takes 1 cold damage.

Actions

Multiattack. The elemental makes two touch attacks.

Touch. Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: (206 + 3)
fire damage. If the target is a creature or a flammable object, it ignites. Until a
creature takes an action to douse the fire, the target takes 5 (110) fire damage
at the start of each of its turns

From <https://app roll20.net/compendium/dndSe/Firest20Elementalih-Fire%420Elemental>

Light Elemental
Large elemental, neutral good
Armor Class 15

Hit Points 90 (12410 + 24)
Speed Off, fly 90 t. (hover)

STR DEX CON INT WIS CHA
14 (42) 20(45) 14(42) 6(-2)  10(#0) 6 (-2)

Damage Resistances lightning, thunder; bludgeoning, piercing, and slashing from nonmagical weapons
Damage Immunities poison

Condition Immunities exhaustion, grappled, paralyzed, petrified, poisoned, prone, restrained,
unconscious

‘Senses darkvision 60ft,, passive perception 10

Languages —

Challenge 5 (1800 XP)

Light Form. The elemental can move through a space as narrow as 1 inch wide without squeezing. It
can enter a hostile creature's space and stop there.

‘Mumination. The elemental sheds bright light in a 60-foot radius and dim light an additional 30 feet.
ACTIONS

‘Multiattack. The elemental makes two slam attacks

Slam. Melee Weapon Attack: +8 to hit, reach 5 ft,, one target. Hit: 1d8 + 5 bludgeoning damage + 1D12
Radiant damage

Illuminating Discharge (recharge 5-6): The elemental glows in blinding light. All creatures with 15ft must
make a DC14 DEX save or be blinded until the end of the elemental's next turn, and take 1D12 radiant
damage.

#### ChatGPT Output:
# Shadow Warrior - Dragon Born
**CR:** 5

**AC:** 18

**HP:** 80

**Speed:** 30ft

**Attributes:**
- **STR:** 15 (+2)
- **DEX:** 12 (+1)
- **CON:** 14 (+2)
- **INT:** 11 (+0)
- **WIS:** 14 (+2)
- **CHA:** 16 (+3)

**Skills:**
- Athletics +8
- Perception +6
- Stealth +6
- Deception +6
- Intimidate +4

**Traits:**
- **Shadow Faith:** Adds CHA score to hit (in stats), and adds 1d6 necrotic damage on damage rolls

**Actions:**
- **Multi-attack:** 2
- **Longsword:** +8 to hit, 1d8/1d10+5
- **Shortsword:** +8 to hit, 1d6+5
- **Crossbow:** +8 to hit, 1d10+4
- **Shadow Step:** (recharge: 5-6) The cultist magically teleports, along with any equipment it is wearing or carrying, up to 40 ft. to an unoccupied space it can see. It may make a single attack on an adjacent creature

# Shadow Warlock - Dragon Born
**CR:** 6

**AC:** 16

**HP:** 50

**Speed:** 30ft

**Attributes:**
- **STR:** 10 (+0)
- **DEX:** 12 (+1)
- **CON:** 12 (+1)
- **INT:** 12 (+1)
- **WIS:** 11 (+0)
- **CHA:** 18 (+4)

**Skills:**
- Deception +4
- Persuasion +4
- Arcane +4
- Religion +2
- Stealth +4
- Deception +4

**Resistance:**
- Necrotic, Lightning

**Traits:**
- **Dark Devotion:** Advantage vs. charmed or frightened
- **Pact of the Blade:** Shadow Reaping Scythe (+1d8 necrotic damage on weapon hit)
- **Boons:**
  - **Armor of Shadows:** Free mage armor as a bonus action -> AC15
  - **Dark One's Luck:** Once per rest, may add 10 to an ability check or saving throw rolls' total.
  - **Thirsting Blade:** You gain +1 attacks when you attack with your pact weapon

**Actions:**
- **Reaper's blade:** +5 to hit, 1d8+5 + 1d8 necrotic

**Spellcasting:** 7th level spell-caster, Spell Save DC 15, +6 to hit with spell attacks

**Spell Slots:**
- **Spells Known:** 6

**Cantrips:**
- Chill touch
- Blade Ward
- Eldritch Blast

**Spells:**
- **Level 4:**
  - [Confusion](https://app.roll20.net/compendium/dnd5e/Confusion#content)
  - [Black Tentacles](https://app.roll20.net/compendium/dnd5e/Black%20Tentacles#content)

- **Level 3:**
  - [Vampiric Touch](https://app.roll20.net/compendium/dnd5e/Vampiric%20Touch#content)
  - [Shatter](https://app.roll20.net/compendium/dnd5e/Shatter#content)
  - [Darkness](https://app.roll20.net/compendium/dnd5e/Darkness#content)
  - [Ray of Enfeeblement](https://app.roll20.net/compendium/dnd5e/Ray%20of%20Enfeeblement#content)

- **Level 1:**
  - [Hellish Rebuke](https://app.roll20.net/compendium/dnd5e/Hellish%20Rebuke#content)
  - [Shield](https://app.roll20.net/compendium/dnd5e/Spells:Shield/#h-Shield)

# Eternal Flame Priest
**Type:** Medium humanoid (human), neutral evil

**Armor Class:** 12 (15 with mage armor)

**Hit Points:** 52 (8d8+16)

**Speed:** 30ft.

**Attributes:**
- **STR:** 12 (+1)
- **DEX:** 15 (+2)
- **CON:** 14 (+2)
- **INT:** 10 (+0)
- **WIS:** 11 (+0)
- **CHA:** 16 (+3)

**Damage Resistances:** Fire

**Skills:**
- Deception +5
- Intimidation +5
- Religion +2

**Languages:** Common, Ignan

**Challenge:** 3 (700 XP)

**Spellcasting:** The priest is a 5th-level spellcaster. Its spellcasting ability is Charisma (spell save DC 15, +5 to hit with spell attacks). It knows the following sorcerer spells:

**Cantrips (at will):**
- Control flames
- Create bonfire
- Fire bolt
- Light
- Minor illusion

**1st level (4 slots):**
- Burning hands
- Expeditious retreat
- Mage armor

**2nd level (3 slots):**
- Blur
- Scorching ray

**3rd level (2 slots):**
- Fireball

**Actions:**
- **Dagger:** Melee or Ranged Weapon Attack: +4 to hit, reach 5 ft. or range 20/60 ft., one target. Hit: 4 (1d4+2) piercing damage

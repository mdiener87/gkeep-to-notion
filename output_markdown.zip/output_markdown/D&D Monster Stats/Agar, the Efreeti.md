# Agar, the Efreeti

    **Created:** 2021-10-29 11:25:40  
    **Last Edited:** 2021-10-29 11:25:45  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Agar, the Efreeti
Large elemental, awful evil

Armor Class 17 (Natural Armor)
Hit Points 250 (16d10+112)

Speed 40 ft, fly 60 ft.
STR
22.46) DEX 12 (+1) CON24 (+7) INT16 (+3) WIS 15 (+2) CHA 16 (+3)
‘Saving Throws Int +7, Wis +6, Cha +7

Damage Immunities Fire
‘Senses Darkvision 120 Ft,, passive Perception 12

Languages Ignan

Challenge 11 (7,200 XP}

Elemental Demise. if the efreeti dies, its body disintegrates in a flash of fire and puff of smoke, leaving behind only
equipment the djinni was wearing or carrying.

Innate Spelicasting. The efreeti's innate spell casting ability is Charisma (spell save DC 15, +7 to hit with spell attacks). It
can innately cast the following spells, requiring no material components:

3/day: enlarge/reduce, tongues, dispel magic (Sth level)
1/day each: conjure elemental (fire elemental only), gaseous form, invisibility, major image, plane shift, wall of fire,
counterspell (5th Ivel)

Variant: Genie Powers. Genies have a variety of magical capabilities, including spells. A few have even greater powers
that allow them to alter their appearance or the nature of reality.

Multiattack. Agar makes two broadsword attacks or uses its Hur! Flame twice,

Molten Blade . Melee Weapon Attack: +12 to hit, reach 10 ft,, one target. Hit: (208 + 8) slashing damage plus (2d6) fire
damage. Target's struck by this are also affected by Dispel Magic as a 5th level spell.

Hurl Flame. Ranged Spell Attack: +7 to hit, reach 120 ft, one target. Hit: (Sd6) fire damage.

From <https://app rolI20.net/compendium/dndSe/Efreetith-Efreeti>

Fire Elemental
Large elemental, neutral
+ Armor Class 13
* Hit Points 102 (12d10+36)
+ Speed so ft.
‘STR10 (+0) DEX 17 (+3) CON16 (+3)INTS (-2)WIS10 (+0}CHA7 (-2)

* Damage Resistance Bludgeoning, Piercing, and Slashing From Nonmagical
Attacks

= Damage immu

* Condition Immunities Exhaustion, Grappled, Paralyzed, Petrified, Poisoned,
Prone, Restrained, Unconscious

ies Fire, Poison

* Senses Darkvision 60 Ft,, passive Perception 10

* Languages ignan

* Challenge 5 (1,800 XP)

"Fire Form. The elemental can move through a space as narrow as 1 inch wide
without squeezing. A creature that touches the elemental or hits it with a melee
attack while within 5 ft. of it takes 5 (1410) fire damage. In addition, the
elemental can enter a hostile creature's space and stop there. The first time it
enters a creature's space on a turn, that creature takes 5 (1410) fire damage
and catches fire; until someone takes an action to douse the fire, the creature
takes 5 (1410) fire damage at the start of each of its turns.

+ iHlumination. The elemental sheds bright light in a 30-foot radius and dim light
in an additional 30 ft..

* Water Susceptibility. For every 5 ft. the elemental moves in water, or for every
gallon of water splashed on it, it takes 1 cold damage.

Actions

"| Multiattack. The elemental makes two touch attacks.

* Touch, Melee Weapon Attack: +6 to hit, reach 5 ft,, one target. Hit: (246+ 3)
fire damage. If the target is a creature or a flammable object, it ignites. Until a
creature takes an action to douse the fire, the target takes 5 (110) fire damage
at the start of each of its turns

From <https://app rolI20.net/compendium/dndSe/Firest20Elementalih-Fire%420Elemental>

Enlage/Reduce https://app.roll20.net/compendium/dnd5e/Spells:Enlarge%20Reduce#content
Gaseous Form https://app.roll20.net/compendium/dnd5e/Gaseous%20Formi#h-Gaseous%20Form
Invisibility https://app.roli20.net/compendium/dndSe/invisibilitys#th-Invisibility

Major Image https://app.roll20.net/compendium/dndSe/Major%20Imageith-Major%20Image
Wall of Fire https://app.roll20.net/compendium/dndSe/Wall%200f%620Fire#h-Wall%4200f%20Fire

Dispel Magic https://app.roll20.net/compendium/dndSe/Dispel%20Magicith-Dispel%20Magic
Counter Spell: https://app.roli20.net/compendium/dndSe/Counterspellith-Counterspell

‘Agar's Blade of Molten Magi
+3 Great sword, heavy (2d6 slashing + 3), Reach {10ft)
Does an additional 246 fire damage on hit

Magical items struck by this weapon are automatically subjected to Dispel Magic as a 3rd level spell.
Magical items repeatedly struck by this weapon will become increasingly vulnerable to this Dispel Magic
effect, as follows:
= 3 Impacts: Roll with advantage on the Dispel Magic effect
+ 6 impacts: Items and effects normally immune to Dispel Magic lose that immunity to this
weapon's Dispel Magic effect
= 9 Impacts: Automatic success on the Dispel Magic attempt

‘The blade has one CounterMagic charge that recharges daily at dawn. You may use this charge to cast
Counter Spell as 3rd level spell as a reaction,

#### ChatGPT Output:
# Agar, the Efreeti
**Large elemental, awful evil**

- **Armor Class** 17 (Natural Armor)
- **Hit Points** 250 (16d10+112)
- **Speed** 40 ft, fly 60 ft.

**STR** 22 (+6) **DEX** 12 (+1) **CON** 24 (+7) **INT** 16 (+3) **WIS** 15 (+2) **CHA** 16 (+3)

- **Saving Throws** Int +7, Wis +6, Cha +7
- **Damage Immunities** Fire
- **Senses** Darkvision 120 Ft., passive Perception 12
- **Languages** Ignan
- **Challenge** 11 (7,200 XP)

**Elemental Demise.** If the efreeti dies, its body disintegrates in a flash of fire and puff of smoke, leaving behind only equipment the efreeti was wearing or carrying.

**Innate Spellcasting.** The efreeti's innate spellcasting ability is Charisma (spell save DC 15, +7 to hit with spell attacks). It can innately cast the following spells, requiring no material components:
- 3/day: enlarge/reduce, tongues, dispel magic (5th level)
- 1/day each: conjure elemental (fire elemental only), gaseous form, invisibility, major image, plane shift, wall of fire, counterspell (5th level)

**Variant: Genie Powers.** Genies have a variety of magical capabilities, including spells. A few have even greater powers that allow them to alter their appearance or the nature of reality.

**Multiattack.** Agar makes two broadsword attacks or uses its Hurl Flame twice.

**Molten Blade.** Melee Weapon Attack: +12 to hit, reach 10 ft., one target. Hit: (2d8 + 8) slashing damage plus (2d6) fire damage. Targets struck by this are also affected by Dispel Magic as a 5th level spell.

**Hurl Flame.** Ranged Spell Attack: +7 to hit, reach 120 ft, one target. Hit: (5d6) fire damage.

From <https://app.roll20.net/compendium/dnd5e/Efreeti#content>

# Fire Elemental
**Large elemental, neutral**
- **Armor Class** 13
- **Hit Points** 102 (12d10+36)
- **Speed** 50 ft.

**STR** 10 (+0) **DEX** 17 (+3) **CON** 16 (+3) **INT** 5 (-2) **WIS** 10 (+0) **CHA** 7 (-2)

- **Damage Resistance** Bludgeoning, Piercing, and Slashing From Nonmagical Attacks
- **Damage Immunities** Fire, Poison
- **Condition Immunities** Exhaustion, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained, Unconscious
- **Senses** Darkvision 60 Ft., passive Perception 10
- **Languages** Ignan
- **Challenge** 5 (1,800 XP)

**Fire Form.** The elemental can move through a space as narrow as 1 inch wide without squeezing. A creature that touches the elemental or hits it with a melee attack while within 5 ft. of it takes 5 (1d10) fire damage. In addition, the elemental can enter a hostile creature's space and stop there. The first time it enters a creature's space on a turn, that creature takes 5 (1d10) fire damage and catches fire; until someone takes an action to douse the fire, the creature takes 5 (1d10) fire damage at the start of each of its turns.

- **Illumination.** The elemental sheds bright light in a 30-foot radius and dim light in an additional 30 ft.
- **Water Susceptibility.** For every 5 ft. the elemental moves in water, or for every gallon of water splashed on it, it takes 1 cold damage.

**Actions**

- **Multiattack.** The elemental makes two touch attacks.
- **Touch.** Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: (2d6 + 3) fire damage. If the target is a creature or a flammable object, it ignites. Until a creature takes an action to douse the fire, the target takes 5 (1d10) fire damage at the start of each of its turns.

From <https://app.roll20.net/compendium/dnd5e/Fire%20Elemental#content>

[Enlarge/Reduce](https://app.roll20.net/compendium/dnd5e/Spells:Enlarge%20Reduce#content)
[Gaseous Form](https://app.roll20.net/compendium/dnd5e/Gaseous%20Form#content)
[Invisibility](https://app.roll20.net/compendium/dnd5e/Invisibility#content)
[Major Image](https://app.roll20.net/compendium/dnd5e/Major%20Image#content)
[Wall of Fire](https://app.roll20.net/compendium/dnd5e/Wall%20of%20Fire#content)
[Dispel Magic](https://app.roll20.net/compendium/dnd5e/Dispel%20Magic#content)
[Counterspell](https://app.roll20.net/compendium/dnd5e/Counterspell#content)

# Agar's Blade of Molten Magic
**+3 Greatsword, heavy (2d6 slashing + 3), Reach 10ft**
Does an additional 2d6 fire damage on hit

Magical items struck by this weapon are automatically subjected to Dispel Magic as a 3rd level spell.
Magical items repeatedly struck by this weapon will become increasingly vulnerable to this Dispel Magic effect, as follows:
- **3 Impacts:** Roll with advantage on the Dispel Magic effect
- **6 impacts:** Items and effects normally immune to Dispel Magic lose that immunity to this weapon's Dispel Magic effect
- **9 Impacts:** Automatic success on the Dispel Magic attempt

The blade has one CounterMagic charge that recharges daily at dawn. You may use this charge to cast Counterspell as a 3rd level spell as a reaction.

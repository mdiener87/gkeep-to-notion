# Shadows Fall - Monster Notebook

    **Created:** 2021-10-29 11:24:17  
    **Last Edited:** 2021-10-29 11:24:22  
    **Labels:** D&D Items & Monster Stats, D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Shadow Warlock

cR:3.
AC 13 (AC15 w/ Spell Armor}
HP 40

Speed: 30ft

‘STR: 10 (+0) DEX: 12 (#1) CON: 12 (+1) INT: 12 (+1) WIS: 11 (+0) CHA 15 (#3)
‘Skills: Deception +4, Persuasion +4, Arcane +4, Religion +2, Stealth +4, Deception +4

Traits
Dark Devotion - advantage vs. charmed or frightened
Boon: Armor of Shadows (free mage armor as a bonus action -> AC15)

Spelleast
Spell Slots: 2

Spells Known:

Cantrips: Eldritch Blast, Blade Ward

ith level spell-caster, Spell Save DC 14, +4 to hit with spell attacks

Spelts: Darkness, Ray of Enfeeblement, Crown of Madness, Arms of Hadar, Hellish rebuke (nightmare rebuke), Shatter

Shadow Bruiser
cR3

ACB

HP: 70

Speed: 20ft

‘STR: 18 (+4) DEX: 12 (+1) CON: 18 (+4) INT: 12 (#1) WIS: 11 (+0) CHA 12 (#1)
Skills: Intimidation +5, survival +2, Religion +2

Traits
Aggressive. As a bonus action, the orog can move up to its speed toward a hostile creature that it can
see,

Shadow Grapple: The Orc has advantage on grapple attempts while both it and its victim are at least

partly covered in shadow. On shadow-grappled targets, the scythe necrotic damage increases to 2d6+2.

Actions

Multiattack 2

Dark Scythe. Melee Weapon Attack: +5 to hit, reach 10 ft,, one target. Hit
1d6 necrotic damage.

:2d6 +5 slashing damage +

Javelin, Melee or Ranged Weapon Attack: +6 to hit, reach 5 ft. or range 30/120 ft., one target. Hit: 7
(1d6 + 4) piercing damage.

Shadow citizens:
Shades {buff stats)
Shadow Demons
Hooked Horrors
Shadow Dragon Cultists
‘Wraiths (mix up stats)
Grell (pet)

Shadow Cultist
R:3

ACIS

HP 60

‘Speed: 30ft

‘STR: 12 (+1) DEX: 10 (+0) CON: 12 (+1) INT: 10 (+0) WIS: 13 (+1) CHA 14 (#2)
: Athletics + 5, Perception +2, Stealth +4, Deception +4

Action
Multi-attack: 2

Longsword +7 to hit, 1d8+3/vers/1d10+3
Shortsword: +7 to hit, 1d6+3

Crossbow: +5 to hit, 1d 1041

Shadow Faith: Adds CHA score to hit (in stats), and adds 1d6 necrotic damage

Shadow Walk: The cultist magically teleports, afong with any equipment it is wearing or carrying, up to 40 ft. to.an

unoccupied space it can see. Before or after teleporting, the cultist can make one attack.

Shadow Assassin
cR:4

ACIS

HP 70

Speed: 40ft

‘STR: 11 (+0) DEX: 16 (+3) CON: 14 (+2) INT: 13 (#1) WIS: 10 (+0) CHA 12 (#1)

Skills: Athletics + 5, Acrobatics +5, Perception + 4, Stealth + 5, Sleight of Hand +5, Deception +4

Actions:

Multi-attack: 2

Shortsword: +5 to hit, 146+3 piercing damage

‘Wrist Crossbow: +5 to hit, 14843 piercing damage

Poisoned Weapons: On hit, target must make a DC15 CON saving throw or take 2d6 poison damage, half
as much on save.

Assassinate: During its first turn, the assassin has advantage on attack rolls against any target that hasn't,
taken a turn. Any hit scored this way counts as a critical hit.

Evasion: takes no damage on successful reflex saves

‘Sneak Attack: Once per turn, With advantage on attack or ally within 5 ft of target and attacking w/o
disadvantage, deal an additional 3d6 damage with its weapon attack.

Shadow Elemental
Large Elemental, neutral evil

CR:6

ACIS

HP 130

Speed: Soft

‘STR: 11 (+0) DEX: 18 (+4) CON: 18 (+4) INT: 14 (#2) WIS: 10 (+0) CHA 6 (-2)

Damage Immunity: Necrotic, Fire

Damage Resistance: bludgeoning, piercing, slashing from non-magical weapons

Damage Vulnerability: Radiant

Condition Immunity: exhaustion, grappled, paralyzed, petrified, poisoned, prone, restrained, unconscious
Language: Umbral [shadow language]

Skills: Stealth +6, grapple modifier +6

Multiattack: 2

‘Shadow Form: The elemental can move through a space as narrow as 1 inch wide without squeezing. While in
shadow, it may attempt to hide as a free action, and may move along any corporeal surface or wall without a
skill check.

Dark Sight: The shadow elemental may see into darkness, even magical darkness, out to 120ft

Light Sensitivity: While in bright light, the Shadow Elemental has disadvantage on attack and skill rolls and
attack roles have advantage vs. the Shadow Elemental.

Actions:
Slam: #6 to hit, 5ft range, 2d8 +6 dmg bludgeoning

Constrict: Melee weapon attack +6 to hit, 1d6+6 necrotic damage. If the target is a large or smaller creature,
the Shadow Elemental may attempt a free grapple with advantage (grapple +6). Creatures grappled by the
Shadow Elemental are unable to breathe and begin to suffocate (p.183). As an action, a creature within 5ft of

the elemental can pull a creature so constricted out of it by succeeding on a DC 16 STR check.

‘The shadow elemental may simultaneously constrict one large, or two medium, or four small creatures.

#### ChatGPT Output:
❌ API request timed out after 30 seconds
# Narzugon, Brathrizard

    **Created:** 2021-10-29 11:36:57  
    **Last Edited:** 2021-10-29 11:37:04  
    **Labels:** D&D 2020, D&D Items & Monster Stats  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
ttps://www.dndbeyond.com/monsters/narzugon

Narzugon 's Name: Brarthrizad
Scared of: The Phoenix. A spirit of firey redemption, Brathrizad corrupted and defiled a Phoenix as part of his fall from
the royal order of Paladins over 200 years ago. A devil bent on corrupting the Kingdom, the Narzugon Brathrizad is highly
capable, purely evil, and willing to make logical pacts with other forces to further his evil will.

is original pact with the Dragon Cult is still in effect - he made a deal with the Clan, not just Kaladan. He intends to fulfil
that promise. That is, to corrupt the very best the Kingdom of Dawn has to offer and turn their own fallen soldiers
against the crown. In exchange, Kaladan offered him a magical item [roll]

‘The Drow have a natural fondness for Devils. While their methods differ somewhat, they too have found the Narzugon
an invaluable ally. He has been tasked with locating Princess Rose - in exchange, the Drow have also given him a magical
item,

Horse name: Odyssey

Improved Capabilities:
Shadowire Lance . Melee Weapon Attack: +13 to hit, reach 10 ft,, one target. Hit: 11 (1442 4 5) piercing damage plus
16 (310) fire damage plus 3d6 necrotic damage. if this damage kills a creature, the creature's soul rises from the River
Styx as a lemure in Avernus in 1d4 hours. If the creature isn’t revived before then, only a wish

spell or killing the lemure and casting true resurrection on the creature's original body can restore it to life. Constructs
and devils are immune to this effect.

Hurl Darkfire. Ranged Weapon Attack: +10 to hit, range 120ftft. one target. Hit: 16 (34410) fire damage plus 3440
necrotic damage. Creatures normally resistant to necrotic or fire damage are considered to have normal resistance
against this effect. Creatures normally immune to necrotic or fire damage are instead considered to be resistant to this
damage.1

/fegendary Resistance 1/Day - The Narzugon may choose to succeed on any saving throw it has failed.

#### ChatGPT Output:
[https://www.dndbeyond.com/monsters/narzugon](https://www.dndbeyond.com/monsters/narzugon)

**Narzugon's Name:** Brarthrizad  
**Scared of:** The Phoenix. A spirit of fiery redemption, Brarthrizad corrupted and defiled a Phoenix as part of his fall from  
the royal order of Paladins over 200 years ago. A devil bent on corrupting the Kingdom, the Narzugon Brarthrizad is highly  
capable, purely evil, and willing to make logical pacts with other forces to further his evil will.

His original pact with the Dragon Cult is still in effect - he made a deal with the Clan, not just Kaladan. He intends to fulfill  
that promise. That is, to corrupt the very best the Kingdom of Dawn has to offer and turn their own fallen soldiers  
against the crown. In exchange, Kaladan offered him a magical item [roll]

‘The Drow have a natural fondness for Devils. While their methods differ somewhat, they too have found the Narzugon  
an invaluable ally. He has been tasked with locating Princess Rose - in exchange, the Drow have also given him a magical  
item,

**Horse name:** Odyssey

**Improved Capabilities:**
- **Shadowfire Lance**  
  Melee Weapon Attack: +13 to hit, reach 10 ft., one target. Hit: 11 (1d8+4+5) piercing damage plus  
  16 (3d10) fire damage plus 3d6 necrotic damage. If this damage kills a creature, the creature's soul rises from the River  
  Styx as a lemure in Avernus in 1d4 hours. If the creature isn’t revived before then, only a wish  
  spell or killing the lemure and casting true resurrection on the creature's original body can restore it to life. Constructs  
  and devils are immune to this effect.

- **Hurl Darkfire**  
  Ranged Weapon Attack: +10 to hit, range 120 ft., one target. Hit: 16 (3d10+10) fire damage plus 3d10  
  necrotic damage. Creatures normally resistant to necrotic or fire damage are considered to have normal resistance  
  against this effect. Creatures normally immune to necrotic or fire damage are instead considered to be resistant to this  
  damage.

- **Legendary Resistance 1/Day**  
  The Narzugon may choose to succeed on any saving throw it has failed.

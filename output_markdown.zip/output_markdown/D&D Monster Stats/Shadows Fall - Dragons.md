# Shadows Fall - Dragons

    **Created:** 2021-10-29 11:27:55  
    **Last Edited:** 2021-10-29 11:28:00  
    **Labels:** D&D Items & Monster Stats, D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Savaran Orexijandilin (Or-eh-an-Dehy-len}

‘Adult Blue Shadow Dragon; Huge Creature, over 500 years old
AC: 19

HP: 300

‘Speed: 40ft, burrow 30ft, fly Soft

‘STR: 25 (+7) DEX: 10 (+0) CON: 23 (+6) INT: 16 (+3) WIS: 15 (#2) CHA 19 (+4)
Saves: Dex #5, Con +11, Wis +7, CHA +9

Skills: Perception #12, stealth +10

Damage Immunity: Necrotic

Damage Resistance: Lightening

‘Senses: blind sight 60ft, dark vision 120ft, passive perception 22
Languages: Common, Draconic

Legendary Resistance: 3/Day (can chose to succeed on a fail)

rightful Presence Then 3x attacks (bite, 2x claws)
Bite: +12 hit, reach 10ft, 241247 + 1d10 necrotic.

Claw: +12 to hit, reach Sft, 24847 slashing

Tail: +12 to hit, reach 15ft, 241047 bludgeoning

Spell Actions:

Frightful Presence

Each creature within 120ft that dragon targets must make DC17 wisdom saving throw or become frightened for one
minute. A creature can repeat saving throw at the end of their turn, ending the effect on a success. Immune for 24hours
after save.

Shadow Breath:

Recharge (5-6): 30ft cone attack. DC18 Dexterity saving throw, taking 16d6 necrotic on a failed save, or half on a success.

Humanoids reduced to Ohp by this damage dies, and a shadow rises from its corpse with
dragons.

ative immediately after the

Shadow Traits:

Living Shadow - While in dim light or darkness, dragon has resistance to damage that isn't force, psychic, or radiant.
Shadow Stealth: Double stealth proficiency (applied to stat block)

Sunlight Sensitivity: While in sunlight, dragon has disadvantage on attack roles and Perception checks that rely on
eyesight.

Spell actions:

‘Shadow Orb (as Chromatic Orb, 3rd level spell) - 348 lightening 3d8 necrotic x3

Legendary Actions:

‘The dragon can take 3 legendary actions, using one after another creatures tum. Gains 3 actions back after end of
round.

Detect: The dragon makes a wisdom (perception) check

Tail Attack: The dragon makes a tail attack

‘Wing Attack (2 actions}: Dragon beats its wings, forcing each creature within 10 ft to succeed on a DC20 dexterity check
or take 2d6+7 bludg, Damage and be knocked prone. The dragon can then fly up to half its lying speed.

Rezena Orexijandilin

‘Young Blue Shadow Dragon; Large creature, about 75 years old.
AC 15

HP: 180

‘Speed: 40ft, burrow 30ft, fly Soft

‘STR: 21 (#5) DEX: 10 (+0) CON: 19 (+4) INT: 14 (+2) WIS: 13 (+1) CHA 17 (+3)
Saves: Dex +4, Con +8, Wis +5, CHA +7

Skills: Perception #12, stealth +10

Damage Immunity: Necrotic

Damage Resistance: Lightening

‘Senses: blind sight 60ft, dark vision 120ft, passive perception 22
Languages: Common, Draconic

: Frightful Presence Then 3x attacks (bite, 2x claws or tail + bite at opposing targets)
Bite: +9 hit, reach 10ft, 2410+5 + 1410 necrotic

Claw: +9 to hit, reach Sft, 2d6+5 slashing

Tail: +9 to hit, reach 15ft, 24845 bludgeoning

Spell Actions:

Frightful Presence

Each creature within 120ft that dragon targets must make DC15 wisdom saving throw or become
frightened for one minute. A creature can repeat saving throw at the end of their turn, ending the effect
ona success. Immune for 24hours after save.

Shadow Breath:
Recharge (5-6): 30ft cone attack. DC18 Dexterity saving throw, taking 14d6 necrotic on a failed save, or
half on a success. Humanoids reduced to Ohp by this damage dies, and a shadow rises from its corpse
with initiative immediately after the dragons.

Lightening Breath:

(Recharge 5-6). The dragon exhales lightning in an 60-foot line that is 5 feet wide. Each creature in that
line must make a DC 16 Dexterity saving throw, taking 55 (10d0) lightning damage on a failed save, or
half as much damage on a successful one. Shared recharge between breath weapons.

Other:

Living Shadow - While in dim light or darkness, dragon has resistance to damage that isn't force, psychic,
or radiant.

‘Shadow Stealth: Double stealth proficiency (applied to stat block)

Sunlight Sensitivity: While in sunlight, dragon has disadvantage on attack roles and Perception checks
that rely on eyesight.

Kaladan is young by dragon standards, still new to dragoning, He is proud, arrogant, and out to make
mommy proud. This involves subjugating his own kindgoms of course, and then widening a realm tear
wide enough for the rest of the clan to join.

Kaladan Orexijandi
‘Young Blue Shadow Dragon; Large creature, about 75 years old.

AC 18

HP: 200

Speed: 40ft, burrow 30ft, fly 8xOft

‘STR: 21 (45) DEX: 10 (+0) CON: 19 (+4) INT: 14 (+2) WIS: 13 (+1) CHA 17 (+3)
Saves: Dex +4, Con +8, Wis +5, CHA +7

Skills: Perception #12, stealth +10

Damage Immunity: Necrotic, Lightening

Damage Resistance:

‘Senses: blind sight 60ft, dark vision 120ft, passive perception 22
Languages: Common, Draconic

Legendary Resistance: 1/Day (can chose to succeed on a fail)

rightful Presence Then 3x attacks (bite, 2x claws or tail + bite/claw at opposing targets)
Bite: +9 hit, reach Loft, 2d10+5 + 1410 necrotic

Claw: +9 to hit, reach Sft, 2d6+5 slashing

Tall: +9 to hit, reach 15ft, 2d8+5 bludgeoning

Spell Actions:

Frightful Presence

Each creature within 120ft that dragon targets must make DC15 wisdom saving throw or become
frightened for one minute. A creature can repeat saving throw at the end of their turn, ending the effect
ona success. Immune for 24hours after save.

‘Shadow Breath:

Recharge (5-6): 30ft cone attack. DC18 Dexterity saving throw, taking 14d6 necrotic on a failed save, or
half on a success. Humanoids reduced to Ohp by this damage dies, and a shadow rises from its corpse
with initiative immediately after the dragons.

Lightening Breath:

(Recharge 5-6). The dragon exhales lightning in an 60-foot line that is 5 feet wide. Each creature in that
line must make a DC 16 Dexterity saving throw, taking 55 (10d0) lightning damage on a failed save, or
half as much damage on a successful one. Shared recharge between breath weapons.

Other:
Living Shadow - While in dim light or darkness, dragon has resistance to damage that isn't force, psychic,
or radiant.

‘Shadow Stealth: Double stealth proficiency (applied to stat block)

Sunlight Sensitivity: While in sunlight, dragon has disadvantage on attack roles and Perception checks
that rely on eyesight.

Aether Sense - Can detect the magical aura of the Aether Flame within 30mi, and see its affects on
recent users or near where spells from it were cast

Aether Control 3/Day - Can attempt to force an opposed spellcasting ability check on the Aether Flame
spells. On success, the spell is countered, and a shockwave emanates out from the casting point of origin
in a 20ft radius. Does 2010 thunder damage to those in the blast radius, and imposes DC16 CON saving
throw or be knocked back from the blast. If failed, there is a DC16 Reflex Save to remain holding the vial
of Aether Flame.

Animate Shadow - Kaladan sends out his shadow as an independent creature. See Shadow Elemental
for stats, except it cannot constrict. Instead, it has his Claw attack x2. The living shadow has 100HP and
destroying it inflicts SOHP of damage back onto Kaladan as a feedback effect. The living shadow acts on
Kaladan's turn,

Innate Spellcasting (DC 16, +9 to hit) {Spell Recharge 6)(Bonus action)

Call Lightening x1
Darkness x3

Mirror Image x1
Chain Lightening x1

Kaladan is young by dragon standards, still new to dragoning, He is proud, arrogant, and out to make
mommy proud. This involves subjugating his own kindgoms of course, and then widening a realm tear
wide enough for the rest of the clan to join.

#### ChatGPT Output:
# Savaran Orexijandilin (Or-eh-an-Dehy-len)

**Adult Blue Shadow Dragon; Huge Creature, over 500 years old**  
AC: 19  
HP: 300  
Speed: 40ft, burrow 30ft, fly 80ft  

**Attributes:**
- STR: 25 (+7)
- DEX: 10 (+0)
- CON: 23 (+6)
- INT: 16 (+3)
- WIS: 15 (+2)
- CHA 19 (+4)

**Saves:**
- Dex +5
- Con +11
- Wis +7
- CHA +9

**Skills:**
- Perception +12
- Stealth +10

**Damage Immunity:** Necrotic  
**Damage Resistance:** Lightning  

**Senses:**
- Blindsight 60ft
- Dark vision 120ft
- Passive perception 22

**Languages:** Common, Draconic  

**Legendary Resistance:** 3/Day (can choose to succeed on a fail)  

**Attack Options:**
- Frightful Presence  
- Then 3x attacks (bite, 2x claws)
  - Bite: +12 to hit, reach 10ft, 2d12 + 7 + 1d10 necrotic.
  - Claw: +12 to hit, reach 5ft, 2d8 + 7 slashing
  - Tail: +12 to hit, reach 15ft, 2d10 + 7 bludgeoning

**Spell Actions:**

**Frightful Presence**  
Each creature within 120ft that dragon targets must make DC17 wisdom saving throw or become frightened for one minute. A creature can repeat saving throw at the end of their turn, ending the effect on a success. Immune for 24 hours after save.

**Shadow Breath:**  
Recharge (5-6): 30ft cone attack. DC18 Dexterity saving throw, taking 16d6 necrotic on a failed save, or half on a success. Humanoids reduced to 0hp by this damage dies, and a shadow rises from its corpse with initiative immediately after the dragon.

**Shadow Traits:**
- **Living Shadow** - While in dim light or darkness, dragon has resistance to damage that isn't force, psychic, or radiant.
- **Shadow Stealth:** Double stealth proficiency (applied to stat block)
- **Sunlight Sensitivity:** While in sunlight, dragon has disadvantage on attack roles and Perception checks that rely on eyesight.

**Spell actions:**
- **Shadow Orb** (as Chromatic Orb, 3rd level spell) - 3d8 lightning + 3d8 necrotic x3

**Legendary Actions:**
The dragon can take 3 legendary actions, using one after another creature's turn. Gains 3 actions back after end of round.

- **Detect:** The dragon makes a wisdom (perception) check
- **Tail Attack:** The dragon makes a tail attack
- **Wing Attack (2 actions):** Dragon beats its wings, forcing each creature within 10 ft to succeed on a DC20 dexterity check or take 2d6+7 bludgeoning Damage and be knocked prone. The dragon can then fly up to half its flying speed.

# Rezena Orexijandilin

**Young Blue Shadow Dragon; Large creature, about 75 years old.**  
AC: 15  
HP: 180  
Speed: 40ft, burrow 30ft, fly 80ft  

**Attributes:**
- STR: 21 (+5)
- DEX: 10 (+0)
- CON: 19 (+4)
- INT: 14 (+2)
- WIS: 13 (+1)
- CHA 17 (+3)

**Saves:**
- Dex +4
- Con +8
- Wis +5
- CHA +7

**Skills:**
- Perception +12
- Stealth +10

**Damage Immunity:** Necrotic  
**Damage Resistance:** Lightning  

**Senses:**
- Blindsight 60ft
- Dark vision 120ft
- Passive perception 22

**Languages:** Common, Draconic  

**Attack Options**:
- Frightful Presence  
- Then 3x attacks (bite, 2x claws or tail + bite at opposing targets)
  - Bite: +9 to hit, reach 10ft, 2d10+5 + 1d10 necrotic
  - Claw: +9 to hit, reach 5ft, 2d6+5 slashing
  - Tail: +9 to hit, reach 15ft, 2d8+5 bludgeoning

**Spell Actions:**

**Frightful Presence**  
Each creature within 120ft that dragon targets must make DC15 wisdom saving throw or become frightened for one minute. A creature can repeat saving throw at the end of their turn, ending the effect on a success. Immune for 24 hours after save.

**Shadow Breath:**  
Recharge (5-6): 30ft cone attack. DC18 Dexterity saving throw, taking 14d6 necrotic on a failed save, or half on a success.

**Lightning Breath:**  
(Recharge 5-6). The dragon exhales lightning in a 60-foot line that is 5 feet wide. Each creature in that line must make a DC 16 Dexterity saving throw, taking 55 (10d10) lightning damage on a failed save, or half as much damage on a successful one.

**Other Traits:**
- **Living Shadow** - While in dim light or darkness, dragon has resistance to damage that isn't force, psychic, or radiant.
- **Shadow Stealth:** Double stealth proficiency (applied to stat block)
- **Sunlight Sensitivity:** While in sunlight, dragon has disadvantage on attack roles and Perception checks that rely on eyesight.
- **Aether Sense** - Can detect the magical aura of the Aether Flame within 30mi, and see its affects on recent users or where spells from it were cast
- **Aether Control 3/Day** - Can attempt to force an opposed spellcasting ability check on the Aether Flame spells. On success, the spell is countered, and a shockwave emanates out from the casting point of origin in a 20ft radius. Does 2d10 thunder damage to those in the blast radius, and imposes DC16 CON saving throw. If failed, there is a DC16 Reflex Save to remain holding the vial of Aether Flame.

**Animate Shadow** - Kaladan sends out his shadow as an independent creature. See Shadow Elemental for stats, except it cannot constrict. Instead, it has his Claw attack x2. The living shadow has 100HP and destroying it inflicts 50HP of damage back onto Kaladan as a feedback effect. The living shadow acts on Kaladan's turn,

**Innate Spellcasting (DC 16, +9 to hit) (Spell Recharge 6)(Bonus action):**
- **Call Lightning x1**
- **Darkness x3**
- **Mirror Image x1**
- **Chain Lightning x1**

Kaladan is young by dragon standards, still new to dragoning. He is proud, arrogant, and out to make mommy proud. This involves subjugating his own kingdoms of course, and then widening a realm tear wide enough for the rest of the clan to join.

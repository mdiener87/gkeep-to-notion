# Shadows Fall - Kaladan

    **Created:** 2021-10-29 11:28:08  
    **Last Edited:** 2021-10-29 11:28:13  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Well we postponed this fight for 3 weeks and | never actually wrote anything in this tab. So its time to
set up some notes about this fight.

Derick has built a big arena to fight the dragon in! Sick! Will be awesome to have some additional stage
props to set the scene.

This is the biggest boss fight in the campaign. Kaldan needs to have an ace up his sleeve (or two) in
addition to his Lair bonuses. He has now ransacked the Kingodm and taken the thrown, he surely has
found an awesome magical item or two in there to bolster his fighting chances.
Result: He has found the Grimoire of Shadow and can innately cast spells from it as long asit is on
his person. Heavy hits could cause him to drop this book in combat.

He also has prepared to meet the Aether Flame in combat. He knows the players are using it and
wielding it. That they were foolish enough to bring the Flame to the Prismatic Crystal for him only aids
his cause,

Kaladan also has his mommy there to help him. Her immense head tries to fit through the shadow realm
on Initiative 20, If she succeeds, she can use her breath weapon or bite attack on nearby targets.
Dispelling the Prismatic Crystal successfully (8th level spell) will close the realm tear enough where she
can't do this any longer.

Kaldan will have troops arriving as backup. These are freshly born dragonborn and have less stats (1/3
hp, -3 AC, -2 to hit), but are eager to protect ‘daddy’. At end of each round, there is a 33% another baby
dragonling joins the fight unless the tunnels are somehow sealed (see dericks model);

Kaladan has a large number of concubines scattered around the room. They are drunk on dragon magic
and eager to protect their master (see yuan-ti pureblood for stats). No real attack but can grapple.

Result:

= BING fight

- Players engaged in combat with the dragonborn, Kaladan, Mommy's Head, and even the
concubines

-  Asathra killed a bunch of dragon concubines

-  Kaladan and mommy attacked with ranged attacks for a while

- Bob Ross banished mommy's head back to the shadow plane for a few turns

-  Kaladan went for the Aether Flame on Ayden several times but couldn't get it

- Dore flew up on his broom and shoved the polymorphed wurm up into Kaladans asshole with a
nat20 role, inflicting 64 damage and spanwing the wurm directly on top of himself

-  Elryiss was temporarily consumed by the wurm

- Dore got stung by the wurm, but his heroe's feast prevented the poison damage

Mommy is trying to get back through the portal. Who will win this fight?

Kaladan Tactics:

Kaladan knows better than to get into melee range against Dore again. He wants to blast the party with
spells and lightening breath weapons until they are softened up. He could also burrow underground for
surprise maneuvers against the party.

Kaladan has the Shadow orb in effect (party did not find), granting him +2 AC and +100HP. He also has
his lair and legendary creature actions.

If Kaladan can rest control of the Aether Flame, he will use it to complete the realm tear and open a hole
to the shadow realm. This realm tear would be considered permeant unless it can be disrupted by
another type-S abil

‘Young Desert Wurm / Polymorphed rat:

Not sure how this is going to play out. There is no way kaladan is interested in eating a rat. He gorges
himself on fine cows, sheep, and humans. A rat is beneath his dignity. But it might get blapped with a
spell and turn back into a wurm...

‘The wurm will roll to decide its action.

0-23: Flee underground and attempt to escape. May defend itself depending.

34-80: attack anything and everything; rampage mode

81-99: call for help. This will summon mommy wurm after 1D6+2 rounds. After calling for help, it will
defend itself but not rampage

‘Warm Up fight song:

https;

/waww.youtube.com/watch?v=4-1 swBMOB4

#### ChatGPT Output:
‘Well we postponed this fight for 3 weeks and | never actually wrote anything in this tab. So it's time to
set up some notes about this fight.

Derick has built a big arena to fight the dragon in! Sick! Will be awesome to have some additional stage
props to set the scene.

This is the biggest boss fight in the campaign. Kaldan needs to have an ace up his sleeve (or two) in
addition to his Lair bonuses. He has now ransacked the Kingdom and taken the throne, he surely has
found an awesome magical item or two in there to bolster his fighting chances.
Result: He has found the Grimoire of Shadow and can innately cast spells from it as long as it is on
his person. Heavy hits could cause him to drop this book in combat.

He also has prepared to meet the Aether Flame in combat. He knows the players are using it and
wielding it. That they were foolish enough to bring the Flame to the Prismatic Crystal for him only aids
his cause,

Kaladan also has his mommy there to help him. Her immense head tries to fit through the shadow realm
on Initiative 20. If she succeeds, she can use her breath weapon or bite attack on nearby targets.
Dispelling the Prismatic Crystal successfully (8th level spell) will close the realm tear enough where she
can't do this any longer.

Kaldan will have troops arriving as backup. These are freshly born dragonborn and have less stats (1/3
hp, -3 AC, -2 to hit), but are eager to protect ‘daddy’. At the end of each round, there is a 33% chance another baby
dragonling joins the fight unless the tunnels are somehow sealed (see Derick's model);

Kaladan has a large number of concubines scattered around the room. They are drunk on dragon magic
and eager to protect their master (see yuan-ti pureblood for stats). No real attack but can grapple.

Result:

- BIG fight
- Players engaged in combat with the dragonborn, Kaladan, Mommy's Head, and even the
concubines
- Asathra killed a bunch of dragon concubines
- Kaladan and mommy attacked with ranged attacks for a while
- Bob Ross banished mommy's head back to the shadow plane for a few turns
- Kaladan went for the Aether Flame on Ayden several times but couldn't get it
- Dore flew up on his broom and shoved the polymorphed wurm up into Kaladan's asshole with a
nat20 roll, inflicting 64 damage and spawning the wurm directly on top of himself
- Elryiss was temporarily consumed by the wurm
- Dore got stung by the wurm, but his hero's feast prevented the poison damage

Mommy is trying to get back through the portal. Who will win this fight?

Kaladan Tactics:

Kaladan knows better than to get into melee range against Dore again. He wants to blast the party with
spells and lightning breath weapons until they are softened up. He could also burrow underground for
surprise maneuvers against the party.

Kaladan has the Shadow orb in effect (party did not find), granting him +2 AC and +100HP. He also has
his lair and legendary creature actions.

If Kaladan can wrest control of the Aether Flame, he will use it to complete the realm tear and open a hole
to the shadow realm. This realm tear would be considered permanent unless it can be disrupted by
another type-S ability

‘Young Desert Wurm / Polymorphed rat:

Not sure how this is going to play out. There is no way Kaladan is interested in eating a rat. He gorges
himself on fine cows, sheep, and humans. A rat is beneath his dignity. But it might get blapped with a
spell and turn back into a wurm...

‘The wurm will roll to decide its action.

0-23: Flee underground and attempt to escape. May defend itself depending.
34-80: attack anything and everything; rampage mode
81-99: call for help. This will summon mommy wurm after 1D6+2 rounds. After calling for help, it will
defend itself but not rampage

‘Warm Up fight song:

https://www.youtube.com/watch?v=4-1swBMOB4

# Rupert, the Unchained

    **Created:** 2021-10-29 11:18:03  
    **Last Edited:** 2021-10-29 11:18:13  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Rupert the Unchained
Arcane construct, originally crafted by Lord Tinethra, Rupert the Unchained now has all 5 of his mana crystals intact,
offering him considerable arcane power and capability. He has most of Lord Tinethra's Spell casting capability

AC:17
HP: 250

‘Speed: Soft,
‘STR: 18 (+4) DEX: 10 (+0) CON:

= 20 (+5) WIS: 13 (#1) CHA 17 (+3)

Skills: Arcane + 9, Investigation + 9, History +9, Nature +9
Damage Immunity: Necrotic

Damage Resistance: Lightening

‘Senses: blind sight 60ft, dark vision 120ft, passive perception 22
Languages: Common, Draconic, Elven, Elemental

Legendary Resistance: 1/Day (can chose to succeed on a fail)

Actions:
Opt rightful Presence Then 3x attacks (bite, 2x claws or tail + bite at opposing targets)
Arcane Strike: +9 hit, reach 5ft, 1d6 + 4 bludgeoning + 4d6 Force damage

Notable Spells:
Counter Spell (1x)
Disintegrate (3x)
Teleport
Teleport Circle

#### ChatGPT Output:
# Rupert the Unchained
Arcane construct, originally crafted by Lord Tinethra, Rupert the Unchained now has all 5 of his mana crystals intact,
offering him considerable arcane power and capability. He has most of Lord Tinethra's Spell casting capability

**AC:** 17  
**HP:** 250  

**Speed:** Soft  
**STR:** 18 (+4)  
**DEX:** 10 (+0)  
**CON:** 20 (+5)  
**WIS:** 13 (+1)  
**CHA:** 17 (+3)  

**Skills:**  
- Arcane +9  
- Investigation +9  
- History +9  
- Nature +9  

**Damage Immunity:** Necrotic  
**Damage Resistance:** Lightning  

**Senses:** blindsight 60ft, darkvision 120ft, passive perception 22  
**Languages:** Common, Draconic, Elven, Elemental  

**Legendary Resistance:** 1/Day (can choose to succeed on a fail)

## Actions:
- Opt rightful Presence Then 3x attacks (bite, 2x claws or tail + bite at opposing targets)
- Arcane Strike: +9 hit, reach 5ft, 1d6 + 4 bludgeoning + 4d6 Force damage

## Notable Spells:
- Counter Spell (1x)
- Disintegrate (3x)
- Teleport
- Teleport Circle

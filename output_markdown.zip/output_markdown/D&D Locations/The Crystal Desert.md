# The Crystal Desert

    **Created:** 2021-10-29 11:20:31  
    **Last Edited:** 2021-10-29 11:20:33  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Excerpt taken from ‘That Really Big Desert Noone Wants to Travel Through' - a Travel Guide by ReedFellow

‘The Crystal Desert stretches out a large arc at the northern territories of the Kingdom of Dawn. The Desert itself is at
once pronounced by a large, crystalline ridgeline that seems to compose the entire outer perimeter. The ridges vary
wildly in height; some a stout Halfling could hop over, whilst others are small mountains onto themselves. still, the
average height (around the area of KoD at least) seems to be about 20 ft high.

‘These ridges seem to be composed of sand, melted glass shards, and primarily a type of crystalline formation that is
unfamiliar to me. They seem to have no magical or deleterious effect from what | can tell. Some entrances through the
ridges exist. Drunk Dwarven Pass, near Borrend, has a tunnel bored straight through the crystals. Chipahua holds a deep
reverence for the Desert, and its citizens have a well-built road leading into the unknown.

‘Once one passes the ridgeline, be prepared! Marauders and monsters alike wonder these dunes. Its all too easy to
become disoriented and last, easy pickings for those that dwell here. During the day, the intense heat and light can
create a shimmer across the crystals and glass that adorn the landscape. Marauders and caravans alike tend to travel
during the cooler and darker evenings.

‘Sandstorms have been known to occur. If caught in one, take cover! The glass and crystal will tear flesh fram bone.
Chipahua legend speaks of crystal tunnels under the Desert that one might take refuge in when caught in such a
scenario. | for one would caution against such spelunking.

At the center of the Crystal Desert likes the Onyx Mountain. it just out of the ground, a dark dagger of rock, crystal, and
black glass. While | did not ascend the mountain, itis easily stands over 1000ft above the surrounding dunes. Chipahuan
beliefs hold that a Pure Prism exists somewhere within this mountain. Such a prism could supposedly refract nat just
light, but magic, maybe even substance itself. Whatever the truth, itis an incredibly dangerous place to be treasure
hunting. More than a few have sought the secrets here only for their own fates to become part of the mystery.

Finally, be wary the Sand Wurms! They are unpredictable and foul tempered. I've seen wurms the size of a house
emerge in a terrible rage because a sand wasp dared land on its favored dune. Some of the old Chipahuan cutts still
‘worship the wurms supposedly... | wouldn't want to attend that service!

Random Encounters:

‘Sand Wurms (Purple Worm Template, reduce stats}
Xorn (MM304)

Cultist Marauders

Drow Marauders

‘Ankhegs (MIM21, buff stats, swarm)

Giant Scorpions (MM327)

Death Dogs (MM31}

Cyclops (45)

If Kaladan finds out about the party, he will regularly harass them with aerial attacks and direct his
cultists at the players.

If players go into the sand tunnels, they might they will avoid Kaladan. But he can burrow so welp.

A terrible sand-storm now rages around Onyx Mountain 24/7. If the party attempts to force their way
through, they'll need to succeed on a DC20 navigation check or become lost in the storm. If they do
succeed on the navigation, they'll arrive at the base of the mountain, inside the eye of the storm.

Under the storm lies a series of tunnels and passages that could offer a way past the problem.

Combat Maps: use the generator, its actually pretty decent.

#### ChatGPT Output:
Excerpt taken from ‘That Really Big Desert Noone Wants to Travel Through' - a Travel Guide by ReedFellow

‘The Crystal Desert stretches out a large arc at the northern territories of the Kingdom of Dawn. The Desert itself is at
once pronounced by a large, crystalline ridgeline that seems to compose the entire outer perimeter. The ridges vary
wildly in height; some a stout Halfling could hop over, whilst others are small mountains onto themselves. Still, the
average height (around the area of KoD at least) seems to be about 20 ft high.

‘These ridges seem to be composed of sand, melted glass shards, and primarily a type of crystalline formation that is
unfamiliar to me. They seem to have no magical or deleterious effect from what I can tell. Some entrances through the
ridges exist. Drunk Dwarven Pass, near Borrend, has a tunnel bored straight through the crystals. Chipahua holds a deep
reverence for the Desert, and its citizens have a well-built road leading into the unknown.

‘Once one passes the ridgeline, be prepared! Marauders and monsters alike wander these dunes. It's all too easy to
become disoriented and lost, easy pickings for those that dwell here. During the day, the intense heat and light can
create a shimmer across the crystals and glass that adorn the landscape. Marauders and caravans alike tend to travel
during the cooler and darker evenings.

‘Sandstorms have been known to occur. If caught in one, take cover! The glass and crystal will tear flesh from bone.
Chipahua legend speaks of crystal tunnels under the Desert that one might take refuge in when caught in such a
scenario. I for one would caution against such spelunking.

At the center of the Crystal Desert lies the Onyx Mountain. It juts out of the ground, a dark dagger of rock, crystal, and
black glass. While I did not ascend the mountain, it easily stands over 1000ft above the surrounding dunes. Chipahuan
beliefs hold that a Pure Prism exists somewhere within this mountain. Such a prism could supposedly refract not just
light, but magic, maybe even substance itself. Whatever the truth, it is an incredibly dangerous place to be treasure
hunting. More than a few have sought the secrets here only for their own fates to become part of the mystery.

Finally, be wary of the Sand Wurms! They are unpredictable and foul-tempered. I've seen wurms the size of a house
emerge in a terrible rage because a sand wasp dared land on its favored dune. Some of the old Chipahuan cults still
worship the wurms supposedly... I wouldn't want to attend that service!

**Random Encounters:**

- Sand Wurms (Purple Worm Template, reduce stats)
- Xorn (MM304)
- Cultist Marauders
- Drow Marauders
- Ankhegs (MM21, buff stats, swarm)
- Giant Scorpions (MM327)
- Death Dogs (MM31)
- Cyclops (45)

If Kaladan finds out about the party, he will regularly harass them with aerial attacks and direct his
cultists at the players.

If players go into the sand tunnels, they might avoid Kaladan. But he can burrow so well.

A terrible sand-storm now rages around Onyx Mountain 24/7. If the party attempts to force their way
through, they'll need to succeed on a DC20 navigation check or become lost in the storm. If they do
succeed on the navigation, they'll arrive at the base of the mountain, inside the eye of the storm.

Under the storm lies a series of tunnels and passages that could offer a way past the problem.

**Combat Maps:** use the generator, it's actually pretty decent.

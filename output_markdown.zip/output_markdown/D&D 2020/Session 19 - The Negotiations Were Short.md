# Session 19 - The Negotiations Were Short

    **Created:** 2021-10-29 11:33:51  
    **Last Edited:** 2021-10-29 11:34:01  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Probably going to have: Kevin, Derick, Evan, Sam

Party is at the cave tunnel that leads to the back-entrance of Borrend. They have a couple obvious options from here:

1) Go through the tunnel and pop into borrend. If they do so, they'll encounter Brathrizard's tracking demon on the
way through the tunnels.
2) Gothrough the front gates. Is there any way for the Duregar to stop this from happening or have an encounter
before hand?
‘A: Not really! Erirbila will try to persuade Tordid to not let them past the gates. This will be a RP fight, not a
combat one.
3) Attack the Doom Cannon, will fight a lot of Duregar + Borrend forces if they attempt this
4) Something magicky that | haven't through

Dhostik Shadowhide reported that his patrol was wiped out by mercenaries from the Kingdom of Dawn. This is only sort
of half correct. If the party can expose his lies, they could drive a wedge between Tordid and the Duregar. Conversely,
the city is already distrustful of the party. If they show up with some very dead bodies (and no injuries whatsoever on
the part of the party), it will look awfully self-serving on their part.

‘With war brewing, the city is on high alert and locked down. Paranoia is growing. Its unclear to the denizens if the
heroes that once liberated their city aren't here to now conquer it.

Duregar units:
Derro Savant

Duregar

Undergnomes

Mecha constreuts

Mecha suites that enhance stats
Earth Elementals

Oni

Borrend:
Mecha Constructs
Iron Golem + Shield Golem combo

Results:
Players went through the frant door. There was a tense standoff with the outside foces until Tordid reluctantly showed
up and allowed them inside,

‘Within the chambers, accusations from Dhostik and Bririla came fast and furious. Kaeuts in particular nearly lost his cool,
as the offensive accusations really got under his skin. The tense council meeting concluded with Tordid wanting time to
herself to study the body and the accusations made.

From here, the party split into 3 groups:

Kipla went on a solo adventure, following Dhatsik. He could not penetrate her stealth roles, and she snuck into the ODM
headquarters. There, she followed Dhatsik until he was alone... and she promptly assassinated him. Leaving a fish on his
remains. She was nearly caught on the way out, but escaped. The front door guard was surprised to see her, so she
stabbed him in the throat and escaped.

Harold and Kaeuts went to see the Order of Stone Circle druids. They caught up with them, and learned the ODM might
represent more than a third of the population of Borrend now. Bob Ross they learned reunited the dragon souls, but
still had some other task to accomplish to truly leave them at peace. They tried the ring of sending to Bob Ross but he
was on a different plane of existence. Harald and Kaeuts proceeded to get smashed for the rest of the night.

Dore spent the evening with Trodid. For once in his life, he did not try to sexually seduce the woman. Instead, he put on
a macarbe performance, splitting open the skull of the Duregar Gnome. He played ‘doctor and explained how small
defects in its brain made it a Duregar. This somehow convinced Tordid, and Dorc spent the night standing watch as she
slept.

#### ChatGPT Output:
Probably going to have: Kevin, Derick, Evan, Sam

Party is at the cave tunnel that leads to the back-entrance of Borrend. They have a couple obvious options from here:

1) Go through the tunnel and pop into Borrend. If they do so, they'll encounter Brathrizard's tracking demon on the
   way through the tunnels.
2) Go through the front gates. Is there any way for the Duergar to stop this from happening or have an encounter
   beforehand?
   - Not really! Erirbila will try to persuade Tordid to not let them past the gates. This will be a RP fight, not a
     combat one.
3) Attack the Doom Cannon, will fight a lot of Duergar + Borrend forces if they attempt this
4) Something magicky that I haven't thought through

Dhostik Shadowhide reported that his patrol was wiped out by mercenaries from the Kingdom of Dawn. This is only sort
of half correct. If the party can expose his lies, they could drive a wedge between Tordid and the Duergar. Conversely,
the city is already distrustful of the party. If they show up with some very dead bodies (and no injuries whatsoever on
the part of the party), it will look awfully self-serving on their part.

With war brewing, the city is on high alert and locked down. Paranoia is growing. It's unclear to the denizens if the
heroes that once liberated their city aren't here to now conquer it.

Duergar units:
- Derro Savant
- Duergar
- Undergnomes
- Mecha constructs
- Mecha suits that enhance stats
- Earth Elementals
- Oni

Borrend:
- Mecha Constructs
- Iron Golem + Shield Golem combo

Results:
Players went through the front door. There was a tense standoff with the outside forces until Tordid reluctantly showed
up and allowed them inside.

Within the chambers, accusations from Dhostik and Bririla came fast and furious. Kaeuts in particular nearly lost his cool,
as the offensive accusations really got under his skin. The tense council meeting concluded with Tordid wanting time to
herself to study the body and the accusations made.

From here, the party split into 3 groups:

- Kipla went on a solo adventure, following Dhatsik. He could not penetrate her stealth roles, and she snuck into the ODM
  headquarters. There, she followed Dhatsik until he was alone... and she promptly assassinated him. Leaving a fish on his
  remains. She was nearly caught on the way out, but escaped. The front door guard was surprised to see her, so she
  stabbed him in the throat and escaped.
- Harold and Kaeuts went to see the Order of Stone Circle druids. They caught up with them, and learned the ODM might
  represent more than a third of the population of Borrend now. Bob Ross they learned reunited the dragon souls, but
  still had some other task to accomplish to truly leave them at peace. They tried the ring of sending to Bob Ross but he
  was on a different plane of existence. Harald and Kaeuts proceeded to get smashed for the rest of the night.
- Dore spent the evening with Trodid. For once in his life, he did not try to sexually seduce the woman. Instead, he put on
  a macabre performance, splitting open the skull of the Duergar Gnome. He played ‘doctor and explained how small
  defects in its brain made it a Duergar. This somehow convinced Tordid, and Dore spent the night standing watch as she
  slept.

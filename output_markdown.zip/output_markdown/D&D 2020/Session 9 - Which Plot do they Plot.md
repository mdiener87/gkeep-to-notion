# Session 9 - Which Plot do they Plot?

    **Created:** 2021-10-29 11:31:17  
    **Last Edited:** 2021-10-29 11:31:22  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Again very little prep coming into today. Came in from vacation this Sunday and haven't had time to build things out.
Refer to last weeks notes

Result:
Players had a shopping session. They went to an old man's garage sale and discovered... some junk. Some of which was

bought. They then went to see Craigory's shop in Alluin, which had much more powerful items for sale. A few were
purchased here as well.

Kaetus scryed Gildas’ situation. He was being beaten down by the Narzugon - one of the most powerful foes the party
has ever encountered. The Narzugan is after the missing princess’ location, and is torturing Gil until he reveals her fate!
‘The party decided to head out to her rescue first thing in the next morning.

#### ChatGPT Output:
‘Again very little prep coming into today. Came in from vacation this Sunday and haven't had time to build things out.
Refer to last week's notes

Result:
Players had a shopping session. They went to an old man's garage sale and discovered... some junk. Some of which was

bought. They then went to see Craigory's shop in Alluin, which had much more powerful items for sale. A few were
purchased here as well.

Kaetus scryed Gildas’ situation. He was being beaten down by the Narzugon - one of the most powerful foes the party
has ever encountered. The Narzugon is after the missing princess’ location, and is torturing Gil until he reveals her fate!
‘The party decided to head out to her rescue first thing in the next morning.'

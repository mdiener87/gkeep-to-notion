# Session 14 - The Escape

    **Created:** 2021-10-29 11:32:18  
    **Last Edited:** 2021-10-29 11:32:21  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The Narzugon is not a foe to give up easily. He is after the Princess Rose, and he isn't letting a few do-gooders get away
from him. While the party got away initially, they are now taking refuge in the bandit base. A hungry (and trigger happy}
Shane is waiting for them there. Along with those trap explosives - see if the players remember that arming.

How should the Narzugon pursue them?
-> Send a retriever
-> Find them himself
-> Send Demons
Demons:
1 Armanite x2
20rthon

Result:

Kipla's tripwire trap came back in a big way tonight. The players spent considerable time getting past it twice! After
successfully getting past the trap and into the base, they enjoyed a long rest with only completley ominous trampling
coming from underground, After the long rest was completed, they were set upon by two Armanite demons. The tight
corridor made for a hectic fight, but they were soon fought back.

Traversing the dangerous corridor again, the party reconvened in the open air outside the hidden encampment. Kaetus
broke out Transport Via Plants, and teleported the entire party, including passengers, to the royal gardens of Alluin.

#### ChatGPT Output:
‘The Narzugon is not a foe to give up easily. He is after the Princess Rose, and he isn't letting a few do-gooders get away
from him. While the party got away initially, they are now taking refuge in the bandit base. A hungry (and trigger happy)
Shane is waiting for them there. Along with those trap explosives - see if the players remember that arming.

How should the Narzugon pursue them?
-> Send a retriever
-> Find them himself
-> Send Demons
Demons:
1. Armanite x2
2. Orthon

**Result:**

Kipla's tripwire trap came back in a big way tonight. The players spent considerable time getting past it twice! After
successfully getting past the trap and into the base, they enjoyed a long rest with only completely ominous trampling
coming from underground. After the long rest was completed, they were set upon by two Armanite demons. The tight
corridor made for a hectic fight, but they were soon fought back.

Traversing the dangerous corridor again, the party reconvened in the open air outside the hidden encampment. Kaetus
broke out Transport Via Plants, and teleported the entire party, including passengers, to the royal gardens of Alluin.

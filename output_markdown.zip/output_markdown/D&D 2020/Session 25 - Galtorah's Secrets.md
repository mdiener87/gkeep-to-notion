# Session 25 - Galtorah's Secrets

    **Created:** 2021-10-29 11:34:59  
    **Last Edited:** 2021-10-29 11:35:06  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Need to get the party to find the entrance to Galtorah's secret chamber.
It contains the Mirror of Prophecy - if they can defeat the Spirit Naga that now claims the entire keep as its own!

Result:

AGreen slaad in the form of a dwarf came out of the keep. They poly'd it into a koala and shoved it into the bag of
holding.

‘The party went deeper into the keep, following their original path through the dungeon. They encountered Blue and
Green slaads, which by themselves were not too dangerous. They called to a Bone Naga, which parlayed with Ureasua
and wrestled (and paralyzed) Dore. Dore eventually broke out of his charm effect and one shot the bone naga.

Meanwhile, the poly'd green slaad came out of the bag of holding! The koala suffocated to death, and then the slaad,
dying and desperate, transformed himself into a Death Slaad. Armed with the Megged blade, which he found in the
pocket dimension, he cut his way out.

‘The death stad proceded to fight the party. Gandus was having none of this, he swung with the blade of molten magic
and crit twice. He destroyed the meg blade and dispelled the enchantment cleanly. The Death Slaad tried to cast

cloudkill, but Gandus once again hit it with the Blade's counterspell. Poor slaad never stood a chance.

‘They looted the room and communed with galtorah. FIN

#### ChatGPT Output:
Need to get the party to find the entrance to Galtorah's secret chamber.
It contains the Mirror of Prophecy - if they can defeat the Spirit Naga that now claims the entire keep as its own!

**Result:**

A Green slaad in the form of a dwarf came out of the keep. They poly'd it into a koala and shoved it into the bag of holding.

The party went deeper into the keep, following their original path through the dungeon. They encountered Blue and Green slaads, which by themselves were not too dangerous. They called to a Bone Naga, which parlayed with Ureasua and wrestled (and paralyzed) Dore. Dore eventually broke out of his charm effect and one-shot the bone naga.

Meanwhile, the poly'd green slaad came out of the bag of holding! The koala suffocated to death, and then the slaad, dying and desperate, transformed himself into a Death Slaad. Armed with the Megged blade, which he found in the pocket dimension, he cut his way out.

The death slaad proceeded to fight the party. Gandus was having none of this, he swung with the blade of molten magic and crit twice. He destroyed the meg blade and dispelled the enchantment cleanly. The Death Slaad tried to cast cloudkill, but Gandus once again hit it with the Blade's counterspell. Poor slaad never stood a chance.

They looted the room and communed with Galtorah. FIN

# Session 23 - In the Wake of Disaster

    **Created:** 2021-10-29 11:34:36  
    **Last Edited:** 2021-10-29 11:34:46  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
3 days have passed following the Borrend Explosion. The Order was able to escape this blast, but not all of the Order
made it. Harold Crumbebottom, who stayed behind to set the final charges, failed to escape the blast in time. His body
‘took 2 weeks to find amongst the devastated mountain slopes. Travelers, adventurers, animals, even foliage, all
withered and died before the explosive rush of toxic gas.

Borrend is devastated. Over half of the city has perished. Many of the survivors have chemical burns and injuries that
seem unusually resistant to magical healing. Those that have survived have mostly fled to the town of Galtorah. It's
refugee population has now exploded, and a humanitarian crisis is now fully underway. The Order of the Stone Circle
have taken charge of trying to help all the wounded, but are overwhelmed and desperately short of supplies.

Tordid has survived, but is severely injured by the gas. She is conscious only for a few hours per day, and has resigned
from her duties of leadership.

‘The Council of Three all perished. There is no formal leadership of Borrend remaining.

Princess Rose will travel to Galtorah under a humanitarian mission. She travels with members of the royal guard, a
squad of soldiers, medics, and merchants.

For Today:

‘The Party starts in Galtorah. They are going to meet with Princes Rose and the new character from Evan. The Stone
Circle druids have a theory that if the original druidic catalyst could be found, they might be able to devise a healing spell
that can help all the injured Borrend citizens.

‘What actually happened:
Toxic oozes attacked the party, giving Zephyr a chance to fight for the first time

‘There is a toxic, permanent cloud hanging over the area from the explosion. Something evil and willful seems to be
directing these clounds

Toxic rain started to fall on the players, and Kaetus quickly prepared Transport Via Plants and took the party to Galtorah.
Kaetus used the Control Winds spells to blow the clouds away from the town and protect the people from the rain

Kipla finally attuned to the Ring of Djinti Summoning, The Players met tla the Handsome. He conjured gems for Kipla
using Creation, but it took everyone a bit of investigating to realize the gems are all fake! Ila was off ‘looking for shines!
as Kipla instructed and wasn't available for further questioning after the deception was revealed.

Circle of Toxins
Spirit Naga + Toxic Minotaurs

Toxic Minotaur:

ACIS
HP 90
Actions:
Multi-attack 2

Breath Weapon: Cone of Poison 15ft range. DC 15 CON or be poisoned for one day and
take 6d6 damage. 346 damage on save.

Toxic Sludge:
Black Pudding + 2d6 poison damage on hit

#### ChatGPT Output:
3 days have passed following the Borrend Explosion. The Order was able to escape this blast, but not all of the Order
made it. Harold Crumbebottom, who stayed behind to set the final charges, failed to escape the blast in time. His body
took 2 weeks to find amongst the devastated mountain slopes. Travelers, adventurers, animals, even foliage, all
withered and died before the explosive rush of toxic gas.

Borrend is devastated. Over half of the city has perished. Many of the survivors have chemical burns and injuries that
seem unusually resistant to magical healing. Those that have survived have mostly fled to the town of Galtorah. It's
refugee population has now exploded, and a humanitarian crisis is now fully underway. The Order of the Stone Circle
have taken charge of trying to help all the wounded, but are overwhelmed and desperately short of supplies.

Tordid has survived, but is severely injured by the gas. She is conscious only for a few hours per day, and has resigned
from her duties of leadership.

The Council of Three all perished. There is no formal leadership of Borrend remaining.

Princess Rose will travel to Galtorah under a humanitarian mission. She travels with members of the royal guard, a
squad of soldiers, medics, and merchants.

For Today:

The Party starts in Galtorah. They are going to meet with Princess Rose and the new character from Evan. The Stone
Circle druids have a theory that if the original druidic catalyst could be found, they might be able to devise a healing spell
that can help all the injured Borrend citizens.

What actually happened:
Toxic oozes attacked the party, giving Zephyr a chance to fight for the first time

There is a toxic, permanent cloud hanging over the area from the explosion. Something evil and willful seems to be
directing these clouds

Toxic rain started to fall on the players, and Kaetus quickly prepared Transport Via Plants and took the party to Galtorah.
Kaetus used the Control Winds spells to blow the clouds away from the town and protect the people from the rain

Kipla finally attuned to the Ring of Djinti Summoning, The Players met Ila the Handsome. He conjured gems for Kipla
using Creation, but it took everyone a bit of investigating to realize the gems are all fake! Ila was off 'looking for shines'
as Kipla instructed and wasn't available for further questioning after the deception was revealed.

Circle of Toxins
Spirit Naga + Toxic Minotaurs

Toxic Minotaur:

- AC 15
- HP 90
- Actions:
  - Multi-attack 2
  - Breath Weapon: Cone of Poison 15ft range. DC 15 CON or be poisoned for one day and
    take 6d6 damage. 3d6 damage on save.
  - Toxic Sludge:
    - Black Pudding + 2d6 poison damage on hit

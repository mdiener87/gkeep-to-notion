# Session 16 - Introducing Uraeusa

    **Created:** 2021-10-29 11:32:41  
    **Last Edited:** 2021-10-29 11:33:17  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Carolyn is starting with a new characher today. Need to spin her up on this.
Other plots for today:

* Narzugon is hunting players?
Players could encounter wounded soldiers from the kingdom or from borrend

* Refugees will have conflicting stories of who fired on whom, but all agree border skirmishes are breaking out or of
discrimination from within borrend

= Drow raiders

Result:

Party worked with Floriana and the King to fully ascertain the kingdom's disposition and orders regarding the Borrend
situation. They both confirmed no offensive orders have been issued, and are surprised at the conflicting reports of
border skirmishes.

Aasathra retired, introducing Uraeusa as Carolyn's new character
‘They learned that a Commander Tristan, operating out of the captured Orc base near borrend, has been involved in

many of these reports. The party just landed at this outpost at the end of the session. The Dwarfen Emissary Kirdan is
with them.

#### ChatGPT Output:
Carolyn is starting with a new character today. Need to spin her up on this.
Other plots for today:

* Narzugon is hunting players?
  Players could encounter wounded soldiers from the kingdom or from Borrend

* Refugees will have conflicting stories of who fired on whom, but all agree border skirmishes are breaking out or of
  discrimination from within Borrend

* Drow raiders

Result:

Party worked with Floriana and the King to fully ascertain the kingdom's disposition and orders regarding the Borrend
situation. They both confirmed no offensive orders have been issued, and are surprised at the conflicting reports of
border skirmishes.

Aasathra retired, introducing Uraeusa as Carolyn's new character.
They learned that a Commander Tristan, operating out of the captured Orc base near Borrend, has been involved in
many of these reports. The party just landed at this outpost at the end of the session. The Dwarfen Emissary Kirdan is
with them.

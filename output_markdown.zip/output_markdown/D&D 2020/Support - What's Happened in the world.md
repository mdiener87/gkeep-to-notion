# What's Happened in the world?

    **Created:** 2021-10-29 11:29:22  
    **Last Edited:** 2021-10-29 11:29:25  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Six month time skip following the events that killed Kaladan.

Alluil

© King Moryn has effectively become a ghost. His health and spirits continue to fall. Years of war have taken
their toll, and Moryn now rarely greets the public or even his council.

© Floriana has been named Hand of the King, and is effectively leading the city of Alluin in rebuilding efforts.
Much progress has been made around the city, but it will take years before the sacking of Alluin can be
undone.

© Elryiss is not seen much, preferring to let Floriana be the public face while she provides research and advice.

General Trynicass is still there, brooding.

© Sir Gildas has led an Expiditionary Force East to reclaim the lands lost to the ore war. He has proven valiant
in battle, winning his first three encounters with minimal casualties. His men can be heard shouting their
battle phrase, COUNTERSPELL! As they charge into battle.

°

Borrend:

© Tordid Nordak has dectared the city a fully independent state. Faced with the near collapse of the kingdom,
and the loss of many of her own citizens in the wars, she has withdrawn. The city is sealed shut most days.
Suspicion and paranoia have begun to set into these cloiystered, injured peoples.

© The Order tried to step in and negotiate, but Tordid flatly refused compromise.

© Senior Engineering Specialist Broc has begun to rebuild the doom cannon. He now understands why his
grandpappy wanted such a device.

© Disa has gone missing. She left Borrend without notice three months ago. Prior to her disappearance, she
seemed happy to be getting closer to Dore.

© Thradal worked with Bob Ross to unite the souls of the Blood Orb and Dragon wand. However, neither he
nor Bob Ross would reveal their final fate.

(© Roscoe the Mysterious now helps organize the Halfing Swapmeet. He wants you all to know it now meets on
Thursdays.

Galtorah:

© Tren has had to accommodate a great number of refugees that have poured into Galtorah. The town has
now doubled in size, and finding work and supplies is difficult.

© Lord Galtorah has not made his presence known for some time. Kaetus random conversations with himself
and inappropriate outbursts have stopped.

Tinethra's Manor

© Ruport left on his quest to find his master's fate. He left shortly after the victory party. The manor itself is
now under the protection of 8 Helmed Horrors, led by a Champion Horror. The Order is recognized as
honored guests, but otherwise outsiders haven't been present following the relocation of the remaining
refugees.

#### ChatGPT Output:
'Six month time skip following the events that killed Kaladan.

Alluil

- King Moryn has effectively become a ghost. His health and spirits continue to fall. Years of war have taken
their toll, and Moryn now rarely greets the public or even his council.

- Floriana has been named Hand of the King, and is effectively leading the city of Alluin in rebuilding efforts.
Much progress has been made around the city, but it will take years before the sacking of Alluin can be
undone.

- Elryiss is not seen much, preferring to let Floriana be the public face while she provides research and advice.

General Trynicass is still there, brooding.

- Sir Gildas has led an Expeditionary Force East to reclaim the lands lost to the ore war. He has proven valiant
in battle, winning his first three encounters with minimal casualties. His men can be heard shouting their
battle phrase, COUNTERSPELL! As they charge into battle.

Borrend:

- Tordid Nordak has declared the city a fully independent state. Faced with the near collapse of the kingdom,
and the loss of many of her own citizens in the wars, she has withdrawn. The city is sealed shut most days.
Suspicion and paranoia have begun to set into these cloistered, injured peoples.

- The Order tried to step in and negotiate, but Tordid flatly refused compromise.

- Senior Engineering Specialist Broc has begun to rebuild the doom cannon. He now understands why his
grandpappy wanted such a device.

- Disa has gone missing. She left Borrend without notice three months ago. Prior to her disappearance, she
seemed happy to be getting closer to Dore.

- Thradal worked with Bob Ross to unite the souls of the Blood Orb and Dragon wand. However, neither he
nor Bob Ross would reveal their final fate.

- Roscoe the Mysterious now helps organize the Halfling Swapmeet. He wants you all to know it now meets on
Thursdays.

Galtorah:

- Tren has had to accommodate a great number of refugees that have poured into Galtorah. The town has
now doubled in size, and finding work and supplies is difficult.

- Lord Galtorah has not made his presence known for some time. Kaetus random conversations with himself
and inappropriate outbursts have stopped.

Tinethra's Manor

- Ruport left on his quest to find his master's fate. He left shortly after the victory party. The manor itself is
now under the protection of 8 Helmed Horrors, led by a Champion Horror. The Order is recognized as
honored guests, but otherwise outsiders haven't been present following the relocation of the remaining
refugees.

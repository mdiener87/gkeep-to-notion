# Session 11 - Vesstan's Friends

    **Created:** 2021-10-29 11:31:43  
    **Last Edited:** 2021-10-29 11:31:51  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Not much prep coming into todays session. The players didn't get very far with the prep from last episode, so pick up
from there and keep them going.

Result:

After a failed interrogation of Vesstan, the Hold Person effect ended on him and he made a break for his freedom under
the cover of darkness! Kaetus took a blind shot with the Staff of Fire and blew him to smitheritness with a Fireball.

‘The party ventured north, following the smell of smoke. They soon came across the remains of WildeSpell, a town that
has been seemingly burned to ashes. A small child named Shane was found hiding out nearby. He informed the party
that a terrible demon had come into the town, looking for someone. He burned the families alive in their houses. Shane
‘was just barely able to escape under some loose floor boards.

Shane led the players up a rocky path, away from the main road that led to the old wizard's observatory.

While traveling up the road, Kaetus received a Message of Sending from Gildas. He was asking for help, claiming to be at
the old observatory. Kaetus Scryed that to be true, but it was clear that something was wrong. The Light from Gil's eyes
was gone. He stood motionless, like a figurine, in the center of this observatory. The party decided it was a trap and to
come back for Gil later.

Venturing into the hills, they found the bandit caves Shane had mentioned. Two shadow demons had been observing
their progress, but the players could not spot them - only get the feeling they were being watch. Harold charged forward
and found one in the bushes. A short fight broke out, the party easily dispatching them.

Despite Shane pointing out the pressure plates, the party still managed to set them off going into the bandit hideout.
This did some explosive damage to Kaeuts and Harold, but sent Kipla and Shane plummeting into a ravine! Kipla was
able to make an acrobatics check, grabbing Shane in mid air. She abosrbed most of his falling damage. Luckily, Kipla has
alot of HP.

Inside the hideout, they found evidence that people had been staying here for some time. A hidden door at the battom
of the complex led deeper into the caves... To be continued!

#### ChatGPT Output:
Not much prep coming into today's session. The players didn't get very far with the prep from last episode, so pick up from there and keep them going.

Result:

- After a failed interrogation of Vesstan, the **Hold Person** effect ended on him and he made a break for his freedom under the cover of darkness! Kaetus took a blind shot with the **Staff of Fire** and blew him to smitheriness with a **Fireball**.

- The party ventured north, following the smell of smoke. They soon came across the remains of WildeSpell, a town that has been seemingly burned to ashes. A small child named Shane was found hiding out nearby. He informed the party that a terrible demon had come into the town, looking for someone. He burned the families alive in their houses. Shane was just barely able to escape under some loose floorboards.

- Shane led the players up a rocky path, away from the main road that led to the old wizard's observatory.

- While traveling up the road, Kaetus received a **Message of Sending** from Gildas. He was asking for help, claiming to be at the old observatory. Kaetus **Scryed** that to be true, but it was clear that something was wrong. The Light from Gil's eyes was gone. He stood motionless, like a figurine, in the center of this observatory. The party decided it was a trap and to come back for Gil later.

- Venturing into the hills, they found the bandit caves Shane had mentioned. Two shadow demons had been observing their progress, but the players could not spot them - only get the feeling they were being watched. Harold charged forward and found one in the bushes. A short fight broke out, the party easily dispatching them.

- Despite Shane pointing out the pressure plates, the party still managed to set them off going into the bandit hideout. This did some explosive damage to Kaeuts and Harold, but sent Kipla and Shane plummeting into a ravine! Kipla was able to make an acrobatics check, grabbing Shane in mid-air. She absorbed most of his falling damage. Luckily, Kipla has alot of HP.

- Inside the hideout, they found evidence that people had been staying here for some time. A hidden door at the bottom of the complex led deeper into the caves... To be continued!

# Session 8 - Adventures in Zero Prep

    **Created:** 2021-10-29 11:31:05  
    **Last Edited:** 2021-10-29 11:31:10  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Really sad this past week and didn't make any progress on my D&D prep. Fuck.

They'll probably long rest and go to Alluin to take stock of the situation. Orrrr they'll head towards the tower and see
what the hell is going on.

‘The tower itself is invisible, and hidden in a murky swamp. Roll random encounters as they explore the swamp. Save the
tower itself for another day when I have stuff prepared for it.

Monsters: Swamp, forest stuff. Demons + spider themes

(Ok on the plus side I've found a bunch of useful maps so we at least can use those.
Roll Appropriate monsters for them if/when we get to them

‘And we've figured out how to add tokes!
This is taking some shape

Result:
Party went to Alluin, got 30k in Gold for reward of capture of Nenetl.
Learned from Floriana that:

Gildas is in trouble to the East on his Expeditionary force

Borrend is rebuilding the death cannon and withdrawn from the compact
Doesn't know much about the Tower of Bithirya or the Beaconport Abyss

#### ChatGPT Output:
Really sad this past week and didn't make any progress on my D&D prep. Fuck.

They'll probably long rest and go to Alluin to take stock of the situation. Orrrr they'll head towards the tower and see
what the hell is going on.

'The tower itself is invisible, and hidden in a murky swamp. Roll random encounters as they explore the swamp. Save the
tower itself for another day when I have stuff prepared for it.

Monsters: Swamp, forest stuff. Demons + spider themes

(Ok on the plus side I've found a bunch of useful maps so we at least can use those.
Roll Appropriate monsters for them if/when we get to them

'And we've figured out how to add tokens!
This is taking some shape

Result:
Party went to Alluin, got 30k in Gold for reward of capture of Nenetl.
Learned from Floriana that:

- Gildas is in trouble to the East on his Expeditionary force
- Borrend is rebuilding the death cannon and withdrawn from the compact
- Doesn't know much about the Tower of Bithirya or the Beaconport Abyss

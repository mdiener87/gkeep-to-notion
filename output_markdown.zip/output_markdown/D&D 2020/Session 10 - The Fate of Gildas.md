# Session 10 - The Fate of Gildas

    **Created:** 2021-10-29 11:31:27  
    **Last Edited:** 2021-10-29 11:31:35  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Town names:

‘The eastern towns are the newest settlements from within the kingdom. They all started to abut the Orc Kingdom
Inamel, divided by a river [name] and mountain range [name].

‘Town, N to South:
+ Wildespell
© Asmall community of wizards located in the front range of the Troster Slopes. They were reclusive scholars
until the orc invasion burned this community down
+ Cragfair
© The ‘gateway to the Eastern settlements’, Cragfair was renowned for its open markets and delicious fish,
This town was the first to be reclaimed by Gildas’ Expeditionary forces. A few refugees have returned to
Cragfai
+ Darkmeadow
© The largest and fastest growing settlement, Darkmeadow was built in the valley beneath the Rependuff
Peaks. It was the first town to be invaded by the Orc hordes. tt is still unknown how the ores succesfully
mounted such a campaign across the Rependuff Peaks, a mountain range the kingdom had considered
impenetrable. The Queen and Princess were in Darkmeadow when the orc legions struck.

‘What's happened to the Queen and Princess?

Initially, they were captured by the Orcs. Shaggon Megged brutally murdered the Queen, Hellen Moryn, and intended to
keep Princess Rose as his bounty. While Shaggon Megged pressed his campaign west, he left a few Orcs behind to claim
Darkmeadow as the first new Orcish community. The Princess somehow escaped her capture during this interim.

She could not safely return home, however. Instead she found herself concealing her real identity and living a desperate
existance in the high-lands where the Troster Slopes and Rependuff Peaks meet - the Walsbonear Highlands. She has
slowly but surely become an adept rogue, taking to thieving and assassination to ensure her survival. She joined other
refugees and rebels in the Highlands, the so called ‘Highland Raiders’. Answering only to themselves, they sought out
justice on the frontier where none could be found. When the Dragon attacked, many of the nearby refugees became
dragon cultists themselves. Again fearing for her life, the Princess could find no safe way to return home. She has
remained hidden in these slopes, holding out fear that one day her Father and King would return for her.

Gildas can be found in the remains of Darkmeadow. The Orcs have been driven from the town, but can still be found in
‘small encampments in the fields. There is a massive tunnel to the east of Darkmeadow, leading towards the eastern
Plains (off map).

Darkmeadow has a Drow presence, and the Narzugon has for some reason joined their side as well.

Narzugon 's Name: Brarthrizad

Scared of: The Phoenix. A spirit of firey redemption, Brathrizad corrupted and defiled a Phoenix as part of his fall from
the royal order of Paladins over 200 years ago. A devil bent on corrupting the Kingdom, the Narzugon Brathrizad is highly
capable, purely evil, and willing to make logical pacts with other forces to further his evil will.

is original pact with the Dragon Cult is still in effect - he made a deal with the Clan, not just Kaladan. He intends to fulfil
that promise. That is, to corrupt the very best the Kingdom of Dawn has to offer and turn their own fallen soldiers
against the crown. In exchange, Kaladan offered him a magical item [roll]

‘The Drow have a natural fondness for Devils. While their methods differ somewhat, they too have found the Narzugon
an invaluable ally. He has been tasked with locating Princess Rose - in exchange, the Drow have also given him a magical
item,

‘The Beacon Port Abyss

Contemporarily known as The Marshes of Maidfail, this vast region once held a small elven outpost. Bandits and thieves
are known to seek refuge from the lawn in this vast marshland. No significant structures are known to have been built in
the marshes, which are considered cursed, The terrain slowly seems to consume any large structure, until it is swallowed
beneath the shifting morass.

‘The Beacon Port Abyss is the name of an Elven trading community that once resided within these marshes, stricken from
tthe official kingdom records. The BPA had a thriving Drow community, and it was said to be a neutral location where
Elves and Drow could peacefully coexist. Same scholars posit that it was the Elven Lord Tinethra who had this,
community destroyed, as part of an ‘Eleven Great Leap Forward that took place around 500 years ago.

Result:

Players flew to El Enna, and then to the first town, Cragfair. There they were ambushed by Drow and a fierce battle
broke out. A Drow Elite warrior was narrowly captured; his commander tried to kill him when she realized he was
captured;

Drow Elite Name: Vesstan

Level 10 players who were in this battle can level up to level 11.

#### ChatGPT Output:
Town names:

‘The eastern towns are the newest settlements from within the kingdom. They all started to abut the Orc Kingdom
Inamel, divided by a river [name] and mountain range [name].

‘Town, N to South:
- Wildespell
  - A small community of wizards located in the front range of the Troster Slopes. They were reclusive scholars
    until the orc invasion burned this community down
- Cragfair
  - The ‘gateway to the Eastern settlements’, Cragfair was renowned for its open markets and delicious fish,
    This town was the first to be reclaimed by Gildas’ Expeditionary forces. A few refugees have returned to
    Cragfair
- Darkmeadow
  - The largest and fastest growing settlement, Darkmeadow was built in the valley beneath the Rependuff
    Peaks. It was the first town to be invaded by the Orc hordes. It is still unknown how the orcs successfully
    mounted such a campaign across the Rependuff Peaks, a mountain range the kingdom had considered
    impenetrable. The Queen and Princess were in Darkmeadow when the orc legions struck.

‘What's happened to the Queen and Princess?

Initially, they were captured by the Orcs. Shaggon Megged brutally murdered the Queen, Hellen Moryn, and intended to
keep Princess Rose as his bounty. While Shaggon Megged pressed his campaign west, he left a few Orcs behind to claim
Darkmeadow as the first new Orcish community. The Princess somehow escaped her capture during this interim.

She could not safely return home, however. Instead she found herself concealing her real identity and living a desperate
existence in the high-lands where the Troster Slopes and Rependuff Peaks meet - the Walsbonear Highlands. She has
slowly but surely become an adept rogue, taking to thieving and assassination to ensure her survival. She joined other
refugees and rebels in the Highlands, the so called ‘Highland Raiders’. Answering only to themselves, they sought out
justice on the frontier where none could be found. When the Dragon attacked, many of the nearby refugees became
dragon cultists themselves. Again fearing for her life, the Princess could find no safe way to return home. She has
remained hidden in these slopes, holding out fear that one day her Father and King would return for her.

Gildas can be found in the remains of Darkmeadow. The Orcs have been driven from the town, but can still be found in
small encampments in the fields. There is a massive tunnel to the east of Darkmeadow, leading towards the eastern
Plains (off map).

Darkmeadow has a Drow presence, and the Narzugon has for some reason joined their side as well.

Narzugon's Name: Brarthrizad

Scared of: The Phoenix. A spirit of fiery redemption, Brathrizad corrupted and defiled a Phoenix as part of his fall from
the royal order of Paladins over 200 years ago. A devil bent on corrupting the Kingdom, the Narzugon Brathrizad is highly
capable, purely evil, and willing to make logical pacts with other forces to further his evil will.

His original pact with the Dragon Cult is still in effect - he made a deal with the Clan, not just Kaladan. He intends to fulfill
that promise. That is, to corrupt the very best the Kingdom of Dawn has to offer and turn their own fallen soldiers
against the crown. In exchange, Kaladan offered him a magical item [roll]

The Drow have a natural fondness for Devils. While their methods differ somewhat, they too have found the Narzugon
an invaluable ally. He has been tasked with locating Princess Rose - in exchange, the Drow have also given him a magical
item,

The Beacon Port Abyss

Contemporarily known as The Marshes of Maidfail, this vast region once held a small elven outpost. Bandits and thieves
are known to seek refuge from the law in this vast marshland. No significant structures are known to have been built in
the marshes, which are considered cursed, The terrain slowly seems to consume any large structure, until it is swallowed
beneath the shifting morass.

The Beacon Port Abyss is the name of an Elven trading community that once resided within these marshes, stricken from
the official kingdom records. The BPA had a thriving Drow community, and it was said to be a neutral location where
Elves and Drow could peacefully coexist. Some scholars posit that it was the Elven Lord Tinethra who had this,
community destroyed, as part of an ‘Elven Great Leap Forward that took place around 500 years ago.

Result:

Players flew to El Enna, and then to the first town, Cragfair. There they were ambushed by Drow and a fierce battle
broke out. A Drow Elite warrior was narrowly captured; his commander tried to kill him when she realized he was
captured;

Drow Elite Name: Vesstan

Level 10 players who were in this battle can level up to level 11.

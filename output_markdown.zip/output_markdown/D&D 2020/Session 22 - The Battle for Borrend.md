# Session 22 - The Battle for Borrend

    **Created:** 2021-10-29 11:34:26  
    **Last Edited:** 2021-10-29 11:34:31  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
This session will focus on the doom cannon and wrap up (or start to wrap up) the Borrend arc. The players need a
chance to battle Erirbila and have Tordid re-establish control of the city.

‘The council of three has been decieved. The haffling is in on the Dureger plot, as he thinks this is an opportunity to
advance his own career and the interests of halflings within the city.

If Erirbia is near defeat, she will use her action to activate the demonic summoning crystal to summon Illitran, the Drown
Demonic Princess. Buff her stats and make it a two phase boss fight.

‘The dark orb Eribia will use will also call in giant spiders at the end of each round. The sphere has 20HP and AC 20. It has
resistance to frost, necrotic damage and immune to poison.

Brock can be convinced to join the party. He loves explosions, but he doesn't want to hurt innocent people. He will start
by trying to get the weapon operational. if he enters combat, he will go for a nearby mecha-suit and join on whomever's
side he is currently on.

‘The royal guard has been sent to join the forces in the garrison base, who will then mount a joint expedition to Borrend.
If they can get into the city, they can help deal with the Duregar. But only if the players can alert the city to the threat.
Otherwise, it will be seen as a foreign invasion.

Result:
So. None of the above happened.

‘The Party used wind walk and eyes of night to scope out the Doom Cannon and investigate its defenses. While the area
around it was heavily guarded, they found the top levels of the weapon itseff had naone observing it. They easily slipped
in and and reverted to human form.

‘They found a Loader Robot on the second floor, whose task was to precisely arm and load shells into the cannon. Using
Tordid's Rune Key, they overrode its commands and made it obey them. Harold affectionatley renamed it to Jim. The
party set about investigating the shells and how they work. They determined that the shells could be detonated from
impact, air burst altitude, or timer settings. The timer had a maximum duration of 48 seconds,

‘Jim' was overheard talking to himself a lot more than usual, so Brock was sent up to investigate. The party heard his
approach upstairs and was waiting, Kaetus hit him with Command, instructing him with ‘silence’. Brock, unable to locate
the party through Pass without a Trace, was left mystified as he suddenly couldn't talk to himself or Jim. Kaetus gave the
signal to Kipla to 'take action'’.. .and she did, Hitting him with a critical sneak attack dagger throw for 55 damage. Broc
died instantly.

With Broc dispatched, the party set to work to destroy the weapon once and for all. Kipla set up her explosive charges all
around the armaments room. While Harold used Tordid's and Broc’s Rune Keys to instruct Jim to arm as many shells as
he could for their maximum duration. The party flew away as clouds, except for Harold, who used his Cloak of the Bat.
That was a mistake.

48 seconds later, the shells went off. They all went off. A tremendous explosion erupted from the cannon and the.
mountain in which it resides. A giant green fireball erupted into the sky, rapidly expanding in all directions. The party
using Wind Walk were able to reach minimum safe distance. Harold was not. He made his CON save, and managed to
hidein a cave... but his fate is uncertain.

Asis the fate of the city of Borrend, which is fully enveloped within the blast radius.

#### ChatGPT Output:
This session will focus on the doom cannon and wrap up (or start to wrap up) the Borrend arc. The players need a
chance to battle Erirbila and have Tordid re-establish control of the city.

'The council of three has been deceived. The halfling is in on the Duergar plot, as he thinks this is an opportunity to
advance his own career and the interests of halflings within the city.

If Erirbia is near defeat, she will use her action to activate the demonic summoning crystal to summon Illitran, the Drown
Demonic Princess. Buff her stats and make it a two-phase boss fight.

'The dark orb Eribia will use will also call in giant spiders at the end of each round. The sphere has 20HP and AC 20. It has
resistance to frost, necrotic damage and immune to poison.

Brock can be convinced to join the party. He loves explosions, but he doesn't want to hurt innocent people. He will start
by trying to get the weapon operational. If he enters combat, he will go for a nearby mecha-suit and join on whomever's
side he is currently on.

'The royal guard has been sent to join the forces in the garrison base, who will then mount a joint expedition to Borrend.
If they can get into the city, they can help deal with the Duergar. But only if the players can alert the city to the threat.
Otherwise, it will be seen as a foreign invasion.

Result:
So. None of the above happened.

'The Party used wind walk and eyes of night to scope out the Doom Cannon and investigate its defenses. While the area
around it was heavily guarded, they found the top levels of the weapon itself had no one observing it. They easily slipped
in and reverted to human form.

'They found a Loader Robot on the second floor, whose task was to precisely arm and load shells into the cannon. Using
Tordid's Rune Key, they overrode its commands and made it obey them. Harold affectionately renamed it to Jim. The
party set about investigating the shells and how they work. They determined that the shells could be detonated from
impact, air burst altitude, or timer settings. The timer had a maximum duration of 48 seconds,

'Jim' was overheard talking to himself a lot more than usual, so Brock was sent up to investigate. The party heard his
approach upstairs and was waiting, Kaetus hit him with Command, instructing him with 'silence'. Brock, unable to locate
the party through Pass without a Trace, was left mystified as he suddenly couldn't talk to himself or Jim. Kaetus gave the
signal to Kipla to 'take action'.. .and she did, Hitting him with a critical sneak attack dagger throw for 55 damage. Brock
died instantly.

With Brock dispatched, the party set to work to destroy the weapon once and for all. Kipla set up her explosive charges all
around the armaments room. While Harold used Tordid's and Brock’s Rune Keys to instruct Jim to arm as many shells as
he could for their maximum duration. The party flew away as clouds, except for Harold, who used his Cloak of the Bat.
That was a mistake.

48 seconds later, the shells went off. They all went off. A tremendous explosion erupted from the cannon and the
mountain in which it resides. A giant green fireball erupted into the sky, rapidly expanding in all directions. The party
using Wind Walk were able to reach minimum safe distance. Harold was not. He made his CON save, and managed to
hide in a cave... but his fate is uncertain.

As is the fate of the city of Borrend, which is fully enveloped within the blast radius.

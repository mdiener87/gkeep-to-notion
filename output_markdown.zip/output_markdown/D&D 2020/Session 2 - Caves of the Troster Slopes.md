# Session 2 - Caves of the Troster Slopes

    **Created:** 2021-10-29 11:29:45  
    **Last Edited:** 2021-10-29 11:29:52  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party had just gotten to the cabin at the last session. There, they found hidden steps leading down into a dark
tunnel. it seems to go deeper into the mountain. Is this where they'll find Nenetl?
Refer to session 1 dungeon nates

#### ChatGPT Output:
‘The party had just gotten to the cabin at the last session. There, they found hidden steps leading down into a dark
tunnel. It seems to go deeper into the mountain. Is this where they'll find Nenetl?
Refer to session 1 dungeon notes

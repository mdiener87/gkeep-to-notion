# Session 26 - A Thanksgiving Special

    **Created:** 2021-10-29 11:35:11  
    **Last Edited:** 2021-10-29 11:35:24  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
We have a smaller group tonight, so instead of just pressing on in the main story I want to try to find and do something
special for the players. This is Thanksgiving, after all!

Ideas:

They are currently within Galtorah's Manor. This was their first dungeon, which | don't have a good representation of for
Roll20, Galtorah as a shade is well known, but the Elven history of these ruins has not been well explored. Some sort of
vision quest / trap / alternate pocket dimension to explore content is now in order!

Hmm, maybe an interaction between Gandu's painting and the Galotrah Bracer on Kaetus?

Expected Players:
‘Alex, Derick, Sam Carolyn

Astral plane adventure it is!

Apply psychic wind where appropriate in the story

Need to find a way to narrate the environment.

What are the players here for? Why did Galtorah send ther?
To find the same way to capture/freeze the naga that Galtorah used: A Githyanki Soul Stone
Astral plane doesn't do 'time' very well - you'll see Galtorah's ghost interacting randomly at times, leading them
the way to the Gith that he used
‘The Gith are pissed about Galtorah and are hostile. He traded them prophecies that, from the Gith perspective,
have never born true

Gith Prophecy:
A Great band of hereos would soon arrive to the Astral Plane. Powerful and cunning, they would lend aid to
the Gith against their foes. That was several hundred Material years ago, and the Gith have never
encountered such heroes to date!

Gith Problem:
‘They need to get rid of a Mind Flayer that is beyond their ability to slay. They know where it resides (within a
pool of EPoWater), but every attack to kill it has backfired. They have long given up. The Mind Flayer
regularly raids the pirates own pirate ships, eating their brains and absorbing their magic. As the Gith mortal
enemy, they are willing to do whatever it takes to end this threat.

Players could fulfill the prophecy, or fight / whatever the Gith to get the Soul Stone

Astral plane:
Time moves in spurts, and not always forwards or backwards
Beware the astral wind!
Can encounter angels, demons, devils, hags, yugoloths, other planar travels
Astral boat travel - so they could get attacked by water or flying monsters, astral monsters, etc.

Result - the PC party was directed towards the Endemyon artifact. Investigating it teleported them to the astral plane,
where they found themselves aboard the astral plane ship Enemyon. It became apparent that this ship in a bottle served
as a two-way anchor portal to this astral dimension,

‘Amuch younger Galtorah spirit seems to linger on this vessel. It was surprised at the party's arrival at first, but touching
Kaeutus' Galtorah artifiact seemed to bring the spirit up to speed. He informed Kaetus that he once formed an uneasy
truce with the Githyanki, who provided him with a Githyanki Soul Stone that could capture a powerful spirt such as the
Naga's.

‘The party spent the first block of time learning about Endemyion and how to control her. A fast sloop, she is unarmed
(but had sets of elven clothes, armor, and weapons) with a large, magical tree growing in the center. The ship can be
controlled magically, or through persuading the tree to some action.

Traveling the astral plane, they first found a Merrigon Demon and its Nightmare mount. This threat was quickly dealt
with, and its burried treasure revealed. Ureasua was too quick to open the chest, and set off the Fireball explosion
embued within it. This vaporized most of the treasure and hurt all 3 members of the party.

Traveling the abyss and looking for the Gith, they soon found a Githyanki raiding party! Ureasua tried to parlay with the
pirates, but the pirates just started attacking regardless. These Gith weren't super dangerous, and were fairly quickly
dispatched. One tried to get to the helm controls, but a quick Command spell told him to Halt and stand down,

Interrogating the Gith, it became apparent that they would not surrender information easily. No bargain could be struck,
and the Gith yelled at his ship to retreat. Ureasua took the helm controls of Endimyon, and they quickly caught up to the
pirate vessel. They proceedd to ram it, inflicting heavy damage to the Gith pirate vessel.

‘Two low level Gith remained on the ship. After dispatching the first, Kaetus went below deck to look for documents
while Gandus cleaned up the second enemy. Kaetus found maps and gold, and both PCs returned aboard before the
pirate's vessel .

‘The maps indicated that the pirates had set sail from some place called Fool's Hope Stockade. It is estimated to take 2-3
days sailing time to reach it. What awaits them on this next istand? Find out on the next session of DnD!

#### ChatGPT Output:
We have a smaller group tonight, so instead of just pressing on in the main story I want to try to find and do something
special for the players. This is Thanksgiving, after all!

**Ideas:**

They are currently within Galtorah's Manor. This was their first dungeon, which I don't have a good representation of for
Roll20. Galtorah as a shade is well known, but the Elven history of these ruins has not been well explored. Some sort of
vision quest / trap / alternate pocket dimension to explore content is now in order!

Hmm, maybe an interaction between Gandu's painting and the Galotrah Bracer on Kaetus?

**Expected Players:**
- Alex
- Derick
- Sam
- Carolyn

Astral plane adventure it is!

Apply psychic wind where appropriate in the story

Need to find a way to narrate the environment.

What are the players here for? Why did Galtorah send them?
To find the same way to capture/freeze the naga that Galtorah used: A Githyanki Soul Stone
Astral plane doesn't do 'time' very well - you'll see Galtorah's ghost interacting randomly at times, leading them
the way to the Gith that he used
The Gith are pissed about Galtorah and are hostile. He traded them prophecies that, from the Gith perspective,
have never borne true

**Gith Prophecy:**
A Great band of heroes would soon arrive to the Astral Plane. Powerful and cunning, they would lend aid to
the Gith against their foes. That was several hundred Material years ago, and the Gith have never
encountered such heroes to date!

**Gith Problem:**
They need to get rid of a Mind Flayer that is beyond their ability to slay. They know where it resides (within a
pool of EPoWater), but every attack to kill it has backfired. They have long given up. The Mind Flayer
regularly raids the pirates' own pirate ships, eating their brains and absorbing their magic. As the Gith mortal
enemy, they are willing to do whatever it takes to end this threat.

Players could fulfill the prophecy, or fight / whatever the Gith to get the Soul Stone

**Astral plane:**
Time moves in spurts, and not always forwards or backwards
Beware the astral wind!
Can encounter angels, demons, devils, hags, yugoloths, other planar travels
Astral boat travel - so they could get attacked by water or flying monsters, astral monsters, etc.

Result - the PC party was directed towards the Endemyon artifact. Investigating it teleported them to the astral plane,
where they found themselves aboard the astral plane ship Enemyon. It became apparent that this ship in a bottle served
as a two-way anchor portal to this astral dimension,

A much younger Galtorah spirit seems to linger on this vessel. It was surprised at the party's arrival at first, but touching
Kaetus' Galtorah artifact seemed to bring the spirit up to speed. He informed Kaetus that he once formed an uneasy
truce with the Githyanki, who provided him with a Githyanki Soul Stone that could capture a powerful spirit such as the
Naga's.

The party spent the first block of time learning about Endemyion and how to control her. A fast sloop, she is unarmed
(but had sets of elven clothes, armor, and weapons) with a large, magical tree growing in the center. The ship can be
controlled magically, or through persuading the tree to some action.

Traveling the astral plane, they first found a Merrigon Demon and its Nightmare mount. This threat was quickly dealt
with, and its buried treasure revealed. Ureasua was too quick to open the chest, and set off the Fireball explosion
embued within it. This vaporized most of the treasure and hurt all 3 members of the party.

Traveling the abyss and looking for the Gith, they soon found a Githyanki raiding party! Ureasua tried to parlay with the
pirates, but the pirates just started attacking regardless. These Gith weren't super dangerous, and were fairly quickly
dispatched. One tried to get to the helm controls, but a quick Command spell told him to Halt and stand down.

Interrogating the Gith, it became apparent that they would not surrender information easily. No bargain could be struck,
and the Gith yelled at his ship to retreat. Ureasua took the helm controls of Endimyon, and they quickly caught up to the
pirate vessel. They proceeded to ram it, inflicting heavy damage to the Gith pirate vessel.

Two low level Gith remained on the ship. After dispatching the first, Kaetus went below deck to look for documents
while Gandus cleaned up the second enemy. Kaetus found maps and gold, and both PCs returned aboard before the
pirate's vessel.

The maps indicated that the pirates had set sail from some place called Fool's Hope Stockade. It is estimated to take 2-3
days sailing time to reach it. What awaits them on this next island? Find out on the next session of DnD!

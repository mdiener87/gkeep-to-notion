# Session 24 - Fallout

    **Created:** 2021-10-29 11:34:51  
    **Last Edited:** 2021-10-29 11:34:54  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Not much prep coming into today but | know where this is heading... Into the remains of Galtorah's Keep!

‘The PC explored this keep as their first dungeon. Now, they once again delve it for further secrets. A Naga has taken up
residence and is using Galtorah's Mirror of Prophecy to channel her wicked Magick. The Borrend Disaster has given her
everything she needs to exert her toxic will across the area.

Mirror of Prophecy - Galtorah used this to see both past and future events. This ability let him rule the kingdom for a
hundred years of prosperity. The branching, twisting paths of future reality slowly drove Galtorah insane. Many paths
eventually culminated in the 'malestram’. A confluence of time and probability that resulted in the destruction of the
kingdom. Gattorah, for all his research, never could navigate around this outcome.

Changed up the maps a bit. The Naga has been breed Slaad in Galtorah's keep.

Result:
Players had some conversations with the stone druids and Lerry. Stone Druids explained the corrupted druidic magic
that came forth from Borrend and was used in the Doom Cannon. They aren't sure how to solve it. The Party tried to
heal Tordid, but didn't have much luck with her burns.

Kaetus spoke with Galtorah, which has an easier connection close to his former Keep. He learned that there are dangers
lurking in the keep and that Prince Zelphar's magic prevents him from discussing that event easily.

‘They wind walked to Galtorah's keep. There has been some excavation (map changes lol). Blue Slaad attacked the
players once they could smell them as non-cloud humans. Battle broke out. The Slaad were fairly easily dispatched but
the battle took a bit to resolve, Dore and Zephyr were hit by claws and infected with Chaos Phage. Gandus was able to
use lay on hands to heal the disease.

‘The party will take a small rest. Next time... the rest of the dungeon!

#### ChatGPT Output:
Not much prep coming into today but I know where this is heading... Into the remains of Galtorah's Keep!

The PC explored this keep as their first dungeon. Now, they once again delve it for further secrets. A Naga has taken up
residence and is using Galtorah's Mirror of Prophecy to channel her wicked Magick. The Borrend Disaster has given her
everything she needs to exert her toxic will across the area.

**Mirror of Prophecy** - Galtorah used this to see both past and future events. This ability let him rule the kingdom for a
hundred years of prosperity. The branching, twisting paths of future reality slowly drove Galtorah insane. Many paths
eventually culminated in the 'malestram’. A confluence of time and probability that resulted in the destruction of the
kingdom. Gattorah, for all his research, never could navigate around this outcome.

Changed up the maps a bit. The Naga has been breeding Slaad in Galtorah's keep.

**Result:**
Players had some conversations with the stone druids and Lerry. Stone Druids explained the corrupted druidic magic
that came forth from Borrend and was used in the Doom Cannon. They aren't sure how to solve it. The Party tried to
heal Tordid, but didn't have much luck with her burns.

Kaetus spoke with Galtorah, which has an easier connection close to his former Keep. He learned that there are dangers
lurking in the keep and that Prince Zelphar's magic prevents him from discussing that event easily.

They wind walked to Galtorah's keep. There has been some excavation (map changes lol). Blue Slaad attacked the
players once they could smell them as non-cloud humans. Battle broke out. The Slaad were fairly easily dispatched but
the battle took a bit to resolve, Dore and Zephyr were hit by claws and infected with Chaos Phage. Gandus was able to
use lay on hands to heal the disease.

The party will take a small rest. Next time... the rest of the dungeon!

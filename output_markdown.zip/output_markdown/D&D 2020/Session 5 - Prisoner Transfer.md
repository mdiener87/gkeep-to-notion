# Session 5 - Prisoner Transfer

    **Created:** 2021-10-29 11:30:27  
    **Last Edited:** 2021-10-29 11:30:35  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party has captured Nenetl - now how to get her to the King to face justice? They want to put on a public trial to hold

Nenetl responsible for her crimes. Unseen forces are stirring - they'd rather Nenetl be dead, less she spill her final
secrets,

‘The party has been making progress decrypting the Drow documents. A partial decryption has revealed the dungeon
Nenet! originally found them in. Located in the Beaconport Abyss near Ennui, this ancient drown enclave holds secrets
best left alone...

Result:

‘The Maurzhel snuck into the keep while the party was in the dungeon watching Nenetl. A fight broke out - Nahruzi and
‘Shoosuva busting into the keep and killing Sgt. Griffin immediatley. Lt. Lycos was gravely wounded and paralzyed in the
fight. The shoosuva hit Harold hard.

Meanwhile, a Retriver materalized in the dungeon and attempted to snatch Nenetl. The reaminaing guards around her
(Dorc, Kaetus, and Clara) were able to DPS the retriever down before it got too far. They retrieved a Retriever Heart and

oun Stone of Awareness from its corpse.

‘At end of session, Kaetus dispelled the curse from Nenett. This attempt was succesfull, but set off the curse's ‘if removed
early’ rider clause. A dark orb of magic started to form - what will this effect cause?

Find out next time on DND!

#### ChatGPT Output:
'''‘The party has captured Nenetl - now how to get her to the King to face justice? They want to put on a public trial to hold

Nenetl responsible for her crimes. Unseen forces are stirring - they'd rather Nenetl be dead, less she spill her final
secrets,

‘The party has been making progress decrypting the Drow documents. A partial decryption has revealed the dungeon
Nenetl originally found them in. Located in the Beaconport Abyss near Ennui, this ancient drow enclave holds secrets
best left alone...

Result:

‘The Maurzhel snuck into the keep while the party was in the dungeon watching Nenetl. A fight broke out - Nahruzi and
‘Shoosuva busting into the keep and killing Sgt. Griffin immediately. Lt. Lycos was gravely wounded and paralyzed in the
fight. The shoosuva hit Harold hard.

Meanwhile, a Retriever materialized in the dungeon and attempted to snatch Nenetl. The remaining guards around her
(Dorc, Kaetus, and Clara) were able to DPS the retriever down before it got too far. They retrieved a Retriever Heart and

an Stone of Awareness from its corpse.

‘At end of session, Kaetus dispelled the curse from Nenetl. This attempt was successful, but set off the curse's ‘if removed
early’ rider clause. A dark orb of magic started to form - what will this effect cause?

Find out next time on DND!'''

# Session 28 - What Was Left Behind

    **Created:** 2021-10-29 11:35:39  
    **Last Edited:** 2021-10-29 11:35:44  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
It's a boy's night - four players, all our guys. So expect it to be run faster and tighter than our usual games (sorry ladies).
‘The PCs are currently deep within Galtorah's Mannor. They've cleaned up a bunch of low level undead type monsters,
and now have the bodies to investigate and map to explore. | expect we can get the boss fight in tonight, and also tease
some more Galtorah lore. The Naga was experimented on by Galotrah, after all. They are truly immortal creatures. It
might have a grudge.

Potential Thought - make Dissa a captive of the Naga. This is a less obvious move, previously considered making Prince
Zelphar the tyrant here. The Naga has access to the Mirror of Prophecy, and it could potentially divine through said
mirror that the Order could show up one day and ruin his whole evening. Why nat grab Dissa as some cheap and easy
collateral?

Structure of the evening
- Loot / Explore
- Some Combat
- Boss battle?
- Ete

Intermediate fight:
More Slaad, but keep it realitvely light for time constraint.

Boss: Spirit Naga Zsedhaczes}
As spirit naga, plus:

Legendary Save at will 1/Day

uickened Spell (up to 3rd level) 2/Day
HP: 150

Bite: +10 to hit, 1d8 + 10 piercing damage.
can

Has Dissa dominated with mental magic. She will fight on his behalf.

Dissa, Mind Controlled Apothecary:
30HP, AC 12

Dwarfen Warhammer, +3 to hit, 1d12 + 3 bludgeoning damage

2x Incendiary Vials, +3 to hit, 344 fire damage. DC13 reflex save or be lit on fire. Roll a D10 on hit. On 8 or higher, the
‘square is also ignited

2x Toxic Vials, +3 to hit, 1d6 poison damage. DC13 CON save or move at half speed and have disadvantage on attack rolls
until end of the next round.

Can also summon Yuntai True bloods, snakes, and undead, as the stats
Fight: 2x Yuan Ti, True bloods, Disa, and the Naga
Result:

Players looted area, and found a secret ladder down to the antechamber to the Naga boss fight.
‘They then went into the spaceship Endimyon, and Rped their way into an encounter with the Gith at Fools Hope
Stockade

‘There, they bartered with Lazarah for a Gith Soul Stone. This device took a 1,000 GP down payment, on condition the PC
return the soul stone to the Gith with the Naga soul stored. If done so, they would offer up another 3,000 GP (plus the
downpayment) in recompense.

#### ChatGPT Output:
It's a boy's night - four players, all our guys. So expect it to be run faster and tighter than our usual games (sorry ladies).

‘The PCs are currently deep within Galtorah's Manor. They've cleaned up a bunch of low-level undead type monsters, and now have the bodies to investigate and map to explore. I expect we can get the boss fight in tonight, and also tease some more Galtorah lore. The Naga was experimented on by Galotrah, after all. They are truly immortal creatures. It might have a grudge.

Potential Thought - make Dissa a captive of the Naga. This is a less obvious move, previously considered making Prince Zelphar the tyrant here. The Naga has access to the Mirror of Prophecy, and it could potentially divine through said mirror that the Order could show up one day and ruin his whole evening. Why not grab Dissa as some cheap and easy collateral?

### Structure of the evening
- Loot / Explore
- Some Combat
- Boss battle?
- Etc

#### Intermediate fight:
More Slaad, but keep it relatively light for time constraint.

#### Boss: Spirit Naga Zsedhaczes
As spirit naga, plus:

- Legendary Save at will 1/Day
- Quickened Spell (up to 3rd level) 2/Day
- HP: 150
- Bite: +10 to hit, 1d8 + 10 piercing damage.

Has Dissa dominated with mental magic. She will fight on his behalf.

#### Dissa, Mind Controlled Apothecary:
- 30HP, AC 12
- Dwarfen Warhammer, +3 to hit, 1d12 + 3 bludgeoning damage
- 2x Incendiary Vials, +3 to hit, 3d4 fire damage. DC13 reflex save or be lit on fire. Roll a D10 on hit. On 8 or higher, the square is also ignited
- 2x Toxic Vials, +3 to hit, 1d6 poison damage. DC13 CON save or move at half speed and have disadvantage on attack rolls until end of the next round.

Can also summon Yuan-Ti Truebloods, snakes, and undead, as the stats
Fight: 2x Yuan-Ti, Truebloods, Disa, and the Naga
Result:

Players looted area, and found a secret ladder down to the antechamber to the Naga boss fight. They then went into the spaceship Endimyon, and RPed their way into an encounter with the Gith at Fools Hope Stockade.

There, they bartered with Lazarah for a Gith Soul Stone. This device took a 1,000 GP down payment, on condition the PC return the soul stone to the Gith with the Naga soul stored. If done so, they would offer up another 3,000 GP (plus the downpayment) in recompense.

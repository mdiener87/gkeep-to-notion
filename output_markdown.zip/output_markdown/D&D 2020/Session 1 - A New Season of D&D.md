# Session 1 - A New Season of D&D

    **Created:** 2021-10-29 11:29:32  
    **Last Edited:** 2021-10-29 11:29:40  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
This is our first session of the new year. Our players have decided to continue the game in the same world we played
in 2019 - The Kingdom of Dawn. This season, however, is played with a mostly new party. Ayden and Odessyus bath
fell in battle against Kaladan. Plus Aaron and Carolyn are both out entirely. Evan and Sam want to play new
characters, So only Derick’s Kaetus and Kevin's Dorc will be continuing into this new season. Barb will be joining as.
our new player, with an unknown class.

So this new season needs to stand apart compared to the season of storytelling that came before it. It should not
pick up right where players left off. It should have new themes, new faces, new problems to solve. The Order of Sun
and Moon continues on, but this is a whole new season of D&D.

‘We will be opening with setting up Barb's character and then intro to the game and the world.

Intro - mop up action against the remains of the cultists. It took some time, but Elyriss has divined the probable
location of Governor Nenetl. This traitor helped turn much of the populace of Chipahua towards the cultists, and she
personally ambushed the Order when they visited. Nenetl has been holled up in the Troster Slopes, north and east of
Chipahua. if she can be captured or killed, the final remnants of the cuft will be crushed once and for all.

Intro Dungeon:
Shadow cult members to start with. These are recognizable villains from last season and the players are well versed
at killing them. This will give everyone a chance to knock some dust off on familiar targets with their new characters.
Nenetl should have something cool up her sleeves to make the fight interesting,

However, the cultist members are really just the hook. The real plot line is their document - a Drow map. The
document is encrypted, but its clearly documenting the whereabouts of the Tower of Bithyra.

[Encounters]
*  Qutside the mountain:
© Creatures:
= Manticore (MM213) x2 + Tanarukk (Volo186) x2
= Owlbear family x5
= Earth Elementals x3
= Chimera x2 (MIM39)
© Environmental:
= [Harsh Weather]
= Small mountain cabin
© Two human cultists outside
© More dragon cultists inside
(© Hidden passage way to a tunnel inside
= Can be revealed to be drow construction
= Drow tunnels
© Obstacles:
= Suspended rope bridge
= Broken ladders / tall cliff faces,
© Traps:
= Poison barb trip lines - DC16 spot/disable. 206 piercing damaage +6 to hit. DC16 con
save or 4d6 poison damage and poisoned. Or 26 poison damage on save,
= Cave in - loose rock can tumble down in sections, DC12 to spot, DC14 to stabilize.
D100 when passing through to trigger (70 or higher is triggered).
© Creatures:
= Ettinx3 Cave
= Dire Basilisk + x5 spectres (victim spirits)
= Drow Scouting party - investigating tunnel usage
= Shadow Dragon Cultists
= Shadow Human cultists

= Small treasure chest
= Potions
+ Neneti's Lair
© Nenet!- Insane Druid Cultist
= Casts spells from range, will transform into a spider if people get close
© Two cultists for backup
© Nenet! can summon phase spiders
= Two shadow orbs in her lair. Each controls a Phase Spider she has soul grafted
= Shadow Orbs: AC 15, HP 15. If destroyed, Phase Spider control is released
= If Phase spider is killed while shadow orb is active, a new spider is grafted and phases
in at End of Round

Tower of Bithyra
An old Elven song tells the tragedy of Bithyra. Itis a haunting,
slow song, echoing pain and remorse. Bithyra is where children
goto scream, and never again be heard. It is Where lovers go
to touch, and never again be felt. itis where one may goto ki
and never find the satisfaction of death. Such is the curse
described across its haunting melody.

‘Such songs are considered part of Elven classical oral history.
‘They are not considered as having a basis in factual history.

#### ChatGPT Output:
This is our first session of the new year. Our players have decided to continue the game in the same world we played
in 2019 - The Kingdom of Dawn. This season, however, is played with a mostly new party. Ayden and Odessyus both
fell in battle against Kaladan. Plus Aaron and Carolyn are both out entirely. Evan and Sam want to play new
characters, so only Derick’s Kaetus and Kevin's Dorc will be continuing into this new season. Barb will be joining as
our new player, with an unknown class.

So this new season needs to stand apart compared to the season of storytelling that came before it. It should not
pick up right where players left off. It should have new themes, new faces, new problems to solve. The Order of Sun
and Moon continues on, but this is a whole new season of D&D.

We will be opening with setting up Barb's character and then intro to the game and the world.

Intro - mop up action against the remains of the cultists. It took some time, but Elyriss has divined the probable
location of Governor Nenetl. This traitor helped turn much of the populace of Chipahua towards the cultists, and she
personally ambushed the Order when they visited. Nenetl has been holed up in the Troster Slopes, north and east of
Chipahua. If she can be captured or killed, the final remnants of the cult will be crushed once and for all.

Intro Dungeon:
Shadow cult members to start with. These are recognizable villains from last season and the players are well versed
at killing them. This will give everyone a chance to knock some dust off on familiar targets with their new characters.
Nenetl should have something cool up her sleeves to make the fight interesting.

However, the cultist members are really just the hook. The real plot line is their document - a Drow map. The
document is encrypted, but it's clearly documenting the whereabouts of the Tower of Bithyra.

[Encounters]
* Outside the mountain:
  * Creatures:
    * Manticore (MM213) x2 + Tanarukk (Volo186) x2
    * Owlbear family x5
    * Earth Elementals x3
    * Chimera x2 (MM39)
  * Environmental:
    * [Harsh Weather]
    * Small mountain cabin
    * Two human cultists outside
    * More dragon cultists inside
    * Hidden passageway to a tunnel inside
    * Can be revealed to be Drow construction
    * Drow tunnels
  * Obstacles:
    * Suspended rope bridge
    * Broken ladders / tall cliff faces
  * Traps:
    * Poison barb trip lines - DC16 spot/disable. 20 piercing damage +6 to hit. DC16 con
      save or 4d6 poison damage and poisoned. Or 20 poison damage on save.
    * Cave in - loose rock can tumble down in sections, DC12 to spot, DC14 to stabilize.
      D100 when passing through to trigger (70 or higher is triggered).
  * Creatures:
    * Ettin x3 Cave
    * Dire Basilisk + x5 spectres (victim spirits)
    * Drow Scouting party - investigating tunnel usage
    * Shadow Dragon Cultists
    * Shadow Human cultists

  * Small treasure chest
  * Potions
  * Nenetl's Lair
    * Nenetl- Insane Druid Cultist
    * Casts spells from range, will transform into a spider if people get close
    * Two cultists for backup
    * Nenetl can summon phase spiders
    * Two shadow orbs in her lair. Each controls a Phase Spider she has soul grafted
    * Shadow Orbs: AC 15, HP 15. If destroyed, Phase Spider control is released
    * If Phase spider is killed while shadow orb is active, a new spider is grafted and phases
      in at End of Round

Tower of Bithyra
An old Elven song tells the tragedy of Bithyra. It is a haunting,
slow song, echoing pain and remorse. Bithyra is where children
go to scream, and never again be heard. It is where lovers go
to touch, and never again be felt. It is where one may go to kill
and never find the satisfaction of death. Such is the curse
described across its haunting melody.

Such songs are considered part of Elven classical oral history.
They are not considered as having a basis in factual history.

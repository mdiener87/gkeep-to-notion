# Session 29 - An Early Christmas Session

    **Created:** 2021-10-29 11:35:49  
    **Last Edited:** 2021-10-29 11:35:59  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Not much real planning today, but that's okay. Just roll off from last session and be ready for either astral plane
exploration or the boss fight.

Result:

Astral plane shopping!
Bought a snake staff for Ureasua and paid nothing for it,

Dore seduced a Summer Eladrin and got a perm bonus to his Seduction

Kaetus bought astral water for Endimyon

Zephyr noticed Smoke Mephits trying to board the vessel. After dealing with them, they learned they are probably
agents from Rezena, Shadowdragon

Kaetus enchanced his shield to +3 quality, but it came with a curse/bonus effect that draws missiles towards him
Gandus bought a spell scroll

#### ChatGPT Output:
Not much real planning today, but that's okay. Just roll off from last session and be ready for either astral plane
exploration or the boss fight.

Result:

- Astral plane shopping!
  - Bought a snake staff for Ureasua and paid nothing for it,
  - Dore seduced a Summer Eladrin and got a perm bonus to his Seduction
  - Kaetus bought astral water for Endimyon
  - Zephyr noticed Smoke Mephits trying to board the vessel. After dealing with them, they learned they are probably
    agents from Rezena, Shadowdragon
  - Kaetus enhanced his shield to +3 quality, but it came with a curse/bonus effect that draws missiles towards him
  - Gandus bought a spell scroll

# Session 17 - on False Flags

    **Created:** 2021-10-29 11:33:02  
    **Last Edited:** 2021-10-29 11:33:36  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party is landing at Black Scar Garrison base. Led by a commander Tristan, our players are moving deeper into a
murky plot. who is attacking whom? And to what end?

If exploring nearby forests, roll random encounters

"Deep Gnome" + Duregar forces have augmented the military at Borrend. This is highly unusual, as they are normally
against democratic or lawful governments. These forces are using gnomish-engineered mecha forces to augment their
abilities.

Tristan - wants open war. Is very frustrated with the king's lack of additional forces or allowing him to engage the
enemy. He has numerous injured soldiers who will attest to Borrend aggression.

Result:

Party went to the Black Scar Garrison, investigated the reports of battle and met with Commander Tristan. A large
amount of RP occurred as they got him a bit drunk and learned of his motivations. While a bit of an asshole, he is still a
loyal soldier for the kingdom and is tired of bloodshed.

‘The party followed up reports of ambushes, and found a bridge leading toward borrend with dwarfes on it. After walking
into the obvious trap, the party laid waste to the Duergar forces that tried to ambush them. They learned, investigating
the bodies, that they might well be Duergar and not the common’ variety of Gnome and Dwarf that inhabit borrend.
‘The Dwarfen Warlord escaped with 3 hp, casting invisibility and fleeing the battle. The scent of magic he left in his wake
led to Borrend...

#### ChatGPT Output:
'The party is landing at Black Scar Garrison base. Led by a commander Tristan, our players are moving deeper into a
murky plot. Who is attacking whom? And to what end?

If exploring nearby forests, roll random encounters

"Deep Gnome" + Duregar forces have augmented the military at Borrend. This is highly unusual, as they are normally
against democratic or lawful governments. These forces are using gnomish-engineered mecha forces to augment their
abilities.

Tristan - wants open war. Is very frustrated with the king's lack of additional forces or allowing him to engage the
enemy. He has numerous injured soldiers who will attest to Borrend aggression.

Result:

Party went to the Black Scar Garrison, investigated the reports of battle and met with Commander Tristan. A large
amount of RP occurred as they got him a bit drunk and learned of his motivations. While a bit of an asshole, he is still a
loyal soldier for the kingdom and is tired of bloodshed.

The party followed up reports of ambushes, and found a bridge leading toward Borrend with dwarves on it. After walking
into the obvious trap, the party laid waste to the Duergar forces that tried to ambush them. They learned, investigating
the bodies, that they might well be Duergar and not the common variety of Gnome and Dwarf that inhabit Borrend.
The Dwarfen Warlord escaped with 3 hp, casting invisibility and fleeing the battle. The scent of magic he left in his wake
led to Borrend...

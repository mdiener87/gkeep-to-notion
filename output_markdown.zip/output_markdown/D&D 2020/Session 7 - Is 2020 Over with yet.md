# Session 7 - Is 2020 Over with yet?

    **Created:** 2021-10-29 11:30:50  
    **Last Edited:** 2021-10-29 11:31:00  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
So in addition to my breakup, I've had to deal with a worldwide pandemic, lockdown of the city, moving to a new
apartment, and nationwide protests. This year has sucked. Like, really sucked. But the show must, somehow, go on. And
it's time to start to get the band back together here.

What will that require

Learning Roll20
Getting everyone on Beyond DD
Including the DM
Building a game temp back up
Everyone remembering how to play
Remembering how to DM
Bringing the story back into focus, which never really got going in the first place.

Roll20
For tonight, let's just get a generic space going. Maybe | can throw something simple at the players so they can
learn how to use Roll20 with me, and remember how to play the game some.

Generic battle space for their tokens
Set up the website and get that going

Beyond D&D
Get logged in and take inventory of everyone who has character sheets already set up

‘The Campaign Itself
Let's take @ minute and type out where everything is at from this season's events

‘The party is currently at the Military Garison within El Enna. They have defeated the Demon llitran after she
emerged from Nenet''s curse. Nenetl, meanwhile, was transformed into a Dryder monstrosity. The party has
cleared up the fight in the dungeon, holding only the decrypted map to find the Tower af Bithyra somewhere in
the Beaconport Abyss.

Nenet! was supposed to be returned to face the King's justice, but that is no longer an option with her death. She

‘was the last known remenant of the ShadowDragon cult. With her demise, perhaps the kingdom can begin to heal.

Result:
Gandus prayed over the dead soldier slain in the (months ago now) fight in the El Enna Keep. The party
killed the last ishulva demon lurking in the garden. FIN

Tower of Bithyra

Bithyra was a half-Drow, half-elf Prince. Back when the Kingdom was still ruled by
elves, Bithyra was a candidate to rise as king. However, his Drow ancestory was
discovered, and he was subsequently banished from the Kingdom and stripped of his
birthright to the throne. Bithyra Fled, and was never seen again within the kingdom.
‘The incident was suppresed from the official records.

Bithyra's Tower, however, would slowly gain notoriety. While no official location can
be ascribed to it, the fate of those who do wander too close were clearly defined. It
was a place of madness, terror, and murder.

Slowly, Bithyra's plans have come together. Guided by the Drow God Loloth, and with
her attendant’s help, Bithyra has at last pieced together his revenge. Bithyra himself is
long dead, but his demonic spirit lingers on. The tower has drawn in a multitude of
lost and suffering souls, Using them as a power source, he at last has the army
neccesary to catapult Drow society as the true rulers of the Kingdom, with his own
ghastly lich-form to lead it.

Drow city under the tower of bithyra. He is trying to raise it to the surface, and power
an immense Orb of Darkness that will perpetually drown the kingdom in darkness.

#### ChatGPT Output:
So in addition to my breakup, I've had to deal with a worldwide pandemic, lockdown of the city, moving to a new
apartment, and nationwide protests. This year has sucked. Like, really sucked. But the show must, somehow, go on. And
it's time to start to get the band back together here.

### What will that require

- Learning Roll20
- Getting everyone on Beyond D&D
  - Including the DM
- Building a game temp back up
- Everyone remembering how to play
- Remembering how to DM
- Bringing the story back into focus, which never really got going in the first place.

#### Roll20
For tonight, let's just get a generic space going. Maybe I can throw something simple at the players so they can
learn how to use Roll20 with me, and remember how to play the game some.

- Generic battle space for their tokens
- Set up the website and get that going

#### Beyond D&D
Get logged in and take inventory of everyone who has character sheets already set up

#### The Campaign Itself
Let's take a minute and type out where everything is at from this season's events

The party is currently at the Military Garrison within El Enna. They have defeated the Demon Ilitran after she
emerged from Nenet's curse. Nenetl, meanwhile, was transformed into a Dryder monstrosity. The party has
cleared up the fight in the dungeon, holding only the decrypted map to find the Tower of Bithyra somewhere in
the Beaconport Abyss.

Nenetl was supposed to be returned to face the King's justice, but that is no longer an option with her death. She
was the last known remnant of the ShadowDragon cult. With her demise, perhaps the kingdom can begin to heal.

**Result:**
Gandus prayed over the dead soldier slain in the (months ago now) fight in the El Enna Keep. The party
killed the last ishulva demon lurking in the garden. FIN

#### Tower of Bithyra

Bithyra was a half-Drow, half-elf Prince. Back when the Kingdom was still ruled by
elves, Bithyra was a candidate to rise as king. However, his Drow ancestry was
discovered, and he was subsequently banished from the Kingdom and stripped of his
birthright to the throne. Bithyra fled, and was never seen again within the kingdom.
The incident was suppressed from the official records.

Bithyra's Tower, however, would slowly gain notoriety. While no official location can
be ascribed to it, the fate of those who do wander too close were clearly defined. It
was a place of madness, terror, and murder.

Slowly, Bithyra's plans have come together. Guided by the Drow God Lolth, and with
her attendant’s help, Bithyra has at last pieced together his revenge. Bithyra himself is
long dead, but his demonic spirit lingers on. The tower has drawn in a multitude of
lost and suffering souls, Using them as a power source, he at last has the army
necessary to catapult Drow society as the true rulers of the Kingdom, with his own
ghastly lich-form to lead it.

Drow city under the tower of Bithyra. He is trying to raise it to the surface, and power
an immense Orb of Darkness that will perpetually drown the kingdom in darkness.

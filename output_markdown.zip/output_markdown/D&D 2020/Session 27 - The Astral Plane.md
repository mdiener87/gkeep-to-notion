# Session 27 - The Astral Plane

    **Created:** 2021-10-29 11:35:29  
    **Last Edited:** 2021-10-29 11:35:34  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, our players are still aboard the Endimyon. They are on their way to Fools Hope Stockades - a
‘small Githyanki pirate base + prison, These Gith have Gethzerai prisoners. Either faction is capable of supplying a
Gith/Geth Sou! Stone of sufficent quality to capture the soul of a spirit naga and (temporarily) freeze its reincarnation
qyele.

Gith and Geth are basically the same thing, Both are pirates. Both raid the others. Both hate the other faction for
reasons nobody else cares about.

Gith will threaten piracy on sight, but can be bargained with if PCs play their cards correctly. Because ultimatley, they
‘want to kill a Mindflayer, and can make a deal with some random mortals to that end.

Arcane Mindflayer
Has a spell the Gith can't get around - a dome of force around the portal entrance to its realm. with such blasphemous

arcane magic, it has so far proven safe from Gith attack, yet free to launch its own raids across the cosmos.

Mindflayer: Srassk

Night Hag: Shizuka
Result:

Players started heading to the Stockades, and came across another small astral island, On it they met the night hag
Shizuka, which tried to barter with the party. After a bit of back and forth they decided not to buy anything. The night
hag considered treachery, but saw the full party would be too much for it to outright attack. It despratley wanted to buy

Kaetus' entrapped Orthon demon, however.

‘A psychic wind started approaching, which Endimyon warned the party about. Unsure how to face this danger, they
used the World in a Bottle to return back to the material realm.

Contacting Lerry, they learned they had been in the astral plane for ‘several days'.
‘The Party ventured deeper into the dungeon. They came into the crypts of the keep, and faced many a Bodak, Flaming
‘Skull, and Bona Nagas. These undead monstrosities were no match for the Order of Sun and Moon, which cut through

their foul ranks!

Next time - explore the room and loot the bodies. Will they soon reach the boss!?

#### ChatGPT Output:
Coming into this session, our players are still aboard the Endimyon. They are on their way to Fools Hope Stockades - a
small Githyanki pirate base + prison. These Gith have Gethzerai prisoners. Either faction is capable of supplying a
Gith/Geth Soul Stone of sufficient quality to capture the soul of a spirit naga and (temporarily) freeze its reincarnation
cycle.

Gith and Geth are basically the same thing. Both are pirates. Both raid the others. Both hate the other faction for
reasons nobody else cares about.

Gith will threaten piracy on sight, but can be bargained with if PCs play their cards correctly. Because ultimately, they
want to kill a Mindflayer, and can make a deal with some random mortals to that end.

**Arcane Mindflayer**
Has a spell the Gith can't get around - a dome of force around the portal entrance to its realm. With such blasphemous
arcane magic, it has so far proven safe from Gith attack, yet free to launch its own raids across the cosmos.

**Mindflayer: Srassk**

**Night Hag: Shizuka**

Result:

Players started heading to the Stockades, and came across another small astral island. On it they met the night hag
Shizuka, which tried to barter with the party. After a bit of back and forth they decided not to buy anything. The night
hag considered treachery, but saw the full party would be too much for it to outright attack. It desperately wanted to buy
Kaetus' entrapped Orthon demon, however.

A psychic wind started approaching, which Endimyon warned the party about. Unsure how to face this danger, they
used the World in a Bottle to return back to the material realm.

Contacting Lerry, they learned they had been in the astral plane for several days.
The Party ventured deeper into the dungeon. They came into the crypts of the keep, and faced many a Bodak, Flaming
Skull, and Bone Nagas. These undead monstrosities were no match for the Order of Sun and Moon, which cut through
their foul ranks!

Next time - explore the room and loot the bodies. Will they soon reach the boss!?

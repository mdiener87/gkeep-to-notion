# Session 13 - Brathrizard

    **Created:** 2021-10-29 11:32:06  
    **Last Edited:** 2021-10-29 11:32:13  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Does today happen? Maybe run the bonus content of the caves and save the boss fight for more players

‘The party encountered - and fought - Brathrizad. Despite some clever tactices, and conjuring Elemental allies, they were
ho match for its Overwhelming power. In one clutch moment, Kaetus was able to poly the Narzugon into an actups
while he himself dangled over a perilous ravine. This bought the party enough time to grab Gil's soul vial, and extract,
with Gildas and a heavily injured Princess Rose. The Narzugon pursued them, but was unable to close enough to
maintain combat.

#### ChatGPT Output:
Does today happen? Maybe run the bonus content of the caves and save the boss fight for more players

'The party encountered - and fought - Brathrizad. Despite some clever tactics, and conjuring Elemental allies, they were
no match for its overwhelming power. In one clutch moment, Kaetus was able to poly the Narzugon into an octopus
while he himself dangled over a perilous ravine. This bought the party enough time to grab Gil's soul vial, and extract,
with Gildas and a heavily injured Princess Rose. The Narzugon pursued them, but was unable to close enough to
maintain combat.'

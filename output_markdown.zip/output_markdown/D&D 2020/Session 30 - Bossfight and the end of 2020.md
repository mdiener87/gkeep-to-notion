# Session 30 - Bossfight and the end of 2020

    **Created:** 2021-10-29 11:36:04  
    **Last Edited:** 2021-10-29 11:36:11  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Dissa is a brainwashed captive of the Naga. The Naga has traded the Mirror of Prophecy to Prince Zelphar, in exchange
for the power to crush the Order during their foretold battle.

Structure of the evening
- Return to material realm
- Some light Combat before the boss
- Boss battle

Intermediate fight:
More Slaad, but keep it realitvely light for time constraint.

Boss: Spirit Naga Zsedhaczes|
AAs spirit naga, plus:

Legendary Save at will 2/Day

uickened Spell (up to 3rd level) 2/Day

HP: 200 {could be 150 if fight too hard)

ACT

Spell Save DC: 18

Poison Bite Save DC: 14

Bite: +10 to hit, 1d8 + 10 piercing damage.

Lair actions:

Obscuring Mist -
A cloud of mist forms around a point within the naga's lair, 20ft in diamater. tt fills the space and bends around
corners, All within the mist are considred obscured.

Constricting Snakes
‘Snakes emerge from the ground and attempt to constrain all enemies. DC15 reflex to avoid. DC18STR or DEX to
break free, Effect ends at end of round.

‘Summon Yuan Ti
104 Yuan Ti servants emerge and join the fight

‘Summon Snake Swarm
104 swarm of snakes emerge and join the fight

Poison Destiny
‘A deadly, concealed bolt is fired from a panel within the wall. DC20 DEX to avoid. On hit, the target makes a DC20
con save, or takes 10d10 poison damage and is paralyzed and poisoned, or half damage and no paralysis.

Reversal of Fate
‘The next time an attack would deal more than 30 damage to the naga this round, the Naga instead supernaturally
parties and reflects the attack back onto the attacker. The attacker must make a DC20 WIS save to cancel the
original attack. Otherwise, the Naga rolls 1D10, adding the value to the original attack roll, and returns the entire
attack back at the attacker. All damage to the naga from this attack is canceled in any result.

Has Dissa dominated with mental magic. She will fight on his behalf.

Dissa, Mind Controlled Apothecary:

30HP, AC 12

Dwarfen Warhammer, +3 to hit, 1d12 +3 bludgeoning damage

2x Incendiary Vials, +3 to hit, 344 fire damage. DC13 reflex save or be lit on fire. Roll a D.10 on hit. On 8 or higher, the
‘square is also ignited

2x Toxic Vials, +3 to hit, 1d6 poison damage. DC13 CON save or move at half speed and have disadvantage on attack rolls
until end of the next round.

Fight start: 2x Yuan Ti True bloods, Dissa, and the Naga

#### ChatGPT Output:
Dissa is a brainwashed captive of the Naga. The Naga has traded the Mirror of Prophecy to Prince Zelphar, in exchange
for the power to crush the Order during their foretold battle.

**Structure of the evening**
- Return to material realm
- Some light Combat before the boss
- Boss battle

**Intermediate fight:**
More Slaad, but keep it relatively light for time constraint.

**Boss: Spirit Naga Zsedhaczes**
As spirit naga, plus:

- Legendary Save at will 2/Day
- Quickened Spell (up to 3rd level) 2/Day
- HP: 200 (could be 150 if fight too hard)

**ACT**

- Spell Save DC: 18
- Poison Bite Save DC: 14
- Bite: +10 to hit, 1d8 + 10 piercing damage.

**Lair actions:**

- **Obscuring Mist** -
  A cloud of mist forms around a point within the naga's lair, 20ft in diameter. It fills the space and bends around
  corners, All within the mist are considered obscured.

- **Constricting Snakes**
  Snakes emerge from the ground and attempt to constrain all enemies. DC15 reflex to avoid. DC18 STR or DEX to
  break free, Effect ends at end of round.

- **Summon Yuan Ti**
  1d4 Yuan Ti servants emerge and join the fight

- **Summon Snake Swarm**
  1d4 swarm of snakes emerge and join the fight

- **Poison Destiny**
  A deadly, concealed bolt is fired from a panel within the wall. DC20 DEX to avoid. On hit, the target makes a DC20
  con save, or takes 10d10 poison damage and is paralyzed and poisoned, or half damage and no paralysis.

- **Reversal of Fate**
  The next time an attack would deal more than 30 damage to the naga this round, the Naga instead supernaturally
  parries and reflects the attack back onto the attacker. The attacker must make a DC20 WIS save to cancel the
  original attack. Otherwise, the Naga rolls 1D10, adding the value to the original attack roll, and returns the entire
  attack back at the attacker. All damage to the naga from this attack is canceled in any result.

Has Dissa dominated with mental magic. She will fight on his behalf.

**Dissa, Mind Controlled Apothecary:**

- 30HP, AC 12
- Dwarfen Warhammer, +3 to hit, 1d12 +3 bludgeoning damage
- 2x Incendiary Vials, +3 to hit, 3d4 fire damage. DC13 reflex save or be lit on fire. Roll a D10 on hit. On 8 or higher, the
  square is also ignited
- 2x Toxic Vials, +3 to hit, 1d6 poison damage. DC13 CON save or move at half speed and have disadvantage on attack rolls
  until end of the next round.

**Fight start:** 2x Yuan Ti True bloods, Dissa, and the Naga

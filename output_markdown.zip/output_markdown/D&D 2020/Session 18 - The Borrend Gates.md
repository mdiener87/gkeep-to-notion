# Session 18 - The Borrend Gates

    **Created:** 2021-10-29 11:33:39  
    **Last Edited:** 2021-10-29 11:33:46  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
don't have much prepared coming into today (nbs). If the players get to borrend, they'll meet the new dwarf, Erirbila
CrimsonDasher, that has joined the leadership council. She is bright, vicious, beautiful, and feeding lies into the ear of
Tordid Nordak. CrimsonDasher is actually a Duregar Dwarf, and is in league with the Drow to usurp control af the
kingdom. She runs the Obsidian Depths Mining CO.

To get into Borrend, however, the party will first have to contend with a Demonic hunting party. Brathizard is not giving
up easily..

If they do get into Borrend, they'll meet with Tordid and all the other familiar faces

>> Duregar mine: Obsidian Depths Mining CO

Result:

Interrogated Kirdan and forced a circle of truth upon him. They learned he is not particularly well informed and near
retirement. He knows something is up with all of the new gnomes and dwarves populating borrend, but the Duregar are
a myth and he doesn't seriously believe that these reinforcements are ‘evil

‘The party Flew to borrend and checked things out. The gates of the city have been sealed off, leaving little option on
how to get inside. A stealthy investigation of the area revealed hidden troops ready to ambush from the sniper parapets
along the cliff walls.

‘The party decided to not launch an attack or expose themselves to the front door. Instead, they went to the old caves
where the secret entrance to Borrend lies from Season 1. Kaetus sent a message to Tordid, informing her of their
approach to aid in negotations. Afterwords, Kaetus attempted to Scry Tordid and learn what was going on. He observed
Tordid talking with a firey red haired dwarf, but didn't speak the language! He attempted to channel the words, but
rolled so badly that instead Galtorah emerged instead!

Galtorah had a long winded rant, and Harold was there to listen - and appease! His ego. They learned a rough
approximation for where the Tower of Bithyra might lie. They also learned of the BBEG's potential name, Prince Zelphar.

Kaetus pinged Tordid with the ring of sending. She replied that she was open to receving the party, but security has been
tightened around borrend following an ambush of their army.

‘Session concluded the next morning. What direction will the party take? Walk through the front door? Sneak in the
back? Or something else??

#### ChatGPT Output:
don't have much prepared coming into today (nbs). If the players get to Borrend, they'll meet the new dwarf, Erirbila
CrimsonDasher, that has joined the leadership council. She is bright, vicious, beautiful, and feeding lies into the ear of
Tordid Nordak. CrimsonDasher is actually a Duergar Dwarf, and is in league with the Drow to usurp control of the
kingdom. She runs the Obsidian Depths Mining CO.

To get into Borrend, however, the party will first have to contend with a Demonic hunting party. Brathizard is not giving
up easily.

If they do get into Borrend, they'll meet with Tordid and all the other familiar faces

> Duregar mine: Obsidian Depths Mining CO

Result:

Interrogated Kirdan and forced a circle of truth upon him. They learned he is not particularly well informed and near
retirement. He knows something is up with all of the new gnomes and dwarves populating Borrend, but the Duergar are
a myth and he doesn't seriously believe that these reinforcements are ‘evil’.

The party flew to Borrend and checked things out. The gates of the city have been sealed off, leaving little option on
how to get inside. A stealthy investigation of the area revealed hidden troops ready to ambush from the sniper parapets
along the cliff walls.

The party decided to not launch an attack or expose themselves to the front door. Instead, they went to the old caves
where the secret entrance to Borrend lies from Season 1. Kaetus sent a message to Tordid, informing her of their
approach to aid in negotiations. Afterwards, Kaetus attempted to Scry Tordid and learn what was going on. He observed
Tordid talking with a fiery red-haired dwarf, but didn't speak the language! He attempted to channel the words, but
rolled so badly that instead Galtorah emerged instead!

Galtorah had a long-winded rant, and Harold was there to listen - and appease his ego. They learned a rough
approximation for where the Tower of Bithyra might lie. They also learned of the BBEG's potential name, Prince Zelphar.

Kaetus pinged Tordid with the ring of sending. She replied that she was open to receiving the party, but security has been
tightened around Borrend following an ambush of their army.

Session concluded the next morning. What direction will the party take? Walk through the front door? Sneak in the
back? Or something else??

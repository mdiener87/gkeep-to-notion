# Session 4 - A Return to Form

    **Created:** 2021-10-29 11:30:15  
    **Last Edited:** 2021-10-29 11:30:25  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Following my personal drama, we are picking up the game a month after the last session. That really hurts. Its time to
get this drama flowing again.

‘The players have captured Nenetl. She is presently polymorphed as a turtle, when she had previously wild shaped into a
phase spider. So far I'm allowing this type of transformation to apply as CC she can't escape from.

Nenet! has been drawing magic from nat just the remaining energy of the Shadow Cult, but also a dark and terrifying
necrotic source. The Party also retrieved encrypted notes written in a Drow cypher. They can attempt to decrypt these
notes to learn about the Tower of Bithrya, but not its exact location. They can learn, however, that Nenet! went on
several expeditions for more power, taking her deep into [territory] where they might encounter a dungeon.

Nenetl drawing on this power is not without consequences. The Drow magic is cursed; this isthe dark side of dark drow
magic. Drawing from it is never free. Killing or mind controlling Nenetl will draw this curse to the forefront and unleash a
cursed Drow monstrosity on the players

find appropriate monster]

Otherwise probably free form RP as they figure out their footing in the world and start to reveal the location of the
dungeon.

Result:

Kaetus succesfully Geas'd Nenet! to make her remorseful and wanting to turn herself over to the King's justice. In the
process, he felt another presence - an ancient curse lingering within her soul.

‘The party successfully escorted her to El Enna, where the garrison guards they encountered were in poor military form.
‘The party tried to whip them more into shape. They set up a watch while Nenet! was alone in the basement prison.

Kipa met with Nenet! - they have a history. Nenetl was the one who originally recruited her into the Shadow Cult. In a
private moment during which Kippa snuck up to her, Nenetl gave her a Gold-encrusted Dragon's tooth that was
originally from Kaldan. The item is -valuable-, magical, and has a tracking spell placed onto it.

During the night, Drow Demons tried to sneak in. These guys had eaten the elves they were impersonating and tried to
sweet-talk their way into the keep. The party wisely shut them out.

#### ChatGPT Output:
Following my personal drama, we are picking up the game a month after the last session. That really hurts. It's time to
get this drama flowing again.

'The players have captured Nenetl. She is presently polymorphed as a turtle, when she had previously wild shaped into a
phase spider. So far I'm allowing this type of transformation to apply as CC she can't escape from.

Nenetl has been drawing magic from not just the remaining energy of the Shadow Cult, but also a dark and terrifying
necrotic source. The Party also retrieved encrypted notes written in a Drow cypher. They can attempt to decrypt these
notes to learn about the Tower of Bithrya, but not its exact location. They can learn, however, that Nenetl went on
several expeditions for more power, taking her deep into [territory] where they might encounter a dungeon.

Nenetl drawing on this power is not without consequences. The Drow magic is cursed; this is the dark side of dark drow
magic. Drawing from it is never free. Killing or mind controlling Nenetl will draw this curse to the forefront and unleash a
cursed Drow monstrosity on the players

[find appropriate monster]

Otherwise probably free form RP as they figure out their footing in the world and start to reveal the location of the
dungeon.

Result:

Kaetus successfully Geas'd Nenetl to make her remorseful and wanting to turn herself over to the King's justice. In the
process, he felt another presence - an ancient curse lingering within her soul.

'The party successfully escorted her to El Enna, where the garrison guards they encountered were in poor military form.
'The party tried to whip them more into shape. They set up a watch while Nenetl was alone in the basement prison.

Kipa met with Nenetl - they have a history. Nenetl was the one who originally recruited her into the Shadow Cult. In a
private moment during which Kipa snuck up to her, Nenetl gave her a Gold-encrusted Dragon's tooth that was
originally from Kaldan. The item is -valuable-, magical, and has a tracking spell placed onto it.

During the night, Drow Demons tried to sneak in. These guys had eaten the elves they were impersonating and tried to
sweet-talk their way into the keep. The party wisely shut them out.

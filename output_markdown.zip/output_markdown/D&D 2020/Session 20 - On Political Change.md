# Session 20 - On Political Change

    **Created:** 2021-10-29 11:34:06  
    **Last Edited:** 2021-10-29 11:34:11  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Dorc won't be in today's session, so I'm thinking he and Tordid 'escape" into the depths of Borrend off-screen, This then
adds the perfect excuse for Erirbila to begin her military takeover of Borrend - ahead of schedule!

To Erirbila and the ODM Co, the Order of Sun and Moon now has:
*Flagrantly assassinated one of their warleaders
* kidnapped Trodid (via the missing Dorc)

‘And that's in addition to:
* Ambushing their ‘patro!"
* _ Defiling the body of the gnome soldier beyond recognition
* Blowing up the Doom Cannon
= Invading the Borrend Crypts and abusing the bodies of its ancient, entombed leaders
= Punking halfiings at the swapmeet.

Eribila is going to start the session with Orders - Approved by the Borrend High Council - to arrest the Order for further
questioning. They'll need to go quietly, and drop all magical items and gear, and face the judgment of the Council. The
Stone Circle druids are likewise under arrest - apparently the poison bolt found in Dhatsik's throat has all the markings of
poisonous druidic magic.

Kaetus and Harrold will both need to make a CON save at session start given they are ‘drinking all night. DC23. for No
exhaustion levels. DC 18 for 1 exhaustion level. Failure = 2 exhaustion levels.

‘Session will start from the intro into an IMMEDIATE "knock knack FBI OPEN UP"

Kipla - escaped and her wearabouts are unknown. She can start the map where she pleases.
Alyousora (sp) - Guess quarters or with the stone circle druids.
Kaetus + Harold - Stone circle druids

If party surrenders quietly (yea probably not) they will be brought before the council to face a sham trial. They will likely
be found guilty (will need to RP this out) and sentenced to death via [something elaborate that gives them a chance at
living}.

If party fights, they'll face a city convinced they are assassins. Their name will be tarnished, their popularity suddenly a
liability. Eribilia will likely use this as pretense to declare war on the Kingdom and use the Doom Cannon. Probalby in 1-2
episodes.

Units:

Duregar forces + mecha units + special FBI units (magic resistance + higher AC).
Maybe something cool to ‘unleash’ on the party?

Erirbila has an artifact from the Drow. If she is pressed to far, she can use it to unleash a portal directly to the [demonic
layer where the drow demons are]. This will also raise an anti-magic field and cause demons to start spawning forth.
Probably result in a dead council but heyyy that can be blamed on the players too.

Result:
‘The two split parties each worked to escape their arrest forces. Kaeuts + Harold worked with the Stone Circle druids to
escape out the back while using Pass Without a Trace to avoid the police. Gandus charged through the opposition with
Mirror Image and his natural AC and athleticism. Ureasua used Greater Invisibility and just watched. Kipla could have
joined either half, but never felt the need to interject as everyone got out OK.

Having joined up in a less busy part of the city, Kaetus cast Wind Walk and turned everyone into clouds. They quickly
zipped through the city and exited in the old secret entrance from $1. The ring of sending revealed that Dorc was
keeping Tordid safe, and they were trying to make their way out of the city. Tordid estimated it would take them 8 hours
to reach the party's location.

Erirbia = duregar despot

Borrend Enforcer
AC:19

HP: 80

Init: 1

Immune to poison damage, resistant to fire and frost

Condition immunity to: charmed, exhaustion, frightened, paralazied, petrified,
poisoned

Multiattack: 2
Shock Punch:

Melee Weapon Attack #6, reach Sft, one target. Hit: 2410 bludgeioning + 1d8 lightning
damage

Rocket Punch:
Melee Weapon Attack: +12 to hit, reach 1oft, one target plus one adjacent target
within range. Hit: 2d12 bludgeoning + 2d8 fire damage: Recharge: 5-6

Frost Harpoons:
Ranged Weapon Attack +7, reach 60ft, one target. Hit: 2d8 piercing + 1d6 frost
damage.

Senses: darkvision 60ft, passive perception 10

#### ChatGPT Output:
Dorc won't be in today's session, so I'm thinking he and Tordid "escape" into the depths of Borrend off-screen. This then
adds the perfect excuse for Erirbila to begin her military takeover of Borrend - ahead of schedule!

To Erirbila and the ODM Co, the Order of Sun and Moon now has:

- Flagrantly assassinated one of their warleaders
- kidnapped Trodid (via the missing Dorc)

And that's in addition to:
- Ambushing their patrol
- _Defiling the body of the gnome soldier beyond recognition
- Blowing up the Doom Cannon
- Invading the Borrend Crypts and abusing the bodies of its ancient, entombed leaders
- Punking halflings at the swapmeet.

Eribila is going to start the session with Orders - Approved by the Borrend High Council - to arrest the Order for further
questioning. They'll need to go quietly, and drop all magical items and gear, and face the judgment of the Council. The
Stone Circle druids are likewise under arrest - apparently the poison bolt found in Dhatsik's throat has all the markings of
poisonous druidic magic.

Kaetus and Harrold will both need to make a CON save at session start given they are ‘drinking all night. DC23 for No
exhaustion levels. DC 18 for 1 exhaustion level. Failure = 2 exhaustion levels.

Session will start from the intro into an IMMEDIATE "knock knack FBI OPEN UP"

Kipla - escaped and her whereabouts are unknown. She can start the map where she pleases.
Alyousora (sp) - Guess quarters or with the stone circle druids.
Kaetus + Harold - Stone circle druids

If party surrenders quietly (yeah probably not) they will be brought before the council to face a sham trial. They will likely
be found guilty (will need to RP this out) and sentenced to death via [something elaborate that gives them a chance at
living}.

If party fights, they'll face a city convinced they are assassins. Their name will be tarnished, their popularity suddenly a
liability. Eribilia will likely use this as pretense to declare war on the Kingdom and use the Doom Cannon. Probably in 1-2
episodes.

Units:

Duergar forces + mecha units + special FBI units (magic resistance + higher AC).
Maybe something cool to ‘unleash’ on the party?

Erirbila has an artifact from the Drow. If she is pressed too far, she can use it to unleash a portal directly to the [demonic
layer where the drow demons are]. This will also raise an anti-magic field and cause demons to start spawning forth.
Probably result in a dead council but hey, that can be blamed on the players too.

Result:
The two split parties each worked to escape their arrest forces. Kaetus + Harold worked with the Stone Circle druids to
escape out the back while using Pass Without a Trace to avoid the police. Gandus charged through the opposition with
Mirror Image and his natural AC and athleticism. Ureasua used Greater Invisibility and just watched. Kipla could have
joined either half, but never felt the need to interject as everyone got out OK.

Having joined up in a less busy part of the city, Kaetus cast Wind Walk and turned everyone into clouds. They quickly
zipped through the city and exited in the old secret entrance from $1. The ring of sending revealed that Dorc was
keeping Tordid safe, and they were trying to make their way out of the city. Tordid estimated it would take them 8 hours
to reach the party's location.

Erirbia - = duergar despot

Borrend Enforcer
AC: 19

HP: 80

Init: 1

Immune to poison damage, resistant to fire and frost

Condition immunity to: charmed, exhaustion, frightened, paralyzed, petrified,
poisoned

Multiattack: 2

Shock Punch:

Melee Weapon Attack: +6, reach 5ft, one target. Hit: 2d10 bludgeoning + 1d8 lightning
damage

Rocket Punch:
Melee Weapon Attack: +12 to hit, reach 10ft, one target plus one adjacent target
within range. Hit: 2d12 bludgeoning + 2d8 fire damage; Recharge: 5-6

Frost Harpoons:
Ranged Weapon Attack: +7, reach 60ft, one target. Hit: 2d8 piercing + 1d6 frost
damage.

Senses: darkvision 60ft, passive perception 10

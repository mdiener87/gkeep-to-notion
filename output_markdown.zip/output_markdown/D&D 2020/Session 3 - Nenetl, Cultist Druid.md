# Session 3 - Nenetl, Cultist Druid

    **Created:** 2021-10-29 11:29:57  
    **Last Edited:** 2021-10-29 11:30:07  
    **Labels:** D&D 2020  

    ---

    ## Note Content (HTML)

Session 3-

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Actual boss fight against Nenet! tonight. Finally. Lol. Took 2 more sessions than I wanted but that's D&D for you.
Tonight's group is much smaller than last session, so can actually get through some content and actions hopefully

Boss:
Powerful Druid + Phase Spiders
Fight takes place Inside ancient drow shrine. Multi-leveled, with webbing covering many of the surfaces

-> Control Orb in center
-> 3x Phase orbs on outside
~> Spider web: DC 14 restrained

-> Can work on control orb to make phase spiders spawn for each phase orb. If phase orb has a live spider, no effect.
-> Nenet! will transform if people get too close

> loot:
Random Loot rolls
+ Nenet!'s Encrypted documents (druidic)

-» DCIS check - see references to "Tower of Bithyra"

Following fight, players will want to turn in the quest -> Return to Allluin
King is not going to see them, -> Floriana or Trynicus

-> Research the Documents
-> Find clues to the tower's location -> Ancient Drow city
-> Tower is supposed to be an old legend / wives tail.
-> Imposter prince who lied about his accomplishments and powers. Banished by the elven lords for his malice and
insidious lies.
-> Investigate with Galtorah -> Psychic pain at the mention of Bithyra

-> Other city actions

-> Gear shopping?
~> Side Quests?

Kat's (Barb's) Quarterstaff Enchant: Quarterstaff of Natural Channeling
* Counts as a +2 Quarterstaff (requires attunement)
= You have a +2 bonus to concentration checks while channeling Druidic, Cleric, or Monk spells while wielding this
weapon.
* Once per long rest, you may invoke the staff's command word as a bonus action to cast your choice of Detect
‘Magic, Ensnaring Strike or Cure Wounds without material requirements or consuming a spell slot.

#### ChatGPT Output:
'Actual boss fight against Nenet! tonight. Finally. Lol. Took 2 more sessions than I wanted but that's D&D for you.
Tonight's group is much smaller than last session, so can actually get through some content and actions hopefully

**Boss:**
Powerful Druid + Phase Spiders
Fight takes place Inside ancient drow shrine. Multi-leveled, with webbing covering many of the surfaces

-> Control Orb in center
-> 3x Phase orbs on outside
~> Spider web: DC 14 restrained

-> Can work on control orb to make phase spiders spawn for each phase orb. If phase orb has a live spider, no effect.
-> Nenet! will transform if people get too close

**Loot:**
Random Loot rolls
+ Nenet!'s Encrypted documents (druidic)

-» DCIS check - see references to "Tower of Bithyra"

Following fight, players will want to turn in the quest -> Return to Allluin
King is not going to see them, -> Floriana or Trynicus

-> Research the Documents
-> Find clues to the tower's location -> Ancient Drow city
-> Tower is supposed to be an old legend / wives tail.
-> Imposter prince who lied about his accomplishments and powers. Banished by the elven lords for his malice and
insidious lies.
-> Investigate with Galtorah -> Psychic pain at the mention of Bithyra

-> Other city actions

-> Gear shopping?
~> Side Quests?

Kat's (Barb's) Quarterstaff Enchant: Quarterstaff of Natural Channeling
* Counts as a +2 Quarterstaff (requires attunement)
= You have a +2 bonus to concentration checks while channeling Druidic, Cleric, or Monk spells while wielding this
weapon.
* Once per long rest, you may invoke the staff's command word as a bonus action to cast your choice of Detect
Magic, Ensnaring Strike or Cure Wounds without material requirements or consuming a spell slot.'

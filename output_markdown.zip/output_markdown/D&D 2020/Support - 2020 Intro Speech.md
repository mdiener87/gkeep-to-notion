# 2020 Intro Speech

    **Created:** 2021-10-29 11:29:07  
    **Last Edited:** 2021-10-29 11:29:17  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Anumber of months have passed since the players last play session. The Kingdom of Dawn has finally begun to heal
from its long conflict. First, there was the terrible Orc Invasion. Sheggon Megged, the wicked Orc general, invaded across
the great grasslands to the East of the kingdom. His invasion razed these eastern settlements, displacing the first
amongst many waves of refugees in the kingdom. This invasion would eventually lay sieg to both El Enna and Aluin,
Strike forces from the Orcs would make their way far to the West, attacking the City of Borrend and the town of
Galtorah.

ur party, who would eventually become known as the Order of Sun and Moon, began here in the Western,
mountainous town of Galtorah. They first confronted the insane ghost terrorizing this town. They found its spirit bound
to a secret eleven keep located in the steep, wooded hills above the town. Defeating this ghost revealed the first of the
three great Elven lords - Lord Galtorah. He likes to yell at people through Kaetus now.

Exploring the Kingdom around them - and ignoring the war - the party soon found themselves exploring the mysterious,
underwater dungeon of the Valzumin Stronghold. Lost for hundreds of years, the stronghold was busy getting looted by
Soughain. Defeating the fishy invaders - and the Stronghold's own defenses - gave our party their first Legendary
Artifact - the Reality Marble that is the Valzumin Stronghold itself.

However, claiming the stronghold extracted a terrible cost in time, A bad manipulation of the relality marble led the
Order a year into the future - one in which the Kingdom had already begun to lose the war. The order stepped into
action and begun to repel the nearby orcs.

In these battles against the orcs, the entire Royal Guard would be lost - save one brave captain. Captain Floriana's
survival was owed to the intervention of the Order of Sun and Moon. They saved Floriana's life, and the Kingdom, by
rallying the kingdom's hopes in a final stand at Borrend. This city of dwarves, halfings, and gnomes, was under siege and
incursion by the Ores.

In the course of defending the city, the Order found a terrible, ancient weapon - the Borrend Doom Cannon. It was a
difficult choice, but the Order elected to use the weapon on the orc invasion. The weapon worked, annihilating the army
‘that occupied the mountains around Borrend. The Order then personally defeated their leader Sheggon Megged in
battle. The Order would not allow the weapon to remain intact, however, and destroyed this weapon in the course of
battle against Sheggon and his lieutenants.

While the weapon ended the Orc War, it heralded a new problem - a baby dragon was found in the ruins of battle. As it
‘would turn out, the kingdom was still under threat of invasion -this time, by a brood of Blue Shadow Dragons. These
abominable creatures hail from the Shadow Realm, and they had taken recent roost in the Onyx Mountain, in the desert
to the North. There, Kaladan, the Young Shadow Dragon, found a tear between realms and a new world fresh for the
taking.

‘The Order would embark on their most epic quest to defeat this threat. Kaladan was cunning, not afraid to sneak up
close and assassinate the king. But the Order proved steadfast and capable. They saved the King's life multiple times
‘through ongoing battles against the dragon and his growing number of Shadow Cultists. Having saved Alluin from the
cult, the Order would then go onto the offensive, hoping to travel to the Onyx Mountain and defeat the dragon.

Their first stop at Chipahua would end in disaster. This city of religious fanatics had already sworn allegiance to the
‘Shadow Cult! Kaladan sprang a trap, blasting lightening from above while a mob of cultists swarmed the ground. The
Order was forced to retreat deep into the forests to the south of the city, where they eventually eluded further pursuit.

‘Within that forest, they found poisoned ground and slow decay everywhere. Something tortured these lands. A search
revealed the Lair of Forgotten Sins - an abominable dungeon of the Yuan-Ti. Their leader - the Anathamancer - held
three Dryad's captive. These spirits of the forest bestowed blessing onto the Order once freed - and hinted at the
location where the Aether Flame might be discovered.

‘The Aether Flame was the legendary substance Kaladan hoped to find, This impossibly powerful alchemical catalyst
could be used in any number of ways. Kaladan's goal was to use this substance in his mountain, and tear a hole between
dimensions big enough for his mother to emerge. Oxyvezergen™” is an elder shadow dragon, too immense and powerful
to enter the material realm normally.

‘The quest to Tinethera's mannor would reveal the home of the last of three great Elven Lords - Tiniethra, Protected by a
dome of force, it had sat perfectly preserved for centuries. Until the order opened a window inside, anyways! Inside the
Manor, the Order found a Planor Mirror - a portal that could be used to travel to different planes of existance. It was
opened to the elemental plane of Air. And thus the order travelled there.

‘They met essefah

Got conned into fighting agar

Double conned essefah and joined agar

Briefly joined the Grand Suftan

Elryiss introduced religion to the Salamanders and started a religious war
Found a mote of air and returned to the air plane

Stole the Aether Flame from Essefah and returned home
Fought off cultists and agar from their home

Tried to save El Enna from the invading cultist army
Saved Floriana form the cult, but lost the city

Freed Rupert and used him to evacuate Allluin
Teleported to the Onyx Mountain, and defeated Kaladan

#### ChatGPT Output:
‘A number of months have passed since the players' last play session. The Kingdom of Dawn has finally begun to heal
from its long conflict. First, there was the terrible Orc Invasion. Sheggon Megged, the wicked Orc general, invaded across
the great grasslands to the East of the kingdom. His invasion razed these eastern settlements, displacing the first
amongst many waves of refugees in the kingdom. This invasion would eventually lay siege to both El Enna and Aluin,
Strike forces from the Orcs would make their way far to the West, attacking the City of Borrend and the town of
Galtorah.

Our party, who would eventually become known as the Order of Sun and Moon, began here in the Western,
mountainous town of Galtorah. They first confronted the insane ghost terrorizing this town. They found its spirit bound
to a secret elven keep located in the steep, wooded hills above the town. Defeating this ghost revealed the first of the
three great Elven lords - Lord Galtorah. He likes to yell at people through Kaetus now.

Exploring the Kingdom around them - and ignoring the war - the party soon found themselves exploring the mysterious,
underwater dungeon of the Valzumin Stronghold. Lost for hundreds of years, the stronghold was busy getting looted by
Soughain. Defeating the fishy invaders - and the Stronghold's own defenses - gave our party their first Legendary
Artifact - the Reality Marble that is the Valzumin Stronghold itself.

However, claiming the stronghold extracted a terrible cost in time, A bad manipulation of the reality marble led the
Order a year into the future - one in which the Kingdom had already begun to lose the war. The order stepped into
action and begun to repel the nearby orcs.

In these battles against the orcs, the entire Royal Guard would be lost - save one brave captain. Captain Floriana's
survival was owed to the intervention of the Order of Sun and Moon. They saved Floriana's life, and the Kingdom, by
rallying the kingdom's hopes in a final stand at Borrend. This city of dwarves, halflings, and gnomes, was under siege and
incursion by the Orcs.

In the course of defending the city, the Order found a terrible, ancient weapon - the Borrend Doom Cannon. It was a
difficult choice, but the Order elected to use the weapon on the orc invasion. The weapon worked, annihilating the army
that occupied the mountains around Borrend. The Order then personally defeated their leader Sheggon Megged in
battle. The Order would not allow the weapon to remain intact, however, and destroyed this weapon in the course of
battle against Sheggon and his lieutenants.

While the weapon ended the Orc War, it heralded a new problem - a baby dragon was found in the ruins of battle. As it
would turn out, the kingdom was still under threat of invasion - this time, by a brood of Blue Shadow Dragons. These
abominable creatures hail from the Shadow Realm, and they had taken recent roost in the Onyx Mountain, in the desert
to the North. There, Kaladan, the Young Shadow Dragon, found a tear between realms and a new world fresh for the
taking.

The Order would embark on their most epic quest to defeat this threat. Kaladan was cunning, not afraid to sneak up
close and assassinate the king. But the Order proved steadfast and capable. They saved the King's life multiple times
through ongoing battles against the dragon and his growing number of Shadow Cultists. Having saved Alluin from the
cult, the Order would then go onto the offensive, hoping to travel to the Onyx Mountain and defeat the dragon.

Their first stop at Chipahua would end in disaster. This city of religious fanatics had already sworn allegiance to the
Shadow Cult! Kaladan sprang a trap, blasting lightning from above while a mob of cultists swarmed the ground. The
Order was forced to retreat deep into the forests to the south of the city, where they eventually eluded further pursuit.

Within that forest, they found poisoned ground and slow decay everywhere. Something tortured these lands. A search
revealed the Lair of Forgotten Sins - an abominable dungeon of the Yuan-Ti. Their leader - the Anathamancer - held
three Dryad's captive. These spirits of the forest bestowed blessing onto the Order once freed - and hinted at the
location where the Aether Flame might be discovered.

The Aether Flame was the legendary substance Kaladan hoped to find, This impossibly powerful alchemical catalyst
could be used in any number of ways. Kaladan's goal was to use this substance in his mountain, and tear a hole between
dimensions big enough for his mother to emerge. Oxyvezergen™ is an elder shadow dragon, too immense and powerful
to enter the material realm normally.

The quest to Tinethera's manor would reveal the home of the last of three great Elven Lords - Tiniethra, Protected by a
dome of force, it had sat perfectly preserved for centuries. Until the order opened a window inside, anyways! Inside the
Manor, the Order found a Planar Mirror - a portal that could be used to travel to different planes of existence. It was
opened to the elemental plane of Air. And thus the order travelled there.

They met essefah

Got conned into fighting agar

Double conned essefah and joined agar

Briefly joined the Grand Sultan

Elryiss introduced religion to the Salamanders and started a religious war
Found a mote of air and returned to the air plane

Stole the Aether Flame from Essefah and returned home
Fought off cultists and agar from their home

Tried to save El Enna from the invading cultist army
Saved Floriana form the cult, but lost the city

Freed Rupert and used him to evacuate Allluin
Teleported to the Onyx Mountain, and defeated Kaladan

# Session 12 - What Lies Beneath

    **Created:** 2021-10-29 11:31:56  
    **Last Edited:** 2021-10-29 11:32:01  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The players are entering the bandit caves in the Western (name) Highlands today. They are after the princess, who is
pursued by the incredibly dangerous Narzugon Brathrizad. He has traps waiting for the players as they venture further
it

Rooms:
caverns
Grick Ambush!
‘ne Grick can be found chowing down on a charred human. The rest are lurking nearby
Grick x3

Grick Alpha x1
Corrupted Caverns
Vorck x1
Gibbering Mouthers x3
Mines?
Optional - extends off of Caverns,
Galeb Duhr
3x Flameskull
Ores,
Oreit

Ruins of the Broken Lands >Boss Encounter<
x Narzugon
2x Nightmare

Players made it through the caverns and corrupted caverns, Encountered 'Dark Crystals' that have some sort of
corrupting magical energy about them. They retrieved an Intact Dark Crystal + Dark Crystal War Pick

#### ChatGPT Output:
'The players are entering the bandit caves in the Western (name) Highlands today. They are after the princess, who is
pursued by the incredibly dangerous Narzugon Brathrizad. He has traps waiting for the players as they venture further
it

**Rooms:**
- **Caverns**
  - **Grick Ambush!**
    - One Grick can be found chowing down on a charred human. The rest are lurking nearby
    - Grick x3
    - Grick Alpha x1
- **Corrupted Caverns**
  - Vorck x1
  - Gibbering Mouthers x3
- **Mines?**
  - Optional - extends off of Caverns,
  - Galeb Duhr
  - 3x Flameskull
  - Ores,
  - Oreit

**Ruins of the Broken Lands >Boss Encounter<**
- Narzugon x1
- Nightmare x2

Players made it through the caverns and corrupted caverns, Encountered 'Dark Crystals' that have some sort of
corrupting magical energy about them. They retrieved an Intact Dark Crystal + Dark Crystal War Pick

# Session 15 - The Rose Garden Reunion

    **Created:** 2021-10-29 11:32:28  
    **Last Edited:** 2021-10-29 11:32:38  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
It's been a two week hiatus from our last adventure. My mental wellbeing has taken some hits this August, and | just
didn't have the right mindset to DM. Today will be different, and we are going to get some fun dice rolling underway!

This season hasn't feel as solid as I'd desired. The enemy is vague - some drow thing somewhere. The Order has
succeeded in rescuing Princess Rose, lost in the frontier for years now. This should be a momentous occasion. But a pure
RP session of BJs for the party seems a bit lame. At the same time, the plot needs room to breathe.

‘The Narzugon is by far the most outright tough opponent the order has faced. What is he up to?

Need to be ready for these scenes:
* Princess reunited with King and Kingdom.
© She can reveal the queen's fate - murdered by the Orcs
© Princess lived as a freedom fighter / rogue for the past several years in the eastem areas. Her commitment
to the people never let her run away from their need. Now most of them are dead at the hands of
Brathrizard.
(© The princess is marked by foul magic. Every time she sleeps at night, she is awoken by night terrors, Images
of upside down, burning crosses. Of a black moon in the sky, and darkness swallowing the realm.
© AGreater Restoration spell can remove this curse.
+ Gildas
© He has been Soul Flayed. While the soul was retrieved, he has not fully reunited his body and soul together.
He needs a Greater Restoration spell (or equivalent) to remove the flayed condition. However, his
personality will likely never be the same.
= The King
© Isindebted beyond words by the return of his daughter. This will lift him out of the darkness, and begin to
lead the kingdom once more.
© Really has nothing more to offer the players in terms of wealth or magical items. The Order will instead be
anointed as Champions of The Kingdom, a title that is effectively Lordship. They will exist as a full and official
order within the Kingdom, with a stipend, land, and servants. They can do with this power what they will.
‘The King trusts them implicitly.
*  Borrend - this needs to come more into the forefront now
© Disa is still missing
© Tordid Nordak has a new advisor - a disarmingly beautiful dwarfen woman named [name]. She is fueling
Tordid with suspicion and distrust over the kingdom. That the Order exists to perpetuate the dominance of
Humans, Elves, and other ‘noble' species, over the small and subterranean races. Tordid's grief for her
sister's disappearance has fueled her heart with despair.
© Brok has made excellent work on the Doom canon. They are preparing a demonstration of its power.
© Borrend demands to be accepted as an independent City State by the Kingdom, with wartime recompense
equivalent to 1mil gp for the city's damages and casualties.
© Failure to comply will force the City State to demonstrate the power of its new and ultimate weapon,
* Narzugon
© Still under orders to retrieve the princess, but the game has now changed for the Drow. If they can't marry
the princess to secure her power, they'll be forced to tilt the kingdom into further anarchy. Their agents are
at work trying to manufacture an incident between Borrend and Kingdom. The death or capture of the royal
family is the ultimate aim, Barring that, the Tower of Alluin must be disabled or destroyed in order to allow
‘the Tower of Bithyra to awaken.
= Tower of Bithyra
© The insane and banished drown Prince [name] wants to take rightful rule of the kingdom. His tower has the
ultimate ability to Tidally lock the moon in any desired position. He plans to use this to force the kingdom
into permeant solar eclipse.

Result:
Kaetus Removed the Geass curse on The princess

The players joined the huge celebration in Alluin for her return

With Elrys's help, they built a crystal necklace that will fool the tracking spell to ping the necklace bearer's location -
Gandus

‘They met the Dwarf Kirdan, who delivered the ultimatum from Borrend

‘They are going to go with him to Borrend to try to find a diplomatic solution

#### ChatGPT Output:
It's been a two-week hiatus from our last adventure. My mental wellbeing has taken some hits this August, and I just
didn't have the right mindset to DM. Today will be different, and we are going to get some fun dice rolling underway!

This season hasn't felt as solid as I'd desired. The enemy is vague - some drow thing somewhere. The Order has
succeeded in rescuing Princess Rose, lost in the frontier for years now. This should be a momentous occasion. But a pure
RP session of BJs for the party seems a bit lame. At the same time, the plot needs room to breathe.

The Narzugon is by far the most outright tough opponent the order has faced. What is he up to?

Need to be ready for these scenes:
* Princess reunited with King and Kingdom.
* She can reveal the queen's fate - murdered by the Orcs
* Princess lived as a freedom fighter / rogue for the past several years in the eastern areas. Her commitment
  to the people never let her run away from their need. Now most of them are dead at the hands of
  Brathrizard.
* The princess is marked by foul magic. Every time she sleeps at night, she is awoken by night terrors, Images
  of upside down, burning crosses. Of a black moon in the sky, and darkness swallowing the realm.
* A Greater Restoration spell can remove this curse.
* Gildas
* He has been Soul Flayed. While the soul was retrieved, he has not fully reunited his body and soul together.
  He needs a Greater Restoration spell (or equivalent) to remove the flayed condition. However, his
  personality will likely never be the same.
* The King
* Is indebted beyond words by the return of his daughter. This will lift him out of the darkness, and begin to
  lead the kingdom once more.
* Really has nothing more to offer the players in terms of wealth or magical items. The Order will instead be
  anointed as Champions of The Kingdom, a title that is effectively Lordship. They will exist as a full and official
  order within the Kingdom, with a stipend, land, and servants. They can do with this power what they will.
  The King trusts them implicitly.
* Borrend - this needs to come more into the forefront now
* Disa is still missing
* Tordid Nordak has a new advisor - a disarmingly beautiful dwarfen woman named [name]. She is fueling
  Tordid with suspicion and distrust over the kingdom. That the Order exists to perpetuate the dominance of
  Humans, Elves, and other 'noble' species, over the small and subterranean races. Tordid's grief for her
  sister's disappearance has fueled her heart with despair.
* Brok has made excellent work on the Doom canon. They are preparing a demonstration of its power.
* Borrend demands to be accepted as an independent City State by the Kingdom, with wartime recompense
  equivalent to 1mil gp for the city's damages and casualties.
* Failure to comply will force the City State to demonstrate the power of its new and ultimate weapon,
* Narzugon
* Still under orders to retrieve the princess, but the game has now changed for the Drow. If they can't marry
  the princess to secure her power, they'll be forced to tilt the kingdom into further anarchy. Their agents are
  at work trying to manufacture an incident between Borrend and Kingdom. The death or capture of the royal
  family is the ultimate aim, Barring that, the Tower of Alluin must be disabled or destroyed in order to allow
  the Tower of Bithyra to awaken.
* Tower of Bithyra
* The insane and banished drow Prince [name] wants to take rightful rule of the kingdom. His tower has the
  ultimate ability to Tidally lock the moon in any desired position. He plans to use this to force the kingdom
  into permanent solar eclipse.

Result:
* Kaetus Removed the Geass curse on The princess

* The players joined the huge celebration in Alluin for her return

* With Elrys's help, they built a crystal necklace that will fool the tracking spell to ping the necklace bearer's location -
  Gandus

* They met the Dwarf Kirdan, who delivered the ultimatum from Borrend

* They are going to go with him to Borrend to try to find a diplomatic solution

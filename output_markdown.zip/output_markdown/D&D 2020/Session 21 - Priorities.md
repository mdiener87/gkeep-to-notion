# Session 21 - Priorities

    **Created:** 2021-10-29 11:34:16  
    **Last Edited:** 2021-10-29 11:34:21  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
If Kevin is playing today, give him a mini-game to escape Borend with Tordid Nordak

Is today a good day to run the hunter demon?
Brathrizard has been awfully quiet for supposedly tracking the princess with a spell.
Could hint that these events are intended.

Tordid will not accept her city falling, She has the necessary rune key that can make the borrend doom cannon
operational. The OMC has plans to fire the doom cannon! While Tordid was prepared to bluff with the system, she
would never authorize its use on a civilian population! Of course, even without the key, the OMC will simpy have Brock
reconstruct the firing controls to not require it. The order will have to act!

Result:

Dore and Tordid began the session, and Dorc flubbed aif of his starting rolls. Luckily, he has amazing strength, and was
able to yeet multiple gnomes that tried to apprehend Tordid as they made their escape.

‘The Stone Circle Druids + Kirdan left for Galtorah while the party waited for Dore + Tordid to come out of the Borrend
Tunnels.

‘Once out, the party came up with a plan to launch an attack on the doom cannon before Brack could disarm it. Kaetus
‘was busy calling Floriana for assistance when suddenly...

‘The Orthon demon and his hunting pack launched a sneak attack! He started with a bolt into Tordid, and then played
games dancing around the party and shooting them with his crossbow. Unfortunatley for him, he couldn't reliably hit the
party's AC. The Displacer Beasts, while annoying, were no match for the party. A protracted game of hide and snipe
resulted, but the party eventually tore into the Demon and slayed him. But not before his explosive vest activated and
forced Dorc to take yet another frontal attack to save Tordid.

Next time: Clean up actions + long rest. Floriana is mobilizing the royal guard with the sudden drop of the call and
sending them to help.

#### ChatGPT Output:
If Kevin is playing today, give him a mini-game to escape Borend with Tordid Nordak

Is today a good day to run the hunter demon?  
Brathrizard has been awfully quiet for supposedly tracking the princess with a spell.  
Could hint that these events are intended.

Tordid will not accept her city falling, She has the necessary rune key that can make the borrend doom cannon  
operational. The OMC has plans to fire the doom cannon! While Tordid was prepared to bluff with the system, she  
would never authorize its use on a civilian population! Of course, even without the key, the OMC will simply have Brock  
reconstruct the firing controls to not require it. The order will have to act!

Result:

- Dore and Tordid began the session, and Dorc flubbed all of his starting rolls. Luckily, he has amazing strength, and was  
able to yeet multiple gnomes that tried to apprehend Tordid as they made their escape.

- The Stone Circle Druids + Kirdan left for Galtorah while the party waited for Dore + Tordid to come out of the Borrend  
Tunnels.

- Once out, the party came up with a plan to launch an attack on the doom cannon before Brack could disarm it. Kaetus  
was busy calling Floriana for assistance when suddenly...

- The Orthon demon and his hunting pack launched a sneak attack! He started with a bolt into Tordid, and then played  
games dancing around the party and shooting them with his crossbow. Unfortunately for him, he couldn't reliably hit the  
party's AC. The Displacer Beasts, while annoying, were no match for the party. A protracted game of hide and snipe  
resulted, but the party eventually tore into the Demon and slayed him. But not before his explosive vest activated and  
forced Dorc to take yet another frontal attack to save Tordid.

Next time: Clean up actions + long rest. Floriana is mobilizing the royal guard with the sudden drop of the call and  
sending them to help.

# Session 6 - Orb of Darkness

    **Created:** 2021-10-29 11:30:40  
    **Last Edited:** 2021-10-29 11:30:45  
    **Labels:** D&D 2020  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Immediate entry into combat - the curse on Nenet! was broken, but this has spawned a fallback mechanism - an Orb of
Darkness! This Orb is a direct line to the DemonWeb Pits, where Lolth, God of all Drow, resides. The curse placed on
Nenet! was never meant to be removed, and it is death to all who oppose Lolth's will.

Nenetl will be freed of her curse but be afflicted the way all Drow who oppose Lolth - transformed into a Drider. This
agonizing curse will take 3 rounds of combat to apply fully. At which point, Nenetl will become an insane Drider. That
can't go well.

‘A powerful Yocolth Demon will emerge from the orb and represent Lolth. It has some butfed stats (+25% HP, one
legendary resistance) and will command the ather enemies.

‘The Orb will launch chains of Barb Wire to anchor itself to this dimension. if they can be severed, the Orb will
Destabilize. They can also be destroyed with a dispell magic or banishment style effect. Destroying the orb will end the
encounter (AC 20, 20hp, magic resistant)

Additional monsters summoned:
Allips x3 (MTF }

Yocolth Spiders (reduced stats}
vrock

Choldriths (volo 132)

Result - long combat session. They were able to defeat Ilitran and her summons after a long battled

Ilitran, Yocolth Demon
Illtran is a powerful and cunning demon, She was first encountered from the Rider
clause on Nenet's curse. This demon lives in the DemonWeb Pits and has some
connection to the Tower of Bithyra.

#### ChatGPT Output:
Immediate entry into combat - the curse on Nenet! was broken, but this has spawned a fallback mechanism - an Orb of
Darkness! This Orb is a direct line to the DemonWeb Pits, where Lolth, God of all Drow, resides. The curse placed on
Nenet! was never meant to be removed, and it is death to all who oppose Lolth's will.

Nenetl will be freed of her curse but be afflicted the way all Drow who oppose Lolth - transformed into a Drider. This
agonizing curse will take 3 rounds of combat to apply fully. At which point, Nenetl will become an insane Drider. That
can't go well.

A powerful Yocolth Demon will emerge from the orb and represent Lolth. It has some buffed stats (+25% HP, one
legendary resistance) and will command the other enemies.

The Orb will launch chains of Barb Wire to anchor itself to this dimension. If they can be severed, the Orb will
Destabilize. They can also be destroyed with a dispel magic or banishment style effect. Destroying the orb will end the
encounter (AC 20, 20hp, magic resistant)

Additional monsters summoned:
- Allips x3 (MTF)
- Yocolth Spiders (reduced stats)
- Vrock
- Choldriths (volo 132)

Result - long combat session. They were able to defeat Ilitran and her summons after a long battle.

**Ilitran, Yocolth Demon**
Ilitran is a powerful and cunning demon. She was first encountered from the Rider
clause on Nenet's curse. This demon lives in the DemonWeb Pits and has some
connection to the Tower of Bithyra.

# Session 43 - Crystals and Dragons

    **Created:** 2021-10-29 11:26:07  
    **Last Edited:** 2021-10-29 11:26:17  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming in today's session, our party is within Tiniethra's manor and is staring down the immense mana crystal that lay at Tinetra's Mana Crystal:
the bottom of the hidden basement. What secrets does this chamber hold?
Tiniethra constructed this mana crystal over many years of study and effort. While within 30ft of it, a
user can make an arcane check to absorb mana from the crystal to restore missing spell slots (DC 10 +
Acareful study of the area may also reveal potions and magical items. spell slot level restored). On a failure, the user takes 106 * spell slot level force damage.

Within this chamber also lies @ magical forge, tuning crystals, and amplifying rods. They can be used to
rebuild the Force Dome that once protected the manor (DC20 arcane check over 1 day. Can gain

Meanwhile, throughout the kingdom, political unrest and instability grows. While the dragonborn army was defeated advantage with a DC 15 investigation check to figure out how to use all equipment.)
with a powerful strike from the Force Dome, regular human cultists still grow in number. The King's grip on the kingdom
is loosening, and Kaladan is free to lick his wounds deep on the Onyx Mountain. This equipment might also be used for the forging and construction of magical items. The stored items

and workbenches are appropriate for constructing up to rare gear over a1 week duration. Additional
materials might still be needed. When combined with the Aether flame, this automatically grants
advantage on crafting attempts over a one week duration.

Elemental Fascination:
Conjured elementals will find the mana crystal mesmerizing to behold. Any elemental creature with 6Oft
of the mana crystal must make a DC16 will save or become mesmerized, during which they will slowly
walk around the crystal in a form of blissful trance. Interacting with the elemental will cause them to
snap out of the trance, often in a grumpy mood at the interruption.

Results: Looted:

‘The PCs were able to repair the shield control crystal, re-activating the Dome of Force around the manor 2x vials of unknown magical substance from Ayden
‘This re-activated Rupport, who the PCs dug up out of his grave and put him to work in building a

teleportation circle in the manor. This required powering up Rupport to 4/5 crystals (started at 2/5).

After a long debate about the fate of the planar mirror, the party decied to destroy it. But not before a
gateway to the Shadow Realm opened and a Devourer popped out! In an intense fight in which Dore
nearly died. Dore succeeded in destroying the gateway before more shadow denizens could pop out.

‘They were able to successfully distract Rupport from the destroyed mirror so he did nat enrage.
‘The players then teleported back to El Enna, in which they found the destroyed remains of the city.

‘Smoke and fire fill the air, the bell tolls chime the call to arms! The battle of El Enna awaits the next
session!

#### ChatGPT Output:
Coming in today's session, our party is within Tiniethra's manor and is staring down the immense mana crystal that lay at Tinetra's Mana Crystal:
the bottom of the hidden basement. What secrets does this chamber hold?
Tiniethra constructed this mana crystal over many years of study and effort. While within 30ft of it, a
user can make an arcane check to absorb mana from the crystal to restore missing spell slots (DC 10 +
spell slot level restored). On a failure, the user takes 1d6 * spell slot level force damage.

A careful study of the area may also reveal potions and magical items.

Within this chamber also lies a magical forge, tuning crystals, and amplifying rods. They can be used to
rebuild the Force Dome that once protected the manor (DC20 arcane check over 1 day. Can gain
advantage with a DC 15 investigation check to figure out how to use all equipment).

Meanwhile, throughout the kingdom, political unrest and instability grows. While the dragonborn army was defeated
with a powerful strike from the Force Dome, regular human cultists still grow in number. The King's grip on the kingdom
is loosening, and Kaladan is free to lick his wounds deep on the Onyx Mountain. This equipment might also be used for the forging and construction of magical items. The stored items

and workbenches are appropriate for constructing up to rare gear over a 1 week duration. Additional
materials might still be needed. When combined with the Aether flame, this automatically grants
advantage on crafting attempts over a one week duration.

**Elemental Fascination:**
Conjured elementals will find the mana crystal mesmerizing to behold. Any elemental creature within 60ft
of the mana crystal must make a DC16 will save or become mesmerized, during which they will slowly
walk around the crystal in a form of blissful trance. Interacting with the elemental will cause them to
snap out of the trance, often in a grumpy mood at the interruption.

**Results: Looted:**

- The PCs were able to repair the shield control crystal, re-activating the Dome of Force around the manor 2x vials of unknown magical substance from Ayden
- This re-activated Rupert, who the PCs dug up out of his grave and put him to work in building a

teleportation circle in the manor. This required powering up Rupert to 4/5 crystals (started at 2/5).

After a long debate about the fate of the planar mirror, the party decided to destroy it. But not before a
gateway to the Shadow Realm opened and a Devourer popped out! In an intense fight in which Dore
nearly died. Dore succeeded in destroying the gateway before more shadow denizens could pop out.

- They were able to successfully distract Rupert from the destroyed mirror so he did not enrage.
- The players then teleported back to El Enna, in which they found the destroyed remains of the city.

Smoke and fire fill the air, the bell tolls chime the call to arms! The battle of El Enna awaits the next
session!

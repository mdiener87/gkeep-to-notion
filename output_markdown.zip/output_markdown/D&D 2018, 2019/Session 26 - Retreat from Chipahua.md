# Session 26 - Retreat from Chipahua

    **Created:** 2021-10-29 11:20:48  
    **Last Edited:** 2021-10-29 11:21:12  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Ayden Injury - Burn Scars (-1 CON, -1CHA) - Kaladan's lightening breath has left its mark. A twisting

Coming into this, the PCs just suffered their first real defeat. The taste of higher end combat has shown them that they electrical burn has scarred the leit side of Ayden's body.

are not the only ones that can dish out real damage. Ayden was nearly Killed, and Kaetus was bbged out of his beast
shaping more than once. The players finally are starting to respect the NPCs.

Speaking of which, Kaladan has left a hunting party to hound the players at the start of this session. The hunt is on! And
what better to hunt them with than the religious icon of the Chipahuan people - a Juvinile Sand Wurm?! The Wurm will

dig a tunnel to the players, and out will pop the cultist party. pursut Party
ursuit Party:

‘The players don't need to defeat the Wurm - killing the warlock or destroying his Shadow Scepter will release their soul
graft of the wurm, which will instantly burrow and head hone.

Crystal Sands Wurm - Juvinile (cult controlled)
2-4 Cultist
‘1x Shadow Warlock with Shadow Scepter (controlling monsters)

‘Once the players wrap this fight up, they'll have a RP opportunity to figure out next steps. Roll Random encounters as
they travel, then set up for a dungeon or fight for the following week.

Crystal Sands Wurm - Juvinile - Shadow Soul
CRB

ACB

HP 250

‘Speed: SOft / burrow soft

‘STR: 25 (+7) DEX: 9 (-1) CON: 20 (+5) INT: 1 (-5) WIS: 8 (-1) CHA 4 (-3)

Saving Throws: Con +10, Wis +4

Skills: Athletics +7

‘Sand Tunnels: While in sandy terrain, the Wurm gains +5 stealth and double its normal
burrowed movement speed.

‘Sand Sense: The Crystal Sands Wurm gains tremor sense 250ft while in sandy

Results: : environments.
Aasathra's pet has died in combat vs. the Sand Wurm ‘Crystal Corruption: This creature's has elemental crystals embedded throughout its
Players received several magical items, including a Flametoung sword and sandwurm scales body, gaining damage resistance randomly to [Acid, Cold, Fire, Lightning, Necrotic,

Psychic, Radiant]

Damage Resistance: slashing from nonmagical attacks, and Radiant
‘Actions:

Multi-attack: 2

Bite: +7 to hit, reach Loft, one target. Hit: 348+ 7 piercing damage. If the creature is a
medium or smaller creature, it must succeed on a DC17 saving throw or be swallowed
by the worm. A swallowed creature is blinded and restrained, has total cover vs.
attacks from outside the worm, and it takes 5d6 damage at the start of the wurm's
turn.

If the wurm takes 30 damage or more on a single turn from a creature within it, the
‘wurm must succeed on a DC21 CON Saving throw or regurgitate all swallowed
creatures, which fall prone 10ft from the wurm. if the wurm dies, the swallowed
creature is no longer restrained from it and may crawl out.

Tail Stinger: +7 to hit, reach 10ft, one creature. 3d6 + 7 piercing damage, and the
target must make a DC17 CON saving throw, taking 8d6 poison damage on a failed
save, or half on a successful one.

#### ChatGPT Output:
**Ayden Injury - Burn Scars (-1 CON, -1 CHA)** - Kaladan's lightning breath has left its mark. A twisting electrical burn has scarred the left side of Ayden's body.

Coming into this, the PCs just suffered their first real defeat. The taste of higher end combat has shown them that they are not the only ones that can dish out real damage. Ayden was nearly killed, and Kaetus was bugged out of his beast shaping more than once. The players finally are starting to respect the NPCs.

Speaking of which, Kaladan has left a hunting party to hound the players at the start of this session. The hunt is on! And what better to hunt them with than the religious icon of the Chipahuan people - a Juvenile Sand Wurm?! The Wurm will dig a tunnel to the players, and out will pop the cultist party.

**Pursuit Party:**

- The players don't need to defeat the Wurm - killing the warlock or destroying his Shadow Scepter will release their soul graft of the wurm, which will instantly burrow and head home.

**Crystal Sands Wurm - Juvenile (cult controlled)**
- 2-4 Cultist
- 1x Shadow Warlock with Shadow Scepter (controlling monsters)

Once the players wrap this fight up, they'll have a RP opportunity to figure out next steps. Roll Random encounters as they travel, then set up for a dungeon or fight for the following week.

**Crystal Sands Wurm - Juvenile - Shadow Soul**
- CRB
- ACB
- HP 250
- Speed: 50ft / burrow 50ft
- STR: 25 (+7) DEX: 9 (-1) CON: 20 (+5) INT: 1 (-5) WIS: 8 (-1) CHA 4 (-3)
- Saving Throws: Con +10, Wis +4
- Skills: Athletics +7
- **Sand Tunnels:** While in sandy terrain, the Wurm gains +5 stealth and double its normal burrowed movement speed.
- **Sand Sense:** The Crystal Sands Wurm gains tremor sense 250ft while in sandy environments.
- **Crystal Corruption:** This creature has elemental crystals embedded throughout its body, gaining damage resistance randomly to [Acid, Cold, Fire, Lightning, Necrotic, Psychic, Radiant]
- **Damage Resistance:** slashing from nonmagical attacks, and Radiant

**Actions:**
- **Multi-attack:** 2
- **Bite:** +7 to hit, reach 10ft, one target. Hit: 3d8 + 7 piercing damage. If the creature is a medium or smaller creature, it must succeed on a DC17 saving throw or be swallowed by the worm. A swallowed creature is blinded and restrained, has total cover vs. attacks from outside the worm, and it takes 5d6 damage at the start of the wurm's turn.
- If the wurm takes 30 damage or more on a single turn from a creature within it, the wurm must succeed on a DC21 CON Saving throw or regurgitate all swallowed creatures, which fall prone 10ft from the wurm. if the wurm dies, the swallowed creature is no longer restrained from it and may crawl out.
- **Tail Stinger:** +7 to hit, reach 10ft, one creature. 3d6 + 7 piercing damage, and the target must make a DC17 CON saving throw, taking 8d6 poison damage on a failed save, or half on a successful one.

**Results:**
- Aasathra's pet has died in combat vs. the Sand Wurm
- Players received several magical items, including a Flametongue sword and sandwurm scales

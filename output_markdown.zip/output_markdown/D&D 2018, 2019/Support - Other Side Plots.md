# Other Side Plots

    **Created:** 2021-10-29 11:20:38  
    **Last Edited:** 2021-10-29 11:20:43  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Kings Family:

‘Wife was killed in the Orc Wars. Their Daughter is still alive, working with freedom fighters and rebels on the Eastern
Frontier. For them, the war is far from over.

At Risk Tieflings:

Evil is spreading in Ennui. The Tiefling docks are always kind of weird, but now the occult is taking firm hold of this,
population. The Merchants Guild (mafia) runs the town. They are purposefully driving the tieflings to desperation so that
‘they will in turn join the cult. Some of them have the potential to be strong warlocks and wizards.

Florinna Commands El Enna:

Floriana is having trouble in El Enna. Cultists routinely attack guards and attempt assassinations during the night. This,
large, bustling city is now filled with refugees and growing desperation. She needs to establish control of the city and
calm the situation before it spirals into chaos.

#### ChatGPT Output:
Kings Family:

- Wife was killed in the Orc Wars. Their Daughter is still alive, working with freedom fighters and rebels on the Eastern
  Frontier. For them, the war is far from over.

At Risk Tieflings:

- Evil is spreading in Ennui. The Tiefling docks are always kind of weird, but now the occult is taking firm hold of this
  population. The Merchants Guild (mafia) runs the town. They are purposefully driving the tieflings to desperation so that
  they will in turn join the cult. Some of them have the potential to be strong warlocks and wizards.

Florinna Commands El Enna:

- Floriana is having trouble in El Enna. Cultists routinely attack guards and attempt assassinations during the night. This
  large, bustling city is now filled with refugees and growing desperation. She needs to establish control of the city and
  calm the situation before it spirals into chaos.

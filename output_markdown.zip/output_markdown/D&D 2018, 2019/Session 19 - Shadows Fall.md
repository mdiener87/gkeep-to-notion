# Session 19 - Shadows Fall

    **Created:** 2021-10-29 11:17:27  
    **Last Edited:** 2021-10-29 11:17:34  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
First day with actual prep available to us - let's build some good combat encounters!

In the last session, a lot of RP occurred. The players:
+ Chopped apart the shadow blue dragonling, then surmouned its soul and encased it in Bob Ross' warmage wand
* The dragon parts were combined into legendary dragonscale armor for Kaetus

+ Ayden, through a bit of metagaming, tried to ditch the Ore sword. it's not that easy to dodge a soul bond...

Plot points:
Players are probably going to try to reach the capital city of Alluin, meet the king, etc. The war with the orcs has
suddenly reached its conclusion, but will peace finally come to the kingdom of dawn? ... No.

Forces in motion:
Shadows Fall - An adult shadow dragon has awoken. Hungry and greedy for the wealth of the real, it has embarked ona
campaign to enter the material realm. its hunt led it to a tear in the dimensions, and now it is slowly widening the rift. As
time goes on, more of its spawn and other denizens of the shadow realm will flood into the material world.

‘The human populace of Dawn has been deeply traumatized. Over half the citizens are dead, including upwards of 80%
fighting aged men. People are scared and order in outlying towns is falling dramatically. A new doomsday cult is quickly
gaining influence and notoriety- DF: Dusk Falls. They prophesize that the orc invasion was just the start - their true god
will soon cast shadow over all.

Keeping Score - the thieves guild isn’t happy with the players, esp. after Ayden keeps screwing with the halflings. They
can't take the players head on, but they might be able to cause problems at critical moments.

Orc Consequences - the kindgom has been devastated by the invasion. Over half the population is dead, with two
eastem cities entirely wiped out. This chaos and destruction has only helped the shadow dragon gain entrance to the

realm. Roving bands of orcs and other monsters can still be encountered, even on city roads.

‘The king is devastated at war the war has cost. Grateful to the players, but now the task of rebuilding has begun.

Items:
‘Warmage wand +2 - Touched by Shadow (Sethrekar)
This wand has been infused with the spirit of a shadow dragon. While
wielding this wand, you gain dark vision out to 30ft. Additionally, once per
day, you may meditate over one hour in deep shadows to commune with
the dragon's spirit.

‘ShadowScale Dragon Armor - 15AC + DEX Mod (max 2}

* Advantage on saving throws against the Frightful Presence and breath
‘weapons of dragons.

= Damage resistance: necrotic

= Advantage on stealth roles while concealed in shadows

* You may focus your senses to find the nearest shadow dragon within 30mi
once/day

"This unique armor set was crafted by the legendary dwarven armorer,
Morkral. Dark-blue dragon scales are accented by white dragon bone and
gold inlays. impossible shadows seem to dance about the scales, darting
this way and that when just out of sight.

Encounters: Young Shadow Dragon (harasses players at night if they get into it)

#### ChatGPT Output:
First day with actual prep available to us - let's build some good combat encounters!

In the last session, a lot of RP occurred. The players:
+ Chopped apart the shadow blue dragonling, then surmounted its soul and encased it in Bob Ross' warmage wand
* The dragon parts were combined into legendary dragonscale armor for Kaetus

+ Ayden, through a bit of metagaming, tried to ditch the Ore sword. It's not that easy to dodge a soul bond...

Plot points:
Players are probably going to try to reach the capital city of Alluin, meet the king, etc. The war with the orcs has
suddenly reached its conclusion, but will peace finally come to the kingdom of Dawn? ... No.

Forces in motion:
Shadows Fall - An adult shadow dragon has awoken. Hungry and greedy for the wealth of the real, it has embarked on a
campaign to enter the material realm. Its hunt led it to a tear in the dimensions, and now it is slowly widening the rift. As
time goes on, more of its spawn and other denizens of the shadow realm will flood into the material world.

The human populace of Dawn has been deeply traumatized. Over half the citizens are dead, including upwards of 80%
fighting aged men. People are scared and order in outlying towns is falling dramatically. A new doomsday cult is quickly
gaining influence and notoriety—DF: Dusk Falls. They prophesize that the orc invasion was just the start— their true god
will soon cast shadow over all.

Keeping Score - the thieves guild isn’t happy with the players, esp. after Ayden keeps screwing with the halflings. They
can't take the players head on, but they might be able to cause problems at critical moments.

Orc Consequences - the kingdom has been devastated by the invasion. Over half the population is dead, with two
eastern cities entirely wiped out. This chaos and destruction has only helped the shadow dragon gain entrance to the
realm. Roving bands of orcs and other monsters can still be encountered, even on city roads.

The king is devastated at war the war has cost. Grateful to the players, but now the task of rebuilding has begun.

Items:
Warmage wand +2 - Touched by Shadow (Sethrekar)
This wand has been infused with the spirit of a shadow dragon. While
wielding this wand, you gain dark vision out to 30ft. Additionally, once per
day, you may meditate over one hour in deep shadows to commune with
the dragon's spirit.

ShadowScale Dragon Armor - 15AC + DEX Mod (max 2)
* Advantage on saving throws against the Frightful Presence and breath
  weapons of dragons.
* Damage resistance: necrotic
* Advantage on stealth roles while concealed in shadows
* You may focus your senses to find the nearest shadow dragon within 30 mi
  once/day

This unique armor set was crafted by the legendary dwarven armorer,
Morkral. Dark-blue dragon scales are accented by white dragon bone and
gold inlays. Impossible shadows seem to dance about the scales, darting
this way and that when just out of sight.

Encounters: Young Shadow Dragon (harasses players at night if they get into it)

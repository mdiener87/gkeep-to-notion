# Session 36 - The City of Brass

    **Created:** 2021-10-29 11:23:29  
    **Last Edited:** 2021-10-29 11:23:37  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Following the battle with Essafah, Agar has taken a liking to the PC party and will want to take them to the City of
Brass. The capital city of the Elemental Plane of Fire, the City of Brass is a legendary city of Efreeti, Salamanders,
‘Azer. Here they can meet the Grand Sultan of the Efreeti, and the renowned Azer Forgemasters. Salamanders make
up the seedy underbelly of this city, and they are happy to trade in both blood and magic. Mortal humanoids are not
an uncommon sight here - they make excellent slaves and property.

Ultimately this is not really a friendly place to mortals. The Order of Sun and Moon could well find themselves
meeting slavers that want to kidnap them for the trade. Or find themselves on a mission to recover valuable
‘property’... Such as tiefling sex slaves.

Returning to the Mortal realm from this plane won't be easy. They'll need to find another planar portal, and find a
keystone that corresponds to the material plane of existence. Or bargain for such a spell to be cast on the party.

Outcomes:
Met the grand sultan and convinced him that Essafah is some sot of Genie fraud. He is commissioning a
study on what to do about this with his other Efreeeti but no word on his decision.

‘The party then explored the city of brass and got into seroius schenanagains:
Dork: willingly sold himself into sexual stavery, banged 5 efreeti and bought his own freedom
back. Earned a few blood agates for his trouble {and a genie STD that gave him +1 CON)
(Odysseus: Fought in the gladiatorial rings and learned something new (TBD)

Elryss: Started a new cult of Mishkal amongst the fire salamanders. They are starting to turn
‘themselves into fire elementals and have become fervent cultists of Mishkal. They worship Elyris
asa messenger.

Party overall: Worked with the Azer to begin production and upgrade of several items:
Obsidian Ring Shield: Required a mote of soot from the sea of embers
Upgraded Dragonscale Armor: Required a spirit of rage
Roc Feather Cloak: in production without further effort

City of Brass
Ruler - Grand Sultant (Efreeti}

Citizens: Efreeti, Azeer, Salamanders, humanoid slaves, fire creatures
Guilds: Golden Ring - Azer Forgemasters; luminaries - Efreeti enforcers

#### ChatGPT Output:
Following the battle with Essafah, Agar has taken a liking to the PC party and will want to take them to the City of
Brass. The capital city of the Elemental Plane of Fire, the City of Brass is a legendary city of Efreeti, Salamanders,
Azer. Here they can meet the Grand Sultan of the Efreeti, and the renowned Azer Forgemasters. Salamanders make
up the seedy underbelly of this city, and they are happy to trade in both blood and magic. Mortal humanoids are not
an uncommon sight here - they make excellent slaves and property.

Ultimately this is not really a friendly place to mortals. The Order of Sun and Moon could well find themselves
meeting slavers that want to kidnap them for the trade. Or find themselves on a mission to recover valuable
property... Such as tiefling sex slaves.

Returning to the Mortal realm from this plane won't be easy. They'll need to find another planar portal, and find a
keystone that corresponds to the material plane of existence. Or bargain for such a spell to be cast on the party.

### Outcomes:
- Met the grand sultan and convinced him that Essafah is some sort of Genie fraud. He is commissioning a
study on what to do about this with his other Efreeti but no word on his decision.

- The party then explored the city of brass and got into serious shenanigans:
  - **Dork**: willingly sold himself into sexual slavery, banged 5 efreeti, and bought his own freedom
    back. Earned a few blood agates for his trouble (and a genie STD that gave him +1 CON)
  - **Odysseus**: Fought in the gladiatorial rings and learned something new (TBD)
  - **Elryss**: Started a new cult of Mishkal amongst the fire salamanders. They are starting to turn
    themselves into fire elementals and have become fervent cultists of Mishkal. They worship Elyris
    as a messenger.

- Party overall: Worked with the Azer to begin production and upgrade of several items:
  - Obsidian Ring Shield: Required a mote of soot from the sea of embers
  - Upgraded Dragonscale Armor: Required a spirit of rage
  - Roc Feather Cloak: in production without further effort

### City of Brass
**Ruler**: Grand Sultan (Efreeti)

**Citizens**: Efreeti, Azer, Salamanders, humanoid slaves, fire creatures

**Guilds**: Golden Ring - Azer Forgemasters; Luminaries - Efreeti enforcers
# Session 21 - Shadow Cypher

    **Created:** 2021-10-29 11:18:43  
    **Last Edited:** 2021-10-29 11:18:51  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Notes coming into today:
Players threw a party last time to lure the cultists in Alluin out of hiding. Using the king as bait, they succeeded in
drawing out an assassination attempt. After the dust cleared, the king was nearly killed, and an encrypted document
‘was found on one of the bodies...

>So where is the Dragon? What's he up to?

>Where does the document take the plot?

>Get some dice rolling in today

>Dragon is going to kick their butts, they need to level up and get some gear
>Dungeon!

As night falls, its time for the dragon to make its appearance and show the players just how outclassed they are still vs.

serious firepower.

How would Kaladan go about subjugating the kingdom?
>The cult gives him knowledge about mortal affairs, and an outlet to exercise schemes and plots.

>King Moryn has held out vs the Ores and now the dragon siege, but he is starting to lose political control over the
kingdom

>Kaladan is a narcissist and wants everything to be about his obvious dragonkin superiority.

>Shadow cult would send word assassination plot has failed - two warlocks, two cultists, and an assassin. Foiled by the
same group who just saved the Kingdom, when the dragon really didn't want it to be saved.

>So Kaladan is going to show up and try to sneak into the keep and learn what the heroes are about. And then kill the
king in front of them and issue a warning to surrender to the survivors.

>Shadow Cypher:
It's actually just Kaladan's twitter feed. If you can read Umbral, you can read Kaladan's musings.
‘Won't someone rid me of this King Moron?

Like srs just surrender already

Lol omg these cultists just snuck through TSA security

How did that cleric survive!? Healing op!

Fine I'll just kill King Moron myself. Do you think I'l get stupider if | eat him?

Watch to the skies Alluin! Oh wait you can't see me I'm invisible in the dark LOL

King Moryn: Remaining Family
Princess [Something] is in El Enna
Prince [Something] is on a mission towards Chipahua to rally reinforcements vs. the dragon

Outcomes:
>Dragon kills everyone, TPK
‘They actually respawn in the warped shadow realm, and must find their way back

>One or more PK
Give players option to find way back from shadow realm, or [die]

>Dragon gets hit in the face with the Valzumin Stronghold. Dragon ded. City probably swamped with
water as well. Would seriously slow down the cult. Not sure how this would occur in a practical sense.

>Players figure out how to kill the dragon / drive it off

>Players get roundly defeated
Let them lick their wounds and figure out a plan of attack

General Tyr -
Been studying the castle's archives for inspiration on how to defeat the dragon. Is starting to think the
(Orc war might not have been an accident. Mass chaos and destruction, the despair and suffering of
‘thousands - this is the nature of the shadow realm itself. He swears there is a document in the library
detailing the old battles with dragons but can't seem to find it.

Visir Oriana -
Has been working on modifying the castle's magical protection to stave off dragon attacks. The castle
walls and windows are magically shielded, and the entire castle is protected by a Forbiddance spell. But
this doesn't stop things from physically fling over into the keep, and she'd like to enhance the
Forbiddance effect to block dragons and winged overhead flight.

#### ChatGPT Output:
'''Notes coming into today:
Players threw a party last time to lure the cultists in Alluin out of hiding. Using the king as bait, they succeeded in
drawing out an assassination attempt. After the dust cleared, the king was nearly killed, and an encrypted document
was found on one of the bodies...

> So where is the Dragon? What's he up to?
> 
> Where does the document take the plot?
> 
> Get some dice rolling in today
> 
> Dragon is going to kick their butts, they need to level up and get some gear
> Dungeon!

As night falls, it's time for the dragon to make its appearance and show the players just how outclassed they are still vs.
serious firepower.

How would Kaladan go about subjugating the kingdom?
> The cult gives him knowledge about mortal affairs, and an outlet to exercise schemes and plots.
> 
> King Moryn has held out vs the Orcs and now the dragon siege, but he is starting to lose political control over the
kingdom
> 
> Kaladan is a narcissist and wants everything to be about his obvious dragonkin superiority.
> 
> Shadow cult would send word assassination plot has failed - two warlocks, two cultists, and an assassin. Foiled by the
same group who just saved the Kingdom, when the dragon really didn't want it to be saved.
> 
> So Kaladan is going to show up and try to sneak into the keep and learn what the heroes are about. And then kill the
king in front of them and issue a warning to surrender to the survivors.

> Shadow Cypher:
It's actually just Kaladan's twitter feed. If you can read Umbral, you can read Kaladan's musings.
> Won't someone rid me of this King Moron?
> 
> Like srs just surrender already
> 
> Lol omg these cultists just snuck through TSA security
> 
> How did that cleric survive!? Healing op!
> 
> Fine I'll just kill King Moron myself. Do you think I'll get stupider if I eat him?
> 
> Watch to the skies Alluin! Oh wait you can't see me I'm invisible in the dark LOL

King Moryn: Remaining Family
Princess [Something] is in El Enna
Prince [Something] is on a mission towards Chipahua to rally reinforcements vs. the dragon

Outcomes:
> Dragon kills everyone, TPK
> They actually respawn in the warped shadow realm, and must find their way back
> 
> One or more PK
Give players option to find way back from shadow realm, or [die]
> 
> Dragon gets hit in the face with the Valzumin Stronghold. Dragon ded. City probably swamped with
water as well. Would seriously slow down the cult. Not sure how this would occur in a practical sense.
> 
> Players figure out how to kill the dragon / drive it off
> 
> Players get roundly defeated
Let them lick their wounds and figure out a plan of attack

General Tyr -
Been studying the castle's archives for inspiration on how to defeat the dragon. Is starting to think the
Orc war might not have been an accident. Mass chaos and destruction, the despair and suffering of
thousands - this is the nature of the shadow realm itself. He swears there is a document in the library
detailing the old battles with dragons but can't seem to find it.

Visir Oriana -
Has been working on modifying the castle's magical protection to stave off dragon attacks. The castle
walls and windows are magically shielded, and the entire castle is protected by a Forbiddance spell. But
this doesn't stop things from physically fling over into the keep, and she'd like to enhance the
Forbiddance effect to block dragons and winged overhead flight.'''

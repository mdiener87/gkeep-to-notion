# Session 46 - Its Treason, Then

    **Created:** 2021-10-29 11:26:42  
    **Last Edited:** 2021-10-29 11:26:52  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party just had several days of high-stakes combat encounters, so its time to cool things down a touch on today's
session, Bob Ross is nat in this week so the drama of the AF from last week won't play out or be resolved today. Instead,
the party has a severely injured Floriana and a (knight-to-be) Gildas joining them at Tinethra's Manor.

Floriana is the obvious plot hook here - what news does she have? The party has not interacted with Floriana in a serious
way for quite a while now. Her forces had captured a cultist leader in El Enna and interrogated him, learning more about
the Onyx Mountain and Kaladan's Plan.

Floriana will knight Gildas for his bravery.

Alluin is now under active threat.

‘The King is becoming increasingly desperate, and his pleas to the gods go unanswsered. If he is forced down this road,
he might try to make a pact with the very fiendish forces that are currently helping the shadow cultists in a bid to boost

his own power.

Kaladan is ransacking El Enna, hoping to incite fear and terror in the population.

Result:
Rupport had some issues with the AF being present on the players and actively in use to conjure items.
Led to a whole furball about why they had the item and not Teniethra. Ultimatley, the players mostly

succeeded on deceiving him.

Capt. Floriana is healed and ready to kick some ass in revenge for the suffering of El Enna. Her faith in
the light has been signficiantly shaken,

Gil was knighted.
Borrend did declare independent city Status.

King Moryn has pledged the remainder of the Royal Guard to the player's aid for when they ride to
battle.

‘Onyx Mountain intel:

‘An immense sandstorm surrounds and blankets the area, making it difficult to navigate. The sand
is dense enough that it can blind and damage travelers.

‘The cultists have succeeded in widening the rift between the shadow realm and the material
plane, allowing for dragon born soldiers to easily come through the tear in reality. While the
mother cannot fit, there's no telling how long that will stay the case. The chromatic prism at the
heart of the mountain is the cause of this rift

With the fall of El Enna, its feared that Alluin and even Borrend might soon become targets.
Borrend has sealed itself off, much as they did during the orc invasion. Borrend has withdrawn
from the compact of Dawn, declaring it a free city of litle peoples.

Alluin is under active threat. The few remaining Knights of lluin are helping to protect the city,
but itis feared that civil unrest will soon force the King to abdicate the thrown. If and when that
happens, it is expected that Kaladan will take up its mantle and assume ruler ship of the kingdom.

#### ChatGPT Output:
'The party just had several days of high-stakes combat encounters, so it's time to cool things down a touch on today's
session, Bob Ross is not in this week so the drama of the AF from last week won't play out or be resolved today. Instead,
the party has a severely injured Floriana and a (knight-to-be) Gildas joining them at Tinethra's Manor.

Floriana is the obvious plot hook here - what news does she have? The party has not interacted with Floriana in a serious
way for quite a while now. Her forces had captured a cultist leader in El Enna and interrogated him, learning more about
the Onyx Mountain and Kaladan's Plan.

Floriana will knight Gildas for his bravery.

Alluin is now under active threat.

'The King is becoming increasingly desperate, and his pleas to the gods go unanswered. If he is forced down this road,
he might try to make a pact with the very fiendish forces that are currently helping the shadow cultists in a bid to boost
his own power.

Kaladan is ransacking El Enna, hoping to incite fear and terror in the population.

Result:
Rupport had some issues with the AF being present on the players and actively in use to conjure items.
Led to a whole furball about why they had the item and not Teniethra. Ultimately, the players mostly
succeeded on deceiving him.

Capt. Floriana is healed and ready to kick some ass in revenge for the suffering of El Enna. Her faith in
the light has been significantly shaken,

Gil was knighted.
Borrend did declare independent city Status.

King Moryn has pledged the remainder of the Royal Guard to the player's aid for when they ride to
battle.

'Onyx Mountain intel:

'An immense sandstorm surrounds and blankets the area, making it difficult to navigate. The sand
is dense enough that it can blind and damage travelers.

'The cultists have succeeded in widening the rift between the shadow realm and the material
plane, allowing for dragon born soldiers to easily come through the tear in reality. While the
mother cannot fit, there's no telling how long that will stay the case. The chromatic prism at the
heart of the mountain is the cause of this rift

With the fall of El Enna, it's feared that Alluin and even Borrend might soon become targets.
Borrend has sealed itself off, much as they did during the orc invasion. Borrend has withdrawn
from the compact of Dawn, declaring it a free city of little peoples.

Alluin is under active threat. The few remaining Knights of Alluin are helping to protect the city,
but it is feared that civil unrest will soon force the King to abdicate the throne. If and when that
happens, it is expected that Kaladan will take up its mantle and assume rulership of the kingdom.'

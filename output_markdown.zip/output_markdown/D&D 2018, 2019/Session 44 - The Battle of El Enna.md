# Session 44 - The Battle of El Enna

    **Created:** 2021-10-29 11:26:22  
    **Last Edited:** 2021-10-29 11:26:27  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Player objectives:

ur PC party has teleported into the city of El Enna, only to find it is under active siege! Cultist insurrectionists are
making their move against the Kingdom of Dawn, and El Enna as the largest city is taking the brunt of it. Normal civilians
and the milita are both defecting; only the guards led personally by Governor Florianna are having any luck at all at
holding off the attackers.

* Stop reinforcements from coming through the cultists' teleportation circle
© The cultists have set up a base in the old cathedral. t's well guarded, and regularly is
receiving teleports of more dragonborn, controlled monsters, and cultist humans.

‘The cultist army is increasingly made up of dragonborn foot soldiers - where are these guys coming from? (cultist's have "Save Captain Floriana in the governor's mansion.
©. The cultists have seized the governor's mansion. Its defense force was quickly overwhelmed,

set up a teleporation circle outside of town).
paneepo ) and now they are trying to spiritually flay the Governor to join their side! If successful, she

The cultists objective Is to capture the Governor, Floriana. She is one of the last Royal Guards and true Paladins in the will convert to a LE War Paladin, devoted to the evils of Shadow and Dragon.

kingdom. Her bravery and honor are a beacon of light that the cultists are eager to extinguish.
* Save the citizens of El Enna

© Alarge number have been taken into the colleseum for a forced conversion to the shadow
path. They are preparing a ritual that will convert the citezens inside to LE cultists - or kill
them in the process.

Result: players chose to save the citizens in the colleseum. They were able to save several civilians from
sacrifice by the cultists, and cut down their army in the area, The militia member Gildas joined their fight
and aided them in their struggle against the shadow forces.

#### ChatGPT Output:
#### Player objectives:

Your PC party has teleported into the city of El Enna, only to find it is under active siege! Cultist insurrectionists are
making their move against the Kingdom of Dawn, and El Enna as the largest city is taking the brunt of it. Normal civilians
and the militia are both defecting; only the guards led personally by Governor Florianna are having any luck at all at
holding off the attackers.

- Stop reinforcements from coming through the cultists' teleportation circle
- The cultists have set up a base in the old cathedral. It's well guarded, and it's regularly 
  receiving teleports of more dragonborn, controlled monsters, and cultist humans.
- The cultist army is increasingly made up of dragonborn foot soldiers - where are these guys coming from? (Cultists have set up a teleportation circle outside of town).
- Save Captain Floriana in the governor's mansion.
- The cultists have seized the governor's mansion. Its defense force was quickly overwhelmed,
  and now they are trying to spiritually flay the Governor to join their side! If successful, she
  will convert to a LE War Paladin, devoted to the evils of Shadow and Dragon.

The cultists' objective is to capture the Governor, Floriana. She is one of the last Royal Guards and true Paladins in the
kingdom. Her bravery and honor are a beacon of light that the cultists are eager to extinguish.
- Save the citizens of El Enna
- A large number have been taken into the coliseum for a forced conversion to the shadow
  path. They are preparing a ritual that will convert the citizens inside to LE cultists - or kill
  them in the process.

Result: players chose to save the citizens in the coliseum. They were able to save several civilians from
sacrifice by the cultists, and cut down their army in the area. The militia member Gildas joined their fight
and aided them in their struggle against the shadow forces.

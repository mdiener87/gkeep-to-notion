# Session 12 - The Crypts of Borrend

    **Created:** 2021-10-29 11:14:52  
    **Last Edited:** 2021-10-29 11:15:19  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Opening:
‘The players have chosen not to visit the besieged city first. In fact, they never actually confirmed that's the
city. Could make use of that? Either way, they don't have the information about the crypt the city would
have offered them. So its time to have a proper and difficult dungeon for them to into - blind.

‘Theme - crypt, toxic environment. This is a city of the ‘Small Triumverate' Dwarves, Gnomes, and Half-lings
living together. The crypt should have one floor for each as a theme.

Crypt Overall Effects:
Toxicity: Accumulates in the players over time.
Micro-corridors that lead to exploration areas.

More toxic environments that have enemies / treasure / traps
Miniboss on each floor that is spewing toxicity and racial power
Skeletons on each floor of that race's crypt

‘Traps specialized to that race

#### ChatGPT Output:
Opening:
‘The players have chosen not to visit the besieged city first. In fact, they never actually confirmed that's the
city. Could make use of that? Either way, they don't have the information about the crypt the city would
have offered them. So its time to have a proper and difficult dungeon for them to into - blind.

‘Theme - crypt, toxic environment. This is a city of the ‘Small Triumverate' Dwarves, Gnomes, and Half-lings
living together. The crypt should have one floor for each as a theme.

Crypt Overall Effects:
Toxicity: Accumulates in the players over time.
Micro-corridors that lead to exploration areas.

More toxic environments that have enemies / treasure / traps
Miniboss on each floor that is spewing toxicity and racial power
Skeletons on each floor of that race's crypt

‘Traps specialized to that race

### Attachment 2

#### Raw OCR Output:
Caustie Toxicity:

Level

Effect

1

Short rests restore 1/2 HP, rounded up.
Long rests: DC1O con save or restore 1/2 HP, rounded up

‘AC Reduced By 1

Disadvantage on ability checks

Speed Halved; AC Reduced by 2

al s]e]N

Disadvantage on attack rolls and saving throws; DC 10 spellcasting check to
Cast spells or spell is canceled (spell slot is not consumed).

Hit point Maximum Halved

Delirious - unable to effectively attack, block, or concentrate to cast spells

Speed Reduced to 0

el,e|slo

Unconscious

Can no longer regain HP or gain temporary HP. DC10 Con Save applied once
Per hour; on Fail, Death saving throw.

i

Death; 24 hours later is re-animated as a rotting ghoul.

#### ChatGPT Output:
**Caustic Toxicity:**

| Level | Effect |
|-------|--------|
| 1     | Short rests restore 1/2 HP, rounded up. Long rests: DC10 con save or restore 1/2 HP, rounded up |
| 2     | AC Reduced By 1 |
| 3     | Disadvantage on ability checks |
| 4     | Speed Halved; AC Reduced by 2 |
| 5     | Disadvantage on attack rolls and saving throws; DC 10 spellcasting check to cast spells or spell is canceled (spell slot is not consumed). |
| 6     | Hit point Maximum Halved |
| 7     | Delirious - unable to effectively attack, block, or concentrate to cast spells |
| 8     | Speed Reduced to 0 |
| 9     | Unconscious |
| 10    | Can no longer regain HP or gain temporary HP. DC10 Con Save applied once per hour; on Fail, Death saving throw. |
| 11    | Death; 24 hours later is re-animated as a rotting ghoul. |

### Attachment 3

#### Raw OCR Output:
Level 1: Gnome Crypt
Tomb of Panana Lili Meena of the Cursed Raulnor Loofollue Clan

Monsters:
‘Shambling Gnome skelelton - weak, can appear in tombs or as adds
Rotting Gnome skeleton - medium strength skeleton

Agile Gnome skeleton - sneaky and back stabs (unique gnome mab}

Elements to include:
‘Tombs, Crypts, urns to open

Micro passages that lead into secret rooms
Miniboss

Straight up brawl room

Ambient toxicity / toxicity on hit

‘Trapped Drow? Or a ki

#### ChatGPT Output:
### Level 1: Gnome Crypt
**Tomb of Panana Lili Meena of the Cursed Raulnor Loofollue Clan**

**Monsters:**
- Shambling Gnome skeleton - weak, can appear in tombs or as adds
- Rotting Gnome skeleton - medium strength skeleton
- Agile Gnome skeleton - sneaky and back stabs (unique gnome mob)

**Elements to include:**
- Tombs, Crypts, urns to open
- Micro passages that lead into secret rooms
- Miniboss
- Straight up brawl room
- Ambient toxicity / toxicity on hit
- Trapped Drow? Or a ki

### Attachment 4

#### Raw OCR Output:
3 Sins:
Gnomes: Perverting thought (mecha weapon)
Dwarves: Perverting nature (gas mining)

Halfling: Perverting soul (corrupting chemical)

#### ChatGPT Output:
3 Sins:
- Gnomes: Perverting thought (mecha weapon)
- Dwarves: Perverting nature (gas mining)
- Halfling: Perverting soul (corrupting chemical)

### Attachment 5

#### Raw OCR Output:
Sources:
All crypt sections have automatic toxicity applied to the players. This is applied on contact and via
inhalation. A DC10 Con save should be applied per encounter + short rest + long rest for ambient
toxicity.

Skeletons: On hit, players should roll for an increase in their Crypt Toxicity (DC10 Con save)

Toxic Streams: DC15 Con Save

#### ChatGPT Output:
Sources:
All crypt sections have automatic toxicity applied to the players. This is applied on contact and via
inhalation. A DC10 Con save should be applied per encounter + short rest + long rest for ambient
toxicity.

- Skeletons: On hit, players should roll for an increase in their Crypt Toxicity (DC10 Con save)
- Toxic Streams: DC15 Con Save

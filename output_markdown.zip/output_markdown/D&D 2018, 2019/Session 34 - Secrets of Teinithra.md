# Session 34 - Secrets of Teinithra

    **Created:** 2021-10-29 11:23:02  
    **Last Edited:** 2021-10-29 11:23:12  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘That's Tein-eith-ra - the legendary Elven manor. Its former elven master has been missing for hundreds of years, That's
because he succeeded in his research of the Aether flame, and successfully fused his soul with the essence of the Aether
plane. As a result, he transformed into a powerful Djin, a ruling elemental in the Elemental Plane af Air. The top of the
manor has a research labroatory, and the PCs can discover a covered mirror which acts as a bridge to this realm. The
Djin has long forgotten his roots as Tenithra, and now rules as a Gennie in full.

‘There is no Aether Flame left in the lab, and the lab is guarded by two powerful golems. If they can reach the Gennie,
‘they might be able to barter for a vial of the Flame. Or they might learn that Kaladan has already entreated him for a
vial, and the Gennie is considering offering it to him instead. There might be a battle to win the Gennie's favor here...

Pull up a map from .html download for the aether realm exploration.

Result:

‘The party explored the Manor, and Ayden used the Viper key to break into the research lab. Kaetus used
dispel magic on a clay golem, and with an excellent roll disenchanted it. The party then found the Planar
Portal and transported themselves to the Elemental Plane af Air in search of the Aether Flame.

Within that plane, they met Mekrus the cloud giant and Essafah the Enchanted (Djin). Essafah tricked
‘Odysseus into eating the food and drink, and was enchanted into becoming his best friend. Soon Essafah
teleported the PC party to the plane of fire, on a mission to steal a prized painting from his rival Gennie,
‘Agar the Burning Efreeti.

‘The PC avoided the Salamanders that inhabit this plane, and found Agar on his lava throne. Instead of
fighting or stealing the desired artifact from the Efreeti, they decided to entreat it in a bid to turn the
tables on Essafah. Agar agreed, and they mocked Agar's death using the Feign Death spell from Elryss.
Essafah appeared as desired, pleased as punch that his rival was dead.

But then Odesseuys' enchantment triggered, and he warned Essafah of the trap! Elryss ended Agar's
feign death effect, and both genies now find themselves in an elemental fight! Fire and air elementals
are being conjured around the party as the whole thing heads into massive combat at next session's
start!

Essafah the Enchanted
‘A former High-Elf lord, Essafah fused his soul's essence with the Aether Flame and transformed
himself into a powerful Djin of the air elemental plane.

Air plane monsters:

Chimeras
Air Giants
Air Elementals
Roc

Behir
Manticores
Etins

Phase Spiders
Deva
Demons??

#### ChatGPT Output:
‘That's Tein-eith-ra - the legendary Elven manor. Its former elven master has been missing for hundreds of years. That's
because he succeeded in his research of the Aether flame, and successfully fused his soul with the essence of the Aether
plane. As a result, he transformed into a powerful Djin, a ruling elemental in the Elemental Plane of Air. The top of the
manor has a research laboratory, and the PCs can discover a covered mirror which acts as a bridge to this realm. The
Djin has long forgotten his roots as Tenithra, and now rules as a Genie in full.

‘There is no Aether Flame left in the lab, and the lab is guarded by two powerful golems. If they can reach the Genie,
they might be able to barter for a vial of the Flame. Or they might learn that Kaladan has already entreated him for a
vial, and the Genie is considering offering it to him instead. There might be a battle to win the Genie's favor here...

Pull up a map from .html download for the aether realm exploration.

Result:

‘The party explored the Manor, and Ayden used the Viper key to break into the research lab. Kaetus used
dispel magic on a clay golem, and with an excellent roll disenchanted it. The party then found the Planar
Portal and transported themselves to the Elemental Plane of Air in search of the Aether Flame.

Within that plane, they met Mekrus the cloud giant and Essafah the Enchanted (Djin). Essafah tricked
Odysseus into eating the food and drink, and was enchanted into becoming his best friend. Soon Essafah
teleported the PC party to the plane of fire, on a mission to steal a prized painting from his rival Genie,
Agar the Burning Efreeti.

The PC avoided the Salamanders that inhabit this plane, and found Agar on his lava throne. Instead of
fighting or stealing the desired artifact from the Efreeti, they decided to entreat it in a bid to turn the
tables on Essafah. Agar agreed, and they mocked Agar's death using the Feign Death spell from Elryss.
Essafah appeared as desired, pleased as punch that his rival was dead.

But then Odysseus' enchantment triggered, and he warned Essafah of the trap! Elryss ended Agar's
feign death effect, and both genies now find themselves in an elemental fight! Fire and air elementals
are being conjured around the party as the whole thing heads into massive combat at next session's
start!

Essafah the Enchanted
A former High-Elf lord, Essafah fused his soul's essence with the Aether Flame and transformed
himself into a powerful Djin of the air elemental plane.

Air plane monsters:

- Chimeras
- Air Giants
- Air Elementals
- Roc

- Behir
- Manticores
- Etins

- Phase Spiders
- Deva
- Demons??

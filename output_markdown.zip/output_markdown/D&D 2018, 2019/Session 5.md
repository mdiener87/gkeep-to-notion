# Session 5

    **Created:** 2021-10-29 11:09:18  
    **Last Edited:** 2021-10-29 11:09:23  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Full party, not much prep. Hmm

Lead uf
They will be in exploration mode, currently dealing with Graves the lycanthrope.

Outstanding plot threads:
Recruiters trying to draft all men in the kingdom, will be very happy to recruit the players.

‘The cursed elven bracelet will try to freak out every time it sees the holy symbol of the human kingdom. Or
werewolves.

Dungeons:

#### ChatGPT Output:
Full party, not much prep. Hmm

Lead off  
They will be in exploration mode, currently dealing with Graves the lycanthrope.

Outstanding plot threads:  
- Recruiters trying to draft all men in the kingdom, will be very happy to recruit the players.  

- The cursed elven bracelet will try to freak out every time it sees the holy symbol of the human kingdom. Or  
werewolves.  

Dungeons:

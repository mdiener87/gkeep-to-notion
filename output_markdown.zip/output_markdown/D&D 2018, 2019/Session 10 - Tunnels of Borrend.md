# Session 10 - Tunnels of Borrend

    **Created:** 2021-10-29 11:13:35  
    **Last Edited:** 2021-10-29 11:13:44  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Entrance - guarded by a lazy Orc who is standing outside as punishment for some transgression. He is fuming back and
forth.

Level One: Random maze of narrow tunnels. Players can encounter Orcs, Oozes, sleeping owl bears, etc. Roll randomly
for one or two encounters depending on time. One of the blind ends has a small chest clutched by a dead soldier. tt
contains a random magic item (uncommon).

‘The exit is a narrow ladder leading deeper into the darkness

Level two runs along a deep ravine to the player's right. Ores have built a makeshift bridge across a gap, and several are
on the other side, Giant spiders lurk deep in the recesses af this larger level. Orcs have torches and a makeshift camp on
the other side. They are guarding one tunnel in particular that goes deeper into the complex

‘The Shelogh priestess is at this war camp. She commands the other orcs from atop her makeshift ore war keep, and will
hur! insults and fire bolts down at the players.

Orc camp loot: There is a chest of war spoils the Ores have collected atop the keep. A pile of dwarven bodies lies at the
edge of the camp.

On the other side of the tunnel is the Borrend Mauleleum. The Etin is here, along with an orc squad. They are busy trying
to breach an old sealed entrance into Borrend. Coffins and other heirlooms fill this chamber. The Etin is busy arguing
with itself whether it should smash the door in, or pull the door off its hinges.

#### ChatGPT Output:
**Entrance** - guarded by a lazy Orc who is standing outside as punishment for some transgression. He is fuming back and
forth.

**Level One**: Random maze of narrow tunnels. Players can encounter Orcs, Oozes, sleeping owl bears, etc. Roll randomly
for one or two encounters depending on time. One of the blind ends has a small chest clutched by a dead soldier. It
contains a random magic item (uncommon).

*The exit is a narrow ladder leading deeper into the darkness.*

**Level Two** runs along a deep ravine to the player's right. Orcs have built a makeshift bridge across a gap, and several are
on the other side. Giant spiders lurk deep in the recesses of this larger level. Orcs have torches and a makeshift camp on
the other side. They are guarding one tunnel in particular that goes deeper into the complex.

*The Shelogh priestess is at this war camp. She* commands the other orcs from atop her makeshift orc war keep, and will
hurl insults and fire bolts down at the players.

**Orc camp loot**: There is a chest of war spoils the Orcs have collected atop the keep. A pile of dwarven bodies lies at the
edge of the camp.

*On the other side of the tunnel is the Borrend Mausoleum.* The Etin is here, along with an orc squad. They are busy trying
to breach an old sealed entrance into Borrend. Coffins and other heirlooms fill this chamber. The Etin is busy arguing
with itself whether it should smash the door in, or pull the door off its hinges.

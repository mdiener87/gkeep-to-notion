# Session 16 - Borrend Doom Cannon, cont

    **Created:** 2021-10-29 11:16:40  
    **Last Edited:** 2021-10-29 11:16:53  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
No Notes ready for this one, and just 3 players. Going to wing everything and see where we get!
Refer to SESIS

Post game play notes:

Players [Aaron] murdered a drow in cold blood, Broc saw this.

Players [Aaron] imprisoned Broc against his will
>[Aaron] Also stole a bunch of shit from a weapons fence

Players turned gas extraction to off via Broc. The system is stable; has fuel for one more shot without restarting as
extraction to corrupted mode, Further normal gas extraction will cause seperator to explode.

Players requested Gnome Engineering + Tordid + The War council to arrive to confirm everything before firing.
Players fired the Borrend Doom Cannon. The weapon was a direct hit and destroyed the entirety of the Orc army.
However, this has also rendered the surrounding terrain toxic and sealed off the way into Borrend for the forseeable
future.

Tordid Nordak saw the power of the weapon first-hand and now wants control over its destiny. While she was originally
for this being a onetime thing, the power of the weapon cannot be denied, Its successful use has put the once sleepy

community of Borrend on the magical community map.

PCs are properly famous now. They have single-handily retrieved an ancient weapon and vanquished an orc army single
handedly!

Captrain Floriana is pissed about using the weapon. Her heart of righteousness won't excuse the use of chemical
‘weapons that easily.

Jasper has def. sold the players out. Question is to whom. ..

#### ChatGPT Output:
No Notes ready for this one, and just 3 players. Going to wing everything and see where we get!
Refer to SESIS

Post game play notes:

- Players [Aaron] murdered a drow in cold blood, Broc saw this.

- Players [Aaron] imprisoned Broc against his will
  >[Aaron] Also stole a bunch of shit from a weapons fence

- Players turned gas extraction to off via Broc. The system is stable; has fuel for one more shot without restarting as
  extraction to corrupted mode, Further normal gas extraction will cause separator to explode.

- Players requested Gnome Engineering + Tordid + The War council to arrive to confirm everything before firing.
- Players fired the Borrend Doom Cannon. The weapon was a direct hit and destroyed the entirety of the Orc army.
  However, this has also rendered the surrounding terrain toxic and sealed off the way into Borrend for the foreseeable
  future.

- Tordid Nordak saw the power of the weapon first-hand and now wants control over its destiny. While she was originally
  for this being a one-time thing, the power of the weapon cannot be denied, Its successful use has put the once sleepy

  community of Borrend on the magical community map.

- PCs are properly famous now. They have single-handedly retrieved an ancient weapon and vanquished an orc army single
  handedly!

- Captain Floriana is pissed about using the weapon. Her heart of righteousness won't excuse the use of chemical
  'weapons that easily.

- Jasper has def. sold the players out. Question is to whom. ..

# Session 47 - I hate 3M

    **Created:** 2021-10-29 11:26:57  
    **Last Edited:** 2021-10-29 11:27:02  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Skipped last week because 3M. Irate this week because 3M. Ineed a new job.

‘The PC party are trying to get to Borrend this week in an attempt to gather forces and get closer to the Onyx Mountain.
Kaladan is on approach in the sky already, he knows the Aether Flame is close. It's use was confirmed in El Enna against
‘the Narzugon, and the party is covered in its magical aura. Kaladan wants this thing, and he wants it bad.

Air Assault:
Kaladan + Shadow Demons, He will send in progressive waves of Shadow Demons if the players get caught by him to act
as front line assault. Meanwhile, Kaladan will stay back and blast away with his Lightening Breath if he can,

Kaladan has a new ability - Aether Counter - which he can use to help fight back against Aether Flame usage.

If they get into Borrend, they'll find that the city has become quite militarized sense they were last present. With full
power to the city restored from the crypts below, the city has begun an aggressive rearmament campaign. This is
resulting in numerous cannons and defensive structures built into the sides of the Borrend city. Tordid suspects the PCs
didn't rescue the Doom Cannon on purpose, and has commissioned Broc as Head Doom Engineer to build a new,
improved version. She doesn't want the city to ever face a crisis like the orc invasion again, during which her own
defenders felt helpless to stop the siege.

* Kaladan can burrow underground. If the Players get to Borrend safely without incident, he will begin a
subterranean attack on the city and bring cultist reinforcements in that way.

+ He might also use the Drow as agents to secure both WMDs and the Aether Flame. A retriever will be sent after
the flame itself, while a Drow raiding party attempts to infiltrate the Doorn Cannon's supply storage and lift one of,
the warheads full of corrupted gas.

* The Narzugon has nat lost his desire for Floriana's soul. He will try to turn up when he is least expected

If they can find it, the Thieves guild has a small teleport circle within the halls of Borrend. They also have learned,
‘through contacts within the cult, the rune pattern for the Onyx Mountain teleportation circle, This could be used to set
up an ambush on the cultists within their own base. However, given the party's disposition to the TG currently, this will
be a difficutt bargain to reach.

Result:

‘Welp none of that on the left happened.

‘The party, after much discussion, gave Rupport his final mana crystal. This has unlocked
tremendous magical power and knowledge within Rupport, taking him to Ultron levels. Ruport
then aided the party in teleporting to Alluin, in an effort to set up a teleportation circle back to
Tenithra's Manor. A thousand refuges had been gathered in the Alluin castle and Kaladan was on
the attack.

Visir Oriana had been building a corrupted teleporation circle, in a bid to sacrifice unwitting souls
toa layer of hell, hoping to bring back bound demons to fight the dragon in return. The party
found her there, holding the lock to the dungeon's teleport circle. Ruport took unkindly to this
threat, and cast Disintegrate on her. She failed her reflex saving throw and was vaporized, along
with the dungeon door.

‘The party was then able to succesfully evacuate the refugees from the keep to T.M. King Moryn
was injured

Ruport is declaring himself lord of the manor, alongside the (minor) lords of the party.

#### ChatGPT Output:
Skipped last week because 3M. Irate this week because 3M. I need a new job.

'The PC party are trying to get to Borrend this week in an attempt to gather forces and get closer to the Onyx Mountain.
Kaladan is on approach in the sky already, he knows the Aether Flame is close. Its use was confirmed in El Enna against
the Narzugon, and the party is covered in its magical aura. Kaladan wants this thing, and he wants it bad.

Air Assault:
Kaladan + Shadow Demons, He will send in progressive waves of Shadow Demons if the players get caught by him to act
as front line assault. Meanwhile, Kaladan will stay back and blast away with his Lightning Breath if he can,

Kaladan has a new ability - Aether Counter - which he can use to help fight back against Aether Flame usage.

If they get into Borrend, they'll find that the city has become quite militarized since they were last present. With full
power to the city restored from the crypts below, the city has begun an aggressive rearmament campaign. This is
resulting in numerous cannons and defensive structures built into the sides of the Borrend city. Tordid suspects the PCs
didn't rescue the Doom Cannon on purpose, and has commissioned Broc as Head Doom Engineer to build a new,
improved version. She doesn't want the city to ever face a crisis like the orc invasion again, during which her own
defenders felt helpless to stop the siege.

* Kaladan can burrow underground. If the Players get to Borrend safely without incident, he will begin a
subterranean attack on the city and bring cultist reinforcements in that way.

+ He might also use the Drow as agents to secure both WMDs and the Aether Flame. A retriever will be sent after
the flame itself, while a Drow raiding party attempts to infiltrate the Doom Cannon's supply storage and lift one of,
the warheads full of corrupted gas.

* The Narzugon has not lost his desire for Floriana's soul. He will try to turn up when he is least expected

If they can find it, the Thieves guild has a small teleport circle within the halls of Borrend. They also have learned,
through contacts within the cult, the rune pattern for the Onyx Mountain teleportation circle, This could be used to set
up an ambush on the cultists within their own base. However, given the party's disposition to the TG currently, this will
be a difficult bargain to reach.

Result:

Welp none of that on the left happened.

The party, after much discussion, gave Rupport his final mana crystal. This has unlocked
tremendous magical power and knowledge within Rupport, taking him to Ultron levels. Ruport
then aided the party in teleporting to Alluin, in an effort to set up a teleportation circle back to
Tenithra's Manor. A thousand refugees had been gathered in the Alluin castle and Kaladan was on
the attack.

Visir Oriana had been building a corrupted teleportation circle, in a bid to sacrifice unwitting souls
to a layer of hell, hoping to bring back bound demons to fight the dragon in return. The party
found her there, holding the lock to the dungeon's teleport circle. Ruport took unkindly to this
threat, and cast Disintegrate on her. She failed her reflex saving throw and was vaporized, along
with the dungeon door.

The party was then able to successfully evacuate the refugees from the keep to T.M. King Moryn
was injured

Ruport is declaring himself lord of the manor, alongside the (minor) lords of the party.

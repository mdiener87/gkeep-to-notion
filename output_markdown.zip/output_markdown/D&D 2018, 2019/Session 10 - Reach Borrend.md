# Session 10 - Reach Borrend

    **Created:** 2021-10-29 11:12:32  
    **Last Edited:** 2021-10-29 11:13:11  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Ores are sieging Borrend, the city of Dwarvs, Halflings, Gnomes, and other small folk. Borrend is considered
unbreachable, with its entrance built into a sheer cliff. A retracting Dwarven bridge prevents attackers from reaching its
formidable door. But Borrend is not invulnerable - it connects deep into a series of abandoned tunnels and shafts, and
even now an Ore Terror squad are navigating the tunnels in hopes of finding a hidden passage in. If they get inside, they
will smash the defenders and lower the bridge!

‘Setup: Captain Florianna is aware of the weakness of the cities defenses. As a captain of the royal guard, we was tasked
to help seal those weak spots when her unit was attacked and captured. The orcs tortured her party and learned of the
weakness, a5 well as the strength of Borrend - an artifact weapon that might turn the tide of the war!

#### ChatGPT Output:
Ores are sieging Borrend, the city of Dwarvs, Halflings, Gnomes, and other small folk. Borrend is considered
unbreachable, with its entrance built into a sheer cliff. A retracting Dwarven bridge prevents attackers from reaching its
formidable door. But Borrend is not invulnerable - it connects deep into a series of abandoned tunnels and shafts, and
even now an Orc Terror squad are navigating the tunnels in hopes of finding a hidden passage in. If they get inside, they
will smash the defenders and lower the bridge!

Setup: Captain Florianna is aware of the weakness of the cities defenses. As a captain of the royal guard, she was tasked
to help seal those weak spots when her unit was attacked and captured. The orcs tortured her party and learned of the
weakness, as well as the strength of Borrend - an artifact weapon that might turn the tide of the war!

### Attachment 2

#### Raw OCR Output:
Captain Floriana - She can requip at Borrend, where she will take up command duties and start seeing,
to the wounded.

#### ChatGPT Output:
Captain Floriana - She can requip at Borrend, where she will take up command duties and start seeing,
to the wounded.

### Attachment 3

#### Raw OCR Output:
‘Weapon - Borrend Observatory:

Can focus solar energy during the day to redirect and blast a tile within 20hex of Borrend. After charging,
the Observatory fires an immense solar rainbow beam that arcs into the target and purges everything it
hits. This uses a tremendous amount of energy, which must be captured and stored in Dwarven Salt
Rocks. These rocks are heated with lava deep beneath the observatory, then hauled to the top with
mechanical chains. After the salt rock is loaded, its energy can be used as the power and focal
requirements for the artifact spell to cast.

‘The motten charging system has been destroyed! The players will need to venture deep into the caverns
beneath Borrend to discover what's stopping the apparatus from working,

#### ChatGPT Output:
### Weapon - Borrend Observatory:

Can focus solar energy during the day to redirect and blast a tile within 20 hex of Borrend. After charging,  
the Observatory fires an immense solar rainbow beam that arcs into the target and purges everything it  
hits. This uses a tremendous amount of energy, which must be captured and stored in Dwarven Salt  
Rocks. These rocks are heated with lava deep beneath the observatory, then hauled to the top with  
mechanical chains. After the salt rock is loaded, its energy can be used as the power and focal  
requirements for the artifact spell to cast.

The motion charging system has been destroyed! The players will need to venture deep into the caverns  
beneath Borrend to discover what's stopping the apparatus from working.

### Attachment 4

#### Raw OCR Output:
‘Sheggohn Priestess

‘STR +3 DEX #0 CON 42 INT 12 WIS 14 CHA 12
ACIS

Hit Points: 60

Speed: 30ft

Aggressive - bonus action may move towards
players

Spellcasting - The orc is a 3rd-level spellcaster.
Its spellcasting DC is wisdom (DC 13, +4 hit
with spell attacks)

Spells:

2nd level 3 slots: See invisibility, scorching ray
Ast level 4 slots: Shield, Burning Hands
Cantrip: Fire Bolt, light, mage hand

Actions: Spear: +4 to hit, hit: 1d6 +2

Orc Orogs - these are branded with symbols
of devotion to Illneveal, and Sheggohn's
bloodied war crest. Itis one sword raised high
in triumph, the other impaled onto an eff. tis,
said not to be an earned crest until splashed
with both orc and elf blood.

#### ChatGPT Output:
# Sheggohn Priestess

- **STR** +3
- **DEX** +0
- **CON** 42
- **INT** 12
- **WIS** 14
- **CHA** 12
- **AC** 15

**Hit Points:** 60

**Speed:** 30ft

**Aggressive** - bonus action may move towards players

**Spellcasting** - The orc is a 3rd-level spellcaster. Its spellcasting ability is wisdom (DC 13, +4 hit with spell attacks)

**Spells:**

- **2nd level (3 slots):** See invisibility, scorching ray
- **1st level (4 slots):** Shield, Burning Hands
- **Cantrips:** Fire Bolt, light, mage hand

**Actions:** Spear: +4 to hit, hit: 1d6 +2

**Orc Orogs** - these are branded with symbols of devotion to Illneveal, and Sheggohn's bloodied war crest. It is one sword raised high in triumph, the other impaled onto an effigy. It is said not to be an earned crest until splashed with both orc and elf blood.

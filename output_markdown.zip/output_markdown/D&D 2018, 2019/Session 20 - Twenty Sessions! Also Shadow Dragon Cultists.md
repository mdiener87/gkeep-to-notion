# Session 20 - Twenty Sessions! Also Shadow Dragon Cultists

    **Created:** 2021-10-29 11:18:21  
    **Last Edited:** 2021-10-29 11:18:35  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, the players are going to begin the legwork of dealing with the dragon threat. The Ore invasion
has sent this kingdom reeling. Refugees flood Alluin and El Enna. Buildings and families alike have been torn asunder.
‘Amongst this chaos, a new cult is gaining rapid influence. Their members are fueled by the magic and malice of
Orexijandilin, an adult Shadow Dragon now trying to find her way home.

Gries" goal is to reach the material realm and once again have a home worth gloating about. The shadow realm is full of
death and decay; little Is tasty, or shiny, or brag-worthy. The wanton deaths in the war have caused the shadows to
grow long indeed - now a tiny slip in the dimensions is growing larger... Her hunger is growing...

PCs will need to RP to discover the political life of alluin and the growing influence of the cult. Kaladan is harassing the
city, a5 well as Ennui, El Enna, and Chipahua at random. He demands respect, fealty, and sacrifice, Cruel and reckless,
Kaladan is enjoying his first taste of the material realm where he clearly thinks (and is probably correct about) being the
big dog on campus.

Shadow cultists objective:
Open the chromatic prism within the heart of the Onyx Mountain. This uniquely large prism was thought
to be an ancient religious artifact of little importance; perhaps form the people of Chipahua. Regardless
of its original purpose, the cult has found a way to use the prism to serve as a conduit to the shadow
realm,

‘They are currently searching for a vial of AetherFlame; This ethereal substance is rare on the material
plane and highly prized in alchemy and arcana for both its extraordinary magical potential, and ability to
phase between dimensions. if they can find it, they can use it in conjunction with the prism to burn a
hole between dimensions - directly into the shadow realm. A hole large enough for mature dragons to
slip through.

In the meantime, the cult is following the orders of Kaladan. He is trying to seize control of the kingdom
‘through terror and suppression.

#### ChatGPT Output:
Convert the following OCR text to Markdown, preserving all formatting:

Coming into this session, the players are going to begin the legwork of dealing with the dragon threat. The Orc invasion
has sent this kingdom reeling. Refugees flood Alluin and El Enna. Buildings and families alike have been torn asunder.
Amongst this chaos, a new cult is gaining rapid influence. Their members are fueled by the magic and malice of
Orexijandilin, an adult Shadow Dragon now trying to find her way home.

Gries' goal is to reach the material realm and once again have a home worth gloating about. The shadow realm is full of
death and decay; little is tasty, or shiny, or brag-worthy. The wanton deaths in the war have caused the shadows to
grow long indeed - now a tiny slip in the dimensions is growing larger... Her hunger is growing...

PCs will need to RP to discover the political life of Alluin and the growing influence of the cult. Kaladan is harassing the
city, as well as Ennui, El Enna, and Chipahua at random. He demands respect, fealty, and sacrifice. Cruel and reckless,
Kaladan is enjoying his first taste of the material realm where he clearly thinks (and is probably correct about) being the
big dog on campus.

Shadow cultists objective:
- Open the chromatic prism within the heart of the Onyx Mountain. This uniquely large prism was thought
  to be an ancient religious artifact of little importance; perhaps from the people of Chipahua. Regardless
  of its original purpose, the cult has found a way to use the prism to serve as a conduit to the shadow
  realm,

They are currently searching for a vial of AetherFlame; This ethereal substance is rare on the material
plane and highly prized in alchemy and arcana for both its extraordinary magical potential, and ability to
phase between dimensions. if they can find it, they can use it in conjunction with the prism to burn a
hole between dimensions - directly into the shadow realm. A hole large enough for mature dragons to
slip through.

In the meantime, the cult is following the orders of Kaladan. He is trying to seize control of the kingdom
through terror and suppression.

# Sessions 2 + 3

    **Created:** 2021-10-29 11:02:49  
    **Last Edited:** 2021-10-29 11:07:21  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Game will open with players leveling up to level 2. Carolyn will be out so party will be 5 characters still. Derick can come
in at level 2 but without extra resources.

Setting stage from last game

‘Adventuring party has been traveling along the road of Hadari, seeking adventure, fortune, and your fates. After staying
the night at a small inn, the party was confronted by a regal specter terrorizing the village. Blah blah. You've defeated
the ogre, and are setting up camp for the night...

‘Session two might prove linear if it's just a dungeon crawl. There should be opportunity for exploring this elven crypt,
some social interaction, room for unexpected, and a boss battle

Working backwards:
Second floor needs to do a lot. Players need to explore and have some social interaction here,

Hallway N: Switch One to open staircase to boss
Grand hall, with switch at the end
Hall is littered with dead, petrified spiders. A basilisk lurks in the great hall, happy to be at the top of the
food chain.

‘The switch and other items of significance are in the private meeting chamber behind the hall. This room is
trapped with eye warding sentries,
Ghostly elven It for chat interaction? Could activate weapons/armors if players fail to talk to him correctly.

Secondary traps can activate animated armor and weapons if the players fail to open the stuff correctly.

Hallway S: Switch Two to open staircase to boss
‘Avnest of spiders guards this annex. They are hungry and eat everything that comes near.
‘The spider webs conceal a hidden room. The switch will be on the opposite side of the room, also buried in
spider webs within the officer's mess.

Hidden room is a supply closet with one feast's worth left of Elven food (magically preserved), plus roll on
magic item table for the chest.

More content here?

Hallway E: Burst pipe in the barracks

‘The hallway in is partially collapsed and flooded. Navigating it in the cold and dark is not easy. Inside lies an
ancient elven barracks. it's been long looted, except for a brilliant, golden chest submerged in running
water. Its overflowing from a burst pipe in the ceiling.

‘The chest is really a mimic (220). The overflowing water makes it difficult to open and loot the chest. If
players can somehow fix the pipe, the water will start draining from the area. If the pipe continues to break,
the room and adjoining hallways could continue to flood.

‘The officers’ quarters are further down the flooded section. It opens to a small open space clear of flooding
to an apparent dead end. The door is hidden, and difficult to open against the floodwater if the pipe has not
been fixed.

Inside lies a chest, and a necklace that's a bane of the boss. It allows the holder to strike the boss for super
effect. [Plot item?]

Hallway W: Arcane lab
Notebooks to decipher, about magick runes of prophecy and omens of disaster
Clearly powerful divination magick was once studied here

‘A drow raiding party has dug their way in from somewhere and are busy looting the place. A chance for
dialog and probably combat.

Motivation: to acquire elven artifacts and protect ‘their heritage’. Might barter elven crystals + gold for
peaceful resolution, but won't get to loot the room.

Boss Battle - Lord Goltorah

Undead Elven Ghost
He haunts the village, in a twisted attempt to warn of the kingdom's turning to demonic influence. Talking with the
ghost will prove vain. He isn't a lich or a powerful sorcerer, just a restless soul on a vain quest.

Encounter: Interesting and tough. Boss should be able to animate defenses to his ald as adds. Animated elven
armor and weapons.

Root

hird and final floor of dungeon. Two switches are required to open the stairs down,

A burst pipe on the second floor is sending excess water into the boss room. If the players fail to clear this
challenge, the room will be filled with knee-deep water, hampering their movement (-50% penalty).

‘The room was designed to be a divination ward against evil that might imperil the realm. While long abandoned,
its potent elven magick has roused this lord from his rest one last time, Regardless of how the players resolve the
boss battle, they can likely use research against the room to learn about the presence of demons.

Large mirrors on the walls the boss can phase into, Gannondorf style. He can re-emerge from another divination
mirror and restore HP while doing so.

Players can destroy the mirrors to stop this affect. The boss is damaged each time they do so.

‘The boss, even if ‘killed’, will return with 50% from one of the mirrors. All mirrors must be smashed before the
encounter is cleared.

Mirrors: AC 10, 10HP. Vulnerable to smashing damage, resistant to magic damage

#### ChatGPT Output:
Game will open with players leveling up to level 2. Carolyn will be out so party will be 5 characters still. Derick can come
in at level 2 but without extra resources.

Setting stage from last game

‘Adventuring party has been traveling along the road of Hadari, seeking adventure, fortune, and your fates. After staying
the night at a small inn, the party was confronted by a regal specter terrorizing the village. Blah blah. You've defeated
the ogre, and are setting up camp for the night...

‘Session two might prove linear if it's just a dungeon crawl. There should be opportunity for exploring this elven crypt,
some social interaction, room for unexpected, and a boss battle

Working backwards:
Second floor needs to do a lot. Players need to explore and have some social interaction here,

- Hallway N: Switch One to open staircase to boss
  - Grand hall, with switch at the end
  - Hall is littered with dead, petrified spiders. A basilisk lurks in the great hall, happy to be at the top of the
    food chain.

‘The switch and other items of significance are in the private meeting chamber behind the hall. This room is
trapped with eye warding sentries,
Ghostly elven It for chat interaction? Could activate weapons/armors if players fail to talk to him correctly.

Secondary traps can activate animated armor and weapons if the players fail to open the stuff correctly.

- Hallway S: Switch Two to open staircase to boss
  - ‘A nest of spiders guards this annex. They are hungry and eat everything that comes near.
  - ‘The spider webs conceal a hidden room. The switch will be on the opposite side of the room, also buried in
    spider webs within the officer's mess.

Hidden room is a supply closet with one feast's worth left of Elven food (magically preserved), plus roll on
magic item table for the chest.

More content here?

- Hallway E: Burst pipe in the barracks

  - ‘The hallway in is partially collapsed and flooded. Navigating it in the cold and dark is not easy. Inside lies an
    ancient elven barracks. it's been long looted, except for a brilliant, golden chest submerged in running
    water. Its overflowing from a burst pipe in the ceiling.

  - ‘The chest is really a mimic (220). The overflowing water makes it difficult to open and loot the chest. If
    players can somehow fix the pipe, the water will start draining from the area. If the pipe continues to break,
    the room and adjoining hallways could continue to flood.

  - ‘The officers’ quarters are further down the flooded section. It opens to a small open space clear of flooding
    to an apparent dead end. The door is hidden, and difficult to open against the floodwater if the pipe has not
    been fixed.

Inside lies a chest, and a necklace that's a bane of the boss. It allows the holder to strike the boss for super
effect. [Plot item?]

- Hallway W: Arcane lab
  - Notebooks to decipher, about magick runes of prophecy and omens of disaster
  - Clearly powerful divination magick was once studied here

  - ‘A drow raiding party has dug their way in from somewhere and are busy looting the place. A chance for
    dialog and probably combat.

Motivation: to acquire elven artifacts and protect ‘their heritage’. Might barter elven crystals + gold for
peaceful resolution, but won't get to loot the room.

Boss Battle - Lord Goltorah

- Undead Elven Ghost
  - He haunts the village, in a twisted attempt to warn of the kingdom's turning to demonic influence. Talking with the
    ghost will prove vain. He isn't a lich or a powerful sorcerer, just a restless soul on a vain quest.

Encounter: Interesting and tough. Boss should be able to animate defenses to his aid as adds. Animated elven
armor and weapons.

Root

- Third and final floor of dungeon. Two switches are required to open the stairs down,

  - A burst pipe on the second floor is sending excess water into the boss room. If the players fail to clear this
    challenge, the room will be filled with knee-deep water, hampering their movement (-50% penalty).

  - ‘The room was designed to be a divination ward against evil that might imperil the realm. While long abandoned,
    its potent elven magick has roused this lord from his rest one last time, Regardless of how the players resolve the
    boss battle, they can likely use research against the room to learn about the presence of demons.

  - Large mirrors on the walls the boss can phase into, Gannondorf style. He can re-emerge from another divination
    mirror and restore HP while doing so.

  - Players can destroy the mirrors to stop this affect. The boss is damaged each time they do so.

  - ‘The boss, even if ‘killed’, will return with 50% from one of the mirrors. All mirrors must be smashed before the
    encounter is cleared.

Mirrors: AC 10, 10HP. Vulnerable to smashing damage, resistant to magic damage

### Attachment 2

#### Raw OCR Output:
Outstanding Threads:
Second Floor: North room is still to be cleared. Expand this some - spider-infested hallways

Drow Priestess" Document:
Its encrypted. If they can break the cypher, they'll be able to read their orders:

1: Raid the keep and retake all of our cultural artifacts
2: Spread the call of the spider throughout the keep
3: f possible, find the Elven Power Crystal at the center of the keep and return itto the
Drow temple
4: Attack nearby human settlements. The kingdom is in disarray from the Orc War to the
east - there is no standing army to contest our raiding parties

#### ChatGPT Output:
**Outstanding Threads:**
*Second Floor: North room is still to be cleared. Expand this some - spider-infested hallways*

**Drow Priestess' Document:**
*It's encrypted. If they can break the cipher, they'll be able to read their orders:*

1. Raid the keep and retake all of our cultural artifacts
2. Spread the call of the spider throughout the keep
3. If possible, find the Elven Power Crystal at the center of the keep and return it to the Drow temple
4. Attack nearby human settlements. The kingdom is in disarray from the Orc War to the east - there is no standing army to contest our raiding parties

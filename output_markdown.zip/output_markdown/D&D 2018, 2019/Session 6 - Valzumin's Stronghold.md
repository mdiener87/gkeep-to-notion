# Session 6 - Valzumin's Stronghold

    **Created:** 2021-10-29 11:09:38  
    **Last Edited:** 2021-10-29 11:09:45  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Note: Play mat dimensions: 56x32 squares

Lost for hundreds of years, our intrepid gang of explorers has managed to uncover the entrance to the legendary
vValzumin Stronghold.

‘Some things to answer -

Why's there a stronghold in a lake like this? What is it even a stronghold for? What happened to the elven kingdom that
once ruled these lands? Lake is within the center of a mesa - why?

Answer - the lake, the structure within it are all within the remains of a reality bubble. The lake, naturally, would just be
a small pond otherwise. The elevator is the only obvious connection to enter the reality marble,

In reality, the marble is at the end of its life. It has been operating for hundreds of years without a top-off, and now this
ZPM is just about exhausted. Reality marbles are poorly anchored, and this one is leaking into the elemental plane of
water at a worrying pace.

‘So what happened to the elves?

‘The fate of the kingdom is still unknown. The fate of this stronghold seems clear - Sahuagin. They have moved in and laid
claim to the Stronghold. They plan to decypher the reality marble at the heart af the stronghold. Their plan is to re-seal
the marble, and thereby gain the ability to move their new impenetrable base to a better location than the middle of
this rocky area.

Let's think about pacing here.

Estimated game duration: 4 hours
* Boss fight should be the climax of the night, something memorable
© Estimate one hour for the boss fight, including finding the room and everything
* This leaves room for anywhere from 2 - 4 encounters for the rest of the evening

#### ChatGPT Output:
**Note: Play mat dimensions: 56x32 squares**

Lost for hundreds of years, our intrepid gang of explorers has managed to uncover the entrance to the legendary
Valzumin Stronghold.

**Some things to answer -**

- Why's there a stronghold in a lake like this? What is it even a stronghold for? What happened to the elven kingdom that
once ruled these lands? Lake is within the center of a mesa - why?

**Answer** - the lake, the structure within it are all within the remains of a reality bubble. The lake, naturally, would just be
a small pond otherwise. The elevator is the only obvious connection to enter the reality marble,

In reality, the marble is at the end of its life. It has been operating for hundreds of years without a top-off, and now this
ZPM is just about exhausted. Reality marbles are poorly anchored, and this one is leaking into the elemental plane of
water at a worrying pace.

**So what happened to the elves?**

The fate of the kingdom is still unknown. The fate of this stronghold seems clear - Sahuagin. They have moved in and laid
claim to the Stronghold. They plan to decipher the reality marble at the heart of the stronghold. Their plan is to re-seal
the marble, and thereby gain the ability to move their new impenetrable base to a better location than the middle of
this rocky area.

**Let's think about pacing here.**

Estimated game duration: 4 hours
- Boss fight should be the climax of the night, something memorable
- Estimate one hour for the boss fight, including finding the room and everything
- This leaves room for anywhere from 2 - 4 encounters for the rest of the evening

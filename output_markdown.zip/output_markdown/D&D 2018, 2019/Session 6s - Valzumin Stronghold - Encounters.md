# Valzumin Stronghold - Encounters

    **Created:** 2021-10-29 11:09:54  
    **Last Edited:** 2021-10-29 11:10:04  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Dungeon Layout:

Dungeon is composed of 4 levels. The dungeon itself is a composed of an elegant (and still living) Elven coral, half carved and half grown into place. It rests at the bottom of an
immense lake, which itself resides within a reality marble at the heart of the stronghold.

Level 0 - Observation Deck
‘The observation deck is unvisited by the shauglin raiding party. A coral (earth) elemental is ponderously patrolling the area, seemingly paying no heed to events going on
around it. Destroying coral in its vicinity will agro it - this is its home.

‘There isa coral orate chest in this room. Careful to pick the lock without it noticing...

Level 1 - Main Keep Level
Entrance
‘The elevator opens into a small 'mudroom’, guarded by an asleep Shauglin party (2x). Elaborate and hardened doors lead further inward, their locking mechanism has
been smashed to pieces.

Main Hallway
Various rooms and bedrooms Iie adjacent to this main hallway. They have been clearly been smashed and ransacked in haste, A Shaugalin raiding party is looking
through the room, trying to find Elven treasures. The players will have to kick some butt here too.

Shauglin Raiding Party
2x Cleric
2x Shalguin warriors

‘Additional shauglin warriors will agro in to keep i

interesting

‘Side rooms (4x)
Minor Loot
Concealed Door - reveals a winding, gently sloping hallway to level 0, higher in the coral.

Main Stairs
Another long, descending stairs goes from here to Level 2

Level 2- VIP Keep level
‘The stairs open into a curved hallway, going to the left and right out of sight.
Pathway Left: Stronghold Vault

‘The vault was nat penetrated by the Shauglin or any other raiding party. Coral gives way to an exotic gleaming door. Impressive, silent, and locked tightly shut. Two
locking mechanisms guard the door. Each must be disengaged before the vault can be opened.

Vault Lock:

DC 201o disengage lock

Magically shielded - Another player must make a DC15 concentration check to cancel the magic (while concentration is maintained), or remove the magic as per a
counterspell or anti-magick zone

On any failure, a water weird is spawned in one of the two fountains behind the vault. f killed, it respawns on the next failure.

Pathway Right: VIP Quarters / skip if time is needed

It seems the Shaugalin first broke into - and then later smashed shut - the locking mechanism behind this door. Streaks of grey blood cover the door, hallways, and locking
mechanism. A thud, thud, thud comes from the other side.

Monster: Helmed Horror - instructed to eliminate all intruders and threats to the VS
Further down the hallway it stretches into winding stairs that eventually lead to level 3
Level 3 - reality marble containment room
Boss encounter:
‘Sahuagin Baron, lord of the V.S.
See page 264 for main stat blocks
Encounter:
‘Sahuagain Baron
‘Sahuagain Priestess

2x Sahuagain warriors
Additional warriors will jump out of the water and join the fray as needed to keep it intersting

#### ChatGPT Output:
Dungeon Layout:

Dungeon is composed of 4 levels. The dungeon itself is a composed of an elegant (and still living) Elven coral, half carved and half grown into place. It rests at the bottom of an
immense lake, which itself resides within a reality marble at the heart of the stronghold.

### Level 0 - Observation Deck
The observation deck is unvisited by the shauglin raiding party. A coral (earth) elemental is ponderously patrolling the area, seemingly paying no heed to events going on
around it. Destroying coral in its vicinity will agro it - this is its home.

There is a coral ornate chest in this room. Careful to pick the lock without it noticing...

### Level 1 - Main Keep Level
#### Entrance
The elevator opens into a small 'mudroom’, guarded by an asleep Shauglin party (2x). Elaborate and hardened doors lead further inward, their locking mechanism has
been smashed to pieces.

#### Main Hallway
Various rooms and bedrooms lie adjacent to this main hallway. They have been clearly been smashed and ransacked in haste, A Shaugalin raiding party is looking
through the room, trying to find Elven treasures. The players will have to kick some butt here too.

#### Shauglin Raiding Party
- 2x Cleric
- 2x Shalguin warriors

Additional shauglin warriors will agro in to keep it interesting

#### Side rooms (4x)
- Minor Loot
- Concealed Door - reveals a winding, gently sloping hallway to level 0, higher in the coral.

#### Main Stairs
Another long, descending stairs goes from here to Level 2

### Level 2- VIP Keep level
The stairs open into a curved hallway, going to the left and right out of sight.
#### Pathway Left: Stronghold Vault

The vault was not penetrated by the Shauglin or any other raiding party. Coral gives way to an exotic gleaming door. Impressive, silent, and locked tightly shut. Two
locking mechanisms guard the door. Each must be disengaged before the vault can be opened.

##### Vault Lock:
- DC 20 to disengage lock
- Magically shielded - Another player must make a DC15 concentration check to cancel the magic (while concentration is maintained), or remove the magic as per a
counterspell or anti-magick zone

On any failure, a water weird is spawned in one of the two fountains behind the vault. If killed, it respawns on the next failure.

#### Pathway Right: VIP Quarters / skip if time is needed

It seems the Shaugalin first broke into - and then later smashed shut - the locking mechanism behind this door. Streaks of grey blood cover the door, hallways, and locking
mechanism. A thud, thud, thud comes from the other side.

Monster: Helmed Horror - instructed to eliminate all intruders and threats to the VS
Further down the hallway it stretches into winding stairs that eventually lead to level 3

### Level 3 - reality marble containment room
#### Boss encounter:
Sahuagin Baron, lord of the V.S.
See page 264 for main stat blocks
#### Encounter:
- Sahuagain Baron
- Sahuagain Priestess
- 2x Sahuagain warriors

Additional warriors will jump out of the water and join the fray as needed to keep it interesting

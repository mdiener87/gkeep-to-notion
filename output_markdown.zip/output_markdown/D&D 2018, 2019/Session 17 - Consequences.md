# Session 17 - Consequences

    **Created:** 2021-10-29 11:16:59  
    **Last Edited:** 2021-10-29 11:17:06  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Final session until the new year! Evan is back, and with him the party is finally reunited!

Probably spend the first few minutes getting Evan back up to speed with the plot and where we are at as a group. Find
out what level he is and etc. PCs will all move up to level 6 at the end of tonight. We just need to put on a good finale for
the winter break!

Current Situation: Tordid is try to claim political control over the weapon. Its her people's property, and it might come in
handy in the future. While she did want to originally destroy the weapon, its use has put Borrend on the map.

>PCs can forcibly destroy weapon, damaging relations with Tordid to a small degree
>PCs can try to persuade her to destroy, but they are going to get some hassle by Broc. Hes starting to see the players
as reckless,

There will be some role playing to hash this out.
Dwarf Guards: 3x Veteran MM 350

Regardless, the weapon has had serious unintended consequences. The area is covered in a toxic
residue that seems to linger and cling to everything. Wildlife that enters the area dies, and there are
reports that some of the dead are coming back as vile monstrosities!

> Somehow, the players will have to face the now mutated form of the Orc leader. His god has
warned him of this moment - of a triumphant final battle, his body covered in burns. His warriors,
scarred beyond recognition. He is ready to face this test, and prove his devotion!

[Manticore Pike]
1D12 piercing - +2 weapon
Heavy, Reach, Two Handed

Loot table:

WarChief_| Megged Blade
+2 Greatsword (208)

Two handed, heavy, cursed: Berserker (DM 155)

Wicked and evil, stained dark with countless victims blood

+1 Ore Chainmail
Surprisingly sophisticated and well fitting. The crest of itineveal is on the right breast.

6 elaborate signet rings bearing the mark of the royal guard

Third Eye _| Stone of good luck in bag full of otherwise generic stones

Burst Ogre | Broom of Flying
100g in swallowed diamonds tied to broom. And severed hand

Ores Potion of greater healing
125g

Captain Floriana
[stats]

HP: 60

AC: 18 (full plate)

STR +3 DEX +1 CON 42 INT +1 WIS +3 CHA +4
Skills: Athletics +4, Perception +2

Actions:
Multi-attack:

Captain's Blade:

Melee Weapon attack +7 to hit; 1D8 +5 / 1D10 +5 two handed

Bonus action: Protection: May impose disadvantage on one melee attack directed at her or her party
within 5ft o her once per round
Sacred Weapon: Can embue weapon with holy energy for CHA bonus to attack for 1 min

[oxified]
Immune to poison damage
Immune to poison, exhaustion condition

Melee hits inflict 1D6 additional poison damage.

‘Sheggohn Megged
Toxified Ore War Chief

Same as MM 246 Except as noted:
str+5

HP 115

Toxic Belch: Line effect 20ft long. On hit, DC15 con save or 3d6 poison damage and considered poisoned
for an hour (disadvantage on attack and skills) . Or half as much on save.

Ore Third Eye of Gruumsh (woke orc is woke)
HP: 65

stra

Spells: 1st level (4 slots) inflict wounds, Bane

2nd level (2 slats) hold person, dispel magic (20ft range)(vornit on effect to end)

Toxified Ogre
HP 70

Speed 20ft / bulging

Toxic Burst - if Killed by piercing, slashing, or fire damage, explodes in 20ft cloud of toxic fumes.
Creatures that enter must make save as per Toxic Belch effect.

Toxified Ore
ACIS

HP 20

stra

Toxic Grapple: if successfully grapple, can belch in targets face to inflict DC15 con save or 3d6 poison
damage and considered poisoned for an hour (disadvantage on attack and skills) . Or half as much on
save.

#### ChatGPT Output:
Final session until the new year! Evan is back, and with him the party is finally reunited!

Probably spend the first few minutes getting Evan back up to speed with the plot and where we are at as a group. Find
out what level he is and etc. PCs will all move up to level 6 at the end of tonight. We just need to put on a good finale for
the winter break!

Current Situation: Tordid is try to claim political control over the weapon. Its her people's property, and it might come in
handy in the future. While she did want to originally destroy the weapon, its use has put Borrend on the map.

- PCs can forcibly destroy weapon, damaging relations with Tordid to a small degree
- PCs can try to persuade her to destroy, but they are going to get some hassle by Broc. He's starting to see the players
as reckless,

There will be some role playing to hash this out.
Dwarf Guards: 3x Veteran MM 350

Regardless, the weapon has had serious unintended consequences. The area is covered in a toxic
residue that seems to linger and cling to everything. Wildlife that enters the area dies, and there are
reports that some of the dead are coming back as vile monstrosities!

- Somehow, the players will have to face the now mutated form of the Orc leader. His god has
warned him of this moment - of a triumphant final battle, his body covered in burns. His warriors,
scarred beyond recognition. He is ready to face this test, and prove his devotion!

**[Manticore Pike]**
1D12 piercing - +2 weapon
Heavy, Reach, Two Handed

**Loot table:**

WarChief_| Megged Blade
+2 Greatsword (208)

Two handed, heavy, cursed: Berserker (DM 155)

Wicked and evil, stained dark with countless victims blood

+1 Ore Chainmail
Surprisingly sophisticated and well fitting. The crest of itineveal is on the right breast.

6 elaborate signet rings bearing the mark of the royal guard

Third Eye _| Stone of good luck in bag full of otherwise generic stones

Burst Ogre | Broom of Flying
100g in swallowed diamonds tied to broom. And severed hand

Ores Potion of greater healing
125g

**Captain Floriana**
[stats]

HP: 60

AC: 18 (full plate)

STR +3 DEX +1 CON 42 INT +1 WIS +3 CHA +4
Skills: Athletics +4, Perception +2

Actions:
Multi-attack:

Captain's Blade:

Melee Weapon attack +7 to hit; 1D8 +5 / 1D10 +5 two handed

Bonus action: Protection: May impose disadvantage on one melee attack directed at her or her party
within 5ft of her once per round
Sacred Weapon: Can embue weapon with holy energy for CHA bonus to attack for 1 min

[oxified]
Immune to poison damage
Immune to poison, exhaustion condition

Melee hits inflict 1D6 additional poison damage.

‘Sheggohn Megged
Toxified Ore War Chief

Same as MM 246 Except as noted:
str+5

HP 115

Toxic Belch: Line effect 20ft long. On hit, DC15 con save or 3d6 poison damage and considered poisoned
for an hour (disadvantage on attack and skills) . Or half as much on save.

Ore Third Eye of Gruumsh (woke orc is woke)
HP: 65

stra

Spells: 1st level (4 slots) inflict wounds, Bane

2nd level (2 slots) hold person, dispel magic (20ft range)(vomit on effect to end)

Toxified Ogre
HP 70

Speed 20ft / bulging

Toxic Burst - if Killed by piercing, slashing, or fire damage, explodes in 20ft cloud of toxic fumes.
Creatures that enter must make save as per Toxic Belch effect.

Toxified Ore
AC 15

HP 20

stra

Toxic Grapple: if successfully grapple, can belch in targets face to inflict DC15 con save or 3d6 poison
damage and considered poisoned for an hour (disadvantage on attack and skills) . Or half as much on
save.

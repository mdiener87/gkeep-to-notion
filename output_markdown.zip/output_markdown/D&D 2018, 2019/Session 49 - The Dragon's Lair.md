# Session 49 - The Dragon's Lair

    **Created:** 2021-10-29 11:27:20  
    **Last Edited:** 2021-10-29 11:27:22  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Spice up the dungeon map with additional threats - not just the sand pitfall traps, but also arcane wards they must
destroy to progress further. The dragon is very paranoid about intruders and will have a variety of defenses to
overcome. Add lightening elementals and the more powerful disciples of flame as well.

#### ChatGPT Output:
Spice up the dungeon map with additional threats - not just the sand pitfall traps, but also arcane wards they must
destroy to progress further. The dragon is very paranoid about intruders and will have a variety of defenses to
overcome. Add lightening elementals and the more powerful disciples of flame as well.

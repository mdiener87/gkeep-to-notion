# Session 8 - Orc War Camps + Encounters

    **Created:** 2021-10-29 11:11:30  
    **Last Edited:** 2021-10-29 11:11:49  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Ore War Camp:
Led by a Shegghon Priestess and an accompinying warband of Orcs

‘The camp is to the north and east - they'll need to find it and slay the orcs to save the prisoners. The camp is nestled in
‘the mountains, overlooking Roads between three cities (Goltorah, Alluin, third city). There is a single road leading up to
‘the war camp, and it is patrolled by ores non-stop. Small orc raiding parties routinely depart the camp, and others return
with loot and pillage. Times are good, and ores are plentiful.

Approach: Narrow, winding road. The mountainous terrain might be traversed with climbing gear (DC 20) to sneak into
the fortress.
Main Entrance: Guarded by 3 orcs (one is an urog on alert). A wall and gate have been built over the mountain
pass road. If the players cause a ruckus more orcs will come to fight them.

Ifthe players can navigate the terrain, they can potentially climb into the valley unnoticed and begin the mission

stealth-like. If they attempt to find a way in, they will need to sneak or deal w/ a scouting party first.

Interior: The ore war camp is a series of numerous scattered huts and hovels. Its actually... not that impressive. The main
camp building is near the entrance. Two stories and hexagon shaped, it has the Priestess and her attendant Orcs. A
muddy field separates this orc camp from the stave pens, which are built into the cliffside. The Named NPCs and seven
other survivors are being held there, forced to work a long-exhausted mine.

‘Annearby barracks holds numerous orcs an an orog or two.

‘The gathering hall, the final structure, is a long open building. An ogre chef might decide players on the menu.
Encounters:

Etin -is kept on staff as a bodyguard for the camp. He likes to sleep near the prisoners where he can get a late-sniack if

they decide they are both hungry. Will come out if a big ruckus is made or they attempt to free the prisoners in front of
him.

res x many. Experiment with waves of ores and keeping the players in combat longer.
Ore Orogs.

Orc Eye of Grummash. Swap Augery for Hold Person.

#### ChatGPT Output:
# Ore War Camp:
Led by a Shegghon Priestess and an accompanying warband of Orcs

The camp is to the north and east - they'll need to find it and slay the orcs to save the prisoners. The camp is nestled in
the mountains, overlooking Roads between three cities (Goltorah, Alluin, third city). There is a single road leading up to
the war camp, and it is patrolled by orcs non-stop. Small orc raiding parties routinely depart the camp, and others return
with loot and pillage. Times are good, and orcs are plentiful.

## Approach:
- Narrow, winding road. The mountainous terrain might be traversed with climbing gear (DC 20) to sneak into
the fortress.

## Main Entrance:
- Guarded by 3 orcs (one is an urog on alert). A wall and gate have been built over the mountain
pass road. If the players cause a ruckus more orcs will come to fight them.

If the players can navigate the terrain, they can potentially climb into the valley unnoticed and begin the mission
stealth-like. If they attempt to find a way in, they will need to sneak or deal with a scouting party first.

## Interior:
The orc war camp is a series of numerous scattered huts and hovels. It's actually... not that impressive. The main
camp building is near the entrance. Two stories and hexagon shaped, it has the Priestess and her attendant Orcs. A
muddy field separates this orc camp from the slave pens, which are built into the cliffside. The Named NPCs and seven
other survivors are being held there, forced to work a long-exhausted mine.

A nearby barracks holds numerous orcs and an orog or two.

The gathering hall, the final structure, is a long open building. An ogre chef might decide players are on the menu.

## Encounters:

- Etin - is kept on staff as a bodyguard for the camp. He likes to sleep near the prisoners where he can get a late-snack if
they decide they are both hungry. Will come out if a big ruckus is made or they attempt to free the prisoners in front of
him.

- Orcs x many. Experiment with waves of orcs and keeping the players in combat longer.
- Orc Orogs.
- Orc Eye of Grummash. Swap Augury for Hold Person.

### Attachment 2

#### Raw OCR Output:
‘Sheggohn Priestess

‘STR +3 DEX #0 CON 42 INT 12 WIS 14 CHA 12
ACIS

Hit Points: 60

Speed: 30ft

Aggressive - bonus action may move towards
players

Spellcasting - The orc is a 3rd-level spellcaster.
Its spellcasting DC is wisdom (DC 12, +3 hit
with spell attacks)

Spells:

2nd level 2 slots: See invisibility, scorching ray
Ast level 4 slots: Shield, Burning Hands
Cantrip: Fire Bolt, light, mage hand

Actions: Spear: +4 to hit, hit: 1d6 +2

Orc Orogs - these are branded with symbols
of devotion to Illneveal, and Sheggohn's
bloodied war crest. Itis one sword raised high
in triumph, the other impaled onto an eff. tis,
said not to be an earned crest until splashed
with both orc and elf blood.

#### ChatGPT Output:
# Sheggohn Priestess

**STR** +3  
**DEX** #0  
**CON** 42  
**INT** 12  
**WIS** 14  
**CHA** 12  
**AC** 15  

**Hit Points:** 60  

**Speed:** 30ft  

**Aggressive** - bonus action may move towards players  

**Spellcasting** - The orc is a 3rd-level spellcaster.  
Its spellcasting ability is wisdom (DC 12, +3 hit with spell attacks)  

**Spells:**

- **2nd level (2 slots):** See invisibility, scorching ray  
- **1st level (4 slots):** Shield, Burning Hands  
- **Cantrip:** Fire Bolt, light, mage hand  

**Actions:** Spear: +4 to hit, hit: 1d6 +2  

**Orc Orogs** - these are branded with symbols of devotion to Illneveal, and Sheggohn's bloodied war crest. It is one sword raised high in triumph, the other impaled onto an effigy. It is said not to be an earned crest until splashed with both orc and elf blood.

# Session 24 - Access Groups Suck

    **Created:** 2021-10-29 11:19:58  
    **Last Edited:** 2021-10-29 11:20:05  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Yay No prep work!
Last time party found a hidden torture chamber / research facility in the cultist's base within Alluin. They recovered Results:

notes about the cult's work on controlling mosnters with shadow magic and grafted souls, as well as the cult's desire to Party on their way to face the dragon, having done research on the surrounding areas and purchased
retrieve AetherFlame to bring :mother: In from the other side. additional magical ttems and resources.

Annnd go Revealed Side Quests:

‘The Kings Family

At Risk Tieflings
Party retrieved: one injured person -> Cralgory - Runs an import / export shop in Alluin Library Stack Troubles with Trynacius

New items:
‘Wand of Lightning Bolts
Map of Area

#### ChatGPT Output:
Yay No prep work!
Last time party found a hidden torture chamber / research facility in the cultist's base within Alluin. They recovered Results:

- notes about the cult's work on controlling monsters with shadow magic and grafted souls, as well as the cult's desire to
- Party on their way to face the dragon, having done research on the surrounding areas and purchased
- retrieve AetherFlame to bring :mother: In from the other side.
- additional magical items and resources.

Annnd go Revealed Side Quests:

- The Kings Family
- At Risk Tieflings

Party retrieved: one injured person -> Cralgory - Runs an import / export shop in Alluin
Library Stack Troubles with Trynacius

New items:
- Wand of Lightning Bolts
- Map of Area

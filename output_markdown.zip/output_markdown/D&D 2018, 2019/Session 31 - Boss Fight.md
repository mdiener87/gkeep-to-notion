# Session 31 - Boss Fight

    **Created:** 2021-10-29 11:22:29  
    **Last Edited:** 2021-10-29 11:22:37  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Its finally time for the players to fight the boss and reach the end of this dungeon. They still have two fights to go:

‘The first, in an anti-magic field. The player's haven't fought in one af these before and it should give the snakes a bit of a
workout.

Boss fight is the Anathemancer. Should leave enough time for some post dungeon RP and set up where the rest of the
kingdom is at. Speaking of which - what are those pesky cultists up to anymore???

Aether Flame Location: Tiltathana

#### ChatGPT Output:
It's finally time for the players to fight the boss and reach the end of this dungeon. They still have two fights to go:

- The first, in an anti-magic field. The players haven't fought in one of these before and it should give the snakes a bit of a workout.

- Boss fight is the Anathemancer. Should leave enough time for some post-dungeon RP and set up where the rest of the kingdom is at. Speaking of which - what are those pesky cultists up to anymore???

Aether Flame Location: Tiltathana

# Session 33 - The search for the Aether Flame

    **Created:** 2021-10-29 11:22:52  
    **Last Edited:** 2021-10-29 11:22:57  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
After last session, Alex's Odesseyus was added to the group, and the PC party set off on a hunt for the Aether Flame.
Kaetus is now high enough level to summon giant eagles for the whole party to fly on, and so their mobility has gone
way way up. Kaladan is after that Aether Flame with a powerful need, and has taken to terrorizing the town of Enui. His
cultist followers are out in force in the surrounding hills and forests, searching for Tiltathana,

Tiltathana was the third legendary Elven Lord, and the Tiltathana Hills to the west of Enui still bear his name. These old
forests are considered highly dangerous and full of monsters. Expeditions by the kingdom through these lands have
often ended in disaster.

Somewhere deep in these hills lies the Tiltathana Manor. The Manor has never been hard to find (besides it being in the
middle of nowhere) but accessing it has always been a problem for would-be callers. The entire grounds is protected in a
‘magical barrier of force with no known way around.

Players can try to find the Tiltathana Charm which lets them through this barrier (the Lycantrhopes have one without
knowing what it does), or otherwise magic their way around. Or they can find the drow tunnels that take them into the
manor basement without breaching the barrier itself.

Using Drow magic and undergorund tunnels, the Drow were eventaully able to tunnel into the manor and raid it. They
have used the arcane forge at the heart of the manor to make impraved weapons and armor for themselves, making
these very dangerous and motivated Drow. A terrible Dryder is on assignment to find the Aether Flame, but despite her
search she is no closer to finding it.

‘The Aether Flame is in the ethereal plane - the players will need to find the portal to the other half of the dungeon. Once
they get o all of this.

Teinithra Session Results:

Forest Monsters:
Lycanthropes - Bring Back Graves

Leading a group of bandits, deserters, and disillusioned cultists in the Tiltathana hills. They believe

the hills are theirs and seek to form their own united wildling tribe.

Faerie Dragons
Insane Druid Cults
Awakened Trees
Basilisks.
Elementals

Drow:
Upgrade their armies with Phase Spiders,

Guardian Naga Rules this Forest, in opposition to the Yuan-Ti
Forest

‘With Bob Ross in the party, they skipped most of the prepared content by using the
robe of many useful items Window to just waltz into Tenitra's Manor. | had to.
generate the manor and its content on the spot... welp. The manor is guarded and
curated by Helmed Horrors. They are programed to obey the orders of the lords of the
manor and otherwise tend to the grounds. A number of elven mechanical butlers also
roam the halls and tend to guests.

‘The players burst into the master bedroom last night, and were forced to defeat 2 HH
personal body guards for the bedroom. What else exists in the manor...?

Cultist Wizard - See Drow Mage 129

Apply Shadow Typing to these as needed:
Oni

Perytons

Bone Naga

Quaggoth

Shadows

Wraiths

Trolls

Bulette

Basilisk

‘Shadow Demons
racks

#### ChatGPT Output:
After last session, Alex's Odesseyus was added to the group, and the PC party set off on a hunt for the Aether Flame.
Kaetus is now high enough level to summon giant eagles for the whole party to fly on, and so their mobility has gone
way way up. Kaladan is after that Aether Flame with a powerful need, and has taken to terrorizing the town of Enui. His
cultist followers are out in force in the surrounding hills and forests, searching for Tiltathana,

Tiltathana was the third legendary Elven Lord, and the Tiltathana Hills to the west of Enui still bear his name. These old
forests are considered highly dangerous and full of monsters. Expeditions by the kingdom through these lands have
often ended in disaster.

Somewhere deep in these hills lies the Tiltathana Manor. The Manor has never been hard to find (besides it being in the
middle of nowhere) but accessing it has always been a problem for would-be callers. The entire grounds is protected in a
magical barrier of force with no known way around.

Players can try to find the Tiltathana Charm which lets them through this barrier (the Lycanthropes have one without
knowing what it does), or otherwise magic their way around. Or they can find the drow tunnels that take them into the
manor basement without breaching the barrier itself.

Using Drow magic and underground tunnels, the Drow were eventually able to tunnel into the manor and raid it. They
have used the arcane forge at the heart of the manor to make improved weapons and armor for themselves, making
these very dangerous and motivated Drow. A terrible Dryder is on assignment to find the Aether Flame, but despite her
search she is no closer to finding it.

The Aether Flame is in the ethereal plane - the players will need to find the portal to the other half of the dungeon. Once
they get to all of this.

### Teinithra Session Results:

#### Forest Monsters:
- Lycanthropes - Bring Back Graves
  - Leading a group of bandits, deserters, and disillusioned cultists in the Tiltathana hills. They believe
    the hills are theirs and seek to form their own united wildling tribe.
- Faerie Dragons
- Insane Druid Cults
- Awakened Trees
- Basilisks
- Elementals

#### Drow:
- Upgrade their armies with Phase Spiders,
- Guardian Naga Rules this Forest, in opposition to the Yuan-Ti Forest

With Bob Ross in the party, they skipped most of the prepared content by using the
robe of many useful items Window to just waltz into Tenitra's Manor. I had to
generate the manor and its content on the spot... welp. The manor is guarded and
curated by Helmed Horrors. They are programmed to obey the orders of the lords of the
manor and otherwise tend to the grounds. A number of elven mechanical butlers also
roam the halls and tend to guests.

The players burst into the master bedroom last night, and were forced to defeat 2 HH
personal bodyguards for the bedroom. What else exists in the manor...?

#### Cultist Wizard - See Drow Mage 129

Apply Shadow Typing to these as needed:
- Oni
- Perytons
- Bone Naga
- Quaggoth
- Shadows
- Wraiths
- Trolls
- Bulette
- Basilisk
- Shadow Demons

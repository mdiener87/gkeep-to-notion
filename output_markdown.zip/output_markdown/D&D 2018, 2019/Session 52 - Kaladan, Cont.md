# Session 52 - Kaladan, Cont

    **Created:** 2021-10-29 11:28:18  
    **Last Edited:** 2021-10-29 11:28:22  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
See session 51 for setup notes.

Result:

Ayden rolled a nat 1 on the aether flame, killing himself and heavily damaging the crystal.

Kaeus and Dorc attacked the crystal and destroyed it, setting off a chain reaction of energy that destroyed the portals
and set off an immense explosion.

This explosion killed Odesseyus, and would have killed Kaetus if it were not for his Earth Elemental Form. He took 241,
damage total.

The players found a total of:
12,000 gold on the floor
110,000 gold worth of diamonds and gems

Belt of Fire Giant Strength
Manual of Bodily Health
loune Stone of Absorption
Ring of Djini summoning
Kaladan's Blood Crystal

#### ChatGPT Output:
See session 51 for setup notes.

Result:

- Ayden rolled a nat 1 on the aether flame, killing himself and heavily damaging the crystal.
- Kaeus and Dorc attacked the crystal and destroyed it, setting off a chain reaction of energy that destroyed the portals
  and set off an immense explosion.
- This explosion killed Odesseyus, and would have killed Kaetus if it were not for his Earth Elemental Form. He took 241,
  damage total.

The players found a total of:
- 12,000 gold on the floor
- 110,000 gold worth of diamonds and gems

- Belt of Fire Giant Strength
- Manual of Bodily Health
- Ioun Stone of Absorption
- Ring of Djinn Summoning
- Kaladan's Blood Crystal

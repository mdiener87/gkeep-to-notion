# Session 42 - One Year of D&D

    **Created:** 2021-10-29 11:25:52  
    **Last Edited:** 2021-10-29 11:26:02  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
This session makes an official year of running the campaign. I can't really believe how fast its gone. Let's start this session
with a cake to celebrate, and everyone taking a turn to discuss their favorite moments} from the game to date. At 42
sessions out of 52 weeks, this represents “80% of all weeks hit. That's a very high number for an after-work D&D ever
Everyone should feel proud of that.

Coming into the actual game, the players now have an Elven manor that has lost its protective shield, along with all the
constructs in the place losing power. They might be able to repair the control interface (DC25 now), but it's going to be
hard. Any further failures will blow the thing up (6d10 damage).

‘As for combat and adventure, we will see where they start to go. The onyx mountain beckons, but its going to take them
some real effort to get to it. Vrocks and Shadow demons now openly circle the desert, along with that perpetual
sandstorm. Still, that is likely where the plot is headed before long.

In the meantime, the shadow cultists are besieging El Enna and the Capital, if the players make it over there that can be
the source of some combat.

Essafah is going to make an appearance at sometime, but I haven't made stats for him yet so whatever

Shield guardian
Helmed horror
Stone Golem

Pentradome x4

Result:

Party spent the session exploring the hidden basement under Tiniethra's Manor. Inside, they found a
chamber guarded by constructs (pentradames) which led to an immense door. Within, lay a large mana
crystal. An elemental of each type surrounded it, caught in a mesmerizing dance of mana and light.

‘The crystal itself was guarded by a stone golem and a shield guardian. It was a tougher fight to defeat
both but with victory comes access to the crystal.. And the elementals surrounding it.

#### ChatGPT Output:
This session makes an official year of running the campaign. I can't really believe how fast it's gone. Let's start this session
with a cake to celebrate, and everyone taking a turn to discuss their favorite moments from the game to date. At 42
sessions out of 52 weeks, this represents "80% of all weeks hit. That's a very high number for an after-work D&D ever.
Everyone should feel proud of that.

Coming into the actual game, the players now have an Elven manor that has lost its protective shield, along with all the
constructs in the place losing power. They might be able to repair the control interface (DC25 now), but it's going to be
hard. Any further failures will blow the thing up (6d10 damage).

As for combat and adventure, we will see where they start to go. The onyx mountain beckons, but it's going to take them
some real effort to get to it. Vrocks and Shadow demons now openly circle the desert, along with that perpetual
sandstorm. Still, that is likely where the plot is headed before long.

In the meantime, the shadow cultists are besieging El Enna and the Capital, if the players make it over there that can be
the source of some combat.

Essafah is going to make an appearance at some time, but I haven't made stats for him yet so whatever

- Shield guardian
- Helmed horror
- Stone Golem

- Pentradome x4

Result:

Party spent the session exploring the hidden basement under Tiniethra's Manor. Inside, they found a
chamber guarded by constructs (pentradomes) which led to an immense door. Within, lay a large mana
crystal. An elemental of each type surrounded it, caught in a mesmerizing dance of mana and light.

The crystal itself was guarded by a stone golem and a shield guardian. It was a tougher fight to defeat
both but with victory comes access to the crystal.. And the elementals surrounding it.

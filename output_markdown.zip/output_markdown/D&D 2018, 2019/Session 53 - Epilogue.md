# Sesion 53 - Epilogue

    **Created:** 2021-10-29 11:28:28  
    **Last Edited:** 2021-10-29 11:28:35  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Lots of character re-rolls today. Going to spend most of it doing new character sheets + intros to the old members.
‘Standing of various chrachters:

King Maryn + Advisors

Civilian populace stuck in T.M.

Ruport the Unchained

Elyriss got married!
Offered a permeant position as the King's Visir, with Floriana taking over as Hand of the Realm.

#### ChatGPT Output:
Lots of character re-rolls today. Going to spend most of it doing new character sheets + intros to the old members.
‘Standing of various characters:

- King Maryn + Advisors
- Civilian populace stuck in T.M.
- Ruport the Unchained
- Elyriss got married!

Offered a permanent position as the King's Visir, with Floriana taking over as Hand of the Realm.

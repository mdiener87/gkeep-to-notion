# Session 22 - Plan of Action

    **Created:** 2021-10-29 11:19:25  
    **Last Edited:** 2021-10-29 11:19:32  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Kaladan will issue following order:

It is time to judge the people of Alluin. They have failed to see the truth of my eminence before them. So be it. All will
turn to shadow. All will bow before the majesty of Kaladan Orexijandilin! Tonight, you shall return to them their own
creation - a deadly chemical that cleanses all! Ready the cannon, and let us judge this kingdom of Dawn!

Players need insight roll 20 to know that the message might not really be his plan.

Cultist Lt. Has moved the real base of operations into an invisible bunker underneath one of the
garrison's rooms. The trap tower is cleared out except for the kegs of explosives. The LT is hiding atop
another structure watching and plotting the action.

IF PCs go for Kaladin in his lair, they will need to navigate to it through the Desert. Kaladan will harass
‘them at night as they approach, and there are sandwurms that lurk in the valley.

Kaladan's lair atop the mountain has cultists defending it and is generally well guarded. Kaladan is
raising a new generation of warlock who will not allow daylight spells to wreck havok again, and a
shadow sentinel with the sentinel feat.

#### ChatGPT Output:
Kaladan will issue the following order:

It is time to judge the people of Alluin. They have failed to see the truth of my eminence before them. So be it. All will
turn to shadow. All will bow before the majesty of Kaladan Orexijandilin! Tonight, you shall return to them their own
creation - a deadly chemical that cleanses all! Ready the cannon, and let us judge this kingdom of Dawn!

Players need an insight roll of 20 to know that the message might not really be his plan.

Cultist Lt. has moved the real base of operations into an invisible bunker underneath one of the
garrison's rooms. The trap tower is cleared out except for the kegs of explosives. The LT is hiding atop
another structure watching and plotting the action.

IF PCs go for Kaladin in his lair, they will need to navigate to it through the Desert. Kaladan will harass
them at night as they approach, and there are sandwurms that lurk in the valley.

Kaladan's lair atop the mountain has cultists defending it and is generally well guarded. Kaladan is
raising a new generation of warlock who will not allow daylight spells to wreak havoc again, and a
shadow sentinel with the sentinel feat.

# Session 41 - 3D Printed Danger

    **Created:** 2021-10-29 11:25:25  
    **Last Edited:** 2021-10-29 11:25:32  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
I've got a 3D printer! It's so amazing, Let's see if we can't throw some of these new minis at the players...

Last session, a pitched battle broke out and the dragonborn / dragon cultists were invading the Manor grounds. A
window is still open allowing them to come in further, and now Kaladan is aware that the Aether Flame exists and that,
the players have it (he has Aether sense). Piling in through the window one by one didn't really work well last time, so
perhaps it's time to bring in some backup from the EPoF to get the force field down,

Essafah is also very very mad, Like raving mad. He wants revenge on the Order, and he might just remember how to get
back through his own planar mirror.

Iwant to keep the pressure up on the players, but they need a brief reprieve to get back into shape as well or the next
fight will be a slaughter. The dragons aren't going to just file in one at a time, they want to zerg the manor in a proper
offensive. To do so, they'll need to find a way to break the wall of force that protects the establishment.

To that end, the dragons will ikely call on a new ally in their fight -a certain Agar is seeking revenge on the players for
his humiliation before the Grand Sultan, If he can retrieve the Aether Flame and kill the players, he will have redeemed
his name and honored a pact with the shadow born dragon. Walls of force are normally immune to dispel magic, but his
blade of molten magic can repeatedly strike through and destroy such obstacles.

Player Injuries
Elryis:
Severe Lacerations: -1 Con -1str

Oddesseyus:
Puncture Wounds: -1 Con -1Dex

Result:

Bob Ross was able to command the force field model in the basement of the manor, making an
incredible roll that allowed him to not only repair the force dome, but use it to cast disintegration beams,
against all shadow dragons near the dome. This gravely injured kaladan, as well as vaporizing all
dragonborn in his cultist armies.

‘Agar was then sent in on the following morning to break the dome as well as kill the party. Ayden,
studying the dome, tried to command it to do a similar blast to Agar. This succeeded in blasting him
(which Agar reflex saved for half damage), but the field was destroyed in the process.

An epic fight broke out with Agar, who in the end fell to the order. He dropped his legendary blade of
Molten Magic.

#### ChatGPT Output:
I've got a 3D printer! It's so amazing, Let's see if we can't throw some of these new minis at the players...

Last session, a pitched battle broke out and the dragonborn / dragon cultists were invading the Manor grounds. A
window is still open allowing them to come in further, and now Kaladan is aware that the Aether Flame exists and that,
the players have it (he has Aether sense). Piling in through the window one by one didn't really work well last time, so
perhaps it's time to bring in some backup from the EPoF to get the force field down,

Essafah is also very very mad, Like raving mad. He wants revenge on the Order, and he might just remember how to get
back through his own planar mirror.

I want to keep the pressure up on the players, but they need a brief reprieve to get back into shape as well or the next
fight will be a slaughter. The dragons aren't going to just file in one at a time, they want to zerg the manor in a proper
offensive. To do so, they'll need to find a way to break the wall of force that protects the establishment.

To that end, the dragons will likely call on a new ally in their fight -a certain Agar is seeking revenge on the players for
his humiliation before the Grand Sultan, If he can retrieve the Aether Flame and kill the players, he will have redeemed
his name and honored a pact with the shadow born dragon. Walls of force are normally immune to dispel magic, but his
blade of molten magic can repeatedly strike through and destroy such obstacles.

**Player Injuries**
- **Elryis:**
  - Severe Lacerations: -1 Con -1 str
- **Oddesseyus:**
  - Puncture Wounds: -1 Con -1 Dex

**Result:**

Bob Ross was able to command the force field model in the basement of the manor, making an
incredible roll that allowed him to not only repair the force dome, but use it to cast disintegration beams,
against all shadow dragons near the dome. This gravely injured Kaladan, as well as vaporizing all
dragonborn in his cultist armies.

Agar was then sent in on the following morning to break the dome as well as kill the party. Ayden,
studying the dome, tried to command it to do a similar blast to Agar. This succeeded in blasting him
(which Agar reflex saved for half damage), but the field was destroyed in the process.

An epic fight broke out with Agar, who in the end fell to the order. He dropped his legendary blade of
Molten Magic.

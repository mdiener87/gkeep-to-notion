# Lair of Forgotten Sins

    **Created:** 2021-10-29 11:21:49  
    **Last Edited:** 2021-10-29 11:21:53  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Set in the Weeping Forest, the Lair of Forgotten Sins is a lair of Yuan-ti worshipers. The lair is presently sealed off, with
the dungeon citizens in a state of hibernation. Opening the forgotten seals will surely lead to problerns...

City ruins: basically wiped out, overrun with forest. Players can discover an entrance than leads them
underground, leading to a chamber with a cyclops in it. Cyclops is dwelling in a large room with a sealed
entrance. Opening the entrance leads into the lair.

Lair first floor: Square series of rooms and halls. They can take any path (left / right) through the arc, and
the exit is on the other side

Primary Monsters: Yuan-ti
Boss: Spirit Naga / Snake Demon

Secondary:
Rust Monsters
Trolls

‘Shambling Mounds
Ropers

cyclops

#### ChatGPT Output:
Set in the Weeping Forest, the Lair of Forgotten Sins is a lair of Yuan-ti worshipers. The lair is presently sealed off, with
the dungeon citizens in a state of hibernation. Opening the forgotten seals will surely lead to problems...

City ruins: basically wiped out, overrun with forest. Players can discover an entrance that leads them
underground, leading to a chamber with a cyclops in it. Cyclops is dwelling in a large room with a sealed
entrance. Opening the entrance leads into the lair.

Lair first floor: Square series of rooms and halls. They can take any path (left / right) through the arc, and
the exit is on the other side

Primary Monsters: Yuan-ti
Boss: Spirit Naga / Snake Demon

Secondary:
- Rust Monsters
- Trolls

- Shambling Mounds
- Ropers

- cyclops

# Session 1

    **Created:** 2021-10-29 11:01:09  
    **Last Edited:** 2021-10-29 11:01:35  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Gameplay Notes:
Dungeon: Ruined Castle / Tombs

Road of Hadari

Former Elven keep, terrorizing villiage in twisted attempt to warn the people about the demonic-worshiping cult that is
taking over the kingdom. The cult seeks demonic power to save the kingdom from the encroaching orc hoards to the
East.

Players enter the kingdom of Dawn in search of adventure. They come from different backgrounds, but a shared road
and sense of destiny have brought this band together. They aren't yet aware of the larger political problems or wars
facing the struggling kingdom. Players can leave it to their own why they were on the road at this time.

Kingdom has a mix of all races and while it has never been a major world player, has generally been a kind and just place
to live.

World is relatively low magic; most people don't have access, knowledge, or wealth for magick.

Players will quickly enter the small town of : Goltorah
DC10 to recognize its an Elven family name, but currently a human settlement
Population: “500 (small town)

‘Some potions available for sale if players can find the apathecary

Inn is run by a halfling named Lerry. Jovial normally, he is worried about business drying up from the war in the
East and the local hauntings of the villiage

Ghost 147. Players won't really fight it, will fuck off after a round or two.
Dissa (apothethecary)
Tren (mayor)
Exploration -

Players will search nearby forest for the source of the hauntings/keep. They might learn this area was Elven long ago.
While exploring, roll for random encounters from forest table (wolves and Drow most likely opponents).

May find:
Friendly holy cleric (can be talked into giving a health potion or selling it)
Bandits
Abandoned camp with small treasure

#### ChatGPT Output:
### Gameplay Notes:
**Dungeon:** Ruined Castle / Tombs

**Road of Hadari**

Former Elven keep, terrorizing village in twisted attempt to warn the people about the demonic-worshiping cult that is
taking over the kingdom. The cult seeks demonic power to save the kingdom from the encroaching orc hoards to the
East.

Players enter the kingdom of Dawn in search of adventure. They come from different backgrounds, but a shared road
and sense of destiny have brought this band together. They aren't yet aware of the larger political problems or wars
facing the struggling kingdom. Players can leave it to their own why they were on the road at this time.

Kingdom has a mix of all races and while it has never been a major world player, has generally been a kind and just place
to live.

World is relatively low magic; most people don't have access, knowledge, or wealth for magic.

Players will quickly enter the small town of: Goltorah
- DC10 to recognize it's an Elven family name, but currently a human settlement
- Population: “500 (small town)

‘Some potions available for sale if players can find the apothecary

Inn is run by a halfling named Lerry. Jovial normally, he is worried about business drying up from the war in the
East and the local hauntings of the village

- Ghost 147. Players won't really fight it, will fuck off after a round or two.
- Dissa (apothecary)
- Tren (mayor)

**Exploration -**

Players will search nearby forest for the source of the hauntings/keep. They might learn this area was Elven long ago.
While exploring, roll for random encounters from forest table (wolves and Drow most likely opponents).

May find:
- Friendly holy cleric (can be talked into giving a health potion or selling it)
- Bandits
- Abandoned camp with small treasure

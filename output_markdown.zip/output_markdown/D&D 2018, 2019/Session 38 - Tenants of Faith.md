# Session 38 - Tenants of Faith

    **Created:** 2021-10-29 11:24:05  
    **Last Edited:** 2021-10-29 11:24:12  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, its time to start ramping the pressure up. The PCs have been living cushy in this elemental
plane of fire, buying shit and converting citizens. This plane is largely evil, and it's about time to remind them of this fact.

‘On Going Events:

Material Realm:
While time moves very slowly on the material plane, days also last very long here on the fire plane. Kaladan has
continued to attack the city of Ennui, and his cultists grow in influence and power throughout the realm. Even without
the Aether Flame, his wizard researchers are making progress on widening the portal between the shadow realm and
the material.

Elemental Plane of Fire:
‘The Grand Suttan is on a Mishakal hunt and is furious at the introduction of religions into the Elemental Chaos.
Elementals are pure creatures, and their belief defines their reality. Mortal faith is a conduit to the Gods and Avatars of
the Outer Planes of existence, channeling power across the Astral plane. With elementals diverting from the Grand
Sultan (of their plane} to Mishakal (of the Outer Plane - Elysium), this is causing an instability in balance of power
between bath the inner elemental planes, and the outer elemental planes.

Such disturbances are hardly uncommon, but they do tend to be quite dramatic!

‘This disturbance is allowing for devils to infiltrate the plane of water, and demonic shadow to begin corrupting the plane
of air. Meanwhile, a civil war is basically building on the plane of fire.

Shadowfell:
Savaran Orexijanditin has not waited idle. Her immense power cannot be contained to merely the Shadow Plane. Her
patience with Kaladan has its limits - her lust for power and dominion does nat. She has dispatched another of her
children to the far planes to deal with the Order of Sun and Moon, and finally find a way to release her from her
shadowy prison on this Plane.

Introducing: Dragonborn ShadowCultists
‘These guys are tougher and more powerful than regular cultists. They are all corrupted dragonborn, humanoid
children of Savaran.

Elemental Plane of Wate
>Devils are corrupting this plane in response to Mishakal's purifying of the fire plane. They are also sending a
representative from the 9 hells to the elemental plane of fire. And generally are pissed about losing access to the
Blackened Foregemaster, the best of the Golden Ring and producer of legendary armors.

Elemental Plane of Air
>Essafah is pissed that the PCs introduced the concept of mortal faith to the elemental planes. This dangerously corrupts
the balance between the inner and outer planes of existance,

Plot:
PCs will need to deal with the salamander faith problem somehow. Meanwhile, their problems seem to
be multiplying - not all salamanders that kill themselves are returning as purified fire elementals! Some

are returning as Ash Elementals - corrupted, fallen forms.

Ifthe PCs leave the palace for a long time, representatives from other faiths are going to start popping
up and trying to convince the newly religious elementals about other walks in life.

+1 Leather Demon Armor - need to roll stats

Result - The PCs convinced the Grand Sultan about the power of religion, but the light and fluffy religion
of Mishakal wasn't to his liking. So he went for outside consulting, and found Rezena, first daughter of
Shadow. The Shadow Dragons have not been idle, and while they can't yet get into the material realm,
‘they are continuing to expand their corruption towards other planes of existence.

‘The Grand Sultan's Illuminares tried to assassinate the agent of Mishakal but failed. However, the
assassin retreated before he could be dealt with.

‘The Grand Sultan is slowly learning how to convert Efreeti into ShadowFire Elementals,

‘The PCs took one look at the situation and decided to nope out of there. They asked the Salamanders
where that mirror was and had them taken to it.

Elyriss

#### ChatGPT Output:
Coming into this session, it's time to start ramping the pressure up. The PCs have been living cushy in this elemental
plane of fire, buying shit and converting citizens. This plane is largely evil, and it's about time to remind them of this fact.

**On Going Events:**

**Material Realm:**
While time moves very slowly on the material plane, days also last very long here on the fire plane. Kaladan has
continued to attack the city of Ennui, and his cultists grow in influence and power throughout the realm. Even without
the Aether Flame, his wizard researchers are making progress on widening the portal between the shadow realm and
the material.

**Elemental Plane of Fire:**
The Grand Suttan is on a Mishakal hunt and is furious at the introduction of religions into the Elemental Chaos.
Elementals are pure creatures, and their belief defines their reality. Mortal faith is a conduit to the Gods and Avatars of
the Outer Planes of existence, channeling power across the Astral plane. With elementals diverting from the Grand
Sultan (of their plane) to Mishakal (of the Outer Plane - Elysium), this is causing an instability in balance of power
between both the inner elemental planes, and the outer elemental planes.

Such disturbances are hardly uncommon, but they do tend to be quite dramatic!

This disturbance is allowing for devils to infiltrate the plane of water, and demonic shadow to begin corrupting the plane
of air. Meanwhile, a civil war is basically building on the plane of fire.

**Shadowfell:**
Savaran Orexijanditin has not waited idle. Her immense power cannot be contained to merely the Shadow Plane. Her
patience with Kaladan has its limits - her lust for power and dominion does not. She has dispatched another of her
children to the far planes to deal with the Order of Sun and Moon, and finally find a way to release her from her
shadowy prison on this Plane.

**Introducing: Dragonborn ShadowCultists**
These guys are tougher and more powerful than regular cultists. They are all corrupted dragonborn, humanoid
children of Savaran.

**Elemental Plane of Water**
- Devils are corrupting this plane in response to Mishakal's purifying of the fire plane. They are also sending a
representative from the 9 hells to the elemental plane of fire. And generally are pissed about losing access to the
Blackened Foregemaster, the best of the Golden Ring and producer of legendary armors.

**Elemental Plane of Air**
- Essafah is pissed that the PCs introduced the concept of mortal faith to the elemental planes. This dangerously corrupts
the balance between the inner and outer planes of existence.

**Plot:**
PCs will need to deal with the salamander faith problem somehow. Meanwhile, their problems seem to
be multiplying - not all salamanders that kill themselves are returning as purified fire elementals! Some
are returning as Ash Elementals - corrupted, fallen forms.

If the PCs leave the palace for a long time, representatives from other faiths are going to start popping
up and trying to convince the newly religious elementals about other walks in life.

+1 Leather Demon Armor - need to roll stats

**Result** - The PCs convinced the Grand Sultan about the power of religion, but the light and fluffy religion
of Mishakal wasn't to his liking. So he went for outside consulting, and found Rezena, first daughter of
Shadow. The Shadow Dragons have not been idle, and while they can't yet get into the material realm,
they are continuing to expand their corruption towards other planes of existence.

The Grand Sultan's Illuminares tried to assassinate the agent of Mishakal but failed. However, the
assassin retreated before he could be dealt with.

The Grand Sultan is slowly learning how to convert Efreeti into ShadowFire Elementals.

The PCs took one look at the situation and decided to nope out of there. They asked the Salamanders
where that mirror was and had them taken to it.

Elyriss

# Session 13 - The Saviors of Borrend...?

    **Created:** 2021-10-29 11:15:27  
    **Last Edited:** 2021-10-29 11:15:44  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Notes:
PC Group has killed the Gorgon at the heard of the Borrend Cattacboms. This vile creature was once the false god of the
Stonefall Druid clan. This secretive clan of Dwarves and Gnomes once was the secret of Borrend's success - the immense
25 pipes that power all manner of marvel throughout Borrend. The druidic magic that once wrought this marvel was
corrupted, turned evil by greed and sorrow. The players have destroyed the Gorgon, and restored the ancient Relic of
Stone Circles to its rightful place.

‘There's a snag. There always is.

‘The players have spent over two days in the Crypts alone. They never really sealed off this back entrance, nor did they
check where the stairs upstairs went. They just dived greedily down into the dungeon. Time for their rush into action to
have a consequence.

‘The Ores didn't give up with their first assault. Their Ores, after all. Assaulting this is kind of what they do. So the players
are going to enter into the middle of the city getting sacked from this back entrance, Open with combat and dice rolling
action, and then leave enough time afterwords for everyone to enjoy being heroes - or nat? Within the City of Borrend.
This should give a nice opportunity to wrap up various storylines in preparation of Thanksgiving.

#### ChatGPT Output:
### Notes:
PC Group has killed the Gorgon at the heart of the Borrend Catacombs. This vile creature was once the false god of the
Stonefall Druid clan. This secretive clan of Dwarves and Gnomes once was the secret of Borrend's success - the immense
25 pipes that power all manner of marvel throughout Borrend. The druidic magic that once wrought this marvel was
corrupted, turned evil by greed and sorrow. The players have destroyed the Gorgon, and restored the ancient Relic of
Stone Circles to its rightful place.

- 'There's a snag. There always is.

- 'The players have spent over two days in the Crypts alone. They never really sealed off this back entrance, nor did they
check where the stairs upstairs went. They just dived greedily down into the dungeon. Time for their rush into action to
have a consequence.

- 'The Orcs didn't give up with their first assault. They're Orcs, after all. Assaulting this is kind of what they do. So the players
are going to enter into the middle of the city getting sacked from this back entrance, Open with combat and dice rolling
action, and then leave enough time afterward for everyone to enjoy being heroes - or not? Within the City of Borrend.
This should give a nice opportunity to wrap up various storylines in preparation of Thanksgiving.'

### Attachment 2

#### Raw OCR Output:
Encounter Notes:

Back to Orcs - they are a classic staple the players know and can beat up quickly. New twist: suicide
bombing orcs being used to blow open reinforced doors.

‘Opening: Chants of For the Horde! The players have clearly forgotten about something. Orcs are
streaming through the tunnel up into the city!

#### ChatGPT Output:
Encounter Notes:

- Back to Orcs - they are a classic staple the players know and can beat up quickly. New twist: suicide bombing orcs being used to blow open reinforced doors.

- Opening: Chants of For the Horde! The players have clearly forgotten about something. Orcs are streaming through the tunnel up into the city!

### Attachment 3

#### Raw OCR Output:
Room: Crypt room, four orcs are busy amusing themselves looting the crypts and the mangled remains
of the defenders.

‘Tunnels: Orcs can stream up behind the players and engage them at any moment unless they can seal
the way behind them,

Roomz: Ransacked city space. An Orc Eye, elite orc, and two regular Orcs are looting the main space. An
additional regular orc is single-mindindly trying to get into a room to kill the inhabitants. 3 Turns to
break in, one turn to kill.

Room 3: Extravagant hallway with a lava center piece. A Troll is leading the orcs in attempting to smash
the large gnomish door leading into the rest of the city. Meanwhile, a Halfling is holding precariously
onto a statue that is rapidly falling apart. The troll is not stupid and has no intention of becoming the
72000.

#### ChatGPT Output:
**Room:** Crypt room, four orcs are busy amusing themselves looting the crypts and the mangled remains
of the defenders.

**Tunnels:** Orcs can stream up behind the players and engage them at any moment unless they can seal the way behind them.

**Room 2:** Ransacked city space. An Orc Eye, elite orc, and two regular Orcs are looting the main space. An additional regular orc is single-mindedly trying to get into a room to kill the inhabitants. 3 Turns to break in, one turn to kill.

**Room 3:** Extravagant hallway with a lava centerpiece. A Troll is leading the orcs in attempting to smash the large gnomish door leading into the rest of the city. Meanwhile, a Halfling is holding precariously onto a statue that is rapidly falling apart. The troll is not stupid and has no intention of becoming the 72000.

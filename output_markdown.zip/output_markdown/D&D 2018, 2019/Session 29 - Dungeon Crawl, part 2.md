# Session 29 - Dungeon Crawl, part 2

    **Created:** 2021-10-29 11:22:02  
    **Last Edited:** 2021-10-29 11:22:12  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Greatsword + 1 - Dragonstaying
Beautiful and ornamental; the blade is etched with a viper striking a dragon

So we lost a week to snow. Super lame. Coming into this week, | don't want a bunch of talking or drama - | want a proper
dungeon crawl and to put some hurt on some cocky players.

Refer to dungeon notebook + folder for content. Can add more rooms if necessary but it should be enough.

If they start taking too long on rests, throw wandering snakes at them.

Result:
Party cleared the first floor and found:
Greatsword of Dragonslaying + 1
Viper Key - Unlocks any lock and disables any trap below DC22. One time use

#### ChatGPT Output:
**Greatsword + 1 - Dragonstaying**  
Beautiful and ornamental; the blade is etched with a viper striking a dragon

So we lost a week to snow. Super lame. Coming into this week, I don't want a bunch of talking or drama - I want a proper  
dungeon crawl and to put some hurt on some cocky players.

Refer to dungeon notebook + folder for content. Can add more rooms if necessary but it should be enough.

If they start taking too long on rests, throw wandering snakes at them.

**Result:**  
Party cleared the first floor and found:  
- **Greatsword of Dragonslaying + 1**  
- **Viper Key** - Unlocks any lock and disables any trap below DC22. One time use

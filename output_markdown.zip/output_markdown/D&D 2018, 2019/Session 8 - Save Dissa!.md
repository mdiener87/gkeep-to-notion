# Session 8 - Save Dissa!

    **Created:** 2021-10-29 11:11:06  
    **Last Edited:** 2021-10-29 11:11:14  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Dissa, Lerry, and Tren {the mayor) and seven other villagers have been taken captive by an orc raiding party! Their fates,
are uncertain, and the party is going to be eager to kick butt, roll dice, and try to save their known NPCs.

Events:
‘The world has shifted ~18months since the players exited the Valzumin Stronghold. (In the fight, the attempt to grab the
orb had this effect on the dimension gap). Orcs have laid siege to much of Dawn, but the Kingdom is not out of the fight
yet. The Kingdom's Royal Guard, led by Captain [name roll] have been valiantly helping to turn the tide. till, chaos and
sorrow now rule these lands.

‘The Orc Leader - Sheggohn Megged -is a devout follower of llIneveal (http://forgottenrealms.wikia.com/wikiflIneval), a
lesser god in the Orc pantheon. IlIneveal is the god of cunning brutality, and this war is a mighty testament to|
‘Sheggohn's devotion to his cause.

Note - Sheggohn has trained devout priestesses to oversee his warcamps. Orc priestess leading warbands is rare - they
are seen as less likely to betray their leader, and therefore weaker than a male orc warleader would be. Sheggohn's
Priestess are therefore extra cunning, and extra ruthless.

#### ChatGPT Output:
Dissa, Lerry, and Tren (the mayor) and seven other villagers have been taken captive by an orc raiding party! Their fates,
are uncertain, and the party is going to be eager to kick butt, roll dice, and try to save their known NPCs.

Events:
- The world has shifted ~18 months since the players exited the Valzumin Stronghold. (In the fight, the attempt to grab the
orb had this effect on the dimension gap). Orcs have laid siege to much of Dawn, but the Kingdom is not out of the fight
yet. The Kingdom's Royal Guard, led by Captain [name roll] have been valiantly helping to turn the tide. Still, chaos and
sorrow now rule these lands.

- The Orc Leader - Sheggohn Megged -is a devout follower of IIneveal ([IIneveal](http://forgottenrealms.wikia.com/wiki/IIneval)), a
lesser god in the Orc pantheon. IIneveal is the god of cunning brutality, and this war is a mighty testament to
Sheggohn's devotion to his cause.

Note - Sheggohn has trained devout priestesses to oversee his warcamps. Orc priestess leading warbands is rare - they
are seen as less likely to betray their leader, and therefore weaker than a male orc warleader would be. Sheggohn's
Priestesses are therefore extra cunning, and extra ruthless.

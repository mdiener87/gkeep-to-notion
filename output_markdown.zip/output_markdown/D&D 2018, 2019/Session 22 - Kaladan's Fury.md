# Session 22 - Kaladan's Fury

    **Created:** 2021-10-29 11:19:01  
    **Last Edited:** 2021-10-29 11:19:08  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Session 21 didn't really go as planned. Kaladan totally fucked up his assassination of the king. While he did sneak into the
castle undetected, he completely botched his various attack rolls on the target. The King was killed by the dragon's
shadow breath, but the quick actions of Elyris brought him back to life while his soul was still on the material plane
(shadow breath effect).

After the party rallied from their initial fear of the dragon, the tables in the encounter quickly turned. Dorc's Sentinel
feat became VIP when it prevented Kaladan from flying away from the encounter two turns in a row. Kaladan failed STR
checks to fling Dorc out of range. If Dorc's third Sentinel attack had hit, Kaladan would surely have perished in the
following round of combat.

Kaladan was barely able to get out of the keep and start to fly to safety. The dangerous spell casters were still just a few
squares out of range. Dorc's final boftcaster bolt scored a crit - and brought Kaladan down to Shp. Kaladan fell from the
sky, and crashed into a shopping center in the city.

‘A desperate chase broke out immediately to bag the dragon. Dorc jumped on his magic broom, and the Druid shape
shifted into bird to carry down the other two. Elryis- reviving the king, was delayed. (Aasthraa not present). The party, in
their greed to bag the dragon, split up. This nearly cost Kaetus his life, when he became skewered by cultists on the
either end of a doorway he tried to barge through!

In the end, Kaladan was able to heal over three rounds, regain flight capability, and escape before the party could reach
him. tt was a close, pitched battle - the most epic of the campaign so far!

So lets look at the consequences of this fight:

Kaladan is pissed. And for the first time, genuinely scared. These material plane assholes are no joke. fnot dealt with,
‘they might just... kill him. He nearly died that night, and the king - he lived. it was a tragic flip of Kaladan's plans to
demonstrate the shadow cult's power. Plus, one of his cultist minions was captured by the PCs during the fight! He
sacrificed himself to save Kaladan, As a pawn should,

Still, the situation must be dealt with - and promptly.

PC loot / etc:
Kings Favor to Elyriss for saving his life during the Cultist's Ball
Kings Second Favor - Mother's Prayer Beads
Beads: Bless, Curing x2, Favor, and Summons
Cultist ShadowBlade +1 /
Shadow Cut + 1d6 necrotic and reach #5ft. Shadow cut can only be used in areas of shadows or
darkness.
Captured Cultist
‘4x ShadowDragon Scales - Adult Sized

Kaetus Injury : Pulmonary damage (-1CON score; When you make a spell concentration check for a spell
with a verbal component, the DC is increased by 2.).

‘So What is Kaladan going to do? And keeping in mind, he's pissed

First, he puts a notice out about the PCs - they are to be dealt with immediately. Bounties are posted
‘through proxies. A disinformation campaign is begun to cast the PC group in a negative light in any other
city than Alluin, Borrend, and Galtorah.

Results:
Chipahua (N town) - Townspeople very suspicious / concerned about these PCs

El Enna (Middle town) - Townspeople confused / open debate about their role

Ennu (southern port) - Townspeople hear rumors all the time, hard to say what really happened

Captured Cultist - Mook intel level, loyal to the dragon cult
Can be convinced to tell them where the cult lair is, how to read Umbral

‘Shadow Scroll - Ever evolving instructions to cultists. This is for the cultists within Alluin,

Kaladan is going to set a trap for the players. He knows a cultist has been captured, and that at least one
‘Shadow Scroll is likely missing. The Cult has now teamed up with the Thieves guild, who want to get
revenge for the slights incurred in Borrend. This has afforded them more knowledge about the PC party
and their capabilities.

For instance, that the PCs found a powerful weapon in Borrend and killed his baby brother with it.
‘That the PCs defeated their last enemy with explosives and chemical weapons.
That the PCs are nefarious double crossers when it suites them.

Plan - Assume the PCs will use the shadow scroll to learn his plan. Spread a false plan to the PCs through
the scroll

#### ChatGPT Output:
Session 21 didn't really go as planned. Kaladan totally fucked up his assassination of the king. While he did sneak into the
castle undetected, he completely botched his various attack rolls on the target. The King was killed by the dragon's
shadow breath, but the quick actions of Elyris brought him back to life while his soul was still on the material plane
(shadow breath effect).

After the party rallied from their initial fear of the dragon, the tables in the encounter quickly turned. Dorc's Sentinel
feat became VIP when it prevented Kaladan from flying away from the encounter two turns in a row. Kaladan failed STR
checks to fling Dorc out of range. If Dorc's third Sentinel attack had hit, Kaladan would surely have perished in the
following round of combat.

Kaladan was barely able to get out of the keep and start to fly to safety. The dangerous spell casters were still just a few
squares out of range. Dorc's final boftcaster bolt scored a crit - and brought Kaladan down to Shp. Kaladan fell from the
sky, and crashed into a shopping center in the city.

A desperate chase broke out immediately to bag the dragon. Dorc jumped on his magic broom, and the Druid shape
shifted into bird to carry down the other two. Elryis- reviving the king, was delayed. (Aasthraa not present). The party, in
their greed to bag the dragon, split up. This nearly cost Kaetus his life, when he became skewered by cultists on the
either end of a doorway he tried to barge through!

In the end, Kaladan was able to heal over three rounds, regain flight capability, and escape before the party could reach
him. It was a close, pitched battle - the most epic of the campaign so far!

So let's look at the consequences of this fight:

- Kaladan is pissed. And for the first time, genuinely scared. These material plane assholes are no joke. If not dealt with,
  they might just... kill him. He nearly died that night, and the king - he lived. It was a tragic flip of Kaladan's plans to
  demonstrate the shadow cult's power. Plus, one of his cultist minions was captured by the PCs during the fight! He
  sacrificed himself to save Kaladan, As a pawn should.

Still, the situation must be dealt with - and promptly.

**PC loot / etc:**
- King's Favor to Elyris for saving his life during the Cultist's Ball
- King's Second Favor - Mother's Prayer Beads
- Beads: Bless, Curing x2, Favor, and Summons
- Cultist ShadowBlade +1 /
  Shadow Cut + 1d6 necrotic and reach #5ft. Shadow cut can only be used in areas of shadows or
  darkness.
- Captured Cultist
- 4x ShadowDragon Scales - Adult Sized

**Kaetus Injury :** Pulmonary damage (-1CON score; When you make a spell concentration check for a spell
with a verbal component, the DC is increased by 2.).

So What is Kaladan going to do? And keeping in mind, he's pissed

First, he puts a notice out about the PCs - they are to be dealt with immediately. Bounties are posted
through proxies. A disinformation campaign is begun to cast the PC group in a negative light in any other
city than Alluin, Borrend, and Galtorah.

**Results:**
- Chipahua (N town) - Townspeople very suspicious / concerned about these PCs
- El Enna (Middle town) - Townspeople confused / open debate about their role
- Ennu (southern port) - Townspeople hear rumors all the time, hard to say what really happened

Captured Cultist - Mook intel level, loyal to the dragon cult
Can be convinced to tell them where the cult lair is, how to read Umbral

Shadow Scroll - Ever evolving instructions to cultists. This is for the cultists within Alluin,

Kaladan is going to set a trap for the players. He knows a cultist has been captured, and that at least one
Shadow Scroll is likely missing. The Cult has now teamed up with the Thieves guild, who want to get
revenge for the slights incurred in Borrend. This has afforded them more knowledge about the PC party
and their capabilities.

For instance, that the PCs found a powerful weapon in Borrend and killed his baby brother with it.
That the PCs defeated their last enemy with explosives and chemical weapons.
That the PCs are nefarious double crossers when it suits them.

Plan - Assume the PCs will use the shadow scroll to learn his plan. Spread a false plan to the PCs through
the scroll

# Session 39 - You can't go home again

    **Created:** 2021-10-29 11:24:47  
    **Last Edited:** 2021-10-29 11:24:52  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, the PCs have returned to the EPoA. There, they must find some way to return to Terra
(hopefully their time and place on Terra). By returning to EPoA the time slip versus Terra is gone, so they can get the
latest report from Captain Floriana. While they've only been gone a day, Floriana is getting word that Kaladan is pressing
an attack on Enui, It seems the cultists are making a play and trying to assert themselves as the new real rulers of the
kingdom! The royal guard is overwhelmed maintaining order in the capital and El Enna - the rest is turning to disarray!

To get home, they will need to find an Elemental Mote of Terra in order to return to the Material Plane. This is actually a
tricky thing to find out in the elemental planes. Not many elemental creatures care to keep ties to mortals around.

Essafah and the other cloud Djin are all horrified that the PCs would so blithely violate the Inner/Outer compact like
that. The Guter planes, for the first time in this epoch, are now trying to influence the alignment of the Inner. The Inner
lords, in turn, are starting to build weapons and armies for the other planes. Things are going crazy in a hurry!

Raider's keep

In the ruins of a cloud giant's keep lies a gith raiding party. They

Result:
After a great discussion the players went through to the Air Plane. There they sent ward of Sending to
Essafah. They were soon greeted as friends by Mekrus, who sent his wyrvren riders out to save them
from an incoming thunderstorm. After a nat 20 painting by BoB Ross, they befriended Merkus who told
‘them about how the Inter/Outer Compact was violated, and now war and religion and chaos have
returned to the inner and outer planes.

Upon meeting Essafah, they were confronted by his multiple changing personalities. It became clear that
he really is Tiniethera, although transformed by the aether flame. The PCs were able to convince him
that they really are his friend, and had retrieved his tapestry. This greatly pleased Essafah, who invited
everyone to stay as his guests. Elryis and Essafah then went off to talk religion.

‘Ayden then snuck up and using invisibility and a great role, successfully pilfered the aether flame! Wat!
This enraged Essafah, who promptly issued a Fatwah against the party. Ayden channeled the Aether
Flame and teleported to Captain/Governor Floriana on the material plane.

‘The rest of the party had to engage in a sudden and dramatic escape back to the mirror. Odesseuys was
able to grab a mote of material from the sprites that lived here, trading mushrooms, a hammer, and a
femur for this legendary substance. The party then was able to return to Tiniethras mannor in the
material plane.

Inner Outer Compact

Inner planes, composed of the raw stuff of creation, are elementally pure places. They should not be
corrupted by the Who or Why of Philosophy.

Outer planes, composed of the raw thought of creation, are philosophically pure places. They should not
be corrupted by the What or How of Materials.

‘The Material plane, serving as the final junction of all other planes, is the designated dumping ground of
impure, comingled elements from any other plane.

Mote of Terra:

Essafah does nat have one, He hasn't needed use of a Planar Mirror since he became his current form.
He does know where one might be found tho - within the lowest, darkest cloud in the sky. There ina
Giant's storm keep, a Mote of Terra might be found,

Demon Leather Armor +1
You have advantage on Intimidation checks. Does not work against demons, fiends, or devils.

#### ChatGPT Output:
### Coming into this session, the PCs have returned to the EPoA.

There, they must find some way to return to Terra (hopefully their time and place on Terra). By returning to EPoA the time slip versus Terra is gone, so they can get the latest report from Captain Floriana. While they've only been gone a day, Floriana is getting word that Kaladan is pressing an attack on Enui. It seems the cultists are making a play and trying to assert themselves as the new real rulers of the kingdom! The royal guard is overwhelmed maintaining order in the capital and El Enna - the rest is turning to disarray!

To get home, they will need to find an Elemental Mote of Terra in order to return to the Material Plane. This is actually a tricky thing to find out in the elemental planes. Not many elemental creatures care to keep ties to mortals around.

Essafah and the other cloud Djin are all horrified that the PCs would so blithely violate the Inner/Outer compact like that. The Guter planes, for the first time in this epoch, are now trying to influence the alignment of the Inner. The Inner lords, in turn, are starting to build weapons and armies for the other planes. Things are going crazy in a hurry!

#### Raider's keep

In the ruins of a cloud giant's keep lies a gith raiding party. They

**Result:**
After a great discussion the players went through to the Air Plane. There they sent ward of Sending to Essafah. They were soon greeted as friends by Mekrus, who sent his wyrvren riders out to save them from an incoming thunderstorm. After a nat 20 painting by Bob Ross, they befriended Merkus who told them about how the Inter/Outer Compact was violated, and now war and religion and chaos have returned to the inner and outer planes.

Upon meeting Essafah, they were confronted by his multiple changing personalities. It became clear that he really is Tiniethera, although transformed by the aether flame. The PCs were able to convince him that they really are his friend, and had retrieved his tapestry. This greatly pleased Essafah, who invited everyone to stay as his guests. Elryis and Essafah then went off to talk religion.

Ayden then snuck up and using invisibility and a great role, successfully pilfered the aether flame! What! This enraged Essafah, who promptly issued a Fatwah against the party. Ayden channeled the Aether Flame and teleported to Captain/Governor Floriana on the material plane.

The rest of the party had to engage in a sudden and dramatic escape back to the mirror. Odysseus was able to grab a mote of material from the sprites that lived here, trading mushrooms, a hammer, and a femur for this legendary substance. The party then was able to return to Tiniethras manor in the material plane.

#### Inner Outer Compact

- **Inner planes**, composed of the raw stuff of creation, are elementally pure places. They should not be corrupted by the Who or Why of Philosophy.
- **Outer planes**, composed of the raw thought of creation, are philosophically pure places. They should not be corrupted by the What or How of Materials.
- **The Material plane**, serving as the final junction of all other planes, is the designated dumping ground of impure, comingled elements from any other plane.

#### Mote of Terra:

Essafah does not have one. He hasn't needed use of a Planar Mirror since he became his current form. He does know where one might be found though - within the lowest, darkest cloud in the sky. There in a Giant's storm keep, a Mote of Terra might be found.

#### Demon Leather Armor +1

You have advantage on Intimidation checks. Does not work against demons, fiends, or devils.

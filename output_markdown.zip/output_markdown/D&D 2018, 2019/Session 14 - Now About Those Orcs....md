# Session 14 - Now About Those Orcs...

    **Created:** 2021-10-29 11:15:57  
    **Last Edited:** 2021-10-29 11:16:09  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Session Notes:
Picking this back up after thanksgiving break. Players are opening in the city of Borrend, and are encountering more
meaningful NPCs than they have in their previous sessions. This is an opportunity to trade and barter with the three
factions of Borrend - Gnomes, Dwarves, and Halflings.

After their shopping expedition, the game will naturally turn towards action. The Orcs aren't sitting around - they are
trying to scale the cliff to break into the ramparts. Something will have to be done about the Orc Army itself.

Options:

Ride With Me - Open the gates and engage the Orcs. If the players can fight their way to the center and kill the
commander, the rest of the Ores will run,
Ends up Fighting: Numerous Orcs

‘Sneak Attack - Sneak out through other abandoned tunnels, then ambush the Orcs from behind.
Ends up fighting: Troll in tunnel, Orc Camp, Ore Leader + Etin

Borrend Cannon - If players lear of this -In the aftermath of the Fall of Stone incident, an insane Gnome Chouncilor
started building an immense cannon deep in an abanonded section of Borrend. This Cannon - The Ultimate Very Vertical
Doom Blaster (or by anyone less insane, the Borrend Cannon) - was designed to destroy any armies that might threaten
the free city. The effort consumed so many resources the city went into a dark age, and knowledge of the project was
lost to time and new city governments.

‘The cannon can be used to clear the Orc army - but will start to carry political consequences from its use.

To use the Cannon, the PCs will first have to find it, arm it, and blast the Ores with it.
May encounter Drow, Bulette, Ropers on way to Cannon
Activating firing sequence draws an Earth Elemental if need more time
Firing sequence requires players to fix controls, then aim cannon (DC15 int}, then charge, then finally fire.

‘Spectral Assassin - if players revive ol Gnome Hitler [change name], he can be negotiated with. He doesn't like Orcs (who
does, really?), and will happily help the players take the orcs out. By assassinating the Orc leader for you. Yea, that won't
have any consequences down the road at all.

If players take him up on his offer, will need to retrieve his Wand from a crypt. Doing so retums the revenant to his full
strength, and off on his merry way he goes.
Enemies Faced: Drow, Bulette, Ropers, Earth Elemental who tries to stop the players. This is >clearly< a bad idea.

Trading Groups:

Gnomes: Engineers Guild [Broc]

High energy Gnome on Meth

Has lots of inventions, many of them bad ideas

Bringing back to life Gnome Hitler is probably a bad idea.

Can build upgrades for players
>Gnomatic Wolf Jump Springs {Can jump vertically 20ft, horizontally 40ft, 2x per day)
>Wolf Armor +1AC

Upgrades take time, often need parts to be built and not just Gold

Dwarves: Druids of the Stone Circles

>Roll Names dwarfs

>Druidic Dwarven magic takes the form of stone shapping, working with natural resources, etc.

>Can train in ways of their magic once crisis ends and proves up to the task

>Has spell scrolls and potions for sale otherwise

>Also roll for magic items they can barter form here
‘Warhammer of Ore Slaying +1 (+1D6 Damage done to Orcs)

Halflings: Swap Meet
>Need to find a Halfling in the swap with something interesting to trade
>Halflings prefer to swap items than trade in Gold, Gold sells, but they are shrewd about it
>Can potentially swap for: Dungeon Tip (Borrend's Cannon) | Ring | Powder | Weapon
Tip: Existence of the Borrend Cannon
Ring: Ring of Swimming, Ring of Jumping, Ring of Warmth
Powder: Dust of Invisibility
‘Weapon: Berserker's Greataxe +1 / +1 Max HP Per level / Cursed: Bersker's,
Javelin of Ligtening

Knuckistepp Shappin

#### ChatGPT Output:
### Session Notes:
Picking this back up after thanksgiving break. Players are opening in the city of Borrend, and are encountering more
meaningful NPCs than they have in their previous sessions. This is an opportunity to trade and barter with the three
factions of Borrend - Gnomes, Dwarves, and Halflings.

After their shopping expedition, the game will naturally turn towards action. The Orcs aren't sitting around - they are
trying to scale the cliff to break into the ramparts. Something will have to be done about the Orc Army itself.

#### Options:

- **Ride With Me** - Open the gates and engage the Orcs. If the players can fight their way to the center and kill the
  commander, the rest of the Orcs will run,
  Ends up Fighting: Numerous Orcs

- **Sneak Attack** - Sneak out through other abandoned tunnels, then ambush the Orcs from behind.
  Ends up fighting: Troll in tunnel, Orc Camp, Orc Leader + Etin
  
- **Borrend Cannon** - If players learn of this -In the aftermath of the Fall of Stone incident, an insane Gnome Councilor
  started building an immense cannon deep in an abandoned section of Borrend. This Cannon - The Ultimate Very Vertical
  Doom Blaster (or by anyone less insane, the Borrend Cannon) - was designed to destroy any armies that might threaten
  the free city. The effort consumed so many resources the city went into a dark age, and knowledge of the project was
  lost to time and new city governments.
  
  The cannon can be used to clear the Orc army - but will start to carry political consequences from its use.
  
  To use the Cannon, the PCs will first have to find it, arm it, and blast the Orcs with it.
  May encounter Drow, Bulette, Ropers on way to Cannon
  Activating firing sequence draws an Earth Elemental if need more time
  Firing sequence requires players to fix controls, then aim cannon (DC15 int), then charge, then finally fire.

- **Spectral Assassin** - if players revive old Gnome Hitler [change name], he can be negotiated with. He doesn't like Orcs (who
  does, really?), and will happily help the players take the orcs out. By assassinating the Orc leader for you. Yea, that won't
  have any consequences down the road at all.
  
  If players take him up on his offer, will need to retrieve his Wand from a crypt. Doing so returns the revenant to his full
  strength, and off on his merry way he goes.
  Enemies Faced: Drow, Bulette, Ropers, Earth Elemental who tries to stop the players. This is >clearly< a bad idea.

#### Trading Groups:

- **Gnomes: Engineers Guild [Broc]**
  - High energy Gnome on Meth
  - Has lots of inventions, many of them bad ideas
  - Bringing back to life Gnome Hitler is probably a bad idea.
  - Can build upgrades for players
    - Gnomatic Wolf Jump Springs (Can jump vertically 20ft, horizontally 40ft, 2x per day)
    - Wolf Armor +1AC
  - Upgrades take time, often need parts to be built and not just Gold

- **Dwarves: Druids of the Stone Circles**
  - Roll Names dwarfs
  - Druidic Dwarven magic takes the form of stone shaping, working with natural resources, etc.
  - Can train in ways of their magic once crisis ends and proves up to the task
  - Has spell scrolls and potions for sale otherwise
  - Also roll for magic items they can barter form here
    - Warhammer of Orc Slaying +1 (+1D6 Damage done to Orcs)

- **Halflings: Swap Meet**
  - Need to find a Halfling in the swap with something interesting to trade
  - Halflings prefer to swap items than trade in Gold, Gold sells, but they are shrewd about it
  - Can potentially swap for: Dungeon Tip (Borrend's Cannon) | Ring | Powder | Weapon
    - Tip: Existence of the Borrend Cannon
    - Ring: Ring of Swimming, Ring of Jumping, Ring of Warmth
    - Powder: Dust of Invisibility
    - Weapon: Berserker's Greataxe +1 / +1 Max HP Per level / Cursed: Bersker's,
      Javelin of Lightning

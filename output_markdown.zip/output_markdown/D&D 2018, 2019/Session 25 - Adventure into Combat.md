# Session 25 - Adventure into Combat

    **Created:** 2021-10-29 11:20:10  
    **Last Edited:** 2021-10-29 11:20:23  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
So the party has a bunch of new magical items and an itch to put them to use. It's time to start breaking out some
heavier hitting creatures and challenging the party to use their full potential.

‘Their initial plan was to head towards Kaladan's lair and fight him head on. Assuming that holds, they will head into the
Crystal Desert, Assuming they can survive its challenges, they will reach the base of the Onyx Mountain - and Kaladan's
lair!

If they don't pursue this option, they could go for a side quest. Need to have some prep materials on hand for:
Kings Family

Floriana in El Enna

At Risk Tieflings

But Assume they'll go for the dragon.

Result —

Player party elected to head towards Chipahua, the crazy town of worm worshipers. The cult's grip was
strong over this town, and the players quickly found themselves an angry mob. Nenetl, the town leader,
‘was quite happy to fork the players over to cultists.

Elyrss was able to subdue the emotions of the mob with a cleric spell, and the situation seemed to cool
down. Until Kaladan himself appeared over the city. His terrifying presence set the town into an uproar,
and soon cultists were coming out of the woodwork to kill the players. Kaladan regularly strafed the
battlefield with his lightening breath weapon, inflicting major damage.

In the end, the players were defeated in the city square. They could not keep the town within the
Kingdom's rule, and were lucky to escape with their lives. They now are on the run in the forests nearby
Chipahua...

#### ChatGPT Output:
So the party has a bunch of new magical items and an itch to put them to use. It's time to start breaking out some
heavier hitting creatures and challenging the party to use their full potential.

Their initial plan was to head towards Kaladan's lair and fight him head on. Assuming that holds, they will head into the
Crystal Desert. Assuming they can survive its challenges, they will reach the base of the Onyx Mountain - and Kaladan's
lair!

If they don't pursue this option, they could go for a side quest. Need to have some prep materials on hand for:
- Kings Family
- Floriana in El Enna
- At Risk Tieflings

But assume they'll go for the dragon.

Result —

Player party elected to head towards Chipahua, the crazy town of worm worshipers. The cult's grip was
strong over this town, and the players quickly found themselves an angry mob. Nenetl, the town leader,
was quite happy to fork the players over to cultists.

Elyrss was able to subdue the emotions of the mob with a cleric spell, and the situation seemed to cool
down. Until Kaladan himself appeared over the city. His terrifying presence set the town into an uproar,
and soon cultists were coming out of the woodwork to kill the players. Kaladan regularly strafed the
battlefield with his lightning breath weapon, inflicting major damage.

In the end, the players were defeated in the city square. They could not keep the town within the
Kingdom's rule, and were lucky to escape with their lives. They now are on the run in the forests nearby
Chipahua...

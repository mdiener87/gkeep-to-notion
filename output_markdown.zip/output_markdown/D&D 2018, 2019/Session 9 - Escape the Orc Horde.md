# Session 9 - Escape the Orc Horde

    **Created:** 2021-10-29 11:12:08  
    **Last Edited:** 2021-10-29 11:12:16  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Evan is not in today
rcs will pursue players and try to rectaim their prizes. Manticore and Etin as possible miniboss encounters.

Players will discover one of the NPCs they rescued is a knight on the royal guard! Captain Floriana, a decorated knight.
Knight will beesech players to help rescue his comrades, which are holed up in an ald keep high in the mountains. The
ores are planning on launching a final raid through a hidden entrance they found. ->Drow tunnels into the keep, could

encounter drow defending their turf and orcs trying to reach the hidden entrance

Borrend

#### ChatGPT Output:
Evan is not in today  
rcs will pursue players and try to reclaim their prizes. Manticore and Etin as possible miniboss encounters.

Players will discover one of the NPCs they rescued is a knight on the royal guard! Captain Floriana, a decorated knight.  
Knight will beseech players to help rescue his comrades, which are holed up in an old keep high in the mountains. The  
orcs are planning on launching a final raid through a hidden entrance they found. ->Drow tunnels into the keep, could  

encounter drow defending their turf and orcs trying to reach the hidden entrance

Borrend

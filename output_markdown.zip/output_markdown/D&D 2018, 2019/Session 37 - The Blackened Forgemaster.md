# Session 37 - The Blackened Forgemaster

    **Created:** 2021-10-29 11:23:52  
    **Last Edited:** 2021-10-29 11:23:59  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, the PCs have ordered a large number of powerful armor upgrades. They don't
really understand the way to pay for these yet ($$$$ lots of blood agates - or a favor....). The Grand
Sultan is busy debating what to do about the imposter Essafah, but is also disturbed by reports that the
‘Salamanders are migrating deeper into the Lava Fields, something about a new ‘Sala-Savior' and the
‘Sacred Flame’.

Religion translates oddly to elemental creatures - they aren't really capable of the greater moral arcs it
represents. So the religion is spreading fast and warping even faster. Other dieties - and demons - will
‘soon notice and try to provide their own competing religions.

Overall story progression:
Essafah is technically a sidequest but he is a Big Bad in terms af power level and overall craziness
Kaladan has not stopped being a problem in the Material Plane - and time travels faster on the material
plane than on the fire, Things are happening there..

‘Agar is not taking his humiliation lying down,

Favor of the Azer
‘The Golden Ring hasn't been explored much but the forgemasters don't come cheap. The players don't
have anywhere near enough blood agates to trade for their new armor. The Azer will instead ask for
help redeeming a former, fallen Forge Master - [random name]

[random name] - fled into the hills and disowned the group. Now he runs the Blackened Ring, a clear
violation of EPF copyright law. Efreeti are very lazy tho, and tracking down the renegade Azer in the
[location] has been too much effort for them to date to bother with a request for Azer. Maybe the PCs
can help out?

Unknown to everyone, the BR have been supplying magical gear to literal devils. For hundreds af years.
‘Those devils aren't going to take Kindly to intrusion here.

Elemental portal:
‘The salamanders have stolen one, amongst many of the other things
they've stolen from the Efreeti. The bulk of the salamanders are off
‘worshiping Elryss and Mishakal, and that is causing weird disturbances
in the balance of faith across the planes.

City of Brass
Ruler - Grand Sultant (Efreeti}

Citizens: Efreeti, Azeer, Salamanders, humanoid slaves, fire creatures
Guilds: Golden Ring - Azer Forgemasters; Illuminaries - Efreeti enforcers

Previous Session Outcomes:
Met the grand sultan and convinced him that Essafah is some sot of Genie fraud. He is commissioning a
study on what to do about this with his other Efreeeti but no word on his decision.

‘The party then explored the city of brass and got into seroius schenanagains:
Dork: willingly sold himself into sexual stavery, banged 5 efreeti and bought his own freedom
back. Earned a few blood agates for his trouble {and a genie STD that gave him +1 CON)
(Odysseus: Fought in the gladiatorial rings and learned something new (TBD)

Elryss: Started a new cult of Mishkal amongst the fire salamanders. They are starting to turn
‘themselves into fire elementals and have become fervent cultists of Mishkal. They worship Elyris
asa messenger.

Party overall:
Worked with the Azer to begin production and upgrade of several items:
Obsidian Ring Shield: Required a mote of soot from the sea of embers
Upgraded Dragonscale Armor: Required a spirit of rage
Roc Feather Cloak: in production without further effort

‘This sessions" outcomes:
Party got their loot from the Golden Ring and accepted the assassination quest for the Blackened Ring
member. The PCs summoned eagles via Kaetus and took flight, quickly tracking him down using the Orb
of Tracking provided by the Golden Ring (turns out - all their master's marks are tracking beacons).

After tracking him down, they came across Ghadal, the Blackened Forgemaster. Ghadal has been selling
‘weapons to Ice Demons, whom he promptly bat-phoned for aid. Kaetus hit their summoning ring with a
Dispet Magic, aborting the demon's teleporting attempt and leaving them with Ghadal alone. Ghadal
agreed to go into asylum, and gave the PCs his ultimate artifact - an armor of invulnerability pill. Fred ate
it, Welllip.

‘Ayden also robbed him of all his Blood Agates (12,000). That's a fortune!
Upon returning to the city of Brass, they found a furious Grand Sultan, He is mad about this usurping

religion of Mishakal, corrupting his salamander scum into pure fire elementals without his blessing! He
has demanded that this Agent of Mishakal be found and brought forth for the sultans justic

#### ChatGPT Output:
Coming into this session, the PCs have ordered a large number of powerful armor upgrades. They don't
really understand the way to pay for these yet ($$$$ lots of blood agates - or a favor....). The Grand
Sultan is busy debating what to do about the imposter Essafah, but is also disturbed by reports that the
Salamanders are migrating deeper into the Lava Fields, something about a new 'Sala-Savior' and the
'Sacred Flame'.

Religion translates oddly to elemental creatures - they aren't really capable of the greater moral arcs it
represents. So the religion is spreading fast and warping even faster. Other deities - and demons - will
soon notice and try to provide their own competing religions.

Overall story progression:
- Essafah is technically a sidequest but he is a Big Bad in terms of power level and overall craziness
- Kaladan has not stopped being a problem in the Material Plane - and time travels faster on the material
  plane than on the fire. Things are happening there..
- Agar is not taking his humiliation lying down.

**Favor of the Azer**
The Golden Ring hasn't been explored much but the forgemasters don't come cheap. The players don't
have anywhere near enough blood agates to trade for their new armor. The Azer will instead ask for
help redeeming a former, fallen Forge Master - [random name]

[random name] - fled into the hills and disowned the group. Now he runs the Blackened Ring, a clear
violation of EPF copyright law. Efreeti are very lazy though, and tracking down the renegade Azer in the
[location] has been too much effort for them to date to bother with a request for Azer. Maybe the PCs
can help out?

Unknown to everyone, the BR have been supplying magical gear to literal devils. For hundreds of years.
Those devils aren't going to take kindly to intrusion here.

**Elemental portal:**
The salamanders have stolen one, amongst many of the other things
they've stolen from the Efreeti. The bulk of the salamanders are off
worshiping Elryss and Mishakal, and that is causing weird disturbances
in the balance of faith across the planes.

**City of Brass**
- Ruler: Grand Sultan (Efreeti)
- Citizens: Efreeti, Azer, Salamanders, humanoid slaves, fire creatures
- Guilds: Golden Ring - Azer Forgemasters; Illuminaries - Efreeti enforcers

**Previous Session Outcomes:**
Met the grand sultan and convinced him that Essafah is some sort of Genie fraud. He is commissioning a
study on what to do about this with his other Efreeti but no word on his decision.

The party then explored the city of brass and got into serious shenanigans:
- Dork: willingly sold himself into sexual slavery, banged 5 efreeti and bought his own freedom
  back. Earned a few blood agates for his trouble (and a genie STD that gave him +1 CON)
- Odysseus: Fought in the gladiatorial rings and learned something new (TBD)
- Elryss: Started a new cult of Mishkal amongst the fire salamanders. They are starting to turn
  themselves into fire elementals and have become fervent cultists of Mishkal. They worship Elyris
  as a messenger.

**Party overall:**
Worked with the Azer to begin production and upgrade of several items:
- Obsidian Ring Shield: Required a mote of soot from the sea of embers
- Upgraded Dragonscale Armor: Required a spirit of rage
- Roc Feather Cloak: in production without further effort

**This session's outcomes:**
Party got their loot from the Golden Ring and accepted the assassination quest for the Blackened Ring
member. The PCs summoned eagles via Kaetus and took flight, quickly tracking him down using the Orb
of Tracking provided by the Golden Ring (turns out - all their master's marks are tracking beacons).

After tracking him down, they came across Ghadal, the Blackened Forgemaster. Ghadal has been selling
weapons to Ice Demons, whom he promptly bat-phoned for aid. Kaetus hit their summoning ring with a
Dispel Magic, aborting the demon's teleporting attempt and leaving them with Ghadal alone. Ghadal
agreed to go into asylum, and gave the PCs his ultimate artifact - an armor of invulnerability pill. Fred ate
it, Wellip.

Ayden also robbed him of all his Blood Agates (12,000). That's a fortune!
Upon returning to the city of Brass, they found a furious Grand Sultan. He is mad about this usurping
religion of Mishakal, corrupting his salamander scum into pure fire elementals without his blessing! He
has demanded that this Agent of Mishakal be found and brought forth for the sultan's justice.

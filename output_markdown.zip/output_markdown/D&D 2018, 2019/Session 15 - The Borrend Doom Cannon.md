# Session 15 - The Borrend Doom Cannon

    **Created:** 2021-10-29 11:16:23  
    **Last Edited:** 2021-10-29 11:16:33  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, the PC group has purchased new weapons and gear from the various vendors they've
encountered, purchased, and even robbed. So this session should be a larger combat focus so they can break in that
new gear!

Mission: Reach the Borrend Doom Cannon and use it to stop the invading orc army. Of course, there are complications:

1) Finding the weapon?
2) Arming it
3) Firing it

Encounters:

>Find Train Platform
Mutant Spider Ambush

>Traverse to far train platform
>Drow + Spider ambush if they don't find a way to quiet their approach
>Platform leads to: Barracks, Ramp Down, Ramp up
>Platform has other abandoned railways leading deeper into the mountain.

>Barracks
No enemies, just old and ransacked. Can find a [Security Key] in here

>Ramp Down to [armory]
>Drow have been trying to build improved weapons here from the toxic chemicals,
>Drow raiding contingent is here - including a drow mage!

>Players will need to load a shell from the armory up to the cannon
>Control is locked without [Security Key]

>Ramp up to [Firing Control]
>Players will have to figure out controls and aim the cannon
>Controls locked without [Security Key]
>Messing with anything will activate the [Elemental monsters guarding the cannon]

>Charging the cannon will take several turns
>if time allows, Ores are going to start rushing in here from above the ridgeline
>The Ore god Illneveal has revealed the cannon's existence to the Orc horde. And they want it for themselves!
>Zerg players with Ores and a Sheggohn Priestess while they try to arm and fire the weapon

‘Sheggohn Priestess
STR +3 DEX #0 CON 42 INT 12 WIS 14 CHA 12
ACIS

Hit Points: 60

Speed: 20ft

Aggressive - bonus action may mave towards
players

Spellcasting - The orcis a 2rd-level spellcaster.
Its spellcasting DC is wisdom (DC 12, +3 hit
with spell attacks)

Spells:

2nd level 2 slots: Scorching ray

Ast level 4 slots: Burning Hands

Cantrip: Fire Bolt, light, mage hand

om Spear: +4 to hit, hit: 1d6 + 2

Orc Orogs - these are branded with symbols
of devotion to Illneveal, and Sheggohn's
bloodied war crest. Itis one sword raised high
in triumph, the other impaled onto an eff. tis,
said not to be an earned crest until splashed
with both orc and elf blood.

For Derick:
Sandblast
Druid Cantrip
Casting Time: 1 Action
Range: 30ft
Components: V, S
Duration: Instant
‘You blast a jet of sand and dust at a creature you can see, or at two creatures within 5 feet of each
other, and force them to pass a constitution saving throw or take 1d6 bludgeoning damage. If
that creatures fails the save by 3 or more, that creature has disadvantage on its next attack roll
within one round. An action may be taken to remove this disadvantage.+

‘This cantrip's damage die increases at levels 5, 11, and 17.

#### ChatGPT Output:
Coming into this session, the PC group has purchased new weapons and gear from the various vendors they've encountered, purchased, and even robbed. So this session should be a larger combat focus so they can break in that new gear!

**Mission:** Reach the Borrend Doom Cannon and use it to stop the invading orc army. Of course, there are complications:

1) Finding the weapon?
2) Arming it
3) Firing it

**Encounters:**

> Find Train Platform  
> Mutant Spider Ambush

> Traverse to far train platform  
> Drow + Spider ambush if they don't find a way to quiet their approach  
> Platform leads to: Barracks, Ramp Down, Ramp Up  
> Platform has other abandoned railways leading deeper into the mountain.

> Barracks  
> No enemies, just old and ransacked. Can find a [Security Key] in here.

> Ramp Down to [armory]  
> Drow have been trying to build improved weapons here from the toxic chemicals,  
> Drow raiding contingent is here - including a drow mage!

> Players will need to load a shell from the armory up to the cannon  
> Control is locked without [Security Key]

> Ramp up to [Firing Control]  
> Players will have to figure out controls and aim the cannon  
> Controls locked without [Security Key]  
> Messing with anything will activate the [Elemental monsters guarding the cannon]

> Charging the cannon will take several turns  
> If time allows, Orcs are going to start rushing in here from above the ridgeline  
> The Orc god Illneveal has revealed the cannon's existence to the Orc horde. And they want it for themselves!  
> Zerg players with Orcs and a Sheggohn Priestess while they try to arm and fire the weapon

**Sheggohn Priestess**  
*STR +3 DEX #0 CON 42 INT 12 WIS 14 CHA 12*  
**AC 15**  
**Hit Points:** 60  
**Speed:** 20ft  

**Aggressive** - bonus action may move towards players  

**Spellcasting** - The orc is a 2nd-level spellcaster.  
Its spellcasting ability is wisdom (DC 12, +3 hit with spell attacks)

**Spells:**
- 2nd level 2 slots: Scorching Ray
- 1st level 4 slots: Burning Hands
- Cantrip: Fire Bolt, Light, Mage Hand

**Orc Spear:** +4 to hit, hit: 1d6 + 2  

Orc Orogs - these are branded with symbols of devotion to Illneveal, and Sheggohn's bloodied war crest. It is one sword raised high in triumph, the other impaled onto an effigy, said not to be an earned crest until splashed with both orc and elf blood.

**For Derick:**
*Sandblast*  
**Druid Cantrip**  
**Casting Time:** 1 Action  
**Range:** 30ft  
**Components:** V, S  
**Duration:** Instant  

You blast a jet of sand and dust at a creature you can see, or at two creatures within 5 feet of each other, and force them to pass a constitution saving throw or take 1d6 bludgeoning damage. If that creature fails the save by 3 or more, that creature has disadvantage on its next attack roll within one round. An action may be taken to remove this disadvantage.

This cantrip's damage die increases at levels 5, 11, and 17.

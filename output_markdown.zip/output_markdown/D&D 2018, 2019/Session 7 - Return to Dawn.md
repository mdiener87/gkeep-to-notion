# Session 7 - Return to Dawn

    **Created:** 2021-10-29 11:10:34  
    **Last Edited:** 2021-10-29 11:10:55  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming in off two weeks break; everyone is eager to play. Aaron is out (sadness!), leaving:
Kevin

Evan

Carolyn

sam

Derick

Play will pick up following the exit of the Valzumin stronghold. The players might try to pocket the dimensional marble
or not. Either way, once they exit, they'll be confronted with a disturbing reality - time seems to have gotten the better
of them. Where once was a clear spring day, now a dreary fall rain greets the party. The leaves are turning colors and
falling. Poor visibility and pervading damp rain prevails. Oh and yea - the Ores are here,

‘The party never did get around to helping the Kingdom of Dawn out with that Orc invasion, and now the kingdom is in
dire peril. The Orcs have advanced from the East and South, and now openly roam the countryside. The city of Alluin is,
under siege, and smokey fires seem to dot the country side in every direction.
Orc Raiding Parties - players will encounter regular Ore regular parties during day travel. (1-4 orcs, plus an Eye or Orog)
Ifthe players start to make too big a raucous, they'll attract Orc Hunting parties (+Manticore air support).
rcs will have a chance to drop gold, plus random items they've looted from the countryside.
Ifthe party attempts to travel by night, they will possibly be ambushed by Drow (pitfall trap and arrow trap), plus drow.
‘There is opportunity here to potentially barter (#NotAllDrow/!) if they can avoid the trap and approach them head-on.
‘The drow hate the players, but they hate orc invasions even more - being elves and all.
Drow Orc-Slaying Poision - 1d4 poison damage, doubled to 18 vs orcs. DC 12 constitution, +2 DC vs ores. 106 /
vial
Drow Switchblade - 16 piercing, seems to naturally stay hidden in your clothing or gear, resulting in advantage on

attempts to conceal it. 1256

Envenomed Drow Longsword +1 - 148 slashing +1 versatile (1410 + 1), lightweight, Envenomed grooves
allow for easy poison application to this weapon (3506).

An Ettin encounter is also possible {+ a few orcs?) -it's been cajoled to join with the invading armies. Probably helping to
guard the camp with the captured Dawn citizens.

‘Ankhegs have been disturbed to the west if more encounters are needed.
Party direction:
Could go back towards Goltorah and determine the fate of their NPC companions.

Could go towards Alluin and try to save the city.
No dungeon this session - its open world made.

#### ChatGPT Output:
Coming in off two weeks break; everyone is eager to play. Aaron is out (sadness!), leaving:
- Kevin
- Evan
- Carolyn
- Sam
- Derick

Play will pick up following the exit of the Valzumin stronghold. The players might try to pocket the dimensional marble
or not. Either way, once they exit, they'll be confronted with a disturbing reality - time seems to have gotten the better
of them. Where once was a clear spring day, now a dreary fall rain greets the party. The leaves are turning colors and
falling. Poor visibility and pervading damp rain prevails. Oh and yea - the Orcs are here.

The party never did get around to helping the Kingdom of Dawn out with that Orc invasion, and now the kingdom is in
dire peril. The Orcs have advanced from the East and South, and now openly roam the countryside. The city of Alluin is,
under siege, and smokey fires seem to dot the countryside in every direction.
- Orc Raiding Parties - players will encounter regular Orc raiding parties during day travel. (1-4 orcs, plus an Eye or Orog)
- If the players start to make too big a raucous, they'll attract Orc Hunting parties (+Manticore air support).
- Orcs will have a chance to drop gold, plus random items they've looted from the countryside.
- If the party attempts to travel by night, they will possibly be ambushed by Drow (pitfall trap and arrow trap), plus drow.
  - There is opportunity here to potentially barter (#NotAllDrow/!) if they can avoid the trap and approach them head-on.
  - The drow hate the players, but they hate orc invasions even more - being elves and all.
  - Drow Orc-Slaying Poison - 1d4 poison damage, doubled to 8 vs orcs. DC 12 constitution, +2 DC vs orcs. 10 gp /
    vial
  - Drow Switchblade - 1d6 piercing, seems to naturally stay hidden in your clothing or gear, resulting in advantage on
    attempts to conceal it. 12 gp
  - Envenomed Drow Longsword +1 - 1d8 slashing +1 versatile (1d10 + 1), lightweight, Envenomed grooves
    allow for easy poison application to this weapon (35 gp).

An Ettin encounter is also possible (+ a few orcs?) - it's been cajoled to join with the invading armies. Probably helping to
guard the camp with the captured Dawn citizens.

Ankhegs have been disturbed to the west if more encounters are needed.
Party direction:
- Could go back towards Goltorah and determine the fate of their NPC companions.
- Could go towards Alluin and try to save the city.
No dungeon this session - it's open world made.

### Attachment 2

#### Raw OCR Output:
NPC Fates:
Deisa - Captured but alive
Lerry - Captured but alive
Greaves + Outlaw camp: Fighting, on the run

Side quest opportunity: Rescue Deisa, Lerry, and the other villagers. Village was hit by Orc raiding
parties, and many citizens were seized as slaves. Greaves and his deserters are on the run from all
parties, fighting their way through the forest.

Graves, can be persuaded to part with an item:
Guardian's +1 Steel Shield (+2 initiative while worn and conscious) (+3 total AC) - starting ask 2506

#### ChatGPT Output:
### NPC Fates:
- Deisa - Captured but alive
- Lerry - Captured but alive
- Greaves + Outlaw camp: Fighting, on the run

**Side quest opportunity:** Rescue Deisa, Lerry, and the other villagers. Village was hit by Orc raiding
parties, and many citizens were seized as slaves. Greaves and his deserters are on the run from all
parties, fighting their way through the forest.

**Graves, can be persuaded to part with an item:**
- Guardian's +1 Steel Shield (+2 initiative while worn and conscious) (+3 total AC) - starting ask 2506

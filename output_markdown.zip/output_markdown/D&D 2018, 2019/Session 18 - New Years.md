# Session 18 - New Years

    **Created:** 2021-10-29 11:17:14  
    **Last Edited:** 2021-10-29 11:17:19  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Alright need to make some DM notes !

Major events that occurred last time:

Players killed Sheggon Megged, the Orc War Chief

Players blew up the Gnome Doom Cannon

Players somewhat lied about protecting the weapon to Tordid

‘A baby dragon was killed in the gas cloud as collateral damage
© Type: BLACK

Players looted Sheggon's party, getting some good lewt

Outstanding major plot threads:

Orc Invasion is now officially over

© KoDis busy with mop-up actions for forseaable future, but the kingdom seems saved!
© Alluin, the capital, has been devestated. Every city but Borrend has been damaged
© Dissa has had a major change of heart regarding the party - she is impressed!

= Manticore Stinger
Large, Two Handed Greatsword
1 2d6 +2 (melee) / 148 + 2 (stinger)

4 May consume a charge (max 3 charges) as an action to hurl a manticore spike at a target
you may see within 100ft. This counts as a ranged attack. Up to 3 spike charges regrow on

the blade at midnight.

Encounters:

Not sure — random encounters while players are traveling. They are starting to attract attention now,
and not all of it positive. There is also an outstanding hit on the players fram Drow, any Orc remnants,
and now the ShadowedGuild [Japser tipped them off]

Shadowed Guild:

A loose network of thieves and mercenaries, the Shadowed Guild plays fast and loose with law and
morality to always turn a tidy profit. They are normally non-confrontational, unless their target is very
wealthy or carrying valuable items, Or pissed them off.

>invisible Stalker
>NPC assassins? / drow elite warrior template / gladiator template

Shadow-Blue Dragonspawn:

Where did it come from? Why was it here? Lots of questions with no answers. Dragons have not been
seen in the Kingdom since before the first era. Players will need to investigate this situation and see how
to resolve it.

> Shadow Blue dragon adult has moved into the abandoned lands to the north. With the Orc
invasion, this area is seen as week and prime for a new dragon to rule over. Of course, they aren't
anywhere near strong enough to actually fight a dragon, so will need to power up and research
this new foe.

Shadow-Blue Dragonspawn harvesting:
1x Skull

10x Claws

Hide + Scales

Eyes,

Bones

#### ChatGPT Output:
Alright, need to make some DM notes!

**Major events that occurred last time:**

- Players killed Sheggon Megged, the Orc War Chief
- Players blew up the Gnome Doom Cannon
- Players somewhat lied about protecting the weapon to Tordid
- A baby dragon was killed in the gas cloud as collateral damage
  - Type: BLACK
- Players looted Sheggon's party, getting some good lewt

**Outstanding major plot threads:**

- Orc Invasion is now officially over
  - KoDis busy with mop-up actions for foreseeable future, but the kingdom seems saved!
  - Alluin, the capital, has been devastated. Every city but Borrend has been damaged
  - Dissa has had a major change of heart regarding the party - she is impressed!

**Manticore Stinger**
- Large, Two Handed Greatsword
- 1 2d6 +2 (melee) / 1d8 + 2 (stinger)
- May consume a charge (max 3 charges) as an action to hurl a manticore spike at a target you may see within 100ft. This counts as a ranged attack. Up to 3 spike charges regrow on the blade at midnight.

**Encounters:**

Not sure — random encounters while players are traveling. They are starting to attract attention now, and not all of it positive. There is also an outstanding hit on the players from Drow, any Orc remnants, and now the ShadowedGuild [Jasper tipped them off]

**Shadowed Guild:**

A loose network of thieves and mercenaries, the Shadowed Guild plays fast and loose with law and morality to always turn a tidy profit. They are normally non-confrontational, unless their target is very wealthy or carrying valuable items, or pissed them off.

- Invisible Stalker
- NPC assassins? / drow elite warrior template / gladiator template

**Shadow-Blue Dragonspawn:**

Where did it come from? Why was it here? Lots of questions with no answers. Dragons have not been seen in the Kingdom since before the first era. Players will need to investigate this situation and see how to resolve it.

- Shadow Blue dragon adult has moved into the abandoned lands to the north. With the Orc invasion, this area is seen as weak and prime for a new dragon to rule over. Of course, they aren't anywhere near strong enough to actually fight a dragon, so will need to power up and research this new foe.

**Shadow-Blue Dragonspawn harvesting:**
- 1x Skull
- 10x Claws
- Hide + Scales
- Eyes
- Bones

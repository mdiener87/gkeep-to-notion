# Session 45 - Floriana's Fate

    **Created:** 2021-10-29 11:26:35  
    **Last Edited:** 2021-10-29 11:26:40  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The order of Sun and Moon played the hero and worked to save the townspeople of El Enna, While they were Encounter ideas:
(somewhat) successful, their choice has not come without consequences. More reinforcements have now come through Abishai (MTF 160)
the teleporter located in the Mishakal temple, making that fight more difficult than it might have been. Floriana is at the Drow elite party
mercy of the cultists, who are trying to subvert her to shadow. If an honorable and noble heroin like her can be

corrupted, what hope is there for the rest of the kingdom?

Refer to previous maps for overall session combat info. Players will likely need a long rest at the start as they did the
previous coleseum fight without resting from Tinnethra's manor encounters either. Roll to determine if they are
interrupted by roaming cultist forces (who themselves can attempt to rally more forces).

‘Worse still, Kaladan is well aware that the Aether Flame is close. His cultist members can almost taste it. A seeker is now
roaming the city in an attempt to kidnap whomever is holding it and/or steal the item itself. This is a deal with the Drow,
whom are taking advantage of the situation by re-asserting their own dominance against the kingdom. If the Drown can
seize the AF, Kaladan has promised them rulership of Alluin and Sevelarum as their own surface-dwelling cities.

Floriana is going to need to make a WIS saving throw at the start of gameplay...

Marilith - guarding floriana?

Outcome:

‘The party decided to go for the rescue mission on Governor Floriana. Gil led them to a tunnel entrance under a nearby militia outpost, which led to a fairly
successful infiltration of the mansion's space. While still in the middle of cleanup actions with Dragonborn Warlock cultists on the first floor, Elyris burst through
the door into Floriana's office. This triggered the boss fight with the Narzugon, which was busy torturing and trying to tum Floriana, The Narzugon was an
immense fight to handle with full tactics ready, but the party was somewhat split in attention and location across the first and second floors. The situation
quickly turned dire as Ayden tried to conjure a water elemental using the Aethre Flame — only to roll the dreaded Nat 1. Only the quick counterspell action of
Bob Ross allowed the AF from going nuclear, but Ayden still took 102 force damage to the face as the AF ripped space and time asunder around him.
Meanwhile, the Narzugon critically hit Elryis, dropping her HP to the negatives as the fight began. Two players already downed.

Bob Ross took the Aether Flame from Ayden, and used it to cast Phantasmal Killer on the Narzugon. This normally would have had no effect, but with the
power of the Aether Flame, it fully manifested in a real creature that the Narzugon feared -the Phoenix. This led to a narrative fight between two legendary
creatures for supremacy of the Narzugon's mind. This tied up the Narzugon for several turns as they battled for supremacy.

‘When Bob Ross stabilized Ayden and woke him up, he was met with sudden betrayl! Ayden immediately cast Sleep on Bob Ross, succesfully putting him out
and taking back the Aether Flame.

While the Narzugon and the Phoenix battled, Dorc was able to get to Elyris and revive her .The two then worked together to free Floriana from her bindings,
and were able to carry her body to the group. The players gathered together and used the Aether Flame to Plane Shift back to Teniethra's manor, just as the
Narzugon succeded on its battle with the Phoenix and came for the party!

#### ChatGPT Output:
‘The order of Sun and Moon played the hero and worked to save the townspeople of El Enna, While they were Encounter ideas:
(somewhat) successful, their choice has not come without consequences. More reinforcements have now come through Abishai (MTF 160)
the teleporter located in the Mishakal temple, making that fight more difficult than it might have been. Floriana is at the Drow elite party
mercy of the cultists, who are trying to subvert her to shadow. If an honorable and noble heroin like her can be

corrupted, what hope is there for the rest of the kingdom?

Refer to previous maps for overall session combat info. Players will likely need a long rest at the start as they did the
previous coliseum fight without resting from Tinnethra's manor encounters either. Roll to determine if they are
interrupted by roaming cultist forces (who themselves can attempt to rally more forces).

‘Worse still, Kaladan is well aware that the Aether Flame is close. His cultist members can almost taste it. A seeker is now
roaming the city in an attempt to kidnap whomever is holding it and/or steal the item itself. This is a deal with the Drow,
whom are taking advantage of the situation by re-asserting their own dominance against the kingdom. If the Drown can
seize the AF, Kaladan has promised them rulership of Alluin and Sevelarum as their own surface-dwelling cities.

Floriana is going to need to make a WIS saving throw at the start of gameplay...

Marilith - guarding Floriana?

Outcome:

‘The party decided to go for the rescue mission on Governor Floriana. Gil led them to a tunnel entrance under a nearby militia outpost, which led to a fairly
successful infiltration of the mansion's space. While still in the middle of cleanup actions with Dragonborn Warlock cultists on the first floor, Elyris burst through
the door into Floriana's office. This triggered the boss fight with the Narzugon, which was busy torturing and trying to turn Floriana, The Narzugon was an
immense fight to handle with full tactics ready, but the party was somewhat split in attention and location across the first and second floors. The situation
quickly turned dire as Ayden tried to conjure a water elemental using the Aethre Flame — only to roll the dreaded Nat 1. Only the quick counterspell action of
Bob Ross allowed the AF from going nuclear, but Ayden still took 102 force damage to the face as the AF ripped space and time asunder around him.
Meanwhile, the Narzugon critically hit Elyris, dropping her HP to the negatives as the fight began. Two players already downed.

Bob Ross took the Aether Flame from Ayden, and used it to cast Phantasmal Killer on the Narzugon. This normally would have had no effect, but with the
power of the Aether Flame, it fully manifested in a real creature that the Narzugon feared - the Phoenix. This led to a narrative fight between two legendary
creatures for supremacy of the Narzugon's mind. This tied up the Narzugon for several turns as they battled for supremacy.

‘When Bob Ross stabilized Ayden and woke him up, he was met with sudden betrayal! Ayden immediately cast Sleep on Bob Ross, successfully putting him out
and taking back the Aether Flame.

While the Narzugon and the Phoenix battled, Dorc was able to get to Elyris and revive her. The two then worked together to free Floriana from her bindings,
and were able to carry her body to the group. The players gathered together and used the Aether Flame to Plane Shift back to Teniethra's manor, just as the
Narzugon succeeded on its battle with the Phoenix and came for the party!'''

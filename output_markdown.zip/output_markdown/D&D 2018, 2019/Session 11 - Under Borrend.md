# Session 11 - Under Borrend

    **Created:** 2021-10-29 11:13:58  
    **Last Edited:** 2021-10-29 11:14:43  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The PC group has defeated the Orc assault squad that was threatening to break into Borrend. What lies beyond the door
the Orcs were battering? Can the players withstand what lies beyond?

Note - all players level 5. Time to take the kiddie gloves off and give them so monsters worthy their attention.

Plot thoughts:

Go to hexes for map nav. Take a page from dankest dungeon and allow for PC vs. env. Without having to go full tactical.
Tactical map switch then is then for per-round actions. The map will ‘zoom in’ and show the exact terrain, Have notes
for 'path' descriptions and something perhaps for them to overcome / stealth / scout / etc.

Path's then can lead to larger rooms with objectives, encounters, loot, etc.

Hex default size - 20ft radius (4x map scale)

Plot lines - they break in, it’s the top of the sealed catacombs. A flimsy gnomish defense garrison is there to meet the
players - but they clearly are no match for the Orcs that would have shortly met them. The gnome Lt. in charge of the
defense will quickly break the players down on the situation while giving a brief preview of Borrend.

Notable NPCs they might meet in the city:

Tordid Nordak - Choucilar and leader of the city. She is actually Dissa Gilthur's sister. They have a.. Strained relationship,
but Dissa is formally Dissa Nordak, a powerful Dwarfen political family in Borrend. Dissa gave up politics long ago (50+

years), and for the past few years has lived as the apothecary in Galtorah. It's not publically known why she left or where
she went.

DeleBean Broce Fibblestib of the Maekkelferce clan - a rising Gnome engineer of the Engineer's guild.
Can examine the player's inventory and discover a purpose for those elemental stones. For a fee (100g) he thinks
he can reforge them into something wonderous! If a bit dangerous. Cost: 10 Gems, or 10% chance to fail per less
gem, Creates an Elemental Gem

‘Shopping: Players will have an opportunity to trade and gear up before they venture down into the catacombs.

Potions: 146 avaialble

Medallion of thoughts - (4000g, can be hagled down to 600g with trade of a black pearl as well. Or 1200g otherwise)

Prototype KEK-1000 Bolt Blaster (300g, can be haggled down to 800g)
Heavy, loading, two-handed crossbow.
#11410 piercing damage

#### ChatGPT Output:
‘The PC group has defeated the Orc assault squad that was threatening to break into Borrend. What lies beyond the door
the Orcs were battering? Can the players withstand what lies beyond?

Note - all players level 5. Time to take the kiddie gloves off and give them so monsters worthy their attention.

Plot thoughts:

- Go to hexes for map nav. Take a page from dankest dungeon and allow for PC vs. env. Without having to go full tactical.
- Tactical map switch then is then for per-round actions. The map will ‘zoom in’ and show the exact terrain, Have notes
  for 'path' descriptions and something perhaps for them to overcome / stealth / scout / etc.

- Paths then can lead to larger rooms with objectives, encounters, loot, etc.

- Hex default size - 20ft radius (4x map scale)

Plot lines - they break in, it’s the top of the sealed catacombs. A flimsy gnomish defense garrison is there to meet the
players - but they clearly are no match for the Orcs that would have shortly met them. The gnome Lt. in charge of the
defense will quickly break the players down on the situation while giving a brief preview of Borrend.

Notable NPCs they might meet in the city:

- Tordid Nordak - Choucilar and leader of the city. She is actually Dissa Gilthur's sister. They have a.. Strained relationship,
  but Dissa is formally Dissa Nordak, a powerful Dwarfen political family in Borrend. Dissa gave up politics long ago (50+
  years), and for the past few years has lived as the apothecary in Galtorah. It's not publicly known why she left or where
  she went.

- DeleBean Broce Fibblestib of the Maekkelferce clan - a rising Gnome engineer of the Engineer's guild.
  Can examine the player's inventory and discover a purpose for those elemental stones. For a fee (100g) he thinks
  he can reforge them into something wondrous! If a bit dangerous. Cost: 10 Gems, or 10% chance to fail per less
  gem, Creates an Elemental Gem

‘Shopping: Players will have an opportunity to trade and gear up before they venture down into the catacombs.

Potions: 146 available

Medallion of thoughts - (4000g, can be haggled down to 600g with trade of a black pearl as well. Or 1200g otherwise)

Prototype KEK-1000 Bolt Blaster (300g, can be haggled down to 800g)
Heavy, loading, two-handed crossbow.
#11410 piercing damage

### Attachment 2

#### Raw OCR Output:
Borrend:

Built into the side of a sheer cliff, Borrend is situated at end of a deep mountain
ravine, Generally considered unassailable, no army has ever claimed Borrend from the
Dwarves, Gnomes, and Half-lings that chiefly occupy the city. It has its own water
supply, and even steam machinery built into the walls and foundations. Much of this
knowledge has been lost over time, resulting in a growing decree of breakdowns,
decay, etc.

‘The upper area of the city where most live is still in decent shape, and a small but
proud Engineers Guild still calls the city home.

‘The current orc invasion is a problem not because they can likely break in, but
because they aren't giving up. There are a number of hidden underground passages
that dot the mountains and ravines in this area. Many of them lead to the underdark,
and the Drow are as formidable as ever.

>>Dark Secré

Borrend sits above what's generally known as the Borrend Catacombs - the source of
the decay. The truth of this place has been lost to time. Now only the brave and
foolish venture far past the city walls and barriers that lead further down into this
place. Kids make dares - how far can they go down the stairs before turning back?

‘The Catacombs have numerous wild monsters, and the players can encounter them
pretty much anywhere, at any time. There's a reason the walls are so sturdy...

#### ChatGPT Output:
### Borrend:

Built into the side of a sheer cliff, Borrend is situated at the end of a deep mountain
ravine. Generally considered unassailable, no army has ever claimed Borrend from the
Dwarves, Gnomes, and Halflings that chiefly occupy the city. It has its own water
supply, and even steam machinery built into the walls and foundations. Much of this
knowledge has been lost over time, resulting in a growing degree of breakdowns,
decay, etc.

The upper area of the city where most live is still in decent shape, and a small but
proud Engineers Guild still calls the city home.

The current orc invasion is a problem not because they can likely break in, but
because they aren't giving up. There are a number of hidden underground passages
that dot the mountains and ravines in this area. Many of them lead to the underdark,
and the Drow are as formidable as ever.

#### Dark Secret

Borrend sits above what's generally known as the Borrend Catacombs - the source of
the decay. The truth of this place has been lost to time. Now only the brave and
foolish venture far past the city walls and barriers that lead further down into this
place. Kids make dares - how far can they go down the stairs before turning back?

The Catacombs have numerous wild monsters, and the players can encounter them
pretty much anywhere, at any time. There's a reason the walls are so sturdy...

### Attachment 3

#### Raw OCR Output:
Dangling Threads:
Dissa: Working on making something from the manticore tail. Her time in the
caves with Captain Floriana will not go to waste. The fear of her helplessness
again has compelled her to once again make use of her family's ancient alchemical
secrets,

Poison on weapons: Lasts 2 hits or 30 minutes without training or equipment.
With training/poisoners tools, can last 4 hits / 4 hours.

Envenomed weapons count as training/poisoners tools automatically.
Long-duration poisons increase these to 6 hits / 1 day.

Drow poison: 1 Dose
Creatures struck with this weapon feel cold fire rush through their veins. They
must succeed on a DC12 constitution check or become paralyzed for the turn. This
effect persists until the creature saves. If the creature fails three checks, the effect
is considered permanent for the remaining hour without outside intervention.

#### ChatGPT Output:
### Dangling Threads:
- **Dissa**: Working on making something from the manticore tail. Her time in the
  caves with Captain Floriana will not go to waste. The fear of her helplessness
  again has compelled her to once again make use of her family's ancient alchemical
  secrets.

- **Poison on weapons**: Lasts 2 hits or 30 minutes without training or equipment.
  With training/poisoners tools, can last 4 hits / 4 hours.

  - Envenomed weapons count as training/poisoners tools automatically.
  - Long-duration poisons increase these to 6 hits / 1 day.

- **Drow poison**: 1 Dose
  - Creatures struck with this weapon feel cold fire rush through their veins. They
    must succeed on a DC12 constitution check or become paralyzed for the turn. This
    effect persists until the creature saves. If the creature fails three checks, the effect
    is considered permanent for the remaining hour without outside intervention.

### Attachment 4

#### Raw OCR Output:
Players will start breaking into the catacaombs:

Initial entrance: Still locked, door is battered. Can pick (de20) or break open
(dc20).

Monsters:
Gricks, Ropers, Grells, Gorgons, Hooked horrors, Modrons {buff stats),
skeletons (buff stats)

#### ChatGPT Output:
Players will start breaking into the catacombs:

- Initial entrance: Still locked, door is battered. Can pick (dc20) or break open (dc20).

Monsters:
- Gricks
- Ropers
- Grells
- Gorgons
- Hooked horrors
- Modrons (buff stats)
- Skeletons (buff stats)

### Attachment 5

#### Raw OCR Output:
Environmental Hazards:
Gnomish traps (explosives)

Dwarvish Traps (crushing)

Halfling Traps (Irresistible Dance, forced to dance in place,
DcI5wis)

Catacombs have a weird fog lingering throughout. It saps
the player's morale, and causes itching and scratching on
your skins. A level of exhaustion is applied every 24 hours
(ph291). Sleep does not remove this while in the fog.

#### ChatGPT Output:
Environmental Hazards:
- Gnomish traps (explosives)
- Dwarvish Traps (crushing)
- Halfling Traps (Irresistible Dance, forced to dance in place, DC 15 WIS)

Catacombs have a weird fog lingering throughout. It saps
the player's morale, and causes itching and scratching on
your skins. A level of exhaustion is applied every 24 hours
(PH 291). Sleep does not remove this while in the fog.

# Session 35 - Genie Fight

    **Created:** 2021-10-29 11:23:17  
    **Last Edited:** 2021-10-29 11:23:22  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into the session, we have Essafah the Djin squaring off against his old rival, Agar the Efreeti. While air and fire
never get along, these two genies have been feuding for hundreds of years (by mortal reckoning). Now Essafah has been
tricked to traveling to the Elemental Plane of Fire, and faces Agar on his home turf This insult and trap cannot go
unanswered, but a throw-down fight on his rivals home advantage is not really what Essafah had in mind either.

‘Agar, for his part, is looking to prove Essafah the fraud Djin that he is. Victory would mean elevation amongst the ranks
of genies, particularly among his many rival Efreeti princes. Agar wants this fight! Essafah is nat one to be outdone by
his rival, so this is going to go to blows for sure.

Fight setup:

Essafah is at the back, summoning air elementals and other air creatures to attack Agar. Agar is seriously pissed and has
summoned his own fire elementals with which to attack. Essafah is not stupid however, and has learned from his
previous duel. Unable to land direct magic on Agar, Essafah instead is going to summon lots and lots of flying monsters
to attack Agar.

Essafah motives:
1) Get his old family heirloom back from Agar. Essafah will summon an invisible stalker to do this,
a. kill Agar if possible. This is going to be difficult even for him on Agar's home plane
2) Overall: Cause trickery and mischief

‘Agar Motives:
1) Defeat Essafah and drive him off the fire plane
a. kill Essafah if possible. This will be difficult since he is merged with the Aether Flame and can control all
elemental magic! He has mastered this ability and Agar isn't ready for it.
2) Overall: Passionately create and destroy

Combat starts:
5x air elementals vs 5x fire elementals. Agar is in the back commanding his forces, Essafah on the other corner
commanding his. Essafah will also summon water and earth elementals (Galehb Dar maybe?) with which to attack the
players if they interfere. He can also use all magic available to other genies, and summon monsters from the Air Plane
(Roc is his favorite).

Outcome:
‘The PCs decided to join up with Agar - at least for the moment - and fought Essafah near Agar's lava throne. Essafah
hinted at his true power by summoning multiple elementals of different types, and even summoning elemental beasts -
such as the legendary Roc. Eventually Essafah grew bored and returned to his original plane of existence. That leaves the
PCs with Agar in the aftermath of the battle.

‘Agar and Essafah

‘The actual incident that sparked the feud was a social mishap at a great genie conjuring. Essafah, new to
the genie world, boasted of his incredible magick. Agar took him up on the boast, and the two engaged
in a genie duel. This contest of magick and will is a common sight amongst the genie, but this duel in
particular went down in infamy. Essafah underestimated Agar, and Agar's enchanted scimitar easily
melted Essafah's magic and attacks. Agar pressed his advantaged, forcing Essafah to unleash the Aether
Flame magick. Being of non-elemental origin, it caught Agar, and the assembled genies, completely by
surprise. Essafah won the duel, but lost the battle of Genie repuation. Agar maintained his pride by
claiming Essafah cheated, and claimed one of Essafah's prized heirlooms as both sign of his victory and
Essafah's false origins.

Potential Outcomes

‘Agar defeated - he will attempt to Plane shit to the city of brass first. This has a high potential to
succeed,

Agar Killed - He drops his
Consequences.

imitar of Molten Magic. As a prince of the fire realm, this will Have

Essafah defeated - he will attempt to Plane shift back to the air plane. This has a high potential to
succeed, Depending on how he is defeated, he may grant up to a Wish to the players. More likely, he is,
forced back to the Air plane without the party. In which case, Agar will entreat the PCs to join him in the
city of brass. Essafah will likely find his own PC group to entreat - maybe some shadow cultists...?

Essafah killed - He drops his Scimitar of Force as well as his geenie bottle, which contains the Aether
Flame. Unlike normal genies, he can be potentially restored from this state due to the power of the
Aether Flame.

Draw - Players might be returned to their original plane. Really depends on the circumstances of the
draw.

Essafah Claims family tapestry - He will claim this as victory and plane shift out. Agar will take this as an
insult and entreat the players to work together to restore the fire nation honor. Will result in them
traveling to the city of brass.

#### ChatGPT Output:
Coming into the session, we have Essafah the Djin squaring off against his old rival, Agar the Efreeti. While air and fire
never get along, these two genies have been feuding for hundreds of years (by mortal reckoning). Now Essafah has been
tricked to traveling to the Elemental Plane of Fire, and faces Agar on his home turf. This insult and trap cannot go
unanswered, but a throw-down fight on his rival's home advantage is not really what Essafah had in mind either.

Agar, for his part, is looking to prove Essafah the fraud Djin that he is. Victory would mean elevation amongst the ranks
of genies, particularly among his many rival Efreeti princes. Agar wants this fight! Essafah is not one to be outdone by
his rival, so this is going to go to blows for sure.

**Fight setup:**

Essafah is at the back, summoning air elementals and other air creatures to attack Agar. Agar is seriously pissed and has
summoned his own fire elementals with which to attack. Essafah is not stupid, however, and has learned from his
previous duel. Unable to land direct magic on Agar, Essafah instead is going to summon lots and lots of flying monsters
to attack Agar.

**Essafah motives:**
1) Get his old family heirloom back from Agar. Essafah will summon an invisible stalker to do this,
   a. kill Agar if possible. This is going to be difficult even for him on Agar's home plane.
2) Overall: Cause trickery and mischief.

**Agar Motives:**
1) Defeat Essafah and drive him off the fire plane
   a. kill Essafah if possible. This will be difficult since he is merged with the Aether Flame and can control all
      elemental magic! He has mastered this ability and Agar isn't ready for it.
2) Overall: Passionately create and destroy.

**Combat starts:**
5x air elementals vs 5x fire elementals. Agar is in the back commanding his forces, Essafah on the other corner
commanding his. Essafah will also summon water and earth elementals (Galehb Dar maybe?) with which to attack the
players if they interfere. He can also use all magic available to other genies, and summon monsters from the Air Plane
(Roc is his favorite).

**Outcome:**
The PCs decided to join up with Agar - at least for the moment - and fought Essafah near Agar's lava throne. Essafah
hinted at his true power by summoning multiple elementals of different types, and even summoning elemental beasts -
such as the legendary Roc. Eventually Essafah grew bored and returned to his original plane of existence. That leaves the
PCs with Agar in the aftermath of the battle.

**Agar and Essafah**

The actual incident that sparked the feud was a social mishap at a great genie conjuring. Essafah, new to
the genie world, boasted of his incredible magick. Agar took him up on the boast, and the two engaged
in a genie duel. This contest of magick and will is a common sight amongst the genie, but this duel in
particular went down in infamy. Essafah underestimated Agar, and Agar's enchanted scimitar easily
melted Essafah's magic and attacks. Agar pressed his advantaged, forcing Essafah to unleash the Aether
Flame magick. Being of non-elemental origin, it caught Agar, and the assembled genies, completely by
surprise. Essafah won the duel, but lost the battle of Genie reputation. Agar maintained his pride by
claiming Essafah cheated, and claimed one of Essafah's prized heirlooms as both sign of his victory and
Essafah's false origins.

**Potential Outcomes**

- *Agar defeated* - he will attempt to Plane shift to the city of brass first. This has a high potential to
  succeed.
- *Agar Killed* - He drops his Scimitar of Molten Magic. As a prince of the fire realm, this will have
  consequences.
- *Essafah defeated* - he will attempt to Plane shift back to the air plane. This has a high potential to
  succeed. Depending on how he is defeated, he may grant up to a Wish to the players. More likely, he is
  forced back to the Air plane without the party. In which case, Agar will entreat the PCs to join him in the
  city of brass. Essafah will likely find his own PC group to entreat - maybe some shadow cultists...?
- *Essafah killed* - He drops his Scimitar of Force as well as his genie bottle, which contains the Aether
  Flame. Unlike normal genies, he can be potentially restored from this state due to the power of the
  Aether Flame.
- *Draw* - Players might be returned to their original plane. Really depends on the circumstances of the
  draw.
- *Essafah Claims family tapestry* - He will claim this as victory and plane shift out. Agar will take this as an
  insult and entreat the players to work together to restore the fire nation honor. Will result in them
  traveling to the city of brass.

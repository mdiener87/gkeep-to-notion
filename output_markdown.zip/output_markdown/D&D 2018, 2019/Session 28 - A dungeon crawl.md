# Session 28 - A dungeon crawl

    **Created:** 2021-10-29 11:21:36  
    **Last Edited:** 2021-10-29 11:21:43  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming off skipped week due to everyone being ill -

On the previous session, the PC party continued their retreat from Chipahua. Their travels through the forest were
relatively uneventful. Kaetus talked with Plants and was able to learn the history of the area. An ancient human
Givilization once dwelled there; but fell to shadow long ago. The PCs continued towards El Enna and eventually met up
with the knight group dispatched by Captain Floriana, Headed by dwarf Lt. HammerStroke, the knight group escorted
the players back to El Enna.

‘Once in El Enna, the PCs got a taste of some combat finally by dispatching mafia members that wouldn't bend the knee
to the crown any longer. Floriana, officially tired of cultist bs - is on a'kill them all’ spree and ending the mafia's reign
over El Enna. With the mafia dispatched, they found another shadow cultist scroll...

So heading into session 28, the PCs have had lots of RP and little successful dice rolling as combat goes. Time to change
that! Let's dungeon crawl!

Area: The Weeping Forest / Lost Human City
Dungeon: Lair of Forgotten Sins
‘Theme: Yuan-ti, snakes + creepy crawlies

Asaathra: Possible tamed beasts:

Elephant
Giant Elk
Giant Lizard
Giant Spider
Giant Hyena
Crocodile
Bear
Tiger
Panther
Giant Scorpion
Boar

Ape
Eagle
Vulture
Blink Dog
‘Awakened Shrub
Owl Bear

Giant Mormo Lizard
AC 12 (natural armor}
HP 28

Speed: 20ft, climb:
STR: 15 (+2); DEX: 12 (#1), CON 13(+1), INT 2 (-4) WIS: 10 CHAS (-3)
Senses: Darkivsion 36ft, passive perception 14

Skills: Athletics +4

Traits:
Hold Breath: Can hold its breath for 15 minutes

Spider Climb: can climb difficult surfaces, including hanging upside down on ceilings, without making an
ability check

Mount: Can be ridden medium or smaller creatures

Actions:
Bite: melee weapon attack, +6, reach 5 ft, one target. Hit: 1d8 +4 piercing damage

‘Caustic Spit: ranged weapon attack +6, reach 30it, one target. Hit: 1d6 +4 acid damage. Target must
make a DC14 CON save or will be blinded until its next turn. An action may be used to remove this
effect.

#### ChatGPT Output:
Coming off skipped week due to everyone being ill -

On the previous session, the PC party continued their retreat from Chipahua. Their travels through the forest were
relatively uneventful. Kaetus talked with Plants and was able to learn the history of the area. An ancient human
civilization once dwelled there; but fell to shadow long ago. The PCs continued towards El Enna and eventually met up
with the knight group dispatched by Captain Floriana, Headed by dwarf Lt. HammerStroke, the knight group escorted
the players back to El Enna.

Once in El Enna, the PCs got a taste of some combat finally by dispatching mafia members that wouldn't bend the knee
to the crown any longer. Floriana, officially tired of cultist bs - is on a 'kill them all' spree and ending the mafia's reign
over El Enna. With the mafia dispatched, they found another shadow cultist scroll...

So heading into session 28, the PCs have had lots of RP and little successful dice rolling as combat goes. Time to change
that! Let's dungeon crawl!

Area: The Weeping Forest / Lost Human City
Dungeon: Lair of Forgotten Sins
Theme: Yuan-ti, snakes + creepy crawlies

Asaathra: Possible tamed beasts:

- Elephant
- Giant Elk
- Giant Lizard
- Giant Spider
- Giant Hyena
- Crocodile
- Bear
- Tiger
- Panther
- Giant Scorpion
- Boar
- Ape
- Eagle
- Vulture
- Blink Dog
- Awakened Shrub
- Owl Bear

Giant Mormo Lizard
AC 12 (natural armor)
HP 28

Speed: 20ft, climb:
STR: 15 (+2); DEX: 12 (+1), CON 13 (+1), INT 2 (-4) WIS: 10 CHA (-3)
Senses: Darkvision 36ft, passive perception 14

Skills: Athletics +4

Traits:
- Hold Breath: Can hold its breath for 15 minutes
- Spider Climb: can climb difficult surfaces, including hanging upside down on ceilings, without making an
ability check

Mount: Can be ridden by medium or smaller creatures

Actions:
- Bite: melee weapon attack, +6, reach 5 ft, one target. Hit: 1d8 +4 piercing damage
- Caustic Spit: ranged weapon attack +6, reach 30 ft, one target. Hit: 1d6 +4 acid damage. Target must
make a DC14 CON save or will be blinded until its next turn. An action may be used to remove this
effect.

# Session 40 - Secrets of the Aether Flame

    **Created:** 2021-10-29 11:24:57  
    **Last Edited:** 2021-10-29 11:25:07  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
So the PCs have the AF now. Welllp. That was unexpected. Time to crank things up to 11.
Kaladan is on a war rampage. The Kingdom has no hope of defeating him without the order of Sun and Moon about.

‘The Efreeti are embracing Shadow Religions and are creating Shadow Fire elementals. Portals to both the Shadow Realm
and the EPoF are staring to burn their way into the material realm at seemingly random intervals and locations.

Essafah is also going insane, and is going to lead his Cloud Giants + Air Elementals on a war path to retrieve it from
Ayden.

Scene opener:

Most of the players are over at Tinethras' manor, and Ayden is separate. The cultists can sense the AF and will be on him
like flies on shit. He will need to get to the PC party quickly somehow or be bogged down in fights against cultists. Also,
it's time to introduce that Invisible Stalker air elemental that's been after him for a while now.

Governor Floriana is caught by surprise by Ayden's sudden entrance. While she is nat in immediate danger, she is under
guard vs assassination attempts as her life has been repeatedly threatened by cultist assassins,
Party at the Manor:

‘The manor is under direct assault from cultists. The shadow elementals are all now shadow fire elementals, plus cultists.
Essafah may also try to send air elementals through the mirror.

‘Siege of Innui (cut short it’s been basically wiped out by the attack)

Kaladan will sense the AF's presence on the plane almost immediately. He will begin to fly towards the
manner and start trying to blast his way in. Meanwhile, cultists have been pouring through the Window
(one at a time) in an attempt to overwhelm the guards.

Result: A large scale battle broke out on the grounds of Tinethra's manor. After a pitched battle, in
which both Odesseuys and Elryis took extensive (new stat penalties for both), all manor guardians were
destroyed. They recovered a Wand of Fireballs aut of the bodies.

‘Ayden was able to return to his party members by finding the Thieve's Guild in El Enna. From there, he
intimidated his way to a teleportation circle, rolled a 99, and perfectly landed next to his extremely
injured and battle-wary friends.

Night falls, the window to TM forcefield is still open, and several war bands of cultits can be seen in the
‘woods, A familiar dragon shadow was also seen flying overhead the forest...

Player Injuries
Elryis:
Severe Lacerations: -1 Con -1str

Oddesseyus:
Puncture Wounds: -1 Con -1Dex

#### ChatGPT Output:
So the PCs have the AF now. Welllp. That was unexpected. Time to crank things up to 11.
Kaladan is on a war rampage. The Kingdom has no hope of defeating him without the order of Sun and Moon about.

'The Efreeti are embracing Shadow Religions and are creating Shadow Fire elementals. Portals to both the Shadow Realm
and the EPoF are starting to burn their way into the material realm at seemingly random intervals and locations.

Essafah is also going insane, and is going to lead his Cloud Giants + Air Elementals on a war path to retrieve it from
Ayden.

Scene opener:

Most of the players are over at Tinethras' manor, and Ayden is separate. The cultists can sense the AF and will be on him
like flies on shit. He will need to get to the PC party quickly somehow or be bogged down in fights against cultists. Also,
it's time to introduce that Invisible Stalker air elemental that's been after him for a while now.

Governor Floriana is caught by surprise by Ayden's sudden entrance. While she is not in immediate danger, she is under
guard vs assassination attempts as her life has been repeatedly threatened by cultist assassins,
Party at the Manor:

'The manor is under direct assault from cultists. The shadow elementals are all now shadow fire elementals, plus cultists.
Essafah may also try to send air elementals through the mirror.

'Siege of Innui (cut short it’s been basically wiped out by the attack)

Kaladan will sense the AF's presence on the plane almost immediately. He will begin to fly towards the
manor and start trying to blast his way in. Meanwhile, cultists have been pouring through the Window
(one at a time) in an attempt to overwhelm the guards.

Result: A large scale battle broke out on the grounds of Tinethra's manor. After a pitched battle, in
which both Odysseus and Elryis took extensive (new stat penalties for both), all manor guardians were
destroyed. They recovered a Wand of Fireballs out of the bodies.

'Ayden was able to return to his party members by finding the Thieve's Guild in El Enna. From there, he
intimidated his way to a teleportation circle, rolled a 99, and perfectly landed next to his extremely
injured and battle-weary friends.

Night falls, the window to TM forcefield is still open, and several war bands of cultists can be seen in the
woods. A familiar dragon shadow was also seen flying overhead the forest...

Player Injuries
Elryis:
Severe Lacerations: -1 Con -1 Str

Odysseus:
Puncture Wounds: -1 Con -1 Dex

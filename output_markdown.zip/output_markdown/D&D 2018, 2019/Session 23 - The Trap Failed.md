# Session 23 - The Trap Failed

    **Created:** 2021-10-29 11:19:40  
    **Last Edited:** 2021-10-29 11:19:50  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Kaldan's plan to bait the heroes into a booby trapped building failed, and some mooks died. For a dragon, this is a boring
outcome. Instead of worrying about the PCs, Kaladan has instead been reinforcing he cult's control over the other cities
in the kingdom. Kaladan is searching for a source of AetherFlame, and the cult has a bead on it...

‘The PCs don't know about this. They just got led by the nose to a trap. Will they realize the duplicity?
Gr will they try to just attack the dragon lair directly?

Searching the remains of the cultist rooms will reveal partially burned documents, thus describing the cultists
motivation.

If they don't even do that, just have an RP session with random encounters. Its time for the Thieves Guild to make a
showing with an assassination / kidnapping attempt on one af the PCs.

AetherFlame - this compound is thought not to exist on the material plane naturally. It can be brought
back from the Ethereal realm, and some rare samples are thought to exist.

Fomorian - 136

#### ChatGPT Output:
Kaldan's plan to bait the heroes into a booby trapped building failed, and some mooks died. For a dragon, this is a boring
outcome. Instead of worrying about the PCs, Kaladan has instead been reinforcing the cult's control over the other cities
in the kingdom. Kaladan is searching for a source of AetherFlame, and the cult has a bead on it...

‘The PCs don't know about this. They just got led by the nose to a trap. Will they realize the duplicity?
Or will they try to just attack the dragon lair directly?

Searching the remains of the cultist rooms will reveal partially burned documents, thus describing the cultists
motivation.

If they don't even do that, just have an RP session with random encounters. It's time for the Thieves Guild to make a
showing with an assassination / kidnapping attempt on one of the PCs.

AetherFlame - this compound is thought not to exist on the material plane naturally. It can be brought
back from the Ethereal realm, and some rare samples are thought to exist.

Fomorian - 136

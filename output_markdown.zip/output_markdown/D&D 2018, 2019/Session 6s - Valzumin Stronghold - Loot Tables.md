# Valzumin Stronghold - Loot Tables

    **Created:** 2021-10-29 11:10:12  
    **Last Edited:** 2021-10-29 11:10:20  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Magic items so far -
Bag of holding, the immovable rod, and Galtorarh's bracelet, And some +1 ammunition, Not much

5 items? One for every remaining player?

‘Shauglin Welcoming Party:
‘A pair of red elven gems, similar to the ones the players found earlier

‘Shauglin Raiding Party:
Circlet of blasting
Various loose gold pieces, totaling 1256

‘Observation Deck:

vault:
4x Healing Potions
Platinum coins worth 100g
Cloak of Protection
Sunblade

VIP Chambers:
Arcane documents describing the reality sphere
Can obtain how to expand/collapse it from these (DC20 collapse, DC30 expand)
Ring of Swimming
vValzumin's Family Crest - lost art object,
Loose gold and platinum totaling 250g

Boss Encounter:
Greater Healing Potion
Potion of Growth
Potion of Waterbreathing
‘Wand of the Warmage +1
Elven Shield +1
‘Adamantine Chain Mail Armor +1

#### ChatGPT Output:
Magic items so far -
- Bag of holding
- The immovable rod
- Galtorarh's bracelet
- And some +1 ammunition
- Not much

5 items? One for every remaining player?

**Shauglin Welcoming Party:**
- A pair of red elven gems, similar to the ones the players found earlier

**Shauglin Raiding Party:**
- Circlet of blasting
- Various loose gold pieces, totaling 1256

**Observation Deck:**

**Vault:**
- 4x Healing Potions
- Platinum coins worth 100g
- Cloak of Protection
- Sunblade

**VIP Chambers:**
- Arcane documents describing the reality sphere
  - Can obtain how to expand/collapse it from these (DC20 collapse, DC30 expand)
- Ring of Swimming
- Valzumin's Family Crest - lost art object
- Loose gold and platinum totaling 250g

**Boss Encounter:**
- Greater Healing Potion
- Potion of Growth
- Potion of Waterbreathing
- Wand of the Warmage +1
- Elven Shield +1
- Adamantine Chain Mail Armor +1

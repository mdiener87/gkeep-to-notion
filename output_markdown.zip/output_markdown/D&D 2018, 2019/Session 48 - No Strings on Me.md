# Session 48 - No Strings on Me

    **Created:** 2021-10-29 11:27:07  
    **Last Edited:** 2021-10-29 11:27:15  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Coming into this session, the party has evacuated the remaining civilians from Alluin. The city itself now belongs to the
dragon. The Kingdom of Dawn's capital, and many of its cities, are falling to the dragon's control. Things have never been
50 bleak for the Kingdom.

King Moryn and General Trynakiss were both successfully rescued, but his trusted Vizir, Oriana, was killed by Ruport's
Disintegrate spell during the evacuation.

‘The King is distraught. What cruel fate awaits his people? To live to see the end of his Kingdom. The General and Captain
both want to ride into battle. The king is also very grateful that some of his subjects live on, and has one final gift to
bestow upon Elyriss and the rest of the Order of Sun and Moon...

Ruport was never supposed to reach this level of power. The arcane power rads were created during the research into
the Aether Flame. By increasing his power in this way, not only has his magical power increased, but so too has he
unlocked further aspects of his personality, of his understanding of the world and Lord Tinethra. Tinethra himsetf feared
Ruport's true potential, and never enabled him further than level 4 (and even then, only for a brief duration. Ruport
possesses tremendous intellect and analytical ability - where are his ambitions and desires taking him now?

Kaladan is overjoyed. The kingodm burns and the citizens worship him as the new king. But his task remains incomplete.
He must find the Aether Flame and use it to tear assunder the border between the Shadow and Material realms.

Dragon's Lair:
Level 1 Lightening Orb:
Double's Dragon's Breath Weapon Recharge Ability
Level 2 Shadow Orb :
Increases Dragon's AC, Saves by +2
Level 3 Blood Orb:
Increases Dragons HP by 100%
All removed:
Inability to use lair actions

Destroying Orb will create a lightening elemental

‘wyrmlings
‘Those dragon demon things from MTF

#### ChatGPT Output:
Coming into this session, the party has evacuated the remaining civilians from Alluin. The city itself now belongs to the  
dragon. The Kingdom of Dawn's capital, and many of its cities, are falling to the dragon's control. Things have never been  
so bleak for the Kingdom.

King Moryn and General Trynakiss were both successfully rescued, but his trusted Vizir, Oriana, was killed by Ruport's  
Disintegrate spell during the evacuation.

The King is distraught. What cruel fate awaits his people? To live to see the end of his Kingdom. The General and Captain  
both want to ride into battle. The king is also very grateful that some of his subjects live on, and has one final gift to  
bestow upon Elyriss and the rest of the Order of Sun and Moon...

Ruport was never supposed to reach this level of power. The arcane power rods were created during the research into  
the Aether Flame. By increasing his power in this way, not only has his magical power increased, but so too has he  
unlocked further aspects of his personality, of his understanding of the world and Lord Tinethra. Tinethra himself feared  
Ruport's true potential, and never enabled him further than level 4 (and even then, only for a brief duration). Ruport  
possesses tremendous intellect and analytical ability - where are his ambitions and desires taking him now?

Kaladan is overjoyed. The kingdom burns and the citizens worship him as the new king. But his task remains incomplete.  
He must find the Aether Flame and use it to tear asunder the border between the Shadow and Material realms.

### Dragon's Lair:
- **Level 1 Lightning Orb:**
  - Doubles Dragon's Breath Weapon Recharge Ability
- **Level 2 Shadow Orb:**
  - Increases Dragon's AC, Saves by +2
- **Level 3 Blood Orb:**
  - Increases Dragons HP by 100%
- **All removed:**
  - Inability to use lair actions

Destroying Orb will create a lightning elemental

Wyrmlings  
Those dragon demon things from MTF

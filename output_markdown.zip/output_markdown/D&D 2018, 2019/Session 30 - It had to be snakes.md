# Session 30 - It had to be snakes

    **Created:** 2021-10-29 11:22:17  
    **Last Edited:** 2021-10-29 11:22:24  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘The party is still down in the dungeon. Let's wrap it up today and let them get back to adventuring at the end of it. IF
they survive

Pare down the encounters as following:
Second floor:

‘Snake Hallway Maze
Leads to
Gochery 1 > Boss Switch A (gold), Hidden Switch C (silver)
Gochery 2 > Boss Switch B (gold), Hidden Switch D (black)
Trap Room (C} (
Torture Room (stairs to) (D)
Boss Room (stairs to} (A, B)

Third floor:
Boss Room
“

Torture Chamber

Greater Mimic
Large Monstrosity (shapechanger), Neutral

AC: 16 (natural armor)

Hit Points: 155

Speed: 20

Str: 20 (#5), Dex 14 (+2), Con 19 (+4), Int 6 (-3), Wis 16 (+3), Cha 9 (-1)
Skills: Stealth +7

Damage immunities: Acid

Condition Immunities: Prone

‘Senses: Darkvision 60 ft, passive perception 13,

Language
Challenge CR 8 (3900 XP)

‘Shapechanger: The mimic can use its action to polymorph into an object or into its true, amorphous form. t's
statistics are the same in each form. Any equipment it is wearing or carrying isn’t transformed. It reverts to its
‘true form ifit dies.

Adhesive (Object Form Only). The mimic adheres to anything that touches it. A huge or smaller creature
adhered to the mimicis also grappled by it (Escape DC 18) Ability checks made to escape this grapple have
disadvantage.

False Appearance (Object Form Only). While the mimic remains motionless, itis indistinguishable from an
ordinary object.

Grappler The mimic has advantage on attack rolls against any creature grappled by it

Actions: Multiattack. The mimic makes two attacks, one with its pseudopod and one bite attack. ifthe mimic
is grappling a creature it makes two bite attacks against that creature instead.

Pseudopod. Melee Weapon Attack: +8 to hit, reach 5ft, one target Hit: (13) 2d8 +5 bludgeoning damage. if
the mimic isin object form, the target is subject to its Adhesive Trait.

Bite, Melee Weapon Attack: +8 to hit, reach Sft, one target Hit: (13) 2d8 +5 piercing damage + (8) 248 Acid
acid damage.

Comment

#### ChatGPT Output:
'The party is still down in the dungeon. Let's wrap it up today and let them get back to adventuring at the end of it. IF
they survive

Pare down the encounters as following:
Second floor:

- Snake Hallway Maze
  Leads to
  - Gochery 1 > Boss Switch A (gold), Hidden Switch C (silver)
  - Gochery 2 > Boss Switch B (gold), Hidden Switch D (black)
  - Trap Room (C)
  - Torture Room (stairs to) (D)
  - Boss Room (stairs to) (A, B)

Third floor:
- Boss Room

Torture Chamber

Greater Mimic
Large Monstrosity (shapechanger), Neutral

AC: 16 (natural armor)

Hit Points: 155

Speed: 20

Str: 20 (+5), Dex 14 (+2), Con 19 (+4), Int 6 (-3), Wis 16 (+3), Cha 9 (-1)
Skills: Stealth +7

Damage immunities: Acid

Condition Immunities: Prone

Senses: Darkvision 60 ft, passive perception 13,

Language
Challenge CR 8 (3900 XP)

Shapechanger: The mimic can use its action to polymorph into an object or into its true, amorphous form. Its
statistics are the same in each form. Any equipment it is wearing or carrying isn’t transformed. It reverts to its
true form if it dies.

Adhesive (Object Form Only): The mimic adheres to anything that touches it. A huge or smaller creature
adhered to the mimic is also grappled by it (Escape DC 18). Ability checks made to escape this grapple have
disadvantage.

False Appearance (Object Form Only): While the mimic remains motionless, it is indistinguishable from an
ordinary object.

Grappler: The mimic has advantage on attack rolls against any creature grappled by it.

Actions: Multiattack. The mimic makes two attacks, one with its pseudopod and one bite attack. If the mimic
is grappling a creature, it makes two bite attacks against that creature instead.

Pseudopod. Melee Weapon Attack: +8 to hit, reach 5 ft, one target. Hit: (13) 2d8 +5 bludgeoning damage. If
the mimic is in object form, the target is subject to its Adhesive Trait.

Bite. Melee Weapon Attack: +8 to hit, reach 5 ft, one target. Hit: (13) 2d8 +5 piercing damage + (8) 2d8 Acid
acid damage.

Comment

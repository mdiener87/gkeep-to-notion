# Session 50 - 50 Sessions

    **Created:** 2021-10-29 11:27:30  
    **Last Edited:** 2021-10-29 11:27:40  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Continuing into the dragon cave. Kaladan fight is probably next Session. Refer to map notes.

#### ChatGPT Output:
Continuing into the dragon cave. Kaladan fight is probably next Session. Refer to map notes.

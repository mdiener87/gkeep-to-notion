# Session 27 - Its going to be made up

    **Created:** 2021-10-29 11:21:18  
    **Last Edited:** 2021-10-29 11:21:31  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Previously, the PCs defeated a Giant (infant) Sandwurm that the Cult unleashed on the players as they fled Chipahua.
While the PCs proved victorious in the end, Gnash, Asaathra's loyal companion, was consumed and killed by the beast.
Gutting and harvesting the creature yielded a variety of magical items, plus sandwurm scales that might be crafted into
armor later.

The players will be opening following the looting, still in the afternoon. Dark riders previously rode out of Chipahua in
pursuit of the players, but with the Wurm's demise the dragon is going to call them back - he has other objectives.
Namely, political influence and finding a source of the Aether flame. The riders will not head towards the players, but
instead keep heading towards Chipahua. Kaladan will deal with the Knights during the next night.

‘The players have a few options:
Chase / intercept the riders?
Head towards Chipahua / the Onyx mountain again
Head towards El Enna
Explore the Forest / Dungeon Dive
-> Sets up for next time, a dungeon expedition!

Otherwise, random encounters and ad hoc it, tired

#### ChatGPT Output:
Previously, the PCs defeated a Giant (infant) Sandwurm that the Cult unleashed on the players as they fled Chipahua.  
While the PCs proved victorious in the end, Gnash, Asaathra's loyal companion, was consumed and killed by the beast.  
Gutting and harvesting the creature yielded a variety of magical items, plus sandwurm scales that might be crafted into  
armor later.

The players will be opening following the looting, still in the afternoon. Dark riders previously rode out of Chipahua in  
pursuit of the players, but with the Wurm's demise the dragon is going to call them back - he has other objectives.  
Namely, political influence and finding a source of the Aether flame. The riders will not head towards the players, but  
instead keep heading towards Chipahua. Kaladan will deal with the Knights during the next night.

The players have a few options:  
- Chase / intercept the riders?  
- Head towards Chipahua / the Onyx mountain again  
- Head towards El Enna  
- Explore the Forest / Dungeon Dive  
  -> Sets up for next time, a dungeon expedition!

Otherwise, random encounters and ad hoc it, tired

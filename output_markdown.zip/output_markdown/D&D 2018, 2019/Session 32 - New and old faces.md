# Session 32 - New and old faces

    **Created:** 2021-10-29 11:22:42  
    **Last Edited:** 2021-10-29 11:22:47  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
‘Alex is joining our party, coming in as a ranger. We will create his character today, somewhere in 4-6 range. Thinking 5?
Gr is that too low? Should look at ranger and see any obvious breakpoints.

Asfor story —

‘The PC party has defeated the Lair of Forgotten Sins! Enriched with gold and magical weapons, they'll no doubt want to
head back to El Enna for shopping and story progression. Meanwhile, the Weeping Woods have had their spirit Dryads
restored, and a newfound sense of life and bounty can be found. The birds are chirping and the sun is shining!

Kaladan has not been idle, While the PCs dungeon dived (and essentially fell off the map) he has been busy making
inroads throughout the kingdom. Cultist spies seem to lurk around every corner. His spies search for Tiltathana- a long
lost elven manor dating back to the great ages of Elves. If any source might hold the Aether Flame within the kingdom, it
‘would surely be within its walls.

Even if he cannot find the flame, his minions have furthered their mastery of shadow dominion over the monsters of the
Kingdom. New Shadow beasts await to fight, as well as more powerful wizards!

Isabella Family Ring - One of the founding members of the eastern Towns

Cultist Wizard - See Drow Mage 129

Apply Shadow Typing to these as needed:
Oni

Perytons

Bone Naga

Quaggoth

Shadows

Wraiths

Trolls

Bulette

Basilisk

‘Shadow Demons
vrocks

Alex Loot:
Option 1:
Brooch of Shielding
Staff of the Python
Cloak of Elvenkind

Option 2:
Boots of the Winterlands
Gloves of Missile Snaring
Eyes of Charming

+1 Longbow
20x +1 Enchanted Arrows
2x Pation of Healing

1x Potion of Greater Healing

Jasper Purchases:
Perfect Painters Brush
You Roll painting checks with advantage

Gnomish Do Not Disturb Mechanism x3
‘When you touch a locking mechanism with this device ,if tt does not already
have a trap mechanism installed, this device will burrow inside the lock and
apply a trap. Creatures that attempt to open the lock without the key will
trigger the trap.

‘Trap Poison: 2010 Poison Damage on a failed save, or half on a succesfull
one. The creature is considered poisoned for the next hour.

#### ChatGPT Output:
‘Alex is joining our party, coming in as a ranger. We will create his character today, somewhere in 4-6 range. Thinking 5?
Gr is that too low? Should look at ranger and see any obvious breakpoints.

As for story —

‘The PC party has defeated the Lair of Forgotten Sins! Enriched with gold and magical weapons, they'll no doubt want to
head back to El Enna for shopping and story progression. Meanwhile, the Weeping Woods have had their spirit Dryads
restored, and a newfound sense of life and bounty can be found. The birds are chirping and the sun is shining!

Kaladan has not been idle, While the PCs dungeon dived (and essentially fell off the map) he has been busy making
inroads throughout the kingdom. Cultist spies seem to lurk around every corner. His spies search for Tiltathana- a long
lost elven manor dating back to the great ages of Elves. If any source might hold the Aether Flame within the kingdom, it
would surely be within its walls.

Even if he cannot find the flame, his minions have furthered their mastery of shadow dominion over the monsters of the
Kingdom. New Shadow beasts await to fight, as well as more powerful wizards!

Isabella Family Ring - One of the founding members of the eastern Towns

Cultist Wizard - See Drow Mage 129

Apply Shadow Typing to these as needed:
- Oni
- Perytons
- Bone Naga
- Quaggoth
- Shadows
- Wraiths
- Trolls
- Bulette
- Basilisk
- Shadow Demons
- Vrocks

Alex Loot:
Option 1:
- Brooch of Shielding
- Staff of the Python
- Cloak of Elvenkind

Option 2:
- Boots of the Winterlands
- Gloves of Missile Snaring
- Eyes of Charming
- +1 Longbow
- 20x +1 Enchanted Arrows
- 2x Potion of Healing
- 1x Potion of Greater Healing

Jasper Purchases:
- Perfect Painters Brush
  You Roll painting checks with advantage

- Gnomish Do Not Disturb Mechanism x3
  When you touch a locking mechanism with this device, if it does not already
  have a trap mechanism installed, this device will burrow inside the lock and
  apply a trap. Creatures that attempt to open the lock without the key will
  trigger the trap.

  Trap Poison: 20% Poison Damage on a failed save, or half on a successful
  one. The creature is considered poisoned for the next hour.

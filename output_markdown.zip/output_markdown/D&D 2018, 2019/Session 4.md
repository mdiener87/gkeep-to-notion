# Session 4

    **Created:** 2021-10-29 11:07:39  
    **Last Edited:** 2021-10-29 11:08:55  
    **Labels:** D&D 2018, 2019  

    ---

    ## Note Content (HTML)

Primer Notes:
Players have just defeated the first boss - but many questions remain. Who was this ghost, and why was he terrorizing
the village? What was he trying to warn everyone about? What was the mysterious Elven Bracelet that was left behind?
Group options:
Probably return to the village and see what changes are there
Discover / advance plot threads
Open terrain exploration into the unknown
.
O
Plot threads:
The war of Wartimor (name pending)(war with the orcs - eastward)
Kingdom has been sucked into an endless war with the orc hordes to the east of the continent. So have the
orcs. The whole thing is a double setup by a powerful demon seeking to fuel a portal powerful enough that
he might cross into the material plane.
o Kingdom is becoming increasingly militant and is conscripting / recruiting everyone they can to help fight the
orcs. They are slowly losing ground in a bloody, endless grinder.
o This starting village is far enough away that it is only now becoming affected. -> Have a 'recruitment' division
sweep through the village to conscript able-bodied men and try to hire the adventurers as a merc group.
Lord Goltorah's Bracelet
Elven Bracelet, Magical
3 Charges, refreshed at midnight
Consume a charge as a bonus action to:
Gain +1 bonus on saving throws until your next turn
Gain +1 bonus on AC until your next turn
Increase Spell Attack or Spell Save DC by 1 until your next turn
Gain +1 bonus on a spell concentration check
Cursed with Goltrah's Portent
When socially interacting with any entity the shade of Goltorah might reasonably interpret as a 'threat
to the kingdom or life on the material plane', will attempt to take over wielder (DC 15 charisma check,
+1 DC for every successful save vs this effect today). Failure will cause Goltorah to socially take control
and probably make a scene.
The Drow
Drow Decoded Document Contains the name of two elven keeps also on the Drow hit list for this area:
Valzumin Stronghold
Lost to history, its only recorded as being somewhere in the mountains north of here. This
stronghold is a forest-canopy stronghold, with old elven buildings hoisted high in the forest
trees. Damaged and broken bridges link the stronghold rooms together.
A necromancer once tried to claim this stronghold and its elven magick for himself. Now the
dungeon is filled with aberrations, undead, and the occasionally active elven trap.
Tower of Bithyra :
Drow have infiltrated this tower already and are busy trying to gain access to its inner sanctum.
Players will be constantly accosted by Drow scouting and raiding parties while trying to explore
the dungeon.
Plenty of traps active
Also contains a decoded alert- the (Aarons' Elven family name] has put an Extradition request out for
[Aaron's character). The Drow orders are to find Aaron first and blackmail the high elves for losing a
daughter in such an unseeingly fashion.
o Raiding parties are hunting through human lands now that the kings forces are all tied up to the East. Little
security presence remains and the raids are growing more brazen.
Encounters for today:
Random encounters while traveling - Drow raids + random monster encounters as appropriate.
Players traveling to-> [City 2]
Might fight with the recruitment garrison (priests and warriors) if they screw up the socials too badly
Drow raiding party will ambush in route
Possible encounters:
Etins
Drow Raiding parties
Forest Random Encounter roll (xanthars 97)
Hill Giants
Lycanthropes (209)
Trolls
Forest encounters should be low sightline to the sides, allowing monsters or ambushing parties partial cover +
likely an elevation advantage to start. Keep terrain interesting.

*Note: This note contains formatted HTML content that can be viewed in the HTML version.*


    ## Attachments

### Attachment 1

#### Raw OCR Output:
Primer Notes:

Players have just defeated the first boss - but many questions remain. Who was this ghost, and why was he terrorizing
the village? What was he trying to warn everyone about? What was the mysterious Elven Bracelet that was left behind?

Group options:
Probably return to the village and see what changes are there
Discover / advance plot threads

Open terrain exploration into the unknown

Plot threads:
= The war of Wartimor (name pending)(war with the orcs - eastward)

(© Kingdom has been sucked into an endless war with the orc hordes to the east of the continent. So have the
ores. The whole thing is a double setup by a powerful demon seeking to fuel a portal powerful enough that
he might cross into the material plane.

© Kingdom is becoming increasingly militant and is conscripting / recruiting everyone they can to help fight the
ores. They are slowly losing ground in a bloody, endless grinder.

© This starting village is far enough away that itis only now becoming affected, -> Have a ‘recruitment! division
sweep through the village to conscript able-bodied men and try to hire the adventurers asa merc group.

* Lord Gottorah's Bracelet

© Elven Bracelet, Magical

© 3Charges, refreshed at midnight

© Consume a charge as a bonus action to:

= Gain +1 bonus on saving throws until your next turn
= Gain +1 bonus on AC until your next turn
= Increase Spell Attack or Spell Save DC by 1 until your next turn
= Gain +1 bonus on a spell concentration check
© Cursed with Goltrah's Portent
= When socially interacting with any entity the shade of Goltorah might reasonably interpret as a ‘threat
to the kingdom or life on the material plane’, will attempt to take over wielder (DC 15 charisma check,
+1 DC for every successful save vs this effect today). Failure will cause Goltorah to socially take control
and probably make a scene.
+ The Drow
© Drow Decoded Document Contains the name of two elven keeps also on the Drow hit list for this area:
= Valzumin Stronghold
10 Lost to history, its only recorded as being somewhere in the mountains north of here. This
stronghold is a forest-canopy stronghold, with old elven buildings hoisted high in the forest
trees. Damaged and broken bridges link the stronghold rooms together.
10. Anecromancer once tried to claim this stronghold and its elven magick for himself. Now the
dungeon is filled with aberrations, undead, and the occasionally active elven trap.
= Tower of Bithyra
10. Drow have infiltrated this tower already and are busy trying to gain access to its inner sanctum.
Players will be constantly accosted by Drow scouting and raiding parties while trying to explore
the dungeon.
10 Plenty of traps active

© Also contains a decoded alert - the [Aarons' Elven family name] has put an Extradition request out for
[Aaron's character]. The Drow orders are to find Aaron first and blackmail the high elves for losing a
daughter in such an unseeingly fashion.

© Raiding parties are hunting through human lands now that the kings forces are all tied up to the East. Little
security presence remains and the raids are growing more brazen.

Encounters for today:
Random encounters while traveling - Drow raids + random monster encounters as appropriate.

Players traveling to > [city 2]
Might fight with the recruitment garrison (priests and warriors) if they screw up the socials too badly
Drow raiding party will ambush in route

Possible encounters:
Etins
Drow Raiding parties
Forest Random Encounter roll (xanthars 97)
Hill Giants

Lycanthropes (209)
Trolls

Forest encounters should be low sightline to the sides, allowing monsters or ambushing parties partial cover +
likely an elevation advantage to start. Keep terrain interesting.

#### ChatGPT Output:
**Primer Notes:**

Players have just defeated the first boss - but many questions remain. Who was this ghost, and why was he terrorizing
the village? What was he trying to warn everyone about? What was the mysterious Elven Bracelet that was left behind?

**Group options:**
- Probably return to the village and see what changes are there
- Discover / advance plot threads
- Open terrain exploration into the unknown

**Plot threads:**
- The war of Wartimor (name pending)(war with the orcs - eastward)
  - Kingdom has been sucked into an endless war with the orc hordes to the east of the continent. So have the
    orcs. The whole thing is a double setup by a powerful demon seeking to fuel a portal powerful enough that
    he might cross into the material plane.
  - Kingdom is becoming increasingly militant and is conscripting / recruiting everyone they can to help fight the
    orcs. They are slowly losing ground in a bloody, endless grinder.
  - This starting village is far enough away that it is only now becoming affected, -> Have a ‘recruitment! division
    sweep through the village to conscript able-bodied men and try to hire the adventurers as a merc group.

- **Lord Gottorah's Bracelet**
  - Elven Bracelet, Magical
  - 3 Charges, refreshed at midnight
  - Consume a charge as a bonus action to:
    - Gain +1 bonus on saving throws until your next turn
    - Gain +1 bonus on AC until your next turn
    - Increase Spell Attack or Spell Save DC by 1 until your next turn
    - Gain +1 bonus on a spell concentration check
  - Cursed with Goltrah's Portent
    - When socially interacting with any entity the shade of Goltorah might reasonably interpret as a ‘threat
      to the kingdom or life on the material plane’, will attempt to take over wielder (DC 15 charisma check,
      +1 DC for every successful save vs this effect today). Failure will cause Goltorah to socially take control
      and probably make a scene.

- **The Drow**
  - Drow Decoded Document Contains the name of two elven keeps also on the Drow hit list for this area:
    - Valzumin Stronghold
      - Lost to history, it's only recorded as being somewhere in the mountains north of here. This
        stronghold is a forest-canopy stronghold, with old elven buildings hoisted high in the forest
        trees. Damaged and broken bridges link the stronghold rooms together.
      - A necromancer once tried to claim this stronghold and its elven magick for himself. Now the
        dungeon is filled with aberrations, undead, and the occasionally active elven trap.
    - Tower of Bithyra
      - Drow have infiltrated this tower already and are busy trying to gain access to its inner sanctum.
        Players will be constantly accosted by Drow scouting and raiding parties while trying to explore
        the dungeon.
      - Plenty of traps active

  - Also contains a decoded alert - the [Aarons' Elven family name] has put an Extradition request out for
    [Aaron's character]. The Drow orders are to find Aaron first and blackmail the high elves for losing a
    daughter in such an unseemly fashion.

  - Raiding parties are hunting through human lands now that the king's forces are all tied up to the East. Little
    security presence remains and the raids are growing more brazen.

**Encounters for today:**
- Random encounters while traveling - Drow raids + random monster encounters as appropriate.

Players traveling to > [city 2]
- Might fight with the recruitment garrison (priests and warriors) if they screw up the socials too badly
- Drow raiding party will ambush en route

**Possible encounters:**
- Etins
- Drow Raiding parties
- Forest Random Encounter roll (xanthars 97)
- Hill Giants
- Lycanthropes (209)
- Trolls

Forest encounters should be low sightline to the sides, allowing monsters or ambushing parties partial cover +
likely an elevation advantage to start. Keep terrain interesting.

### Attachment 2

#### Raw OCR Output:
World travel - switch to hexes

[Alluin] is 10 hexes away. Players can travel 1 hex by day through rough terrain, 2 through OK terrain,
and three through roads.

Nearby areas: dense forests with a road leading to town 2. Going north gets hilly, going south levels out
to plains and the start of deserts (costal and flat deserts). Going west takes them to the western edge of
the kingdom, into the unclaimed wilds [roll terrain types]

#### ChatGPT Output:
World travel - switch to hexes

[Alluin] is 10 hexes away. Players can travel 1 hex by day through rough terrain, 2 through OK terrain,
and three through roads.

Nearby areas: dense forests with a road leading to town 2. Going north gets hilly, going south levels out
to plains and the start of deserts (coastal and flat deserts). Going west takes them to the western edge of
the kingdom, into the unclaimed wilds [roll terrain types]

### Attachment 3

#### Raw OCR Output:
Alluin - likely will get here

Governor - []

Mages Guild - 1
Trades Guild - []
Champions Guild - 0
Markets -[]
Spiritual Leader - 1

Center of the town lies the old abandoned elven keep (Tower of Bithyra). Itis considered a cultural
heirloom, atime dating back to the old Elven kingdom. The olde town still resides within the walls of the
keep, and the Town governing council meets in the old high levels. Unbenknowns to most, there is an
entire subterranean section of this keep that has gone long-unexplored.

Secret side entrance lies out of town
Primary entrance is a hidden and magically protected wall in the 'Town-Hall’, Leads to a vertical drop
down into the dungeon

#### ChatGPT Output:
Alluin - likely will get here

Governor - []

Mages Guild - 1  
Trades Guild - []  
Champions Guild - 0  
Markets -[]  
Spiritual Leader - 1  

Center of the town lies the old abandoned elven keep (Tower of Bithyra). It is considered a cultural  
heirloom, a time dating back to the old Elven kingdom. The old town still resides within the walls of the  
keep, and the Town governing council meets in the old high levels. Unbeknownst to most, there is an  
entire subterranean section of this keep that has gone long-unexplored.  

Secret side entrance lies out of town  
Primary entrance is a hidden and magically protected wall in the 'Town-Hall’, Leads to a vertical drop  
down into the dungeon

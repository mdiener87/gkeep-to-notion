# Session 1 Encounters

    **Created:** 2021-10-29 11:01:54  
    **Last Edited:** 2021-10-29 11:01:59  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Scene One: outside of keep entrance
Players need to wait for light of full moon for entrance to work. Various destroyed elven writing will hint at this
Door is locked once found, will need to pick/destroy lock.

‘While waiting around, players will be snuck up by two Drow scouts. They are ancient descendants of the Elves to
this land. They might be negotiated with; they wish to prevent desecration of ancient tombs of their people. if
players can convince them that there are restless spirits, they will give them the key to the keep entrance. But
might let them pass if they convince they will not loot the crypt.

‘Scout page 349 DM. They are Drow and have dancing lights
Drow page 128

Scene Two: exploring keep first level
Entrance opens into large hall, covered in old spider webs, ruinded tapestries, and broken statues. A large spider lurks in

one corner. It will wait until a player tries to interact with the webbing and get stuck. Or the PCs can distract it with food
(somehow?) or attack it early if they spot it (lurking on ceiling, DC20 spot)

Entrance has doorways to the left and right. The forward room is sealed shut, players will need to find a way to open the
door.
LEFT

Long, winding hallways with poor visibility. An Goze lurks around a blind corner. Will the players walk into it and be
engulfed?

Gozes page 243
Side Rooms:
Left A: (treasure)

‘A hidden door on another side hallway has a chest, It's buried in rubble and will need to be cleared around (str
checks, fail will cause the roof to collapse in the room).

Left B:
Ancient elven armory covered in spider webs. Dicking around with the webs might cause more enemies to appear
(spider swarm? Check for something approps). This is a fakeout room - there is no treasure, just lots of webs and
old Elven weapons.

Left ¢: {treasure)(trap)
Secure storeroom. Two chests look looted, but one is clearly still intact and locked.
Chest: Locked (DC20)
Chest: Trapped (DC20) - fail (+5 hit, DC20 CON or 2D6 poison, paralyzed for one hour)
If trap goes off, will close and lock the door to the storeroom
Piercers MM252 lurk in the ceiling above, will drop when people try to open the chest and fail

Meanwhile a shadow (MM 269) of a previous victim will haunt those in the hall while the door shuts.

Right: (switch)
‘Adark, descending staircase. tt eventually opens into a larger room with a collapsed floor in the center (20ft deep,

strewn rubble at the bottom, 10-20ft across)

‘Across the room lies a switch. Throwing it opens the hidden door in the central room. Throwing the switch makes a large
amount of noise and takes a DC15 check to pass. There is a hidden trap switch on the main switch (DC15 to
spot/interact). If not disabled, will make the stairs down to this chamber smooth (DC15 acrobatics to move up).

Can re-interact with the switch to raise stairs again.

Interacting with the switch will cause animated armor and swords in the room to attack the players. Armor is near the
switch, while swords start on the other side of the chasm. Swords might start at lower initiative depending on how
players handle things.

Forward Room: (locked by switch)(boss)(treasure}(trap)

Boss encounter for this level: ogre page 237

He has been trying to find access into the crypt but can't open the elven door in the wall and has been stuck for days in
the keep. Probably can't talk way out of fight, watch damage output. Modulate HP to make this harder as needed.

(Ogre has a knapscak in one corner with treasure he has looted from the keep.
4 statues in the center (one destroyed) all blast lines of fire (20ft, 1D6 +2, DC15 reflex) when non-elves walk in front of
them. These statues guard the entrance to the tomb. The ogre has destroyed one that already got in his way.

‘The statues can be disabled (arcana / thieves toal) and looted to take their elven crystals (worth “106 each}

Disabling all four statues also reveals a hidden chamber with loot inside. The chamber could be located normally (DC20}
but isn't likely.

‘Add random encounters as fit and time allows as they explore the first level. This is a former drow (elven) temple, so
spider /watchful theme and have spider encounters as well. MM 328 for spiders. Add webbing complications and holes
in walls for spider areas. (webbing: DC15str check or prone/restrained)

Piercers

Loot: refer to DM 137 XR 133

#### ChatGPT Output:
### Scene One: outside of keep entrance
Players need to wait for light of full moon for entrance to work. Various destroyed elven writing will hint at this.
Door is locked once found, will need to pick/destroy lock.

While waiting around, players will be snuck up by two Drow scouts. They are ancient descendants of the Elves to
this land. They might be negotiated with; they wish to prevent desecration of ancient tombs of their people. If
players can convince them that there are restless spirits, they will give them the key to the keep entrance. But
might let them pass if they convince they will not loot the crypt.

- Scout page 349 DM. They are Drow and have dancing lights
- Drow page 128

### Scene Two: exploring keep first level
Entrance opens into large hall, covered in old spider webs, ruined tapestries, and broken statues. A large spider lurks in
one corner. It will wait until a player tries to interact with the webbing and get stuck. Or the PCs can distract it with food
(somehow?) or attack it early if they spot it (lurking on ceiling, DC20 spot).

Entrance has doorways to the left and right. The forward room is sealed shut, players will need to find a way to open the
door.

#### LEFT

Long, winding hallways with poor visibility. An Goze lurks around a blind corner. Will the players walk into it and be
engulfed?

- Gozes page 243

**Side Rooms:**

**Left A:** (treasure)

A hidden door on another side hallway has a chest. It's buried in rubble and will need to be cleared around (str
checks, fail will cause the roof to collapse in the room).

**Left B:**

Ancient elven armory covered in spider webs. Dicking around with the webs might cause more enemies to appear
(spider swarm? Check for something approps). This is a fakeout room - there is no treasure, just lots of webs and
old Elven weapons.

**Left C:** (treasure)(trap)

Secure storeroom. Two chests look looted, but one is clearly still intact and locked.
- Chest: Locked (DC20)
- Chest: Trapped (DC20) - fail (+5 hit, DC20 CON or 2D6 poison, paralyzed for one hour)
If trap goes off, will close and lock the door to the storeroom.
Piercers MM252 lurk in the ceiling above, will drop when people try to open the chest and fail.

Meanwhile, a shadow (MM 269) of a previous victim will haunt those in the hall while the door shuts.

#### Right: (switch)

A dark, descending staircase. It eventually opens into a larger room with a collapsed floor in the center (20ft deep,
strewn rubble at the bottom, 10-20ft across).

Across the room lies a switch. Throwing it opens the hidden door in the central room. Throwing the switch makes a large
amount of noise and takes a DC15 check to pass. There is a hidden trap switch on the main switch (DC15 to
spot/interact). If not disabled, will make the stairs down to this chamber smooth (DC15 acrobatics to move up).

Can re-interact with the switch to raise stairs again.

Interacting with the switch will cause animated armor and swords in the room to attack the players. Armor is near the
switch, while swords start on the other side of the chasm. Swords might start at lower initiative depending on how
players handle things.

#### Forward Room: (locked by switch)(boss)(treasure)(trap)

Boss encounter for this level: ogre page 237

He has been trying to find access into the crypt but can't open the elven door in the wall and has been stuck for days in
the keep. Probably can't talk way out of fight, watch damage output. Modulate HP to make this harder as needed.

(Ogre has a knapsack in one corner with treasure he has looted from the keep.
4 statues in the center (one destroyed) all blast lines of fire (20ft, 1D6 +2, DC15 reflex) when non-elves walk in front of
them. These statues guard the entrance to the tomb. The ogre has destroyed one that already got in his way.

The statues can be disabled (arcana / thieves tool) and looted to take their elven crystals (worth 100g each).

Disabling all four statues also reveals a hidden chamber with loot inside. The chamber could be located normally (DC20)
but isn't likely.

Add random encounters as fit and time allows as they explore the first level. This is a former drow (elven) temple, so
spider /watchful theme and have spider encounters as well. MM 328 for spiders. Add webbing complications and holes
in walls for spider areas. (webbing: DC15str check or prone/restrained)

Piercers

Loot: refer to DM 137 XR 133

# Conjure Fey Creatures

    **Created:** 2021-10-29 11:27:48  
    **Last Edited:** 2021-10-29 11:27:52  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Roll a D100 to determine which creature is summoned from the Fey Wilds:

Night Hag [0-4

Green Hag | 5-9

Annis Hag | 10-14

Redcap [15-19

Catobelpas | 20-26]

Gorgon | 27-38

Tincalli | 39-45

Chimera | 46-52

Fey Mammoth 53-60

Fey Giant Ape (reduce stats slightly) | 61-66,

Dire Displacer Beast Gazz

Fey Triceratops 74-80

Chibi Eladrin - Autumn | 80-84

Chibi Eladrin- Spring | 85-89

Chibi Eladrin - Summer | 90-94

Chibi Eladrin- winter | 95-100

Change Eladrin stats as follows:
AC: 16

HP: 100

Attack +Hit Ratin
No Presence effect

Buff Dire Displacer Beast - +4 AC
100HP
Four Attacks

#### ChatGPT Output:
Roll a D100 to determine which creature is summoned from the Fey Wilds:

- Night Hag | 0-4
- Green Hag | 5-9
- Annis Hag | 10-14
- Redcap | 15-19
- Catoblepas | 20-26
- Gorgon | 27-38
- Tincalli | 39-45
- Chimera | 46-52
- Fey Mammoth | 53-60
- Fey Giant Ape (reduce stats slightly) | 61-66
- Dire Displacer Beast | 67-73
- Fey Triceratops | 74-80
- Chibi Eladrin - Autumn | 81-84
- Chibi Eladrin - Spring | 85-89
- Chibi Eladrin - Summer | 90-94
- Chibi Eladrin - Winter | 95-100

Change Eladrin stats as follows:
- AC: 16
- HP: 100
- Attack + Hit Rating
- No Presence effect

Buff Dire Displacer Beast:
- +4 AC
- 100HP
- Four Attacks

# Shadows Fall - Spells

    **Created:** 2021-10-29 11:17:47  
    **Last Edited:** 2021-10-29 11:17:57  
    **Labels:** D&D 2018, 2019  

    ---

    
    ## Attachments

### Attachment 1

#### Raw OCR Output:
Ray Of Enfeeblement
2necromancy

‘Casting Time: 1 action
Range: 60 feet
‘Components: VS
Duration: Up to 1 minute
Classes: Warlock, Wizard

A black beam of enervating energy springs from your finger toward a creature within range. Make a ranged spell attack
against the target. On a hit, the target deals only half damage with weapon attacks that use Strength until the spell ends.
‘At the end of each of the target’s tums, it can make a Constitution saving throw against the spell. On a success, the spell
ends.

From <https://roll20.net/compendium /éndSe/Spells:Ray%s2001%20Enfeeblementih-Ray%s2001%20Enfeeblement>

Darkness
evocation

Casting Time: 1 action
0 feet

Range:
‘Components: V M (Bat fur and a drop of pitch or piece of coal)

Duration: Up to 10 minutes

Classes: Sorcerer, Warlock, Wizard

Magical darkness spreads from a point you choose within range to fill a 15-foot-radius sphere for the duration. The
darkness spreads around corners. A creature with darkvision can’t see through this darkness, and nonmagical light can’t
illuminate it.

Ifthe point you choose is on an object you are holding or one that isn’t being worn or carried, the darkness emanates
from the object and moves with it. Completely covering the source of the darkness with an opaque object, such as a
bowl ora helm, blocks the darkness.

If any of this spell’s area overlaps with an area of light created by a spell of 2nd level or lower, the spell that created the
light is dispelled.

From <https://roll20.net/compendium /énd5e/Darknessih-Darkness>

#### ChatGPT Output:
### Ray Of Enfeeblement
**School**: Necromancy  
**Level**: 2  

**Casting Time**: 1 action  
**Range**: 60 feet  
**Components**: V, S  
**Duration**: Up to 1 minute  
**Classes**: Warlock, Wizard  

A black beam of enervating energy springs from your finger toward a creature within range. Make a ranged spell attack against the target. On a hit, the target deals only half damage with weapon attacks that use Strength until the spell ends. At the end of each of the target’s turns, it can make a Constitution saving throw against the spell. On a success, the spell ends.

[More Info](https://roll20.net/compendium/dnd5e/Spells:Ray%20Of%20Enfeeblement)

### Darkness
**School**: Evocation  

**Casting Time**: 1 action  
**Range**: 0 feet  
**Components**: V, M (Bat fur and a drop of pitch or piece of coal)  
**Duration**: Up to 10 minutes  
**Classes**: Sorcerer, Warlock, Wizard  

Magical darkness spreads from a point you choose within range to fill a 15-foot-radius sphere for the duration. The darkness spreads around corners. A creature with darkvision can’t see through this darkness, and nonmagical light can’t illuminate it.

If the point you choose is on an object you are holding or one that isn’t being worn or carried, the darkness emanates from the object and moves with it. Completely covering the source of the darkness with an opaque object, such as a bowl or a helm, blocks the darkness.

If any of this spell’s area overlaps with an area of light created by a spell of 2nd level or lower, the spell that created the light is dispelled.

[More Info](https://roll20.net/compendium/dnd5e/Darkness)